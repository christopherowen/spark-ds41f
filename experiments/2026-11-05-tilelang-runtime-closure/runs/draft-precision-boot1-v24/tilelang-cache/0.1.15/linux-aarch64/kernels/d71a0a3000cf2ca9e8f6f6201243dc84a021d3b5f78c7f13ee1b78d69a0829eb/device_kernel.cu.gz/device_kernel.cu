#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void markov_anchor_embed_kernel(bfloat16_t* __restrict__ confidence_out, const int* __restrict__ ids, const int64_t* __restrict__ index, bfloat16_t* __restrict__ step_out, const bfloat16_t* __restrict__ table, int64_t confidence_stride, int rows, int64_t step_stride, int table_rows);
extern "C" __global__ void __launch_bounds__(32, 1) markov_anchor_embed_kernel(bfloat16_t* __restrict__ confidence_out, const int* __restrict__ ids, const int64_t* __restrict__ index, bfloat16_t* __restrict__ step_out, const bfloat16_t* __restrict__ table, int64_t confidence_stride, int rows, int64_t step_stride, int table_rows) {
  int64_t token = (int64_t)0;
  token = ((int64_t)ids[index[((int64_t)((int)blockIdx.x))]]);
  int64_t token_1 = token;
  for (int v = 0; v < 8; ++v) {
    step_out[(((((int64_t)((int)threadIdx.x)) * (int64_t)8) + (((int64_t)((int)blockIdx.x)) * step_stride)) + ((int64_t)v))] = table[(((max(min(token_1, (((int64_t)table_rows) - (int64_t)1)), (int64_t)0) * (int64_t)256) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)) + ((int64_t)v))];
  }
  for (int v_1 = 0; v_1 < 8; ++v_1) {
    confidence_out[(((((int64_t)((int)threadIdx.x)) * (int64_t)8) + (((int64_t)((int)blockIdx.x)) * confidence_stride)) + ((int64_t)v_1))] = table[(((max(min(token_1, (((int64_t)table_rows) - (int64_t)1)), (int64_t)0) * (int64_t)256) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)) + ((int64_t)v_1))];
  }
}

