// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* dspark_confidence_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_dspark_confidence(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_dspark_confidence(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[11];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "dspark_confidence: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dspark_confidence: args pointer is NULL");
    return -1;
  }
  int32_t h_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((h_handle_type_index == 0) || (h_handle_type_index == 4)) || (h_handle_type_index == 7)) || (64 <= h_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input h expected pointer or tensor handle");
    return -1;
  }
  int32_t e_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((e_handle_type_index == 0) || (e_handle_type_index == 4)) || (e_handle_type_index == 7)) || (64 <= e_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input e expected pointer or tensor handle");
    return -1;
  }
  int32_t weight_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((weight_handle_type_index == 0) || (weight_handle_type_index == 4)) || (weight_handle_type_index == 7)) || (64 <= weight_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input weight expected pointer or tensor handle");
    return -1;
  }
  int32_t out_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((out_handle_type_index == 0) || (out_handle_type_index == 4)) || (out_handle_type_index == 7)) || (64 <= out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input out expected pointer or tensor handle");
    return -1;
  }
  void* h_handle = ((h_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* e_handle = ((e_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* weight_handle = ((weight_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* out_handle = ((out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool dspark_confidence_h_is_null = (h_handle == NULL);
  if (!(!dspark_confidence_h_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dspark_confidence.h is expected to have non-NULL pointer");
    return -1;
  }
  bool dspark_confidence_e_is_null = (e_handle == NULL);
  if (!(!dspark_confidence_e_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dspark_confidence.e is expected to have non-NULL pointer");
    return -1;
  }
  bool dspark_confidence_weight_is_null = (weight_handle == NULL);
  if (!(!dspark_confidence_weight_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dspark_confidence.weight is expected to have non-NULL pointer");
    return -1;
  }
  bool dspark_confidence_out_is_null = (out_handle == NULL);
  if (!(!dspark_confidence_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dspark_confidence.out is expected to have non-NULL pointer");
    return -1;
  }
  void* dspark_confidence_h_shape = (((DLTensor*)h_handle)[0].shape);
  void* dspark_confidence_e_shape = (((DLTensor*)e_handle)[0].shape);
  void* dspark_confidence_weight_shape = (((DLTensor*)weight_handle)[0].shape);
  void* dspark_confidence_out_shape = (((DLTensor*)out_handle)[0].shape);
  if (!(((((DLTensor*)h_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input h ndim mismatch, expected 2", (long long)((((DLTensor*)h_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: dspark_confidence.h, dspark_confidence.e, dspark_confidence.out");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)dspark_confidence_h_shape)[0]);
  void* dspark_confidence_h_strides = (((DLTensor*)h_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)h_handle)[0].device.device_id);
  void* h = (((DLTensor*)h_handle)[0].data);
  if (!(((((DLTensor*)e_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input e ndim mismatch, expected 2", (long long)((((DLTensor*)e_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dspark_confidence_e_strides = (((DLTensor*)e_handle)[0].strides);
  void* e = (((DLTensor*)e_handle)[0].data);
  if (!(((((DLTensor*)weight_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input weight ndim mismatch, expected 1", (long long)((((DLTensor*)weight_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dspark_confidence_weight_strides = (((DLTensor*)weight_handle)[0].strides);
  void* weight = (((DLTensor*)weight_handle)[0].data);
  if (!(((((DLTensor*)out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input out ndim mismatch, expected 1", (long long)((((DLTensor*)out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dspark_confidence_out_strides = (((DLTensor*)out_handle)[0].strides);
  void* out = (((DLTensor*)out_handle)[0].data);
  if (!(((((((DLTensor*)h_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)h_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)h_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input h dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dspark_confidence_h_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input h shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dspark_confidence_h_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((dspark_confidence_h_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)dspark_confidence_h_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((dspark_confidence_h_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)dspark_confidence_h_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input h strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((dspark_confidence_h_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)dspark_confidence_h_strides)[0]);
  }
  if (!(((condval_2 == 5120) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input h strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)h_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input h byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)h_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)h_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input h device_type mismatch, expected cuda", (long long)((((DLTensor*)h_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(h == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input h data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)e_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)e_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)e_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input e dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dspark_confidence_h_shape)[0]) == ((int32_t)((int64_t*)dspark_confidence_e_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input e shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dspark_confidence_h_shape)[0])), (long long)(((int32_t)((int64_t*)dspark_confidence_e_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dspark_confidence_e_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input e shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dspark_confidence_e_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((dspark_confidence_e_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)dspark_confidence_e_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((dspark_confidence_e_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)dspark_confidence_e_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input e strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((dspark_confidence_e_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)dspark_confidence_e_strides)[0]);
  }
  if (!(((condval_5 == 256) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input e strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)e_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input e byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)e_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)e_handle)[0].device.device_id) == (((DLTensor*)h_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input e device_id violates packed ABI constraint", (long long)((((DLTensor*)e_handle)[0].device.device_id)), (long long)((((DLTensor*)h_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)e_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input e device_type mismatch, expected cuda", (long long)((((DLTensor*)e_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(e == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input e data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)weight_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)weight_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)weight_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input weight dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dspark_confidence_weight_shape)[0]) == 5376))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input weight shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dspark_confidence_weight_shape)[0])), (long long)(5376));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((dspark_confidence_weight_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)dspark_confidence_weight_strides)[0]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((dspark_confidence_weight_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)dspark_confidence_weight_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input weight strides[0] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)weight_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input weight byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)weight_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)weight_handle)[0].device.device_id) == (((DLTensor*)h_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input weight device_id violates packed ABI constraint", (long long)((((DLTensor*)weight_handle)[0].device.device_id)), (long long)((((DLTensor*)h_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)weight_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input weight device_type mismatch, expected cuda", (long long)((((DLTensor*)weight_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(weight == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input weight data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)out_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input out dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dspark_confidence_h_shape)[0]) == ((int32_t)((int64_t*)dspark_confidence_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dspark_confidence_h_shape)[0])), (long long)(((int32_t)((int64_t*)dspark_confidence_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((dspark_confidence_out_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)dspark_confidence_out_strides)[0]);
  }
  if (!(((condval_8 == 1) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_id) == (((DLTensor*)h_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input out device_id violates packed ABI constraint", (long long)((((DLTensor*)out_handle)[0].device.device_id)), (long long)((((DLTensor*)h_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dspark_confidence input out device_type mismatch, expected cuda", (long long)((((DLTensor*)out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dspark_confidence input out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (e == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = e;
  if (h == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = h;
  if (out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = out;
  if (weight == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = weight;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)16);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = (int64_t)0;
  if (dspark_confidence_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "dspark_confidence_kernel", &dspark_confidence_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(dspark_confidence_kernel_packed, (TVMFFIAny*) stack_ffi_any, 10, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_dspark_confidence(self, args, num_args, result);
}
