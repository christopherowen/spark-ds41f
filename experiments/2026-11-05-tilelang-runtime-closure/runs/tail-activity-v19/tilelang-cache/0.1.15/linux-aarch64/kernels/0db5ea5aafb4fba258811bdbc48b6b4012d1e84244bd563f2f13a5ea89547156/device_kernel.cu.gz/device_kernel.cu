
__device__ __forceinline__ unsigned vllm_tail_div(
    unsigned n, unsigned d, unsigned magic) {
  if (d == 1) return n;
  unsigned q = __umulhi(n, magic);
  return q - (static_cast<unsigned long long>(q) * d > n);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_rows_bytes_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int output_units, uint row_magic, int row_units, int rows, int source_units, uint span_magic, int world);
extern "C" __global__ void __launch_bounds__(256, 1) collectives_rank_rows_bytes_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int output_units, uint row_magic, int row_units, int rows, int source_units, uint span_magic, int world) {
  if (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) < output_units) {
    uint row = vllm_tail_div(((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))), (((uint)world) * ((uint)row_units)), span_magic);
    uint rank = vllm_tail_div((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))), ((uint)row_units), row_magic);
    ushort condval;
    if (((((((rank * ((uint)rows)) + row) * ((uint)row_units)) + ((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))) - (rank * ((uint)row_units)))) < ((uint)source_units)) && ((uint)0 <= ((((rank * ((uint)rows)) + row) * ((uint)row_units)) + ((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))) - (rank * ((uint)row_units))))))) {
      condval = src[((((rank * ((uint)rows)) + row) * ((uint)row_units)) + ((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))) - (rank * ((uint)row_units))))];
    } else {
      condval = (ushort)0;
    }
    dst[((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x)))] = condval;
  }
}

