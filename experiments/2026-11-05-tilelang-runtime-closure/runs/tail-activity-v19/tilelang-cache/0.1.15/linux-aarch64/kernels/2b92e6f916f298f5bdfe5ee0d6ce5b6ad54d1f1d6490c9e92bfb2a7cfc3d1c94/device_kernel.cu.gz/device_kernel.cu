#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void copy_logits_kernel(float* __restrict__ dst, const half_t* __restrict__ src, int cols, int row_stride, int rows);
extern "C" __global__ void __launch_bounds__(256, 1) copy_logits_kernel(float* __restrict__ dst, const half_t* __restrict__ src, int cols, int row_stride, int rows) {
  if ((((((int)blockIdx.x) * 1024) + (((int)threadIdx.x) * 4)) + 4) <= cols) {
    {
      half_t src_local_cast_1[4];
      float dst_local_cast[4];
      *(uint2*)(src_local_cast_1 + 0) = *(uint2*)(src + (((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + (((int64_t)((int)blockIdx.y)) * ((int64_t)row_stride))));
      float4 __1;
      uint2 v_ = *(uint2*)(src_local_cast_1 + 0);
      ((float2*)(&__1))[0] = __half22float2(((half2*)(&v_))[0]);
      ((float2*)(&__1))[1] = __half22float2(((half2*)(&v_))[1]);
      *(float4*)(dst_local_cast + 0) = __1;
      *(float4*)(dst + (((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + (((int64_t)((int)blockIdx.y)) * ((int64_t)cols)))) = *(float4*)(dst_local_cast + 0);
    }
  }
}

