#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_rows_bytes_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int output_units, int row_units, int rows, int source_units, int world);
extern "C" __global__ void __launch_bounds__(256, 1) collectives_rank_rows_bytes_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int output_units, int row_units, int rows, int source_units, int world) {
  if (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) < output_units) {
    int rmod = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rmod_1 = (((((0 <= (world * row_units)) && (0 <= rmod)) || (((world * row_units) < 0) && (rmod <= 0))) ? rmod : (rmod + (world * row_units))) % row_units);
    int rmod_2 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rdiv = (((((0 <= (world * row_units)) && (0 <= rmod_2)) || (((world * row_units) < 0) && (rmod_2 <= 0))) ? rmod_2 : (rmod_2 + (world * row_units))) / row_units);
    int rmod_3 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rdiv_1 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / (world * row_units));
    int rmod_4 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rmod_5 = (((((0 <= (world * row_units)) && (0 <= rmod_4)) || (((world * row_units) < 0) && (rmod_4 <= 0))) ? rmod_4 : (rmod_4 + (world * row_units))) % row_units);
    int rmod_6 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rmod_7 = (((((0 <= (world * row_units)) && (0 <= rmod_6)) || (((world * row_units) < 0) && (rmod_6 <= 0))) ? rmod_6 : (rmod_6 + (world * row_units))) % row_units);
    int rmod_8 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rdiv_2 = (((((0 <= (world * row_units)) && (0 <= rmod_8)) || (((world * row_units) < 0) && (rmod_8 <= 0))) ? rmod_8 : (rmod_8 + (world * row_units))) / row_units);
    int rmod_9 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rdiv_3 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / (world * row_units));
    int rmod_10 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % (world * row_units));
    int rmod_11 = (((((0 <= (world * row_units)) && (0 <= rmod_10)) || (((world * row_units) < 0) && (rmod_10 <= 0))) ? rmod_10 : (rmod_10 + (world * row_units))) % row_units);
    ushort condval;
    if (((0 <= ((((((((0 <= row_units) && (0 <= rmod_1)) || ((row_units < 0) && (rmod_1 <= 0))) ? rdiv : (rdiv - 1)) * rows) + ((((0 <= (world * row_units)) && (0 <= rmod_3)) || (((world * row_units) < 0) && (rmod_3 <= 0))) ? rdiv_1 : (rdiv_1 - 1))) * row_units) + ((((0 <= row_units) && (0 <= rmod_5)) || ((row_units < 0) && (rmod_5 <= 0))) ? rmod_5 : (rmod_5 + row_units)))) && (((((((((0 <= row_units) && (0 <= rmod_7)) || ((row_units < 0) && (rmod_7 <= 0))) ? rdiv_2 : (rdiv_2 - 1)) * rows) + ((((0 <= (world * row_units)) && (0 <= rmod_9)) || (((world * row_units) < 0) && (rmod_9 <= 0))) ? rdiv_3 : (rdiv_3 - 1))) * row_units) + ((((0 <= row_units) && (0 <= rmod_11)) || ((row_units < 0) && (rmod_11 <= 0))) ? rmod_11 : (rmod_11 + row_units))) < source_units))) {
      int64_t rmod_12 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rmod_13 = ((((((int64_t)0 <= (((int64_t)world) * ((int64_t)row_units))) && ((int64_t)0 <= rmod_12)) || (((((int64_t)world) * ((int64_t)row_units)) < (int64_t)0) && (rmod_12 <= (int64_t)0))) ? rmod_12 : (rmod_12 + (((int64_t)world) * ((int64_t)row_units)))) % ((int64_t)row_units));
      int64_t rmod_14 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rdiv_4 = ((((((int64_t)0 <= (((int64_t)world) * ((int64_t)row_units))) && ((int64_t)0 <= rmod_14)) || (((((int64_t)world) * ((int64_t)row_units)) < (int64_t)0) && (rmod_14 <= (int64_t)0))) ? rmod_14 : (rmod_14 + (((int64_t)world) * ((int64_t)row_units)))) / ((int64_t)row_units));
      int64_t rmod_15 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rdiv_5 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) / (((int64_t)world) * ((int64_t)row_units)));
      int64_t rmod_16 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rmod_17 = ((((((int64_t)0 <= (((int64_t)world) * ((int64_t)row_units))) && ((int64_t)0 <= rmod_16)) || (((((int64_t)world) * ((int64_t)row_units)) < (int64_t)0) && (rmod_16 <= (int64_t)0))) ? rmod_16 : (rmod_16 + (((int64_t)world) * ((int64_t)row_units)))) % ((int64_t)row_units));
      int64_t rmod_18 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rmod_19 = ((((((int64_t)0 <= (((int64_t)world) * ((int64_t)row_units))) && ((int64_t)0 <= rmod_18)) || (((((int64_t)world) * ((int64_t)row_units)) < (int64_t)0) && (rmod_18 <= (int64_t)0))) ? rmod_18 : (rmod_18 + (((int64_t)world) * ((int64_t)row_units)))) % ((int64_t)row_units));
      int64_t rmod_20 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rdiv_6 = ((((((int64_t)0 <= (((int64_t)world) * ((int64_t)row_units))) && ((int64_t)0 <= rmod_20)) || (((((int64_t)world) * ((int64_t)row_units)) < (int64_t)0) && (rmod_20 <= (int64_t)0))) ? rmod_20 : (rmod_20 + (((int64_t)world) * ((int64_t)row_units)))) / ((int64_t)row_units));
      int64_t rmod_21 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rdiv_7 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) / (((int64_t)world) * ((int64_t)row_units)));
      int64_t rmod_22 = (((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) % (((int64_t)world) * ((int64_t)row_units)));
      int64_t rmod_23 = ((((((int64_t)0 <= (((int64_t)world) * ((int64_t)row_units))) && ((int64_t)0 <= rmod_22)) || (((((int64_t)world) * ((int64_t)row_units)) < (int64_t)0) && (rmod_22 <= (int64_t)0))) ? rmod_22 : (rmod_22 + (((int64_t)world) * ((int64_t)row_units)))) % ((int64_t)row_units));
      condval = src[(((((((((int64_t)0 <= ((int64_t)row_units)) && ((int64_t)0 <= rmod_19)) || ((((int64_t)row_units) < (int64_t)0) && (rmod_19 <= (int64_t)0))) ? rdiv_6 : (rdiv_6 - (int64_t)1)) * ((int64_t)rows)) + (((((int64_t)0 <= (((int64_t)world) * ((int64_t)row_units))) && ((int64_t)0 <= rmod_21)) || (((((int64_t)world) * ((int64_t)row_units)) < (int64_t)0) && (rmod_21 <= (int64_t)0))) ? rdiv_7 : (rdiv_7 - (int64_t)1))) * ((int64_t)row_units)) + (((((int64_t)0 <= ((int64_t)row_units)) && ((int64_t)0 <= rmod_23)) || ((((int64_t)row_units) < (int64_t)0) && (rmod_23 <= (int64_t)0))) ? rmod_23 : (rmod_23 + ((int64_t)row_units))))];
    } else {
      condval = (ushort)0;
    }
    dst[((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x)))] = condval;
  }
}

