// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* copy_logits_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_copy_logits(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_copy_logits(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[11];
  void* stack_ffi_any = stack;
  if (!((num_args == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "copy_logits: num_args should be 2", (long long)(num_args), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "copy_logits: args pointer is NULL");
    return -1;
  }
  int32_t src_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((src_handle_type_index == 0) || (src_handle_type_index == 4)) || (src_handle_type_index == 7)) || (64 <= src_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input src expected pointer or tensor handle");
    return -1;
  }
  int32_t dst_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((dst_handle_type_index == 0) || (dst_handle_type_index == 4)) || (dst_handle_type_index == 7)) || (64 <= dst_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input dst expected pointer or tensor handle");
    return -1;
  }
  void* src_handle = ((src_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* dst_handle = ((dst_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  bool copy_logits_src_is_null = (src_handle == NULL);
  if (!(!copy_logits_src_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "copy_logits.src is expected to have non-NULL pointer");
    return -1;
  }
  bool copy_logits_dst_is_null = (dst_handle == NULL);
  if (!(!copy_logits_dst_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "copy_logits.dst is expected to have non-NULL pointer");
    return -1;
  }
  void* copy_logits_src_shape = (((DLTensor*)src_handle)[0].shape);
  void* copy_logits_dst_shape = (((DLTensor*)dst_handle)[0].shape);
  if (!(((((DLTensor*)src_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input src ndim mismatch, expected 2", (long long)((((DLTensor*)src_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: copy_logits.src, copy_logits.dst");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)copy_logits_src_shape)[0]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable cols requires at least one non-null buffer among: copy_logits.src, copy_logits.dst");
    return -1;
  }
  int32_t cols = ((int32_t)((int64_t*)copy_logits_src_shape)[1]);
  void* copy_logits_src_strides = (((DLTensor*)src_handle)[0].strides);
  int32_t condval;
  if ((copy_logits_src_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)copy_logits_src_strides)[0]);
  }
  int32_t row_stride = condval;
  int32_t dev_id = (((DLTensor*)src_handle)[0].device.device_id);
  void* src = (((DLTensor*)src_handle)[0].data);
  if (!(((((DLTensor*)dst_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input dst ndim mismatch, expected 2", (long long)((((DLTensor*)dst_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* copy_logits_dst_strides = (((DLTensor*)dst_handle)[0].strides);
  void* dst = (((DLTensor*)dst_handle)[0].data);
  if (!(((((((DLTensor*)src_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)src_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)src_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input src dtype mismatch, expected bfloat16");
    return -1;
  }
  int32_t condval_1;
  if ((copy_logits_src_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)copy_logits_src_strides)[1]);
  }
  if (!(((condval_1 == 1) || (cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input src strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)src_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)src_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)src_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input src device_type mismatch, expected cuda", (long long)((((DLTensor*)src_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (cols == 0)) || !(src == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)dst_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)dst_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)dst_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input dst dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)copy_logits_src_shape)[0]) == ((int32_t)((int64_t*)copy_logits_dst_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input dst shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)copy_logits_src_shape)[0])), (long long)(((int32_t)((int64_t*)copy_logits_dst_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)copy_logits_src_shape)[1]) == ((int32_t)((int64_t*)copy_logits_dst_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input dst shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)copy_logits_src_shape)[1])), (long long)(((int32_t)((int64_t*)copy_logits_dst_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((copy_logits_dst_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)copy_logits_dst_strides)[1]);
  }
  if (!(((condval_2 == 1) || (cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input dst strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_3;
  if ((copy_logits_dst_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)copy_logits_dst_strides)[0]);
  }
  if (!((((((int32_t)((int64_t*)copy_logits_src_shape)[1]) == condval_3) || (((int32_t)((int64_t*)copy_logits_src_shape)[1]) == 0)) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input dst strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)dst_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input dst byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)dst_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)dst_handle)[0].device.device_id) == (((DLTensor*)src_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input dst device_id violates packed ABI constraint", (long long)((((DLTensor*)dst_handle)[0].device.device_id)), (long long)((((DLTensor*)src_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)dst_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel copy_logits input dst device_type mismatch, expected cuda", (long long)((((DLTensor*)dst_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (cols == 0)) || !(dst == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel copy_logits input dst data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (!(((row_stride % 4) == 0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: row_stride % 4 == 0", (long long)((row_stride % 4)), (long long)(0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((cols % 4) == 0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: cols % 4 == 0", (long long)((cols % 4)), (long long)(0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (dst == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = dst;
  if (src == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = src;
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)cols);
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)row_stride);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)((cols + 1023) >> 10));
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = (int64_t)0;
  if (copy_logits_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "copy_logits_kernel", &copy_logits_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(copy_logits_kernel_packed, (TVMFFIAny*) stack_ffi_any, 10, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_copy_logits(self, args, num_args, result);
}
