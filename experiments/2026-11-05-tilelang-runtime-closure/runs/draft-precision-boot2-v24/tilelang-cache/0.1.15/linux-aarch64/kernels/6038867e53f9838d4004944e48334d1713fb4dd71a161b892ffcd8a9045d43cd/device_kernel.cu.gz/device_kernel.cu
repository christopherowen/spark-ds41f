#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void dspark_confidence_kernel(const bfloat16_t* __restrict__ e, const bfloat16_t* __restrict__ h, float* __restrict__ out, const float* __restrict__ weight, int rows);
extern "C" __global__ void __launch_bounds__(128, 1) dspark_confidence_kernel(const bfloat16_t* __restrict__ e, const bfloat16_t* __restrict__ h, float* __restrict__ out, const float* __restrict__ weight, int rows) {
  bfloat16_t xs[48];
  float ws[48];
  float acc[8];
  extern __shared__ __align__(1024) float partial[];
  float total[1];
  #pragma unroll
  for (int c = 0; c < 5; ++c) {
    *(uint4*)(xs + (c * 8)) = *(uint4*)(h + (((((int64_t)((int)blockIdx.x)) * (int64_t)5120) + (((int64_t)c) * (int64_t)1024)) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    *(float4*)(ws + (c * 8)) = *(float4*)(weight + ((c * 1024) + (((int)threadIdx.x) * 8)));
    *(float4*)(ws + ((c * 8) + 4)) = *(float4*)(weight + (((c * 1024) + (((int)threadIdx.x) * 8)) + 4));
  }
  if (((int)threadIdx.x) < 32) {
    *(uint4*)(xs + 40) = *(uint4*)(e + ((((int64_t)((int)blockIdx.x)) * (int64_t)256) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    *(float4*)(ws + 40) = *(float4*)(weight + ((((int)threadIdx.x) * 8) + 5120));
    *(float4*)(ws + 44) = *(float4*)(weight + ((((int)threadIdx.x) * 8) + 5124));
  } else {
    bfloat16_t broadcast_var = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    *(uint4*)(xs + 40) = make_uint4(__pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var));
    for (int i = 0; i < 2; ++i) {
      float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(ws + ((i * 4) + 40)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    }
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 8; ++i_1) {
    acc[i_1] = 0x0p+0f/*0.000000e+00*/;
  }
  #pragma unroll
  for (int c_1 = 0; c_1 < 6; ++c_1) {
    #pragma unroll
    for (int i_2 = 0; i_2 < 8; ++i_2) {
      acc[i_2] = (acc[i_2] + (((float)xs[((c_1 * 8) + i_2)]) * ws[((c_1 * 8) + i_2)]));
    }
  }
  #pragma unroll
  for (int i_3 = 0; i_3 < 4; ++i_3) {
    acc[i_3] = (acc[i_3] + acc[(i_3 + 4)]);
  }
  #pragma unroll
  for (int i_4 = 0; i_4 < 2; ++i_4) {
    acc[i_4] = (acc[i_4] + acc[(i_4 + 2)]);
  }
  acc[0] = (acc[0] + acc[1]);
  acc[0] = tl::warp_reduce_sum(acc[0]);
  if ((((int)threadIdx.x) % 32) == 0) {
    partial[(((int)threadIdx.x) >> 5)] = acc[0];
  }
  __syncthreads();
  if (((int)threadIdx.x) == 0) {
    total[0] = 0x0p+0f/*0.000000e+00*/;
    for (int warp = 0; warp < 4; ++warp) {
      total[0] = (total[0] + partial[warp]);
    }
    out[((int64_t)((int)blockIdx.x))] = (0x1p+0f/*1.000000e+00*/ / (0x1p+0f/*1.000000e+00*/ + expf((total[0] * -0x1p+0f/*-1.000000e+00*/))));
  }
}

