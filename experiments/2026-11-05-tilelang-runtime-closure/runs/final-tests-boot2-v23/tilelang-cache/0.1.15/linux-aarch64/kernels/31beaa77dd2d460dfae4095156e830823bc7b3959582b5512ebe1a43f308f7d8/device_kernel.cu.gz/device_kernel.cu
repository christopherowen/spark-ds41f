#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_spatial_merge_kernel(const bfloat16_t* __restrict__ x, bfloat16_t* __restrict__ y, int height, int merged, int width);
extern "C" __global__ void __launch_bounds__(256, 1) vision_spatial_merge_kernel(const bfloat16_t* __restrict__ x, bfloat16_t* __restrict__ y, int height, int merged, int width) {
  extern __shared__ __align__(1024) bfloat16_t tile[];
  bfloat16_t values[8];
  bfloat16_t gathered[8];
  #pragma unroll
  for (int step = 0; step < 5; ++step) {
    if (((step * 2) + (((int)threadIdx.x) >> 7)) < 9) {
      int rmod = (((int)blockIdx.x) % (((width + 2) / 3) + (((width + 2) % 3) >> 31)));
      int rdiv = (((int)blockIdx.x) / (((width + 2) / 3) + (((width + 2) % 3) >> 31)));
      int rmod_1 = (((int)blockIdx.x) % (((width + 2) / 3) + (((width + 2) % 3) >> 31)));
      if ((((((((0 <= (((width + 2) / 3) + (((width + 2) % 3) >> 31))) && (0 <= rmod)) || (((((width + 2) / 3) + (((width + 2) % 3) >> 31)) < 0) && (rmod <= 0))) ? rdiv : (rdiv - 1)) * 3) + (((step * 2) + (((int)threadIdx.x) >> 7)) / 3)) < height) & (((((((0 <= (((width + 2) / 3) + (((width + 2) % 3) >> 31))) && (0 <= rmod_1)) || (((((width + 2) / 3) + (((width + 2) % 3) >> 31)) < 0) && (rmod_1 <= 0))) ? rmod_1 : ((((width + 2) / 3) + rmod_1) + (((width + 2) % 3) >> 31))) * 3) + (((step * 2) + (((int)threadIdx.x) >> 7)) % 3)) < width)) {
        int64_t rmod_2 = (((int64_t)((int)blockIdx.x)) % (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)));
        int64_t rmod_3 = (((int64_t)((int)blockIdx.x)) % (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)));
        int64_t rdiv_1 = (((int64_t)((int)blockIdx.x)) / (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)));
        int64_t rmod_4 = (((int64_t)((int)blockIdx.x)) % (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)));
        int64_t rmod_5 = (((int64_t)((int)blockIdx.x)) % (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)));
        int64_t rdiv_2 = (((int64_t)((int)blockIdx.x)) / (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)));
        *(uint4*)(values + 0) = *(uint4*)(x + (((((((((int64_t)0 <= (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63))) && ((int64_t)0 <= rmod_4)) || (((((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)) < (int64_t)0) && (rmod_4 <= (int64_t)0))) ? rmod_4 : ((((((int64_t)width) + (int64_t)2) / (int64_t)3) + rmod_4) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63))) * (int64_t)3072) + (((((((((int64_t)0 <= (((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63))) && ((int64_t)0 <= rmod_5)) || (((((((int64_t)width) + (int64_t)2) / (int64_t)3) + (((((int64_t)width) + (int64_t)2) % (int64_t)3) >> (int64_t)63)) < (int64_t)0) && (rmod_5 <= (int64_t)0))) ? rdiv_2 : (rdiv_2 - (int64_t)1)) * (int64_t)3) + (((((int64_t)step) * (int64_t)2) + (((int64_t)((int)threadIdx.x)) >> (int64_t)7)) / (int64_t)3)) * ((int64_t)width)) * (int64_t)1024)) + ((((((int64_t)step) * (int64_t)2) + (((int64_t)((int)threadIdx.x)) >> (int64_t)7)) % (int64_t)3) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)127) * (int64_t)8)));
      } else {
        bfloat16_t broadcast_var = bfloat16_t(0x0p+0f/*0.000000e+00*/);
        *(uint4*)(values + 0) = make_uint4(__pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var));
      }
      *(uint4*)(tile + (((step * 2064) + ((((int)threadIdx.x) >> 7) * 1032)) + ((((int)threadIdx.x) & 127) * 8))) = *(uint4*)(values + 0);
    }
  }
  __syncthreads();
  #pragma unroll
  for (int step_1 = 0; step_1 < 5; ++step_1) {
    if (((step_1 * 2) + (((int)threadIdx.x) >> 7)) < 9) {
      #pragma unroll
      for (int v = 0; v < 8; ++v) {
        gathered[v] = tile[((((((step_1 * 2048) + (((int)threadIdx.x) * 8)) + v) % 9) * 1032) + ((((step_1 * 2048) + (((int)threadIdx.x) * 8)) + v) / 9))];
      }
      *(uint4*)(y + (((((int64_t)((int)blockIdx.x)) * (int64_t)9216) + (((int64_t)step_1) * (int64_t)2048)) + (((int64_t)((int)threadIdx.x)) * (int64_t)8))) = *(uint4*)(gathered + 0);
    }
  }
}

