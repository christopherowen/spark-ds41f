#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void fill_ids_kernel(const int* __restrict__ custom_ids, const int64_t* __restrict__ mapping, const int* __restrict__ num_custom, int64_t* __restrict__ output, const int64_t* __restrict__ sampled, const int* __restrict__ topk_ids, signed char* __restrict__ valid, int64_t custom_stride, int64_t mask_stride, int out_cols, int64_t output_stride, int rows, int topk, int64_t topk_stride);
extern "C" __global__ void __launch_bounds__(128, 1) fill_ids_kernel(const int* __restrict__ custom_ids, const int64_t* __restrict__ mapping, const int* __restrict__ num_custom, int64_t* __restrict__ output, const int64_t* __restrict__ sampled, const int* __restrict__ topk_ids, signed char* __restrict__ valid, int64_t custom_stride, int64_t mask_stride, int out_cols, int64_t output_stride, int rows, int topk, int64_t topk_stride) {
  int64_t req = mapping[((int64_t)((int)blockIdx.x))];
  if (((int)threadIdx.x) == 0) {
    output[(((int64_t)((int)blockIdx.x)) * output_stride)] = sampled[((int64_t)((int)blockIdx.x))];
    valid[(((int64_t)((int)blockIdx.x)) * mask_stride)] = (signed char)1;
  }
  for (int i = 0; i < ((out_cols + 126) >> 7); ++i) {
    if ((((i * 128) + ((int)threadIdx.x)) + 1) < out_cols) {
      if (0 < num_custom[req]) {
        if (((i * 128) + ((int)threadIdx.x)) < num_custom[req]) {
          output[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * output_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = ((int64_t)custom_ids[(((((int64_t)i) * (int64_t)128) + (req * custom_stride)) + ((int64_t)((int)threadIdx.x)))]);
          valid[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * mask_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = (signed char)1;
        } else {
          output[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * output_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = (int64_t)0;
          valid[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * mask_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = (signed char)0;
        }
      } else {
        if (((i * 128) + ((int)threadIdx.x)) < topk) {
          output[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * output_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = ((int64_t)topk_ids[(((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * topk_stride)) + ((int64_t)((int)threadIdx.x)))]);
          valid[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * mask_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = (signed char)1;
        } else {
          output[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * output_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = (int64_t)0;
          valid[((((((int64_t)i) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * mask_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1)] = (signed char)0;
        }
      }
    }
  }
}

