// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* fill_ids_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_fill_ids(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_fill_ids(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[19];
  void* stack_ffi_any = stack;
  if (!((num_args == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "fill_ids: num_args should be 8", (long long)(num_args), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids: args pointer is NULL");
    return -1;
  }
  int32_t output_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((output_handle_type_index == 0) || (output_handle_type_index == 4)) || (output_handle_type_index == 7)) || (64 <= output_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input output expected pointer or tensor handle");
    return -1;
  }
  int32_t valid_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((valid_handle_type_index == 0) || (valid_handle_type_index == 4)) || (valid_handle_type_index == 7)) || (64 <= valid_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input valid expected pointer or tensor handle");
    return -1;
  }
  int32_t sampled_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((sampled_handle_type_index == 0) || (sampled_handle_type_index == 4)) || (sampled_handle_type_index == 7)) || (64 <= sampled_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input sampled expected pointer or tensor handle");
    return -1;
  }
  int32_t topk_ids_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((topk_ids_handle_type_index == 0) || (topk_ids_handle_type_index == 4)) || (topk_ids_handle_type_index == 7)) || (64 <= topk_ids_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input topk_ids expected pointer or tensor handle");
    return -1;
  }
  int32_t mapping_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((mapping_handle_type_index == 0) || (mapping_handle_type_index == 4)) || (mapping_handle_type_index == 7)) || (64 <= mapping_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input mapping expected pointer or tensor handle");
    return -1;
  }
  int32_t num_custom_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((num_custom_handle_type_index == 0) || (num_custom_handle_type_index == 4)) || (num_custom_handle_type_index == 7)) || (64 <= num_custom_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input num_custom expected pointer or tensor handle");
    return -1;
  }
  int32_t custom_ids_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((custom_ids_handle_type_index == 0) || (custom_ids_handle_type_index == 4)) || (custom_ids_handle_type_index == 7)) || (64 <= custom_ids_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input custom_ids expected pointer or tensor handle");
    return -1;
  }
  int32_t topk_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((topk_type_index == 1) || (topk_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids scalar topk expected integer");
    return -1;
  }
  void* output_handle = ((output_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* valid_handle = ((valid_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* sampled_handle = ((sampled_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* topk_ids_handle = ((topk_ids_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* mapping_handle = ((mapping_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* num_custom_handle = ((num_custom_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* custom_ids_handle = ((custom_ids_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  int32_t topk = ((int32_t)(((TVMFFIAny*)args)[7].v_int64));
  bool fill_ids_output_is_null = (output_handle == NULL);
  if (!(!fill_ids_output_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids.output is expected to have non-NULL pointer");
    return -1;
  }
  bool fill_ids_valid_is_null = (valid_handle == NULL);
  if (!(!fill_ids_valid_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids.valid is expected to have non-NULL pointer");
    return -1;
  }
  bool fill_ids_sampled_is_null = (sampled_handle == NULL);
  if (!(!fill_ids_sampled_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids.sampled is expected to have non-NULL pointer");
    return -1;
  }
  bool fill_ids_topk_ids_is_null = (topk_ids_handle == NULL);
  if (!(!fill_ids_topk_ids_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids.topk_ids is expected to have non-NULL pointer");
    return -1;
  }
  bool fill_ids_mapping_is_null = (mapping_handle == NULL);
  if (!(!fill_ids_mapping_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids.mapping is expected to have non-NULL pointer");
    return -1;
  }
  bool fill_ids_num_custom_is_null = (num_custom_handle == NULL);
  if (!(!fill_ids_num_custom_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids.num_custom is expected to have non-NULL pointer");
    return -1;
  }
  bool fill_ids_custom_ids_is_null = (custom_ids_handle == NULL);
  if (!(!fill_ids_custom_ids_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "fill_ids.custom_ids is expected to have non-NULL pointer");
    return -1;
  }
  void* fill_ids_output_shape = (((DLTensor*)output_handle)[0].shape);
  void* fill_ids_valid_shape = (((DLTensor*)valid_handle)[0].shape);
  void* fill_ids_sampled_shape = (((DLTensor*)sampled_handle)[0].shape);
  void* fill_ids_topk_ids_shape = (((DLTensor*)topk_ids_handle)[0].shape);
  void* fill_ids_mapping_shape = (((DLTensor*)mapping_handle)[0].shape);
  void* fill_ids_num_custom_shape = (((DLTensor*)num_custom_handle)[0].shape);
  void* fill_ids_custom_ids_shape = (((DLTensor*)custom_ids_handle)[0].shape);
  if (!(((((DLTensor*)output_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input output ndim mismatch, expected 2", (long long)((((DLTensor*)output_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: fill_ids.output, fill_ids.valid, fill_ids.sampled, fill_ids.mapping");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)fill_ids_output_shape)[0]);
  int32_t out_cols = ((int32_t)((int64_t*)fill_ids_output_shape)[1]);
  void* fill_ids_output_strides = (((DLTensor*)output_handle)[0].strides);
  int64_t condval;
  if ((fill_ids_output_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)fill_ids_output_strides)[0];
  }
  int64_t output_stride = condval;
  int32_t dev_id = (((DLTensor*)output_handle)[0].device.device_id);
  void* output = (((DLTensor*)output_handle)[0].data);
  if (!(((((DLTensor*)valid_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input valid ndim mismatch, expected 2", (long long)((((DLTensor*)valid_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t mask_cols = ((int32_t)((int64_t*)fill_ids_valid_shape)[1]);
  void* fill_ids_valid_strides = (((DLTensor*)valid_handle)[0].strides);
  int64_t condval_1;
  if ((fill_ids_valid_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)fill_ids_valid_strides)[0];
  }
  int64_t mask_stride = condval_1;
  void* valid = (((DLTensor*)valid_handle)[0].data);
  if (!(((((DLTensor*)sampled_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input sampled ndim mismatch, expected 1", (long long)((((DLTensor*)sampled_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* fill_ids_sampled_strides = (((DLTensor*)sampled_handle)[0].strides);
  void* sampled = (((DLTensor*)sampled_handle)[0].data);
  if (!(((((DLTensor*)topk_ids_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input topk_ids ndim mismatch, expected 2", (long long)((((DLTensor*)topk_ids_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t topk_rows = ((int32_t)((int64_t*)fill_ids_topk_ids_shape)[0]);
  int32_t topk_cols = ((int32_t)((int64_t*)fill_ids_topk_ids_shape)[1]);
  void* fill_ids_topk_ids_strides = (((DLTensor*)topk_ids_handle)[0].strides);
  int64_t condval_2;
  if ((fill_ids_topk_ids_strides == NULL)) {
    condval_2 = (int64_t)1;
  } else {
    condval_2 = ((int64_t*)fill_ids_topk_ids_strides)[0];
  }
  int64_t topk_stride = condval_2;
  void* topk_ids = (((DLTensor*)topk_ids_handle)[0].data);
  if (!(((((DLTensor*)mapping_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input mapping ndim mismatch, expected 1", (long long)((((DLTensor*)mapping_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* fill_ids_mapping_strides = (((DLTensor*)mapping_handle)[0].strides);
  void* mapping = (((DLTensor*)mapping_handle)[0].data);
  if (!(((((DLTensor*)num_custom_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input num_custom ndim mismatch, expected 1", (long long)((((DLTensor*)num_custom_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t states = ((int32_t)((int64_t*)fill_ids_num_custom_shape)[0]);
  void* fill_ids_num_custom_strides = (((DLTensor*)num_custom_handle)[0].strides);
  void* num_custom = (((DLTensor*)num_custom_handle)[0].data);
  if (!(((((DLTensor*)custom_ids_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input custom_ids ndim mismatch, expected 2", (long long)((((DLTensor*)custom_ids_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t custom_cols = ((int32_t)((int64_t*)fill_ids_custom_ids_shape)[1]);
  void* fill_ids_custom_ids_strides = (((DLTensor*)custom_ids_handle)[0].strides);
  int64_t condval_3;
  if ((fill_ids_custom_ids_strides == NULL)) {
    condval_3 = (int64_t)1;
  } else {
    condval_3 = ((int64_t*)fill_ids_custom_ids_strides)[0];
  }
  int64_t custom_stride = condval_3;
  void* custom_ids = (((DLTensor*)custom_ids_handle)[0].data);
  if (!(((((((DLTensor*)output_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)output_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)output_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input output dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_4;
  if ((fill_ids_output_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)fill_ids_output_strides)[1]);
  }
  if (!(((condval_4 == 1) || (out_cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input output strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)output_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input output byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)output_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input output device_type mismatch, expected cuda", (long long)((((DLTensor*)output_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (out_cols == 0)) || !(output == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input output data pointer is NULL");
    return -1;
  }
  if (!((((((((((((DLTensor*)valid_handle)[0].dtype.code) == (uint8_t)6) && ((((DLTensor*)valid_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)valid_handle)[0].dtype.lanes) == (uint16_t)1)) || ((((((DLTensor*)valid_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)valid_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)valid_handle)[0].dtype.lanes) == (uint16_t)1))) || ((((((DLTensor*)valid_handle)[0].dtype.code) == (uint8_t)1) && ((((DLTensor*)valid_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)valid_handle)[0].dtype.lanes) == (uint16_t)1))) || ((((((DLTensor*)valid_handle)[0].dtype.code) == (uint8_t)6) && ((((DLTensor*)valid_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)valid_handle)[0].dtype.lanes) == (uint16_t)1))) || ((((((DLTensor*)valid_handle)[0].dtype.code) == (uint8_t)6) && ((((DLTensor*)valid_handle)[0].dtype.bits) == (uint8_t)1)) && ((((DLTensor*)valid_handle)[0].dtype.lanes) == (uint16_t)1))) || (((((DLTensor*)valid_handle)[0].dtype.bits) == (uint8_t)1) && ((((DLTensor*)valid_handle)[0].dtype.lanes) == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input valid dtype mismatch, expected bool");
    return -1;
  }
  if (!((((int32_t)((int64_t*)fill_ids_output_shape)[0]) == ((int32_t)((int64_t*)fill_ids_valid_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input valid shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)fill_ids_output_shape)[0])), (long long)(((int32_t)((int64_t*)fill_ids_valid_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((fill_ids_valid_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)fill_ids_valid_strides)[1]);
  }
  if (!(((condval_5 == 1) || (mask_cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input valid strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)valid_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input valid byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)valid_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)valid_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input valid device_id violates packed ABI constraint", (long long)((((DLTensor*)valid_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)valid_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input valid device_type mismatch, expected cuda", (long long)((((DLTensor*)valid_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (mask_cols == 0)) || !(valid == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input valid data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)sampled_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)sampled_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)sampled_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input sampled dtype mismatch, expected int64");
    return -1;
  }
  if (!((((int32_t)((int64_t*)fill_ids_output_shape)[0]) == ((int32_t)((int64_t*)fill_ids_sampled_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input sampled shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)fill_ids_output_shape)[0])), (long long)(((int32_t)((int64_t*)fill_ids_sampled_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((fill_ids_sampled_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)fill_ids_sampled_strides)[0]);
  }
  if (!(((condval_6 == 1) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input sampled strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)sampled_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input sampled byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)sampled_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input sampled device_id violates packed ABI constraint", (long long)((((DLTensor*)sampled_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input sampled device_type mismatch, expected cuda", (long long)((((DLTensor*)sampled_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(sampled == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input sampled data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)topk_ids_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)topk_ids_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)topk_ids_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input topk_ids dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_7;
  if ((fill_ids_topk_ids_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)fill_ids_topk_ids_strides)[1]);
  }
  if (!(((condval_7 == 1) || (topk_cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input topk_ids strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)topk_ids_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input topk_ids byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)topk_ids_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)topk_ids_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input topk_ids device_id violates packed ABI constraint", (long long)((((DLTensor*)topk_ids_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)topk_ids_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input topk_ids device_type mismatch, expected cuda", (long long)((((DLTensor*)topk_ids_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((topk_rows == 0) || (topk_cols == 0)) || !(topk_ids == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input topk_ids data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)mapping_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)mapping_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)mapping_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input mapping dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)fill_ids_output_shape)[0]) == ((int32_t)((int64_t*)fill_ids_mapping_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input mapping shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)fill_ids_output_shape)[0])), (long long)(((int32_t)((int64_t*)fill_ids_mapping_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((fill_ids_mapping_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)fill_ids_mapping_strides)[0]);
  }
  if (!(((condval_8 == 1) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input mapping strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)mapping_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input mapping byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)mapping_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)mapping_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input mapping device_id violates packed ABI constraint", (long long)((((DLTensor*)mapping_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)mapping_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input mapping device_type mismatch, expected cuda", (long long)((((DLTensor*)mapping_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(mapping == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input mapping data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)num_custom_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)num_custom_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)num_custom_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input num_custom dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_9;
  if ((fill_ids_num_custom_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)fill_ids_num_custom_strides)[0]);
  }
  if (!(((condval_9 == 1) || (states == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input num_custom strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)num_custom_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input num_custom byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)num_custom_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)num_custom_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input num_custom device_id violates packed ABI constraint", (long long)((((DLTensor*)num_custom_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)num_custom_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input num_custom device_type mismatch, expected cuda", (long long)((((DLTensor*)num_custom_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((states == 0) || !(num_custom == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input num_custom data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)custom_ids_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)custom_ids_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)custom_ids_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input custom_ids dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)fill_ids_num_custom_shape)[0]) == ((int32_t)((int64_t*)fill_ids_custom_ids_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input custom_ids shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)fill_ids_num_custom_shape)[0])), (long long)(((int32_t)((int64_t*)fill_ids_custom_ids_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((fill_ids_custom_ids_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)fill_ids_custom_ids_strides)[1]);
  }
  if (!(((condval_10 == 1) || (custom_cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input custom_ids strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)custom_ids_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input custom_ids byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)custom_ids_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)custom_ids_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input custom_ids device_id violates packed ABI constraint", (long long)((((DLTensor*)custom_ids_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)custom_ids_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel fill_ids input custom_ids device_type mismatch, expected cuda", (long long)((((DLTensor*)custom_ids_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((states == 0) || (custom_cols == 0)) || !(custom_ids == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel fill_ids input custom_ids data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (custom_ids == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = custom_ids;
  if (mapping == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = mapping;
  if (num_custom == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = num_custom;
  if (output == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = output;
  if (sampled == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = sampled;
  if (topk_ids == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = topk_ids;
  if (valid == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = valid;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = custom_stride;
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = mask_stride;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)out_cols);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = output_stride;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)topk);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = topk_stride;
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = (int64_t)0;
  if (fill_ids_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "fill_ids_kernel", &fill_ids_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(fill_ids_kernel_packed, (TVMFFIAny*) stack_ffi_any, 18, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_fill_ids(self, args, num_args, result);
}
