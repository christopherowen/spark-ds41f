// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* collectives_rank_order_strided_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_collectives_rank_order_strided(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_collectives_rank_order_strided(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[58];
  void* stack_ffi_any = stack;
  if (!((num_args == 5))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "collectives_rank_order_strided: num_args should be 5", (long long)(num_args), (long long)(5));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_strided: args pointer is NULL");
    return -1;
  }
  int32_t s0_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((s0_handle_type_index == 0) || (s0_handle_type_index == 4)) || (s0_handle_type_index == 7)) || (64 <= s0_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input s0 expected pointer or tensor handle");
    return -1;
  }
  int32_t s1_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((s1_handle_type_index == 0) || (s1_handle_type_index == 4)) || (s1_handle_type_index == 7)) || (64 <= s1_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source expected pointer or tensor handle");
    return -1;
  }
  int32_t s2_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((s2_handle_type_index == 0) || (s2_handle_type_index == 4)) || (s2_handle_type_index == 7)) || (64 <= s2_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source expected pointer or tensor handle");
    return -1;
  }
  int32_t s3_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((s3_handle_type_index == 0) || (s3_handle_type_index == 4)) || (s3_handle_type_index == 7)) || (64 <= s3_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source expected pointer or tensor handle");
    return -1;
  }
  int32_t output_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((output_handle_type_index == 0) || (output_handle_type_index == 4)) || (output_handle_type_index == 7)) || (64 <= output_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input output expected pointer or tensor handle");
    return -1;
  }
  void* s0_handle = ((s0_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* s1_handle = ((s1_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* s2_handle = ((s2_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* s3_handle = ((s3_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* output_handle = ((output_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  bool collectives_rank_order_strided_s0_is_null = (s0_handle == NULL);
  if (!(!collectives_rank_order_strided_s0_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_strided.s0 is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_strided_source_is_null = (s1_handle == NULL);
  if (!(!collectives_rank_order_strided_source_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_strided.source is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_strided_source_is_null_1 = (s2_handle == NULL);
  if (!(!collectives_rank_order_strided_source_is_null_1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_strided.source is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_strided_source_is_null_2 = (s3_handle == NULL);
  if (!(!collectives_rank_order_strided_source_is_null_2)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_strided.source is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_strided_output_is_null = (output_handle == NULL);
  if (!(!collectives_rank_order_strided_output_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_strided.output is expected to have non-NULL pointer");
    return -1;
  }
  void* collectives_rank_order_strided_s0_shape = (((DLTensor*)s0_handle)[0].shape);
  void* collectives_rank_order_strided_source_shape = (((DLTensor*)s1_handle)[0].shape);
  void* collectives_rank_order_strided_source_shape_1 = (((DLTensor*)s2_handle)[0].shape);
  void* collectives_rank_order_strided_source_shape_2 = (((DLTensor*)s3_handle)[0].shape);
  void* collectives_rank_order_strided_output_shape = (((DLTensor*)output_handle)[0].shape);
  if (!(((((DLTensor*)s0_handle)[0].ndim) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input s0 ndim mismatch, expected 8", (long long)((((DLTensor*)s0_handle)[0].ndim)), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim0 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim0 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim1 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim1 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim2 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim2 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim3 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim3 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim4 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim4 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim5 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim5 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim6 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim6 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable dim7 requires at least one non-null buffer among: collectives_rank_order_strided.s0, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.source, collectives_rank_order_strided.output");
    return -1;
  }
  int32_t dim7 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7]);
  void* collectives_rank_order_strided_s0_strides = (((DLTensor*)s0_handle)[0].strides);
  int32_t condval;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[7]);
  }
  int32_t stride0_7 = condval;
  int32_t condval_1;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[6]);
  }
  int32_t stride0_6 = condval_1;
  int32_t condval_2;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[5]);
  }
  int32_t stride0_5 = condval_2;
  int32_t condval_3;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[4]);
  }
  int32_t stride0_4 = condval_3;
  int32_t condval_4;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[3]);
  }
  int32_t stride0_3 = condval_4;
  int32_t condval_5;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[2]);
  }
  int32_t stride0_2 = condval_5;
  int32_t condval_6;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[1]);
  }
  int32_t stride0_1 = condval_6;
  int32_t condval_7;
  if ((collectives_rank_order_strided_s0_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)collectives_rank_order_strided_s0_strides)[0]);
  }
  int32_t stride0_0 = condval_7;
  int32_t dev_id = (((DLTensor*)s0_handle)[0].device.device_id);
  void* s0 = (((DLTensor*)s0_handle)[0].data);
  if (!(((((DLTensor*)s1_handle)[0].ndim) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source ndim mismatch, expected 8", (long long)((((DLTensor*)s1_handle)[0].ndim)), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_strided_source_strides = (((DLTensor*)s1_handle)[0].strides);
  int32_t condval_8;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[7]);
  }
  int32_t stride1_7 = condval_8;
  int32_t condval_9;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[6]);
  }
  int32_t stride1_6 = condval_9;
  int32_t condval_10;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[5]);
  }
  int32_t stride1_5 = condval_10;
  int32_t condval_11;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[4]);
  }
  int32_t stride1_4 = condval_11;
  int32_t condval_12;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[3]);
  }
  int32_t stride1_3 = condval_12;
  int32_t condval_13;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[2]);
  }
  int32_t stride1_2 = condval_13;
  int32_t condval_14;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[1]);
  }
  int32_t stride1_1 = condval_14;
  int32_t condval_15;
  if ((collectives_rank_order_strided_source_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides)[0]);
  }
  int32_t stride1_0 = condval_15;
  void* source = (((DLTensor*)s1_handle)[0].data);
  if (!(((((DLTensor*)s2_handle)[0].ndim) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source ndim mismatch, expected 8", (long long)((((DLTensor*)s2_handle)[0].ndim)), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_strided_source_strides_1 = (((DLTensor*)s2_handle)[0].strides);
  int32_t condval_16;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[7]);
  }
  int32_t stride2_7 = condval_16;
  int32_t condval_17;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[6]);
  }
  int32_t stride2_6 = condval_17;
  int32_t condval_18;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[5]);
  }
  int32_t stride2_5 = condval_18;
  int32_t condval_19;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[4]);
  }
  int32_t stride2_4 = condval_19;
  int32_t condval_20;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[3]);
  }
  int32_t stride2_3 = condval_20;
  int32_t condval_21;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_21 = 1;
  } else {
    condval_21 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[2]);
  }
  int32_t stride2_2 = condval_21;
  int32_t condval_22;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_22 = 1;
  } else {
    condval_22 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[1]);
  }
  int32_t stride2_1 = condval_22;
  int32_t condval_23;
  if ((collectives_rank_order_strided_source_strides_1 == NULL)) {
    condval_23 = 1;
  } else {
    condval_23 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_1)[0]);
  }
  int32_t stride2_0 = condval_23;
  void* source_1 = (((DLTensor*)s2_handle)[0].data);
  if (!(((((DLTensor*)s3_handle)[0].ndim) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source ndim mismatch, expected 8", (long long)((((DLTensor*)s3_handle)[0].ndim)), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_strided_source_strides_2 = (((DLTensor*)s3_handle)[0].strides);
  int32_t condval_24;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_24 = 1;
  } else {
    condval_24 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[7]);
  }
  int32_t stride3_7 = condval_24;
  int32_t condval_25;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_25 = 1;
  } else {
    condval_25 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[6]);
  }
  int32_t stride3_6 = condval_25;
  int32_t condval_26;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_26 = 1;
  } else {
    condval_26 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[5]);
  }
  int32_t stride3_5 = condval_26;
  int32_t condval_27;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_27 = 1;
  } else {
    condval_27 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[4]);
  }
  int32_t stride3_4 = condval_27;
  int32_t condval_28;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_28 = 1;
  } else {
    condval_28 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[3]);
  }
  int32_t stride3_3 = condval_28;
  int32_t condval_29;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_29 = 1;
  } else {
    condval_29 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[2]);
  }
  int32_t stride3_2 = condval_29;
  int32_t condval_30;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_30 = 1;
  } else {
    condval_30 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[1]);
  }
  int32_t stride3_1 = condval_30;
  int32_t condval_31;
  if ((collectives_rank_order_strided_source_strides_2 == NULL)) {
    condval_31 = 1;
  } else {
    condval_31 = ((int32_t)((int64_t*)collectives_rank_order_strided_source_strides_2)[0]);
  }
  int32_t stride3_0 = condval_31;
  void* source_2 = (((DLTensor*)s3_handle)[0].data);
  if (!(((((DLTensor*)output_handle)[0].ndim) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output ndim mismatch, expected 8", (long long)((((DLTensor*)output_handle)[0].ndim)), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_strided_output_strides = (((DLTensor*)output_handle)[0].strides);
  int32_t condval_32;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_32 = 1;
  } else {
    condval_32 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[7]);
  }
  int32_t stride4_7 = condval_32;
  int32_t condval_33;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_33 = 1;
  } else {
    condval_33 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[6]);
  }
  int32_t stride4_6 = condval_33;
  int32_t condval_34;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_34 = 1;
  } else {
    condval_34 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[5]);
  }
  int32_t stride4_5 = condval_34;
  int32_t condval_35;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_35 = 1;
  } else {
    condval_35 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[4]);
  }
  int32_t stride4_4 = condval_35;
  int32_t condval_36;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_36 = 1;
  } else {
    condval_36 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[3]);
  }
  int32_t stride4_3 = condval_36;
  int32_t condval_37;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_37 = 1;
  } else {
    condval_37 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[2]);
  }
  int32_t stride4_2 = condval_37;
  int32_t condval_38;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_38 = 1;
  } else {
    condval_38 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[1]);
  }
  int32_t stride4_1 = condval_38;
  int32_t condval_39;
  if ((collectives_rank_order_strided_output_strides == NULL)) {
    condval_39 = 1;
  } else {
    condval_39 = ((int32_t)((int64_t*)collectives_rank_order_strided_output_strides)[0]);
  }
  int32_t stride4_0 = condval_39;
  void* output = (((DLTensor*)output_handle)[0].data);
  if (!(((((((DLTensor*)s0_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)s0_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)s0_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input s0 dtype mismatch, expected float32");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s0_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input s0 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s0_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s0_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input s0 device_type mismatch, expected cuda", (long long)((((DLTensor*)s0_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((((((((dim0 == 0) || (dim1 == 0)) || (dim2 == 0)) || (dim3 == 0)) || (dim4 == 0)) || (dim5 == 0)) || (dim6 == 0)) || (dim7 == 0)) || !(s0 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input s0 data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s1_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)s1_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)s1_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[2])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[2])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[3])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[3])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[4])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[4] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[4])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[5])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[5] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[5])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[6])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[6] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[6])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[7])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[7] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[7])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s1_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s1_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s1_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source device_id violates packed ABI constraint", (long long)((((DLTensor*)s1_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s1_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source device_type mismatch, expected cuda", (long long)((((DLTensor*)s1_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((((((((dim0 == 0) || (dim1 == 0)) || (dim2 == 0)) || (dim3 == 0)) || (dim4 == 0)) || (dim5 == 0)) || (dim6 == 0)) || (dim7 == 0)) || !(source == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s2_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)s2_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)s2_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[2])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[2])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[3])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[3])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[4])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[4] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[4])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[5])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[5] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[5])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[6])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[6] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[6])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[7])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[7] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[7])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s2_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s2_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s2_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source device_id violates packed ABI constraint", (long long)((((DLTensor*)s2_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s2_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source device_type mismatch, expected cuda", (long long)((((DLTensor*)s2_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((((((((dim0 == 0) || (dim1 == 0)) || (dim2 == 0)) || (dim3 == 0)) || (dim4 == 0)) || (dim5 == 0)) || (dim6 == 0)) || (dim7 == 0)) || !(source_1 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s3_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)s3_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)s3_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[2])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[2])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[3])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[3])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[4])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[4] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[4])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[5])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[5] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[5])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[6])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[6] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[6])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7]) == ((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[7])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source shape[7] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_source_shape_2)[7])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s3_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s3_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s3_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source device_id violates packed ABI constraint", (long long)((((DLTensor*)s3_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s3_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input source device_type mismatch, expected cuda", (long long)((((DLTensor*)s3_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((((((((dim0 == 0) || (dim1 == 0)) || (dim2 == 0)) || (dim3 == 0)) || (dim4 == 0)) || (dim5 == 0)) || (dim6 == 0)) || (dim7 == 0)) || !(source_2 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input source data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)output_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)output_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)output_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input output dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[1])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[2])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[2])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[2])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[3])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[3])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[3])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[4])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[4] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[4])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[4])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[5])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[5] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[5])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[5])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[6])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[6] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[6])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[6])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7]) == ((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[7])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output shape[7] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_s0_shape)[7])), (long long)(((int32_t)((int64_t*)collectives_rank_order_strided_output_shape)[7])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)output_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)output_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output device_id violates packed ABI constraint", (long long)((((DLTensor*)output_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_strided input output device_type mismatch, expected cuda", (long long)((((DLTensor*)output_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((((((((dim0 == 0) || (dim1 == 0)) || (dim2 == 0)) || (dim3 == 0)) || (dim4 == 0)) || (dim5 == 0)) || (dim6 == 0)) || (dim7 == 0)) || !(output == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_strided input output data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (output == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = output;
  if (s0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = s0;
  if (source_2 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = source_2;
  if (source_1 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = source_1;
  if (source == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = source;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)dim0);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)dim1);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)dim2);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)dim3);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)dim4);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)dim5);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)dim6);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)dim7);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)stride0_0);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)stride0_1);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)stride0_2);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)stride0_3);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)stride0_4);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = ((int64_t)stride0_5);
  (((TVMFFIAny*)stack_ffi_any)[19].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[19].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].v_int64) = ((int64_t)stride0_6);
  (((TVMFFIAny*)stack_ffi_any)[20].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[20].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[20].v_int64) = ((int64_t)stride0_7);
  (((TVMFFIAny*)stack_ffi_any)[21].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[21].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[21].v_int64) = ((int64_t)stride1_0);
  (((TVMFFIAny*)stack_ffi_any)[22].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[22].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[22].v_int64) = ((int64_t)stride1_1);
  (((TVMFFIAny*)stack_ffi_any)[23].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[23].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[23].v_int64) = ((int64_t)stride1_2);
  (((TVMFFIAny*)stack_ffi_any)[24].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[24].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[24].v_int64) = ((int64_t)stride1_3);
  (((TVMFFIAny*)stack_ffi_any)[25].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[25].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[25].v_int64) = ((int64_t)stride1_4);
  (((TVMFFIAny*)stack_ffi_any)[26].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[26].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[26].v_int64) = ((int64_t)stride1_5);
  (((TVMFFIAny*)stack_ffi_any)[27].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[27].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[27].v_int64) = ((int64_t)stride1_6);
  (((TVMFFIAny*)stack_ffi_any)[28].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[28].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[28].v_int64) = ((int64_t)stride1_7);
  (((TVMFFIAny*)stack_ffi_any)[29].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[29].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[29].v_int64) = ((int64_t)stride2_0);
  (((TVMFFIAny*)stack_ffi_any)[30].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[30].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[30].v_int64) = ((int64_t)stride2_1);
  (((TVMFFIAny*)stack_ffi_any)[31].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[31].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[31].v_int64) = ((int64_t)stride2_2);
  (((TVMFFIAny*)stack_ffi_any)[32].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[32].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[32].v_int64) = ((int64_t)stride2_3);
  (((TVMFFIAny*)stack_ffi_any)[33].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[33].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[33].v_int64) = ((int64_t)stride2_4);
  (((TVMFFIAny*)stack_ffi_any)[34].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[34].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[34].v_int64) = ((int64_t)stride2_5);
  (((TVMFFIAny*)stack_ffi_any)[35].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[35].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[35].v_int64) = ((int64_t)stride2_6);
  (((TVMFFIAny*)stack_ffi_any)[36].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[36].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[36].v_int64) = ((int64_t)stride2_7);
  (((TVMFFIAny*)stack_ffi_any)[37].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[37].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[37].v_int64) = ((int64_t)stride3_0);
  (((TVMFFIAny*)stack_ffi_any)[38].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[38].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[38].v_int64) = ((int64_t)stride3_1);
  (((TVMFFIAny*)stack_ffi_any)[39].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[39].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[39].v_int64) = ((int64_t)stride3_2);
  (((TVMFFIAny*)stack_ffi_any)[40].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[40].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[40].v_int64) = ((int64_t)stride3_3);
  (((TVMFFIAny*)stack_ffi_any)[41].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[41].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[41].v_int64) = ((int64_t)stride3_4);
  (((TVMFFIAny*)stack_ffi_any)[42].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[42].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[42].v_int64) = ((int64_t)stride3_5);
  (((TVMFFIAny*)stack_ffi_any)[43].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[43].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[43].v_int64) = ((int64_t)stride3_6);
  (((TVMFFIAny*)stack_ffi_any)[44].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[44].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[44].v_int64) = ((int64_t)stride3_7);
  (((TVMFFIAny*)stack_ffi_any)[45].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[45].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[45].v_int64) = ((int64_t)stride4_0);
  (((TVMFFIAny*)stack_ffi_any)[46].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[46].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[46].v_int64) = ((int64_t)stride4_1);
  (((TVMFFIAny*)stack_ffi_any)[47].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[47].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[47].v_int64) = ((int64_t)stride4_2);
  (((TVMFFIAny*)stack_ffi_any)[48].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[48].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[48].v_int64) = ((int64_t)stride4_3);
  (((TVMFFIAny*)stack_ffi_any)[49].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[49].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[49].v_int64) = ((int64_t)stride4_4);
  (((TVMFFIAny*)stack_ffi_any)[50].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[50].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[50].v_int64) = ((int64_t)stride4_5);
  (((TVMFFIAny*)stack_ffi_any)[51].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[51].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[51].v_int64) = ((int64_t)stride4_6);
  (((TVMFFIAny*)stack_ffi_any)[52].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[52].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[52].v_int64) = ((int64_t)stride4_7);
  (((TVMFFIAny*)stack_ffi_any)[53].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[53].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[53].v_int64) = (((((((((((int64_t)dim0) * ((int64_t)dim1)) * ((int64_t)dim2)) * ((int64_t)dim3)) * ((int64_t)dim4)) * ((int64_t)dim5)) * ((int64_t)dim6)) * ((int64_t)dim7)) + (int64_t)255) >> (int64_t)8);
  (((TVMFFIAny*)stack_ffi_any)[54].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[54].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[54].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[55].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[55].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[55].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[56].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[56].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[56].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[57].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[57].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[57].v_int64) = (int64_t)0;
  if (collectives_rank_order_strided_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "collectives_rank_order_strided_kernel", &collectives_rank_order_strided_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(collectives_rank_order_strided_kernel_packed, (TVMFFIAny*) stack_ffi_any, 57, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_collectives_rank_order_strided(self, args, num_args, result);
}
