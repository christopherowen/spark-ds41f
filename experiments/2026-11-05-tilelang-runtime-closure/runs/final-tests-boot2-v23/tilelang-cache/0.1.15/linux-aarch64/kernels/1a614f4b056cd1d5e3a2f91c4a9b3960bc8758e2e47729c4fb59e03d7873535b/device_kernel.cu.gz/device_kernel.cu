#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_pad_columns_kernel(bfloat16_t* __restrict__ dst, const bfloat16_t* __restrict__ src, int rows);
extern "C" __global__ void __launch_bounds__(128, 1) vision_pad_columns_kernel(bfloat16_t* __restrict__ dst, const bfloat16_t* __restrict__ src, int rows) {
  bfloat16_t values[4];
  if (((((int)blockIdx.x) * 4) + (((int)threadIdx.x) >> 5)) < 5) {
    if (((((int)blockIdx.x) * 128) + ((int)threadIdx.x)) < 147) {
      *(uint2*)(values + 0) = *(uint2*)(src + (((((int64_t)((int)blockIdx.y)) * (int64_t)588) + (((int64_t)((int)blockIdx.x)) * (int64_t)512)) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)));
    } else {
      bfloat16_t broadcast_var = bfloat16_t(0x0p+0f/*0.000000e+00*/);
      *(uint2*)(values + 0) = make_uint2(__pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var));
    }
    *(uint2*)(dst + (((((int64_t)((int)blockIdx.y)) * (int64_t)640) + (((int64_t)((int)blockIdx.x)) * (int64_t)512)) + (((int64_t)((int)threadIdx.x)) * (int64_t)4))) = *(uint2*)(values + 0);
  }
}

