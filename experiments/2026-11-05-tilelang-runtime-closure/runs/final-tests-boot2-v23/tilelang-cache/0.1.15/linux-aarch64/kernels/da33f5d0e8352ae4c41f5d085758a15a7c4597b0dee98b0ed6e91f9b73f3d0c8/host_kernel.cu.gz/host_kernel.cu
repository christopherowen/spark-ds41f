// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* local_stats_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_local_stats(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_local_stats(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[23];
  void* stack_ffi_any = stack;
  if (!((num_args == 9))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "local_stats: num_args should be 9", (long long)(num_args), (long long)(9));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats: args pointer is NULL");
    return -1;
  }
  int32_t local_argmax_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((local_argmax_handle_type_index == 0) || (local_argmax_handle_type_index == 4)) || (local_argmax_handle_type_index == 7)) || (64 <= local_argmax_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_argmax expected pointer or tensor handle");
    return -1;
  }
  int32_t local_max_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((local_max_handle_type_index == 0) || (local_max_handle_type_index == 4)) || (local_max_handle_type_index == 7)) || (64 <= local_max_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_max expected pointer or tensor handle");
    return -1;
  }
  int32_t local_sumexp_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((local_sumexp_handle_type_index == 0) || (local_sumexp_handle_type_index == 4)) || (local_sumexp_handle_type_index == 7)) || (64 <= local_sumexp_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_sumexp expected pointer or tensor handle");
    return -1;
  }
  int32_t logits_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((logits_handle_type_index == 0) || (logits_handle_type_index == 4)) || (logits_handle_type_index == 7)) || (64 <= logits_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input logits expected pointer or tensor handle");
    return -1;
  }
  int32_t expanded_idx_mapping_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((expanded_idx_mapping_handle_type_index == 0) || (expanded_idx_mapping_handle_type_index == 4)) || (expanded_idx_mapping_handle_type_index == 7)) || (64 <= expanded_idx_mapping_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_idx_mapping expected pointer or tensor handle");
    return -1;
  }
  int32_t expanded_local_pos_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((expanded_local_pos_handle_type_index == 0) || (expanded_local_pos_handle_type_index == 4)) || (expanded_local_pos_handle_type_index == 7)) || (64 <= expanded_local_pos_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_local_pos expected pointer or tensor handle");
    return -1;
  }
  int32_t temperature_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((temperature_handle_type_index == 0) || (temperature_handle_type_index == 4)) || (temperature_handle_type_index == 7)) || (64 <= temperature_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input temperature expected pointer or tensor handle");
    return -1;
  }
  int32_t num_speculative_steps_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((num_speculative_steps_type_index == 1) || (num_speculative_steps_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats scalar num_speculative_steps expected integer");
    return -1;
  }
  int32_t apply_temperature_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((apply_temperature_type_index == 1) || (apply_temperature_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats scalar apply_temperature expected integer");
    return -1;
  }
  void* local_argmax_handle = ((local_argmax_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* local_max_handle = ((local_max_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* local_sumexp_handle = ((local_sumexp_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* logits_handle = ((logits_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* expanded_idx_mapping_handle = ((expanded_idx_mapping_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* expanded_local_pos_handle = ((expanded_local_pos_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* temperature_handle = ((temperature_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  int32_t num_speculative_steps = ((int32_t)(((TVMFFIAny*)args)[7].v_int64));
  int32_t apply_temperature = ((int32_t)(((TVMFFIAny*)args)[8].v_int64));
  bool local_stats_local_argmax_is_null = (local_argmax_handle == NULL);
  if (!(!local_stats_local_argmax_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats.local_argmax is expected to have non-NULL pointer");
    return -1;
  }
  bool local_stats_local_max_is_null = (local_max_handle == NULL);
  if (!(!local_stats_local_max_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats.local_max is expected to have non-NULL pointer");
    return -1;
  }
  bool local_stats_local_sumexp_is_null = (local_sumexp_handle == NULL);
  if (!(!local_stats_local_sumexp_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats.local_sumexp is expected to have non-NULL pointer");
    return -1;
  }
  bool local_stats_logits_is_null = (logits_handle == NULL);
  if (!(!local_stats_logits_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats.logits is expected to have non-NULL pointer");
    return -1;
  }
  bool local_stats_expanded_idx_mapping_is_null = (expanded_idx_mapping_handle == NULL);
  if (!(!local_stats_expanded_idx_mapping_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats.expanded_idx_mapping is expected to have non-NULL pointer");
    return -1;
  }
  bool local_stats_expanded_local_pos_is_null = (expanded_local_pos_handle == NULL);
  if (!(!local_stats_expanded_local_pos_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats.expanded_local_pos is expected to have non-NULL pointer");
    return -1;
  }
  bool local_stats_temperature_is_null = (temperature_handle == NULL);
  if (!(!local_stats_temperature_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "local_stats.temperature is expected to have non-NULL pointer");
    return -1;
  }
  void* local_stats_local_argmax_shape = (((DLTensor*)local_argmax_handle)[0].shape);
  void* local_stats_local_max_shape = (((DLTensor*)local_max_handle)[0].shape);
  void* local_stats_local_sumexp_shape = (((DLTensor*)local_sumexp_handle)[0].shape);
  void* local_stats_logits_shape = (((DLTensor*)logits_handle)[0].shape);
  void* local_stats_expanded_idx_mapping_shape = (((DLTensor*)expanded_idx_mapping_handle)[0].shape);
  void* local_stats_expanded_local_pos_shape = (((DLTensor*)expanded_local_pos_handle)[0].shape);
  void* local_stats_temperature_shape = (((DLTensor*)temperature_handle)[0].shape);
  if (!(((((DLTensor*)local_argmax_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_argmax ndim mismatch, expected 2", (long long)((((DLTensor*)local_argmax_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: local_stats.local_argmax, local_stats.local_max, local_stats.local_sumexp, local_stats.logits");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)local_stats_local_argmax_shape)[0]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable blocks requires at least one non-null buffer among: local_stats.local_argmax, local_stats.local_max, local_stats.local_sumexp");
    return -1;
  }
  int32_t blocks = ((int32_t)((int64_t*)local_stats_local_argmax_shape)[1]);
  void* local_stats_local_argmax_strides = (((DLTensor*)local_argmax_handle)[0].strides);
  int64_t condval;
  if ((local_stats_local_argmax_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)local_stats_local_argmax_strides)[0];
  }
  int64_t argmax_stride = condval;
  int32_t dev_id = (((DLTensor*)local_argmax_handle)[0].device.device_id);
  void* local_argmax = (((DLTensor*)local_argmax_handle)[0].data);
  if (!(((((DLTensor*)local_max_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_max ndim mismatch, expected 2", (long long)((((DLTensor*)local_max_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* local_stats_local_max_strides = (((DLTensor*)local_max_handle)[0].strides);
  int64_t condval_1;
  if ((local_stats_local_max_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)local_stats_local_max_strides)[0];
  }
  int64_t max_stride = condval_1;
  void* local_max = (((DLTensor*)local_max_handle)[0].data);
  if (!(((((DLTensor*)local_sumexp_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_sumexp ndim mismatch, expected 2", (long long)((((DLTensor*)local_sumexp_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* local_stats_local_sumexp_strides = (((DLTensor*)local_sumexp_handle)[0].strides);
  int64_t condval_2;
  if ((local_stats_local_sumexp_strides == NULL)) {
    condval_2 = (int64_t)1;
  } else {
    condval_2 = ((int64_t*)local_stats_local_sumexp_strides)[0];
  }
  int64_t sumexp_stride = condval_2;
  void* local_sumexp = (((DLTensor*)local_sumexp_handle)[0].data);
  if (!(((((DLTensor*)logits_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input logits ndim mismatch, expected 2", (long long)((((DLTensor*)logits_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t vocab = ((int32_t)((int64_t*)local_stats_logits_shape)[1]);
  void* local_stats_logits_strides = (((DLTensor*)logits_handle)[0].strides);
  int64_t condval_3;
  if ((local_stats_logits_strides == NULL)) {
    condval_3 = (int64_t)1;
  } else {
    condval_3 = ((int64_t*)local_stats_logits_strides)[0];
  }
  int64_t logits_stride = condval_3;
  void* logits = (((DLTensor*)logits_handle)[0].data);
  if (!(((((DLTensor*)expanded_idx_mapping_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_idx_mapping ndim mismatch, expected 1", (long long)((((DLTensor*)expanded_idx_mapping_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t idx_len = ((int32_t)((int64_t*)local_stats_expanded_idx_mapping_shape)[0]);
  void* local_stats_expanded_idx_mapping_strides = (((DLTensor*)expanded_idx_mapping_handle)[0].strides);
  void* expanded_idx_mapping = (((DLTensor*)expanded_idx_mapping_handle)[0].data);
  if (!(((((DLTensor*)expanded_local_pos_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_local_pos ndim mismatch, expected 1", (long long)((((DLTensor*)expanded_local_pos_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t step_len = ((int32_t)((int64_t*)local_stats_expanded_local_pos_shape)[0]);
  void* local_stats_expanded_local_pos_strides = (((DLTensor*)expanded_local_pos_handle)[0].strides);
  void* expanded_local_pos = (((DLTensor*)expanded_local_pos_handle)[0].data);
  if (!(((((DLTensor*)temperature_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input temperature ndim mismatch, expected 1", (long long)((((DLTensor*)temperature_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t temp_len = ((int32_t)((int64_t*)local_stats_temperature_shape)[0]);
  void* local_stats_temperature_strides = (((DLTensor*)temperature_handle)[0].strides);
  void* temperature = (((DLTensor*)temperature_handle)[0].data);
  if (!(((((((DLTensor*)local_argmax_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)local_argmax_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)local_argmax_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_argmax dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_4;
  if ((local_stats_local_argmax_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)local_stats_local_argmax_strides)[1]);
  }
  if (!(((condval_4 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_argmax strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_argmax_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_argmax byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_argmax_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_argmax_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_argmax device_type mismatch, expected cuda", (long long)((((DLTensor*)local_argmax_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (blocks == 0)) || !(local_argmax == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_argmax data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_max_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)local_max_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)local_max_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_max dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)local_stats_local_argmax_shape)[0]) == ((int32_t)((int64_t*)local_stats_local_max_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_max shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)local_stats_local_argmax_shape)[0])), (long long)(((int32_t)((int64_t*)local_stats_local_max_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)local_stats_local_argmax_shape)[1]) == ((int32_t)((int64_t*)local_stats_local_max_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_max shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)local_stats_local_argmax_shape)[1])), (long long)(((int32_t)((int64_t*)local_stats_local_max_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((local_stats_local_max_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)local_stats_local_max_strides)[1]);
  }
  if (!(((condval_5 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_max strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_max_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_max byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_max_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_max device_id violates packed ABI constraint", (long long)((((DLTensor*)local_max_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_max device_type mismatch, expected cuda", (long long)((((DLTensor*)local_max_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (blocks == 0)) || !(local_max == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_max data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_sumexp_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)local_sumexp_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)local_sumexp_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_sumexp dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)local_stats_local_argmax_shape)[0]) == ((int32_t)((int64_t*)local_stats_local_sumexp_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_sumexp shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)local_stats_local_argmax_shape)[0])), (long long)(((int32_t)((int64_t*)local_stats_local_sumexp_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)local_stats_local_argmax_shape)[1]) == ((int32_t)((int64_t*)local_stats_local_sumexp_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_sumexp shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)local_stats_local_argmax_shape)[1])), (long long)(((int32_t)((int64_t*)local_stats_local_sumexp_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((local_stats_local_sumexp_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)local_stats_local_sumexp_strides)[1]);
  }
  if (!(((condval_6 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_sumexp strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_sumexp_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_sumexp byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_sumexp_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_sumexp_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_sumexp device_id violates packed ABI constraint", (long long)((((DLTensor*)local_sumexp_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_sumexp_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input local_sumexp device_type mismatch, expected cuda", (long long)((((DLTensor*)local_sumexp_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (blocks == 0)) || !(local_sumexp == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input local_sumexp data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)logits_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)logits_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)logits_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input logits dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)local_stats_local_argmax_shape)[0]) == ((int32_t)((int64_t*)local_stats_logits_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input logits shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)local_stats_local_argmax_shape)[0])), (long long)(((int32_t)((int64_t*)local_stats_logits_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((local_stats_logits_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)local_stats_logits_strides)[1]);
  }
  if (!(((condval_7 == 1) || (vocab == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input logits strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)logits_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input logits byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)logits_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input logits device_id violates packed ABI constraint", (long long)((((DLTensor*)logits_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input logits device_type mismatch, expected cuda", (long long)((((DLTensor*)logits_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (vocab == 0)) || !(logits == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input logits data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)expanded_idx_mapping_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)expanded_idx_mapping_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)expanded_idx_mapping_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_idx_mapping dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_8;
  if ((local_stats_expanded_idx_mapping_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)local_stats_expanded_idx_mapping_strides)[0]);
  }
  if (!(((condval_8 == 1) || (idx_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_idx_mapping strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)expanded_idx_mapping_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_idx_mapping byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)expanded_idx_mapping_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)expanded_idx_mapping_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_idx_mapping device_id violates packed ABI constraint", (long long)((((DLTensor*)expanded_idx_mapping_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)expanded_idx_mapping_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_idx_mapping device_type mismatch, expected cuda", (long long)((((DLTensor*)expanded_idx_mapping_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((idx_len == 0) || !(expanded_idx_mapping == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_idx_mapping data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)expanded_local_pos_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)expanded_local_pos_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)expanded_local_pos_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_local_pos dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_9;
  if ((local_stats_expanded_local_pos_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)local_stats_expanded_local_pos_strides)[0]);
  }
  if (!(((condval_9 == 1) || (step_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_local_pos strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)expanded_local_pos_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_local_pos byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)expanded_local_pos_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)expanded_local_pos_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_local_pos device_id violates packed ABI constraint", (long long)((((DLTensor*)expanded_local_pos_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)expanded_local_pos_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input expanded_local_pos device_type mismatch, expected cuda", (long long)((((DLTensor*)expanded_local_pos_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((step_len == 0) || !(expanded_local_pos == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input expanded_local_pos data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)temperature_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)temperature_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)temperature_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input temperature dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_10;
  if ((local_stats_temperature_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)local_stats_temperature_strides)[0]);
  }
  if (!(((condval_10 == 1) || (temp_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input temperature strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)temperature_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input temperature byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)temperature_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input temperature device_id violates packed ABI constraint", (long long)((((DLTensor*)temperature_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel local_stats input temperature device_type mismatch, expected cuda", (long long)((((DLTensor*)temperature_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((temp_len == 0) || !(temperature == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel local_stats input temperature data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (!(((logits_stride % (int64_t)16) == (int64_t)0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: logits_stride % T.int64(16) == T.int64(0)", (long long)((logits_stride % (int64_t)16)), (long long)((int64_t)0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (expanded_idx_mapping == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = expanded_idx_mapping;
  if (expanded_local_pos == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = expanded_local_pos;
  if (local_argmax == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = local_argmax;
  if (local_max == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = local_max;
  if (local_sumexp == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = local_sumexp;
  if (logits == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = logits;
  if (temperature == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = temperature;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)apply_temperature);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = argmax_stride;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)blocks);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = logits_stride;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = max_stride;
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)num_speculative_steps);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = sumexp_stride;
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)vocab);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)blocks);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[19].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[19].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[20].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[20].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[20].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[21].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[21].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[21].v_int64) = ((int64_t)80);
  (((TVMFFIAny*)stack_ffi_any)[22].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[22].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[22].v_int64) = (int64_t)0;
  if (local_stats_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "local_stats_kernel", &local_stats_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(local_stats_kernel_packed, (TVMFFIAny*) stack_ffi_any, 22, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_local_stats(self, args, num_args, result);
}
