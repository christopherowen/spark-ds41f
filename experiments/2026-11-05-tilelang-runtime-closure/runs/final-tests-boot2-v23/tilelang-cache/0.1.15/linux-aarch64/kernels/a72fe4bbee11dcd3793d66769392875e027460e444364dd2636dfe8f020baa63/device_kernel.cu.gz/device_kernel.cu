#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vocab_embedding_kernel(const int* ids, int* __restrict__ out, const int* table, int64_t added_end, int64_t added_offset, int64_t added_start, int64_t org_end, int64_t org_start, int tokens);
extern "C" __global__ void __launch_bounds__(128, 1) vocab_embedding_kernel(const int* ids, int* __restrict__ out, const int* table, int64_t added_end, int64_t added_offset, int64_t added_start, int64_t org_end, int64_t org_start, int tokens) {
  int64_t token = (int64_t)0;
  int64_t row = (int64_t)0;
  int data[20];
  token = ((int64_t)ids[((int64_t)((int)blockIdx.x))]);
  int64_t condval;
  if (((org_start <= token) & (token < org_end))) {
    condval = (token - org_start);
  } else {
    int64_t condval_1;
    if (((added_start <= token) & (token < added_end))) {
      condval_1 = (token + added_offset);
    } else {
      condval_1 = (int64_t)-1;
    }
    condval = condval_1;
  }
  row = condval;
  #pragma unroll
  for (int k = 0; k < 5; ++k) {
    if ((int64_t)0 <= row) {
      *(int4*)(data + (k * 4)) = *(int4*)(table + (((row * (int64_t)2560) + (((int64_t)k) * (int64_t)512)) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)));
    } else {
      int broadcast_var = 0;
      *(int4*)(data + (k * 4)) = make_int4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
  }
  #pragma unroll
  for (int k_1 = 0; k_1 < 5; ++k_1) {
    *(int4*)(out + (((((int64_t)((int)blockIdx.x)) * (int64_t)2560) + (((int64_t)k_1) * (int64_t)512)) + (((int64_t)((int)threadIdx.x)) * (int64_t)4))) = *(int4*)(data + (k_1 * 4));
  }
}

