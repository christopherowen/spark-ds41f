#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_order_strided_kernel(float* __restrict__ output, const bfloat16_t* __restrict__ s0, const bfloat16_t* __restrict__ source, const bfloat16_t* __restrict__ source_1, const bfloat16_t* __restrict__ source_2, const bfloat16_t* __restrict__ source_3, const bfloat16_t* __restrict__ source_4, const bfloat16_t* __restrict__ source_5, const bfloat16_t* __restrict__ source_6, int dim0, int dim1, int dim2, int dim3, int dim4, int dim5, int dim6, int dim7, int stride0_0, int stride0_1, int stride0_2, int stride0_3, int stride0_4, int stride0_5, int stride0_6, int stride0_7, int stride1_0, int stride1_1, int stride1_2, int stride1_3, int stride1_4, int stride1_5, int stride1_6, int stride1_7, int stride2_0, int stride2_1, int stride2_2, int stride2_3, int stride2_4, int stride2_5, int stride2_6, int stride2_7, int stride3_0, int stride3_1, int stride3_2, int stride3_3, int stride3_4, int stride3_5, int stride3_6, int stride3_7, int stride4_0, int stride4_1, int stride4_2, int stride4_3, int stride4_4, int stride4_5, int stride4_6, int stride4_7, int stride5_0, int stride5_1, int stride5_2, int stride5_3, int stride5_4, int stride5_5, int stride5_6, int stride5_7, int stride6_0, int stride6_1, int stride6_2, int stride6_3, int stride6_4, int stride6_5, int stride6_6, int stride6_7, int stride7_0, int stride7_1, int stride7_2, int stride7_3, int stride7_4, int stride7_5, int stride7_6, int stride7_7, int stride8_0, int stride8_1, int stride8_2, int stride8_3, int stride8_4, int stride8_5, int stride8_6, int stride8_7);
extern "C" __global__ void __launch_bounds__(256, 1) collectives_rank_order_strided_kernel(float* __restrict__ output, const bfloat16_t* __restrict__ s0, const bfloat16_t* __restrict__ source, const bfloat16_t* __restrict__ source_1, const bfloat16_t* __restrict__ source_2, const bfloat16_t* __restrict__ source_3, const bfloat16_t* __restrict__ source_4, const bfloat16_t* __restrict__ source_5, const bfloat16_t* __restrict__ source_6, int dim0, int dim1, int dim2, int dim3, int dim4, int dim5, int dim6, int dim7, int stride0_0, int stride0_1, int stride0_2, int stride0_3, int stride0_4, int stride0_5, int stride0_6, int stride0_7, int stride1_0, int stride1_1, int stride1_2, int stride1_3, int stride1_4, int stride1_5, int stride1_6, int stride1_7, int stride2_0, int stride2_1, int stride2_2, int stride2_3, int stride2_4, int stride2_5, int stride2_6, int stride2_7, int stride3_0, int stride3_1, int stride3_2, int stride3_3, int stride3_4, int stride3_5, int stride3_6, int stride3_7, int stride4_0, int stride4_1, int stride4_2, int stride4_3, int stride4_4, int stride4_5, int stride4_6, int stride4_7, int stride5_0, int stride5_1, int stride5_2, int stride5_3, int stride5_4, int stride5_5, int stride5_6, int stride5_7, int stride6_0, int stride6_1, int stride6_2, int stride6_3, int stride6_4, int stride6_5, int stride6_6, int stride6_7, int stride7_0, int stride7_1, int stride7_2, int stride7_3, int stride7_4, int stride7_5, int stride7_6, int stride7_7, int stride8_0, int stride8_1, int stride8_2, int stride8_3, int stride8_4, int stride8_5, int stride8_6, int stride8_7) {
  int64_t remaining = (int64_t)0;
  int indices[8];
  float total = 0x0p+0f/*0.000000e+00*/;
  if (((((int64_t)blockIdx.x) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) < (((((((((int64_t)dim0) * ((int64_t)dim1)) * ((int64_t)dim2)) * ((int64_t)dim3)) * ((int64_t)dim4)) * ((int64_t)dim5)) * ((int64_t)dim6)) * ((int64_t)dim7))) {
    remaining = ((((int64_t)blockIdx.x) * (int64_t)256) + ((int64_t)((int)threadIdx.x)));
    int64_t rmod = (remaining % ((int64_t)dim7));
    indices[7] = ((int)(((((int64_t)0 <= ((int64_t)dim7)) && ((int64_t)0 <= rmod)) || ((((int64_t)dim7) < (int64_t)0) && (rmod <= (int64_t)0))) ? rmod : (rmod + ((int64_t)dim7))));
    int64_t rmod_1 = (remaining % ((int64_t)dim7));
    int64_t rdiv = (remaining / ((int64_t)dim7));
    remaining = (((((int64_t)0 <= ((int64_t)dim7)) && ((int64_t)0 <= rmod_1)) || ((((int64_t)dim7) < (int64_t)0) && (rmod_1 <= (int64_t)0))) ? rdiv : (rdiv - (int64_t)1));
    int64_t rmod_2 = (remaining % ((int64_t)dim6));
    indices[6] = ((int)(((((int64_t)0 <= ((int64_t)dim6)) && ((int64_t)0 <= rmod_2)) || ((((int64_t)dim6) < (int64_t)0) && (rmod_2 <= (int64_t)0))) ? rmod_2 : (rmod_2 + ((int64_t)dim6))));
    int64_t rmod_3 = (remaining % ((int64_t)dim6));
    int64_t rdiv_1 = (remaining / ((int64_t)dim6));
    remaining = (((((int64_t)0 <= ((int64_t)dim6)) && ((int64_t)0 <= rmod_3)) || ((((int64_t)dim6) < (int64_t)0) && (rmod_3 <= (int64_t)0))) ? rdiv_1 : (rdiv_1 - (int64_t)1));
    int64_t rmod_4 = (remaining % ((int64_t)dim5));
    indices[5] = ((int)(((((int64_t)0 <= ((int64_t)dim5)) && ((int64_t)0 <= rmod_4)) || ((((int64_t)dim5) < (int64_t)0) && (rmod_4 <= (int64_t)0))) ? rmod_4 : (rmod_4 + ((int64_t)dim5))));
    int64_t rmod_5 = (remaining % ((int64_t)dim5));
    int64_t rdiv_2 = (remaining / ((int64_t)dim5));
    remaining = (((((int64_t)0 <= ((int64_t)dim5)) && ((int64_t)0 <= rmod_5)) || ((((int64_t)dim5) < (int64_t)0) && (rmod_5 <= (int64_t)0))) ? rdiv_2 : (rdiv_2 - (int64_t)1));
    int64_t rmod_6 = (remaining % ((int64_t)dim4));
    indices[4] = ((int)(((((int64_t)0 <= ((int64_t)dim4)) && ((int64_t)0 <= rmod_6)) || ((((int64_t)dim4) < (int64_t)0) && (rmod_6 <= (int64_t)0))) ? rmod_6 : (rmod_6 + ((int64_t)dim4))));
    int64_t rmod_7 = (remaining % ((int64_t)dim4));
    int64_t rdiv_3 = (remaining / ((int64_t)dim4));
    remaining = (((((int64_t)0 <= ((int64_t)dim4)) && ((int64_t)0 <= rmod_7)) || ((((int64_t)dim4) < (int64_t)0) && (rmod_7 <= (int64_t)0))) ? rdiv_3 : (rdiv_3 - (int64_t)1));
    int64_t rmod_8 = (remaining % ((int64_t)dim3));
    indices[3] = ((int)(((((int64_t)0 <= ((int64_t)dim3)) && ((int64_t)0 <= rmod_8)) || ((((int64_t)dim3) < (int64_t)0) && (rmod_8 <= (int64_t)0))) ? rmod_8 : (rmod_8 + ((int64_t)dim3))));
    int64_t rmod_9 = (remaining % ((int64_t)dim3));
    int64_t rdiv_4 = (remaining / ((int64_t)dim3));
    remaining = (((((int64_t)0 <= ((int64_t)dim3)) && ((int64_t)0 <= rmod_9)) || ((((int64_t)dim3) < (int64_t)0) && (rmod_9 <= (int64_t)0))) ? rdiv_4 : (rdiv_4 - (int64_t)1));
    int64_t rmod_10 = (remaining % ((int64_t)dim2));
    indices[2] = ((int)(((((int64_t)0 <= ((int64_t)dim2)) && ((int64_t)0 <= rmod_10)) || ((((int64_t)dim2) < (int64_t)0) && (rmod_10 <= (int64_t)0))) ? rmod_10 : (rmod_10 + ((int64_t)dim2))));
    int64_t rmod_11 = (remaining % ((int64_t)dim2));
    int64_t rdiv_5 = (remaining / ((int64_t)dim2));
    remaining = (((((int64_t)0 <= ((int64_t)dim2)) && ((int64_t)0 <= rmod_11)) || ((((int64_t)dim2) < (int64_t)0) && (rmod_11 <= (int64_t)0))) ? rdiv_5 : (rdiv_5 - (int64_t)1));
    int64_t rmod_12 = (remaining % ((int64_t)dim1));
    indices[1] = ((int)(((((int64_t)0 <= ((int64_t)dim1)) && ((int64_t)0 <= rmod_12)) || ((((int64_t)dim1) < (int64_t)0) && (rmod_12 <= (int64_t)0))) ? rmod_12 : (rmod_12 + ((int64_t)dim1))));
    int64_t rmod_13 = (remaining % ((int64_t)dim1));
    int64_t rdiv_6 = (remaining / ((int64_t)dim1));
    remaining = (((((int64_t)0 <= ((int64_t)dim1)) && ((int64_t)0 <= rmod_13)) || ((((int64_t)dim1) < (int64_t)0) && (rmod_13 <= (int64_t)0))) ? rdiv_6 : (rdiv_6 - (int64_t)1));
    int64_t rmod_14 = (remaining % ((int64_t)dim0));
    indices[0] = ((int)(((((int64_t)0 <= ((int64_t)dim0)) && ((int64_t)0 <= rmod_14)) || ((((int64_t)dim0) < (int64_t)0) && (rmod_14 <= (int64_t)0))) ? rmod_14 : (rmod_14 + ((int64_t)dim0))));
    int64_t rmod_15 = (remaining % ((int64_t)dim0));
    int64_t rdiv_7 = (remaining / ((int64_t)dim0));
    remaining = (((((int64_t)0 <= ((int64_t)dim0)) && ((int64_t)0 <= rmod_15)) || ((((int64_t)dim0) < (int64_t)0) && (rmod_15 <= (int64_t)0))) ? rdiv_7 : (rdiv_7 - (int64_t)1));
    bfloat16_t condval;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval = s0[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride0_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride0_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride0_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride0_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride0_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride0_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride0_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride0_7)))];
    } else {
      condval = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = ((float)condval);
    bfloat16_t condval_1;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_1 = source_6[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride1_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride1_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride1_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride1_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride1_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride1_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride1_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride1_7)))];
    } else {
      condval_1 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = (total + ((float)condval_1));
    bfloat16_t condval_2;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_2 = source_5[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride2_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride2_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride2_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride2_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride2_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride2_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride2_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride2_7)))];
    } else {
      condval_2 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = (total + ((float)condval_2));
    bfloat16_t condval_3;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_3 = source_4[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride3_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride3_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride3_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride3_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride3_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride3_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride3_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride3_7)))];
    } else {
      condval_3 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = (total + ((float)condval_3));
    bfloat16_t condval_4;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_4 = source_3[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride4_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride4_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride4_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride4_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride4_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride4_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride4_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride4_7)))];
    } else {
      condval_4 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = (total + ((float)condval_4));
    bfloat16_t condval_5;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_5 = source_2[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride5_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride5_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride5_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride5_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride5_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride5_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride5_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride5_7)))];
    } else {
      condval_5 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = (total + ((float)condval_5));
    bfloat16_t condval_6;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_6 = source_1[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride6_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride6_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride6_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride6_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride6_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride6_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride6_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride6_7)))];
    } else {
      condval_6 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = (total + ((float)condval_6));
    bfloat16_t condval_7;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_7 = source[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride7_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride7_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride7_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride7_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride7_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride7_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride7_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride7_7)))];
    } else {
      condval_7 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    }
    total = (total + ((float)condval_7));
    if (0 <= indices[7]) {
      if (indices[7] < dim7) {
        if (0 <= indices[6]) {
          if (indices[6] < dim6) {
            if (0 <= indices[5]) {
              if (indices[5] < dim5) {
                if (0 <= indices[4]) {
                  if (indices[4] < dim4) {
                    if (0 <= indices[3]) {
                      if (indices[3] < dim3) {
                        if (0 <= indices[2]) {
                          if (indices[2] < dim2) {
                            if (0 <= indices[1]) {
                              if (indices[1] < dim1) {
                                if (0 <= indices[0]) {
                                  if (indices[0] < dim0) {
                                    output[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride8_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride8_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride8_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride8_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride8_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride8_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride8_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride8_7)))] = total;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

