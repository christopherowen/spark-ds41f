#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_add_norm_kernel(const bfloat16_t* __restrict__ Branch, bfloat16_t* __restrict__ Out, bfloat16_t* __restrict__ Sum, const bfloat16_t* __restrict__ Weight, const bfloat16_t* __restrict__ X, int M);
extern "C" __global__ void __launch_bounds__(256, 1) vision_add_norm_kernel(const bfloat16_t* __restrict__ Branch, bfloat16_t* __restrict__ Out, bfloat16_t* __restrict__ Sum, const bfloat16_t* __restrict__ Weight, const bfloat16_t* __restrict__ X, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* inverse = ((void*)((char*)buf_dyn_shmem + 0));
  void* partial = ((void*)((char*)buf_dyn_shmem + 0));
  float total = 0x0p+0f/*0.000000e+00*/;
  float values[4];
  float block = 0x0p+0f/*0.000000e+00*/;
  total = 0x0p+0f/*0.000000e+00*/;
  #pragma unroll
  for (int item = 0; item < 4; ++item) {
    values[item] = 0x0p+0f/*0.000000e+00*/;
    bfloat16_t summed = ((bfloat16_t)__fadd_rn(((float)X[(((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)item) * (int64_t)256)) + ((int64_t)((int)threadIdx.x)))]), ((float)Branch[(((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)item) * (int64_t)256)) + ((int64_t)((int)threadIdx.x)))])));
    Sum[(((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)item) * (int64_t)256)) + ((int64_t)((int)threadIdx.x)))] = summed;
    values[item] = ((float)summed);
    total = __fmaf_rn(values[item], values[item], total);
  }
  #pragma unroll
  for (int level = 0; level < 5; ++level) {
    total = (total + __shfl_xor_sync((uint)4294967295, total, (1 << level), 32));
  }
  if ((((int)threadIdx.x) % 32) == 0) {
    ((float*)partial)[(((int)threadIdx.x) >> 5)] = total;
  }
  __syncthreads();
  float condval;
  if (((((int)threadIdx.x) & 31) < 8)) {
    condval = ((float*)partial)[(((int)threadIdx.x) & 31)];
  } else {
    condval = 0x0p+0f/*0.000000e+00*/;
  }
  block = condval;
  #pragma unroll
  for (int level_1 = 0; level_1 < 5; ++level_1) {
    block = (block + __shfl_xor_sync((uint)4294967295, block, (1 << level_1), 32));
  }
  __syncthreads();
  if (((int)threadIdx.x) == 0) {
    ((float*)inverse)[0] = rsqrtf(__fadd_rn(__fdiv_rn(block, 0x1p+10f/*1.024000e+03*/), 0x1.0c6f7a0b5ed8dp-20f/*1.000000e-06*/));
  }
  __syncthreads();
  #pragma unroll
  for (int item_1 = 0; item_1 < 4; ++item_1) {
    float learned = __fadd_rn(0x0p+0f/*0.000000e+00*/, ((float)Weight[((item_1 * 256) + ((int)threadIdx.x))]));
    Out[(((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)item_1) * (int64_t)256)) + ((int64_t)((int)threadIdx.x)))] = ((bfloat16_t)__fmul_rn(__fmul_rn(values[item_1], ((float*)inverse)[0]), learned));
  }
}

