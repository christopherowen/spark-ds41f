// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* gumbel_sample_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gumbel_sample(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gumbel_sample(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[20];
  void* stack_ffi_any = stack;
  if (!((num_args == 9))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "gumbel_sample: num_args should be 9", (long long)(num_args), (long long)(9));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample: args pointer is NULL");
    return -1;
  }
  int32_t local_argmax_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((local_argmax_handle_type_index == 0) || (local_argmax_handle_type_index == 4)) || (local_argmax_handle_type_index == 7)) || (64 <= local_argmax_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_argmax expected pointer or tensor handle");
    return -1;
  }
  int32_t local_max_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((local_max_handle_type_index == 0) || (local_max_handle_type_index == 4)) || (local_max_handle_type_index == 7)) || (64 <= local_max_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_max expected pointer or tensor handle");
    return -1;
  }
  int32_t logits_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((logits_handle_type_index == 0) || (logits_handle_type_index == 4)) || (logits_handle_type_index == 7)) || (64 <= logits_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input logits expected pointer or tensor handle");
    return -1;
  }
  int32_t idx_mapping_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((idx_mapping_handle_type_index == 0) || (idx_mapping_handle_type_index == 4)) || (idx_mapping_handle_type_index == 7)) || (64 <= idx_mapping_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input idx_mapping expected pointer or tensor handle");
    return -1;
  }
  int32_t seeds_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((seeds_handle_type_index == 0) || (seeds_handle_type_index == 4)) || (seeds_handle_type_index == 7)) || (64 <= seeds_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input seeds expected pointer or tensor handle");
    return -1;
  }
  int32_t pos_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((pos_handle_type_index == 0) || (pos_handle_type_index == 4)) || (pos_handle_type_index == 7)) || (64 <= pos_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input pos expected pointer or tensor handle");
    return -1;
  }
  int32_t temperature_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((temperature_handle_type_index == 0) || (temperature_handle_type_index == 4)) || (temperature_handle_type_index == 7)) || (64 <= temperature_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input temperature expected pointer or tensor handle");
    return -1;
  }
  int32_t cache_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((cache_handle_type_index == 0) || (cache_handle_type_index == 4)) || (cache_handle_type_index == 7)) || (64 <= cache_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache expected pointer or tensor handle");
    return -1;
  }
  int32_t cache_col_handle_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((((cache_col_handle_type_index == 0) || (cache_col_handle_type_index == 4)) || (cache_col_handle_type_index == 7)) || (64 <= cache_col_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col expected pointer or tensor handle");
    return -1;
  }
  void* local_argmax_handle = ((local_argmax_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* local_max_handle = ((local_max_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* logits_handle = ((logits_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* idx_mapping_handle = ((idx_mapping_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* seeds_handle = ((seeds_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* pos_handle = ((pos_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* temperature_handle = ((temperature_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* cache_handle = ((cache_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  void* cache_col_handle = ((cache_col_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[8].v_ptr) + 24)) : (((TVMFFIAny*)args)[8].v_ptr));
  bool gumbel_sample_local_argmax_is_null = (local_argmax_handle == NULL);
  if (!(!gumbel_sample_local_argmax_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample.local_argmax is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_sample_local_max_is_null = (local_max_handle == NULL);
  if (!(!gumbel_sample_local_max_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample.local_max is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_sample_logits_is_null = (logits_handle == NULL);
  if (!(!gumbel_sample_logits_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample.logits is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_sample_idx_mapping_is_null = (idx_mapping_handle == NULL);
  if (!(!gumbel_sample_idx_mapping_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample.idx_mapping is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_sample_seeds_is_null = (seeds_handle == NULL);
  if (!(!gumbel_sample_seeds_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample.seeds is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_sample_pos_is_null = (pos_handle == NULL);
  if (!(!gumbel_sample_pos_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample.pos is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_sample_temperature_is_null = (temperature_handle == NULL);
  if (!(!gumbel_sample_temperature_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_sample.temperature is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_sample_cache_is_null = (cache_handle == NULL);
  bool gumbel_sample_cache_col_is_null = (cache_col_handle == NULL);
  void* gumbel_sample_local_argmax_shape = (((DLTensor*)local_argmax_handle)[0].shape);
  void* gumbel_sample_local_max_shape = (((DLTensor*)local_max_handle)[0].shape);
  void* gumbel_sample_logits_shape = (((DLTensor*)logits_handle)[0].shape);
  void* gumbel_sample_idx_mapping_shape = (((DLTensor*)idx_mapping_handle)[0].shape);
  void* gumbel_sample_seeds_shape = (((DLTensor*)seeds_handle)[0].shape);
  void* gumbel_sample_pos_shape = (((DLTensor*)pos_handle)[0].shape);
  void* gumbel_sample_temperature_shape = (((DLTensor*)temperature_handle)[0].shape);
  void* condval;
  if (!gumbel_sample_cache_is_null) {
    condval = (((DLTensor*)cache_handle)[0].shape);
  } else {
    uint64_t v_ = (uint64_t)0;
    condval = (*(void* *)(&(v_)));
  }
  void* gumbel_sample_cache_shape = condval;
  void* condval_1;
  if (!gumbel_sample_cache_col_is_null) {
    condval_1 = (((DLTensor*)cache_col_handle)[0].shape);
  } else {
    uint64_t v__1 = (uint64_t)0;
    condval_1 = (*(void* *)(&(v__1)));
  }
  void* gumbel_sample_cache_col_shape = condval_1;
  if (!(((((DLTensor*)local_argmax_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_argmax ndim mismatch, expected 2", (long long)((((DLTensor*)local_argmax_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable tokens requires at least one non-null buffer among: gumbel_sample.local_argmax, gumbel_sample.local_max, gumbel_sample.logits");
    return -1;
  }
  int32_t tokens = ((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[0]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable blocks requires at least one non-null buffer among: gumbel_sample.local_argmax, gumbel_sample.local_max");
    return -1;
  }
  int32_t blocks = ((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[1]);
  void* gumbel_sample_local_argmax_strides = (((DLTensor*)local_argmax_handle)[0].strides);
  int64_t condval_2;
  if ((gumbel_sample_local_argmax_strides == NULL)) {
    condval_2 = (int64_t)1;
  } else {
    condval_2 = ((int64_t*)gumbel_sample_local_argmax_strides)[0];
  }
  int64_t argmax_stride = condval_2;
  int32_t dev_id = (((DLTensor*)local_argmax_handle)[0].device.device_id);
  void* local_argmax = (((DLTensor*)local_argmax_handle)[0].data);
  if (!(((((DLTensor*)local_max_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_max ndim mismatch, expected 2", (long long)((((DLTensor*)local_max_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gumbel_sample_local_max_strides = (((DLTensor*)local_max_handle)[0].strides);
  int64_t condval_3;
  if ((gumbel_sample_local_max_strides == NULL)) {
    condval_3 = (int64_t)1;
  } else {
    condval_3 = ((int64_t*)gumbel_sample_local_max_strides)[0];
  }
  int64_t max_stride = condval_3;
  void* local_max = (((DLTensor*)local_max_handle)[0].data);
  if (!(((((DLTensor*)logits_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input logits ndim mismatch, expected 2", (long long)((((DLTensor*)logits_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t vocab = ((int32_t)((int64_t*)gumbel_sample_logits_shape)[1]);
  void* gumbel_sample_logits_strides = (((DLTensor*)logits_handle)[0].strides);
  int64_t condval_4;
  if ((gumbel_sample_logits_strides == NULL)) {
    condval_4 = (int64_t)1;
  } else {
    condval_4 = ((int64_t*)gumbel_sample_logits_strides)[0];
  }
  int64_t logits_stride = condval_4;
  void* logits = (((DLTensor*)logits_handle)[0].data);
  if (!(((((DLTensor*)idx_mapping_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input idx_mapping ndim mismatch, expected 1", (long long)((((DLTensor*)idx_mapping_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t idx_len = ((int32_t)((int64_t*)gumbel_sample_idx_mapping_shape)[0]);
  void* gumbel_sample_idx_mapping_strides = (((DLTensor*)idx_mapping_handle)[0].strides);
  void* idx_mapping = (((DLTensor*)idx_mapping_handle)[0].data);
  if (!(((((DLTensor*)seeds_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input seeds ndim mismatch, expected 1", (long long)((((DLTensor*)seeds_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t seed_len = ((int32_t)((int64_t*)gumbel_sample_seeds_shape)[0]);
  void* gumbel_sample_seeds_strides = (((DLTensor*)seeds_handle)[0].strides);
  void* seeds = (((DLTensor*)seeds_handle)[0].data);
  if (!(((((DLTensor*)pos_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input pos ndim mismatch, expected 1", (long long)((((DLTensor*)pos_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t pos_len = ((int32_t)((int64_t*)gumbel_sample_pos_shape)[0]);
  void* gumbel_sample_pos_strides = (((DLTensor*)pos_handle)[0].strides);
  void* pos = (((DLTensor*)pos_handle)[0].data);
  if (!(((((DLTensor*)temperature_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input temperature ndim mismatch, expected 1", (long long)((((DLTensor*)temperature_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t temp_len = ((int32_t)((int64_t*)gumbel_sample_temperature_shape)[0]);
  void* gumbel_sample_temperature_strides = (((DLTensor*)temperature_handle)[0].strides);
  void* temperature = (((DLTensor*)temperature_handle)[0].data);
  if (!((gumbel_sample_cache_is_null || ((((DLTensor*)cache_handle)[0].ndim) == 3)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache ndim mismatch, expected 3");
    return -1;
  }
  int32_t condval_5;
  if (!gumbel_sample_cache_is_null) {
    condval_5 = ((int32_t)((int64_t*)gumbel_sample_cache_shape)[0]);
  } else {
    condval_5 = 0;
  }
  int32_t cache_reqs = condval_5;
  int32_t condval_6;
  if (!gumbel_sample_cache_is_null) {
    condval_6 = ((int32_t)((int64_t*)gumbel_sample_cache_shape)[1]);
  } else {
    condval_6 = 0;
  }
  int32_t cache_cols = condval_6;
  int32_t condval_7;
  if (!gumbel_sample_cache_is_null) {
    condval_7 = ((int32_t)((int64_t*)gumbel_sample_cache_shape)[2]);
  } else {
    condval_7 = 0;
  }
  int32_t cache_vocab = condval_7;
  void* condval_8;
  if (!gumbel_sample_cache_is_null) {
    condval_8 = (((DLTensor*)cache_handle)[0].strides);
  } else {
    uint64_t v__2 = (uint64_t)0;
    condval_8 = (*(void* *)(&(v__2)));
  }
  void* gumbel_sample_cache_strides = condval_8;
  int64_t condval_9;
  if ((gumbel_sample_cache_strides == NULL)) {
    condval_9 = (int64_t)1;
  } else {
    condval_9 = ((int64_t*)gumbel_sample_cache_strides)[1];
  }
  int64_t cache_stride_1 = condval_9;
  int64_t condval_10;
  if ((gumbel_sample_cache_strides == NULL)) {
    condval_10 = (int64_t)1;
  } else {
    condval_10 = ((int64_t*)gumbel_sample_cache_strides)[0];
  }
  int64_t cache_stride_0 = condval_10;
  void* condval_11;
  if (!gumbel_sample_cache_is_null) {
    condval_11 = (((DLTensor*)cache_handle)[0].data);
  } else {
    uint64_t v__3 = (uint64_t)0;
    condval_11 = (*(void* *)(&(v__3)));
  }
  void* cache = condval_11;
  if (!((gumbel_sample_cache_col_is_null || ((((DLTensor*)cache_col_handle)[0].ndim) == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col ndim mismatch, expected 1");
    return -1;
  }
  int32_t condval_12;
  if (!gumbel_sample_cache_col_is_null) {
    condval_12 = ((int32_t)((int64_t*)gumbel_sample_cache_col_shape)[0]);
  } else {
    condval_12 = 0;
  }
  int32_t num_cols = condval_12;
  void* condval_13;
  if (!gumbel_sample_cache_col_is_null) {
    condval_13 = (((DLTensor*)cache_col_handle)[0].strides);
  } else {
    uint64_t v__4 = (uint64_t)0;
    condval_13 = (*(void* *)(&(v__4)));
  }
  void* gumbel_sample_cache_col_strides = condval_13;
  void* condval_14;
  if (!gumbel_sample_cache_col_is_null) {
    condval_14 = (((DLTensor*)cache_col_handle)[0].data);
  } else {
    uint64_t v__5 = (uint64_t)0;
    condval_14 = (*(void* *)(&(v__5)));
  }
  void* cache_col = condval_14;
  if (!(((((((DLTensor*)local_argmax_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)local_argmax_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)local_argmax_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_argmax dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_15;
  if ((gumbel_sample_local_argmax_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)gumbel_sample_local_argmax_strides)[1]);
  }
  if (!(((condval_15 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_argmax strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_argmax_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_argmax byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_argmax_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_argmax_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_argmax device_type mismatch, expected cuda", (long long)((((DLTensor*)local_argmax_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((tokens == 0) || (blocks == 0)) || !(local_argmax == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_argmax data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_max_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)local_max_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)local_max_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_max dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[0]) == ((int32_t)((int64_t*)gumbel_sample_local_max_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_max shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[0])), (long long)(((int32_t)((int64_t*)gumbel_sample_local_max_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[1]) == ((int32_t)((int64_t*)gumbel_sample_local_max_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_max shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[1])), (long long)(((int32_t)((int64_t*)gumbel_sample_local_max_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_16;
  if ((gumbel_sample_local_max_strides == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)gumbel_sample_local_max_strides)[1]);
  }
  if (!(((condval_16 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_max strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_max_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_max byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_max_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_max device_id violates packed ABI constraint", (long long)((((DLTensor*)local_max_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input local_max device_type mismatch, expected cuda", (long long)((((DLTensor*)local_max_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((tokens == 0) || (blocks == 0)) || !(local_max == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input local_max data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)logits_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)logits_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)logits_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input logits dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[0]) == ((int32_t)((int64_t*)gumbel_sample_logits_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input logits shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gumbel_sample_local_argmax_shape)[0])), (long long)(((int32_t)((int64_t*)gumbel_sample_logits_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_17;
  if ((gumbel_sample_logits_strides == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)gumbel_sample_logits_strides)[1]);
  }
  if (!(((condval_17 == 1) || (vocab == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input logits strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)logits_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input logits byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)logits_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input logits device_id violates packed ABI constraint", (long long)((((DLTensor*)logits_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input logits device_type mismatch, expected cuda", (long long)((((DLTensor*)logits_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((tokens == 0) || (vocab == 0)) || !(logits == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input logits data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)idx_mapping_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)idx_mapping_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)idx_mapping_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input idx_mapping dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_18;
  if ((gumbel_sample_idx_mapping_strides == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)gumbel_sample_idx_mapping_strides)[0]);
  }
  if (!(((condval_18 == 1) || (idx_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input idx_mapping strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)idx_mapping_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input idx_mapping byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)idx_mapping_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)idx_mapping_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input idx_mapping device_id violates packed ABI constraint", (long long)((((DLTensor*)idx_mapping_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)idx_mapping_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input idx_mapping device_type mismatch, expected cuda", (long long)((((DLTensor*)idx_mapping_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((idx_len == 0) || !(idx_mapping == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input idx_mapping data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)seeds_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)seeds_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)seeds_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input seeds dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_19;
  if ((gumbel_sample_seeds_strides == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)gumbel_sample_seeds_strides)[0]);
  }
  if (!(((condval_19 == 1) || (seed_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input seeds strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)seeds_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input seeds byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)seeds_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)seeds_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input seeds device_id violates packed ABI constraint", (long long)((((DLTensor*)seeds_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)seeds_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input seeds device_type mismatch, expected cuda", (long long)((((DLTensor*)seeds_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seed_len == 0) || !(seeds == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input seeds data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)pos_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)pos_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)pos_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input pos dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_20;
  if ((gumbel_sample_pos_strides == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)gumbel_sample_pos_strides)[0]);
  }
  if (!(((condval_20 == 1) || (pos_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input pos strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)pos_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input pos byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)pos_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pos_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input pos device_id violates packed ABI constraint", (long long)((((DLTensor*)pos_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pos_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input pos device_type mismatch, expected cuda", (long long)((((DLTensor*)pos_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((pos_len == 0) || !(pos == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input pos data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)temperature_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)temperature_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)temperature_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input temperature dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_21;
  if ((gumbel_sample_temperature_strides == NULL)) {
    condval_21 = 1;
  } else {
    condval_21 = ((int32_t)((int64_t*)gumbel_sample_temperature_strides)[0]);
  }
  if (!(((condval_21 == 1) || (temp_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input temperature strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)temperature_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input temperature byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)temperature_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input temperature device_id violates packed ABI constraint", (long long)((((DLTensor*)temperature_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_sample input temperature device_type mismatch, expected cuda", (long long)((((DLTensor*)temperature_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((temp_len == 0) || !(temperature == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input temperature data pointer is NULL");
    return -1;
  }
  uint8_t condval_22;
  if (!gumbel_sample_cache_is_null) {
    condval_22 = (((DLTensor*)cache_handle)[0].dtype.code);
  } else {
    condval_22 = (uint8_t)2;
  }
  uint8_t condval_23;
  if (!gumbel_sample_cache_is_null) {
    condval_23 = (((DLTensor*)cache_handle)[0].dtype.bits);
  } else {
    condval_23 = (uint8_t)32;
  }
  uint16_t condval_24;
  if (!gumbel_sample_cache_is_null) {
    condval_24 = (((DLTensor*)cache_handle)[0].dtype.lanes);
  } else {
    condval_24 = (uint16_t)1;
  }
  if (!((gumbel_sample_cache_is_null || (((condval_22 == (uint8_t)2) && (condval_23 == (uint8_t)32)) && (condval_24 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_25;
  if ((gumbel_sample_cache_strides == NULL)) {
    condval_25 = 1;
  } else {
    condval_25 = ((int32_t)((int64_t*)gumbel_sample_cache_strides)[2]);
  }
  if (!(((gumbel_sample_cache_is_null || (condval_25 == 1)) || (cache_vocab == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache strides[2] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_26;
  if (!gumbel_sample_cache_is_null) {
    condval_26 = (((DLTensor*)cache_handle)[0].byte_offset);
  } else {
    condval_26 = (uint64_t)0;
  }
  if (!((gumbel_sample_cache_is_null || ((uint64_t)0 == condval_26)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_27;
  if (!gumbel_sample_cache_is_null) {
    condval_27 = (((DLTensor*)cache_handle)[0].device.device_id);
  } else {
    condval_27 = 0;
  }
  if (!((gumbel_sample_cache_is_null || (condval_27 == (((DLTensor*)local_argmax_handle)[0].device.device_id))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_28;
  if (!gumbel_sample_cache_is_null) {
    condval_28 = (((DLTensor*)cache_handle)[0].device.device_type);
  } else {
    condval_28 = 0;
  }
  if (!((gumbel_sample_cache_is_null || (condval_28 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((((gumbel_sample_cache_is_null || (cache_reqs == 0)) || (cache_cols == 0)) || (cache_vocab == 0)) || !(cache == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache data pointer is NULL");
    return -1;
  }
  uint8_t condval_29;
  if (!gumbel_sample_cache_col_is_null) {
    condval_29 = (((DLTensor*)cache_col_handle)[0].dtype.code);
  } else {
    condval_29 = (uint8_t)0;
  }
  uint8_t condval_30;
  if (!gumbel_sample_cache_col_is_null) {
    condval_30 = (((DLTensor*)cache_col_handle)[0].dtype.bits);
  } else {
    condval_30 = (uint8_t)64;
  }
  uint16_t condval_31;
  if (!gumbel_sample_cache_col_is_null) {
    condval_31 = (((DLTensor*)cache_col_handle)[0].dtype.lanes);
  } else {
    condval_31 = (uint16_t)1;
  }
  if (!((gumbel_sample_cache_col_is_null || (((condval_29 == (uint8_t)0) && (condval_30 == (uint8_t)64)) && (condval_31 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_32;
  if ((gumbel_sample_cache_col_strides == NULL)) {
    condval_32 = 1;
  } else {
    condval_32 = ((int32_t)((int64_t*)gumbel_sample_cache_col_strides)[0]);
  }
  if (!(((gumbel_sample_cache_col_is_null || (condval_32 == 1)) || (num_cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_33;
  if (!gumbel_sample_cache_col_is_null) {
    condval_33 = (((DLTensor*)cache_col_handle)[0].byte_offset);
  } else {
    condval_33 = (uint64_t)0;
  }
  if (!((gumbel_sample_cache_col_is_null || ((uint64_t)0 == condval_33)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_34;
  if (!gumbel_sample_cache_col_is_null) {
    condval_34 = (((DLTensor*)cache_col_handle)[0].device.device_id);
  } else {
    condval_34 = 0;
  }
  if (!((gumbel_sample_cache_col_is_null || (condval_34 == (((DLTensor*)local_argmax_handle)[0].device.device_id))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_35;
  if (!gumbel_sample_cache_col_is_null) {
    condval_35 = (((DLTensor*)cache_col_handle)[0].device.device_type);
  } else {
    condval_35 = 0;
  }
  if (!((gumbel_sample_cache_col_is_null || (condval_35 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((gumbel_sample_cache_col_is_null || (num_cols == 0)) || !(cache_col == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_sample input cache_col data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (!(((logits_stride % (int64_t)16) == (int64_t)0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: logits_stride % T.int64(16) == T.int64(0)", (long long)((logits_stride % (int64_t)16)), (long long)((int64_t)0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (idx_mapping == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = idx_mapping;
  if (local_argmax == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = local_argmax;
  if (local_max == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = local_max;
  if (logits == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = logits;
  if (pos == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = pos;
  if (seeds == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = seeds;
  if (temperature == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = temperature;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = argmax_stride;
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)blocks);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = logits_stride;
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = max_stride;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)tokens);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)vocab);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)tokens);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)blocks);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[19].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].v_int64) = (int64_t)0;
  if (gumbel_sample_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "gumbel_sample_kernel", &gumbel_sample_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(gumbel_sample_kernel_packed, (TVMFFIAny*) stack_ffi_any, 19, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_gumbel_sample(self, args, num_args, result);
}
