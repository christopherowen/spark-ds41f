#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_swiglu_linear_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap W_desc, bfloat16_t* __restrict__ Y, int M);
extern "C" __global__ void __launch_bounds__(384, 1) vision_swiglu_linear_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap W_desc, bfloat16_t* __restrict__ Y, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* G_shared = ((void*)((char*)buf_dyn_shmem + 32768));
  void* U_shared = ((void*)((char*)buf_dyn_shmem + 49152));
  __shared__ __align__(16) uint64_t mbarrier_mem[12];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float gate[32];
  float up[32];
  bfloat16_t out[32];
  float gate_part[32];
  float up_part[32];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(A_desc);
    tl::prefetch_tma_descriptor(W_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(1);
    mbarrier[3].init(1);
    mbarrier[4].init(1);
    mbarrier[5].init(1);
    mbarrier[6].init(256);
    mbarrier[7].init(256);
    mbarrier[8].init(256);
    mbarrier[9].init(256);
    mbarrier[10].init(256);
    mbarrier[11].init(256);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int ko = 0; ko < 16; ++ko) {
      mbarrier[((ko & 1) + 6)].wait((((ko & 3) >> 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[(ko & 1)].arrive_and_expect_tx(16384);
        tl::tma_load(A_desc, mbarrier[(ko & 1)], (&(((bfloat16_t*)A_shared)[((ko & 1) * 8192)])), (ko * 64), (((int)blockIdx.y) * 128));
      }
      mbarrier[((ko & 1) + 8)].wait((((ko & 3) >> 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[((ko & 1) + 2)].arrive_and_expect_tx(8192);
        tl::tma_load(W_desc, mbarrier[((ko & 1) + 2)], (&(((bfloat16_t*)G_shared)[((ko & 1) * 4096)])), (ko * 64), (((int)blockIdx.x) * 64));
      }
      mbarrier[((ko & 1) + 10)].wait((((ko & 3) >> 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[((ko & 1) + 4)].arrive_and_expect_tx(8192);
        tl::tma_load(W_desc, mbarrier[((ko & 1) + 4)], (&(((bfloat16_t*)U_shared)[((ko & 1) * 4096)])), (ko * 64), ((((int)blockIdx.x) * 64) + 704));
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i = 0; i < 8; ++i) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(gate + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    #pragma unroll
    for (int i_1 = 0; i_1 < 8; ++i_1) {
      float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(up + (i_1 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    }
    for (int ko_1 = 0; ko_1 < 16; ++ko_1) {
      mbarrier[(ko_1 & 1)].wait(((ko_1 & 3) >> 1));
      mbarrier[((ko_1 & 1) + 2)].wait(((ko_1 & 3) >> 1));
      {
        bfloat16_t A_local[32];
        bfloat16_t B_local[8];
        #pragma unroll
        for (int i_2 = 0; i_2 < 8; ++i_2) {
          float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
          *(float4*)(gate_part + (i_2 * 4)) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
        }
        for (int ki = 0; ki < 4; ++ki) {
          #pragma unroll
          for (int i_3 = 0; i_3 < 4; ++i_3) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((ko_1 & 1) * 8192) + (((((int)threadIdx.x) & 63) >> 5) * 4096)) + (i_3 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_3 * 8)])));
          }
          tl::ptx_ldmatrix_x4((&(((bfloat16_t*)G_shared)[((((((((ko_1 & 1) * 4096) + ((((((int)threadIdx.x) >> 6) + 2) & 3) * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[0])));
          for (int i_4 = 0; i_4 < 4; ++i_4) {
            tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(gate_part + (i_4 * 8)), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + 0));
            tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(gate_part + ((i_4 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + 4));
          }
        }
      }
      mbarrier[((ko_1 & 1) + 8)].arrive();
      mbarrier[((ko_1 & 1) + 4)].wait(((ko_1 & 3) >> 1));
      {
        bfloat16_t A_local_1[32];
        bfloat16_t B_local_1[8];
        #pragma unroll
        for (int i_5 = 0; i_5 < 8; ++i_5) {
          float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
          *(float4*)(up_part + (i_5 * 4)) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
        }
        for (int ki_1 = 0; ki_1 < 4; ++ki_1) {
          #pragma unroll
          for (int i_6 = 0; i_6 < 4; ++i_6) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((ko_1 & 1) * 8192) + (((((int)threadIdx.x) & 63) >> 5) * 4096)) + (i_6 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local_1[(i_6 * 8)])));
          }
          tl::ptx_ldmatrix_x4((&(((bfloat16_t*)U_shared)[((((((((ko_1 & 1) * 4096) + ((((((int)threadIdx.x) >> 6) + 2) & 3) * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_1[0])));
          for (int i_7 = 0; i_7 < 4; ++i_7) {
            tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(up_part + (i_7 * 8)), reinterpret_cast<const unsigned*>(A_local_1 + (i_7 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + 0));
            tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(up_part + ((i_7 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local_1 + (i_7 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + 4));
          }
        }
      }
      mbarrier[((ko_1 & 1) + 6)].arrive();
      mbarrier[((ko_1 & 1) + 10)].arrive();
      #pragma unroll
      for (int i_8 = 0; i_8 < 8; ++i_8) {
        float4 __1;
          float4 v_ = *(float4*)(gate + (i_8 * 4));
          float4 v__1 = *(float4*)(gate_part + (i_8 * 4));
          *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
          *(float2*)(&(__1.z)) = tl::add2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
        *(float4*)(gate + (i_8 * 4)) = __1;
        float4 __2;
          float4 v__2 = *(float4*)(up + (i_8 * 4));
          float4 v__3 = *(float4*)(up_part + (i_8 * 4));
          *(float2*)(&(__2.x)) = tl::add2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
          *(float2*)(&(__2.z)) = tl::add2(*(float2*)(&(v__2.z)), *(float2*)(&(v__3.z)));
        *(float4*)(up + (i_8 * 4)) = __2;
      }
    }
    #pragma unroll
    for (int i_9 = 0; i_9 < 32; ++i_9) {
      out[i_9] = ((bfloat16_t)__fmul_rn(((float)((bfloat16_t)__fmul_rn(((float)((bfloat16_t)gate[i_9])), __fdiv_rn(0x1p+0f/*1.000000e+00*/, __fadd_rn(0x1p+0f/*1.000000e+00*/, __expf((((float)((bfloat16_t)gate[i_9])) * -0x1p+0f/*-1.000000e+00*/))))))), ((float)((bfloat16_t)up[i_9]))));
    }
    #pragma unroll
    for (int i_10 = 0; i_10 < 16; ++i_10) {
      if ((((((((int)blockIdx.y) * 128) + (((((int)threadIdx.x) & 63) >> 5) * 64)) + ((i_10 >> 2) * 16)) + ((i_10 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M) {
        *(uint1*)(Y + ((((((((((((int64_t)((int)blockIdx.y)) * (int64_t)90112) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)45056)) + ((((int64_t)i_10) >> (int64_t)2) * (int64_t)11264)) + ((((int64_t)i_10) & (int64_t)1) * (int64_t)5632)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)704)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)16)) + (((((int64_t)i_10) & (int64_t)3) >> (int64_t)1) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2)) - (int64_t)32)) = *(uint1*)(out + (i_10 * 2));
      }
    }
  }
}

