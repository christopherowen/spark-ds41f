#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/copy_sm100.h>
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void token_ranks_scores_kernel(const int* __restrict__ ids, const bfloat16_t* __restrict__ logits, int64_t* __restrict__ output, float* __restrict__ scores, const int* __restrict__ token_ids, int columns, int64_t id_col, int64_t id_row, int64_t id_stride, int rows);
extern "C" __global__ void __launch_bounds__(512, 1) token_ranks_scores_kernel(const int* __restrict__ ids, const bfloat16_t* __restrict__ logits, int64_t* __restrict__ output, float* __restrict__ scores, const int* __restrict__ token_ids, int columns, int64_t id_col, int64_t id_row, int64_t id_stride, int rows) {
  float selected[1];
  int counts[16];
  int total[1];
  extern __shared__ __align__(1024) int workspace[];
  bfloat16_t condval;
  if (((0 <= token_ids[(((int64_t)((int)blockIdx.x)) * id_stride)]) && (token_ids[(((int64_t)((int)blockIdx.x)) * id_stride)] < 129280))) {
    condval = logits[((((int64_t)((int)blockIdx.x)) * (int64_t)129280) + ((int64_t)token_ids[(((int64_t)((int)blockIdx.x)) * id_stride)]))];
  } else {
    condval = bfloat16_t(0x0p+0f/*0.000000e+00*/);
  }
  selected[0] = ((float)condval);
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    int broadcast_var = 0;
    *(int4*)(counts + (i * 4)) = make_int4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  for (int block = 0; block < 16; ++block) {
    bfloat16_t logits_local_cast[16];
    bfloat16_t broadcast_var_1 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    ulonglong4 condval_1;
    if ((((block * 32) + (((int)threadIdx.x) >> 4)) < 505)) {
      condval_1 = tl::load_global_256(&(*(ulonglong4*)(logits + (((((int64_t)((int)blockIdx.x)) * (int64_t)129280) + (((int64_t)block) * (int64_t)8192)) + (((int64_t)((int)threadIdx.x)) * (int64_t)16)))));
    } else {
      condval_1 = make_ulonglong4(tl::pack_bfloat16x4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1), tl::pack_bfloat16x4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1), tl::pack_bfloat16x4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1), tl::pack_bfloat16x4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1));
    }
    *(ulonglong4*)(logits_local_cast + 0) = condval_1;
    for (int i_1 = 0; i_1 < 4; ++i_1) {
      float broadcast_var_2 = -CUDART_INF_F;
      int4 __1;
        int4 v_ = *(int4*)(counts + (i_1 * 4));
        int4 __2;
        ushort4 __3;
          ushort4 v__1 = make_ushort4((((block * 32) + (((int)threadIdx.x) >> 4)) < 505), (((block * 32) + (((int)threadIdx.x) >> 4)) < 505), (((block * 32) + (((int)threadIdx.x) >> 4)) < 505), (((block * 32) + (((int)threadIdx.x) >> 4)) < 505));
          ushort4 __4;
            float4 v__2 = make_float4(selected[0], selected[0], selected[0], selected[0]);
            float4 condval_2;
            if ((((block * 32) + (((int)threadIdx.x) >> 4)) < 505)) {
              float4 __5;
              uint2 v__3 = *(uint2*)(logits_local_cast + (i_1 * 4));
              ((float2*)(&__5))[0] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__3))[0]);
              ((float2*)(&__5))[1] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__3))[1]);
              condval_2 = __5;
            } else {
              condval_2 = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
            }
            __4.x = (v__2.x<=condval_2.x);
            __4.y = (v__2.y<=condval_2.y);
            __4.z = (v__2.z<=condval_2.z);
            __4.w = (v__2.w<=condval_2.w);
          __3.x = (v__1.x & __4.x);
          __3.y = (v__1.y & __4.y);
          __3.z = (v__1.z & __4.z);
          __3.w = (v__1.w & __4.w);
        __2.x = (int)(__3.x);
        __2.y = (int)(__3.y);
        __2.z = (int)(__3.z);
        __2.w = (int)(__3.w);
        __1.x = (v_.x+__2.x);
        __1.y = (v_.y+__2.y);
        __1.z = (v_.z+__2.z);
        __1.w = (v_.w+__2.w);
      *(int4*)(counts + (i_1 * 4)) = __1;
    }
  }
  total[0] = 0;
  #pragma unroll
  for (int rv = 0; rv < 16; ++rv) {
    total[0] = (total[0] + counts[rv]);
  }
  total[0] = tl::AllReduce<tl::SumOp, 512, 1, 0, tl::NamedBarrier<512>>::run(total[0], (&(workspace[0])));
  output[((int64_t)((int)blockIdx.x))] = ((int64_t)total[0]);
  for (int group = 0; group < ((columns + 511) >> 9); ++group) {
    if (((group * 512) + ((int)threadIdx.x)) < columns) {
      bfloat16_t condval_3;
      if (((0 <= ids[((((int64_t)((int)blockIdx.x)) * id_row) + (((((int64_t)group) * (int64_t)512) + ((int64_t)((int)threadIdx.x))) * id_col))]) && (ids[((((int64_t)((int)blockIdx.x)) * id_row) + (((((int64_t)group) * (int64_t)512) + ((int64_t)((int)threadIdx.x))) * id_col))] < 129280))) {
        condval_3 = logits[((((int64_t)((int)blockIdx.x)) * (int64_t)129280) + ((int64_t)ids[((((int64_t)((int)blockIdx.x)) * id_row) + (((((int64_t)group) * (int64_t)512) + ((int64_t)((int)threadIdx.x))) * id_col))]))];
      } else {
        condval_3 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
      }
      scores[(((((int64_t)group) * (int64_t)512) + (((int64_t)((int)blockIdx.x)) * ((int64_t)columns))) + ((int64_t)((int)threadIdx.x)))] = ((float)condval_3);
    }
  }
}

