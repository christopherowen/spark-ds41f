// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* collectives_rank_order_sum_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_collectives_rank_order_sum(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_collectives_rank_order_sum(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[14];
  void* stack_ffi_any = stack;
  if (!((num_args == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "collectives_rank_order_sum: num_args should be 8", (long long)(num_args), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum: args pointer is NULL");
    return -1;
  }
  int32_t s0_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((s0_handle_type_index == 0) || (s0_handle_type_index == 4)) || (s0_handle_type_index == 7)) || (64 <= s0_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input s0 expected pointer or tensor handle");
    return -1;
  }
  int32_t s1_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((s1_handle_type_index == 0) || (s1_handle_type_index == 4)) || (s1_handle_type_index == 7)) || (64 <= s1_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src expected pointer or tensor handle");
    return -1;
  }
  int32_t s2_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((s2_handle_type_index == 0) || (s2_handle_type_index == 4)) || (s2_handle_type_index == 7)) || (64 <= s2_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src expected pointer or tensor handle");
    return -1;
  }
  int32_t s3_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((s3_handle_type_index == 0) || (s3_handle_type_index == 4)) || (s3_handle_type_index == 7)) || (64 <= s3_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src expected pointer or tensor handle");
    return -1;
  }
  int32_t s4_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((s4_handle_type_index == 0) || (s4_handle_type_index == 4)) || (s4_handle_type_index == 7)) || (64 <= s4_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src expected pointer or tensor handle");
    return -1;
  }
  int32_t s5_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((s5_handle_type_index == 0) || (s5_handle_type_index == 4)) || (s5_handle_type_index == 7)) || (64 <= s5_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src expected pointer or tensor handle");
    return -1;
  }
  int32_t s6_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((s6_handle_type_index == 0) || (s6_handle_type_index == 4)) || (s6_handle_type_index == 7)) || (64 <= s6_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src expected pointer or tensor handle");
    return -1;
  }
  int32_t out_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((out_handle_type_index == 0) || (out_handle_type_index == 4)) || (out_handle_type_index == 7)) || (64 <= out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input out expected pointer or tensor handle");
    return -1;
  }
  void* s0_handle = ((s0_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* s1_handle = ((s1_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* s2_handle = ((s2_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* s3_handle = ((s3_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* s4_handle = ((s4_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* s5_handle = ((s5_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* s6_handle = ((s6_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* out_handle = ((out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  bool collectives_rank_order_sum_s0_is_null = (s0_handle == NULL);
  if (!(!collectives_rank_order_sum_s0_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.s0 is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_sum_src_is_null = (s1_handle == NULL);
  if (!(!collectives_rank_order_sum_src_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.src is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_sum_src_is_null_1 = (s2_handle == NULL);
  if (!(!collectives_rank_order_sum_src_is_null_1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.src is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_sum_src_is_null_2 = (s3_handle == NULL);
  if (!(!collectives_rank_order_sum_src_is_null_2)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.src is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_sum_src_is_null_3 = (s4_handle == NULL);
  if (!(!collectives_rank_order_sum_src_is_null_3)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.src is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_sum_src_is_null_4 = (s5_handle == NULL);
  if (!(!collectives_rank_order_sum_src_is_null_4)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.src is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_sum_src_is_null_5 = (s6_handle == NULL);
  if (!(!collectives_rank_order_sum_src_is_null_5)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.src is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_order_sum_out_is_null = (out_handle == NULL);
  if (!(!collectives_rank_order_sum_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_order_sum.out is expected to have non-NULL pointer");
    return -1;
  }
  void* collectives_rank_order_sum_s0_shape = (((DLTensor*)s0_handle)[0].shape);
  void* collectives_rank_order_sum_src_shape = (((DLTensor*)s1_handle)[0].shape);
  void* collectives_rank_order_sum_src_shape_1 = (((DLTensor*)s2_handle)[0].shape);
  void* collectives_rank_order_sum_src_shape_2 = (((DLTensor*)s3_handle)[0].shape);
  void* collectives_rank_order_sum_src_shape_3 = (((DLTensor*)s4_handle)[0].shape);
  void* collectives_rank_order_sum_src_shape_4 = (((DLTensor*)s5_handle)[0].shape);
  void* collectives_rank_order_sum_src_shape_5 = (((DLTensor*)s6_handle)[0].shape);
  void* collectives_rank_order_sum_out_shape = (((DLTensor*)out_handle)[0].shape);
  if (!(((((DLTensor*)s0_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input s0 ndim mismatch, expected 2", (long long)((((DLTensor*)s0_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable m requires at least one non-null buffer among: collectives_rank_order_sum.s0, collectives_rank_order_sum.src, collectives_rank_order_sum.src, collectives_rank_order_sum.src, collectives_rank_order_sum.src, collectives_rank_order_sum.src, collectives_rank_order_sum.src, collectives_rank_order_sum.out");
    return -1;
  }
  int32_t m = ((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]);
  void* collectives_rank_order_sum_s0_strides = (((DLTensor*)s0_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)s0_handle)[0].device.device_id);
  void* s0 = (((DLTensor*)s0_handle)[0].data);
  if (!(((((DLTensor*)s1_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src ndim mismatch, expected 2", (long long)((((DLTensor*)s1_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_sum_src_strides = (((DLTensor*)s1_handle)[0].strides);
  void* src = (((DLTensor*)s1_handle)[0].data);
  if (!(((((DLTensor*)s2_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src ndim mismatch, expected 2", (long long)((((DLTensor*)s2_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_sum_src_strides_1 = (((DLTensor*)s2_handle)[0].strides);
  void* src_1 = (((DLTensor*)s2_handle)[0].data);
  if (!(((((DLTensor*)s3_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src ndim mismatch, expected 2", (long long)((((DLTensor*)s3_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_sum_src_strides_2 = (((DLTensor*)s3_handle)[0].strides);
  void* src_2 = (((DLTensor*)s3_handle)[0].data);
  if (!(((((DLTensor*)s4_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src ndim mismatch, expected 2", (long long)((((DLTensor*)s4_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_sum_src_strides_3 = (((DLTensor*)s4_handle)[0].strides);
  void* src_3 = (((DLTensor*)s4_handle)[0].data);
  if (!(((((DLTensor*)s5_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src ndim mismatch, expected 2", (long long)((((DLTensor*)s5_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_sum_src_strides_4 = (((DLTensor*)s5_handle)[0].strides);
  void* src_4 = (((DLTensor*)s5_handle)[0].data);
  if (!(((((DLTensor*)s6_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src ndim mismatch, expected 2", (long long)((((DLTensor*)s6_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_sum_src_strides_5 = (((DLTensor*)s6_handle)[0].strides);
  void* src_5 = (((DLTensor*)s6_handle)[0].data);
  if (!(((((DLTensor*)out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input out ndim mismatch, expected 2", (long long)((((DLTensor*)out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* collectives_rank_order_sum_out_strides = (((DLTensor*)out_handle)[0].strides);
  void* out = (((DLTensor*)out_handle)[0].data);
  if (!(((((((DLTensor*)s0_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)s0_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)s0_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input s0 dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input s0 shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((collectives_rank_order_sum_s0_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)collectives_rank_order_sum_s0_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((collectives_rank_order_sum_s0_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)collectives_rank_order_sum_s0_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input s0 strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((collectives_rank_order_sum_s0_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)collectives_rank_order_sum_s0_strides)[0]);
  }
  if (!(((condval_2 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input s0 strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s0_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input s0 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s0_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s0_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input s0 device_type mismatch, expected cuda", (long long)((((DLTensor*)s0_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(s0 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input s0 data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s1_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)s1_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)s1_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((collectives_rank_order_sum_src_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((collectives_rank_order_sum_src_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((collectives_rank_order_sum_src_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides)[0]);
  }
  if (!(((condval_5 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s1_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s1_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s1_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_id violates packed ABI constraint", (long long)((((DLTensor*)s1_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s1_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_type mismatch, expected cuda", (long long)((((DLTensor*)s1_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(src == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s2_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)s2_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)s2_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((collectives_rank_order_sum_src_strides_1 == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_1)[1]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((collectives_rank_order_sum_src_strides_1 == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_1)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src strides[1] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((collectives_rank_order_sum_src_strides_1 == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_1)[0]);
  }
  if (!(((condval_8 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s2_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s2_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s2_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_id violates packed ABI constraint", (long long)((((DLTensor*)s2_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s2_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_type mismatch, expected cuda", (long long)((((DLTensor*)s2_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(src_1 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s3_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)s3_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)s3_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((collectives_rank_order_sum_src_strides_2 == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_2)[1]);
  }
  if (!((condval_9 == 1))) {
    int32_t condval_10;
    if ((collectives_rank_order_sum_src_strides_2 == NULL)) {
      condval_10 = 1;
    } else {
      condval_10 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_2)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src strides[1] violates packed ABI constraint", (long long)(condval_10), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((collectives_rank_order_sum_src_strides_2 == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_2)[0]);
  }
  if (!(((condval_11 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s3_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s3_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s3_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_id violates packed ABI constraint", (long long)((((DLTensor*)s3_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s3_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_type mismatch, expected cuda", (long long)((((DLTensor*)s3_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(src_2 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s4_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)s4_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)s4_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((collectives_rank_order_sum_src_strides_3 == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_3)[1]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((collectives_rank_order_sum_src_strides_3 == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_3)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src strides[1] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_14;
  if ((collectives_rank_order_sum_src_strides_3 == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_3)[0]);
  }
  if (!(((condval_14 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s4_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s4_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s4_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_id violates packed ABI constraint", (long long)((((DLTensor*)s4_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s4_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_type mismatch, expected cuda", (long long)((((DLTensor*)s4_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(src_3 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s5_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)s5_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)s5_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_15;
  if ((collectives_rank_order_sum_src_strides_4 == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_4)[1]);
  }
  if (!((condval_15 == 1))) {
    int32_t condval_16;
    if ((collectives_rank_order_sum_src_strides_4 == NULL)) {
      condval_16 = 1;
    } else {
      condval_16 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_4)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src strides[1] violates packed ABI constraint", (long long)(condval_16), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_17;
  if ((collectives_rank_order_sum_src_strides_4 == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_4)[0]);
  }
  if (!(((condval_17 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s5_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s5_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s5_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_id violates packed ABI constraint", (long long)((((DLTensor*)s5_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s5_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_type mismatch, expected cuda", (long long)((((DLTensor*)s5_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(src_4 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)s6_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)s6_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)s6_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_src_shape_5)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_18;
  if ((collectives_rank_order_sum_src_strides_5 == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_5)[1]);
  }
  if (!((condval_18 == 1))) {
    int32_t condval_19;
    if ((collectives_rank_order_sum_src_strides_5 == NULL)) {
      condval_19 = 1;
    } else {
      condval_19 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_5)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src strides[1] violates packed ABI constraint", (long long)(condval_19), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_20;
  if ((collectives_rank_order_sum_src_strides_5 == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)collectives_rank_order_sum_src_strides_5)[0]);
  }
  if (!(((condval_20 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)s6_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)s6_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s6_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_id violates packed ABI constraint", (long long)((((DLTensor*)s6_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)s6_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input src device_type mismatch, expected cuda", (long long)((((DLTensor*)s6_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(src_5 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)out_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input out dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0]) == ((int32_t)((int64_t*)collectives_rank_order_sum_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_s0_shape)[0])), (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)collectives_rank_order_sum_out_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)collectives_rank_order_sum_out_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_21;
  if ((collectives_rank_order_sum_out_strides == NULL)) {
    condval_21 = 1;
  } else {
    condval_21 = ((int32_t)((int64_t*)collectives_rank_order_sum_out_strides)[1]);
  }
  if (!((condval_21 == 1))) {
    int32_t condval_22;
    if ((collectives_rank_order_sum_out_strides == NULL)) {
      condval_22 = 1;
    } else {
      condval_22 = ((int32_t)((int64_t*)collectives_rank_order_sum_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input out strides[1] violates packed ABI constraint", (long long)(condval_22), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_23;
  if ((collectives_rank_order_sum_out_strides == NULL)) {
    condval_23 = 1;
  } else {
    condval_23 = ((int32_t)((int64_t*)collectives_rank_order_sum_out_strides)[0]);
  }
  if (!(((condval_23 == 8) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_id) == (((DLTensor*)s0_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input out device_id violates packed ABI constraint", (long long)((((DLTensor*)out_handle)[0].device.device_id)), (long long)((((DLTensor*)s0_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_order_sum input out device_type mismatch, expected cuda", (long long)((((DLTensor*)out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_order_sum input out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = out;
  if (s0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = s0;
  if (src == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = src;
  if (src_1 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = src_1;
  if (src_2 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = src_2;
  if (src_3 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = src_3;
  if (src_4 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = src_4;
  if (src_5 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = src_5;
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)m);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)((m + 255) >> 8));
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = (int64_t)0;
  if (collectives_rank_order_sum_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "collectives_rank_order_sum_kernel", &collectives_rank_order_sum_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(collectives_rank_order_sum_kernel_packed, (TVMFFIAny*) stack_ffi_any, 13, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_collectives_rank_order_sum(self, args, num_args, result);
}
