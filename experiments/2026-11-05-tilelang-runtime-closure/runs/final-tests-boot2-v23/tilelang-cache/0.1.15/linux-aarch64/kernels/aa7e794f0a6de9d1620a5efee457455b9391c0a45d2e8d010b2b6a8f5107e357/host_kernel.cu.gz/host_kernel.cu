// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vision_gemv_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_gemv(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_gemv(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[12];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vision_gemv: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_gemv: args pointer is NULL");
    return -1;
  }
  int32_t A_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((A_handle_type_index == 0) || (A_handle_type_index == 4)) || (A_handle_type_index == 7)) || (64 <= A_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input A expected pointer or tensor handle");
    return -1;
  }
  int32_t W_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((W_handle_type_index == 0) || (W_handle_type_index == 4)) || (W_handle_type_index == 7)) || (64 <= W_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input W expected pointer or tensor handle");
    return -1;
  }
  int32_t Bias_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((Bias_handle_type_index == 0) || (Bias_handle_type_index == 4)) || (Bias_handle_type_index == 7)) || (64 <= Bias_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input Bias expected pointer or tensor handle");
    return -1;
  }
  int32_t C_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((C_handle_type_index == 0) || (C_handle_type_index == 4)) || (C_handle_type_index == 7)) || (64 <= C_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input C expected pointer or tensor handle");
    return -1;
  }
  void* A_handle = ((A_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* W_handle = ((W_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* Bias_handle = ((Bias_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* C_handle = ((C_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool vision_gemv_A_is_null = (A_handle == NULL);
  if (!(!vision_gemv_A_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_gemv.A is expected to have non-NULL pointer");
    return -1;
  }
  bool vision_gemv_W_is_null = (W_handle == NULL);
  if (!(!vision_gemv_W_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_gemv.W is expected to have non-NULL pointer");
    return -1;
  }
  bool vision_gemv_Bias_is_null = (Bias_handle == NULL);
  if (!(!vision_gemv_Bias_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_gemv.Bias is expected to have non-NULL pointer");
    return -1;
  }
  bool vision_gemv_C_is_null = (C_handle == NULL);
  if (!(!vision_gemv_C_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_gemv.C is expected to have non-NULL pointer");
    return -1;
  }
  void* vision_gemv_A_shape = (((DLTensor*)A_handle)[0].shape);
  void* vision_gemv_W_shape = (((DLTensor*)W_handle)[0].shape);
  void* vision_gemv_Bias_shape = (((DLTensor*)Bias_handle)[0].shape);
  void* vision_gemv_C_shape = (((DLTensor*)C_handle)[0].shape);
  if (!(((((DLTensor*)A_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input A ndim mismatch, expected 2", (long long)((((DLTensor*)A_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: vision_gemv.A, vision_gemv.C");
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vision_gemv_A_shape)[0]);
  void* vision_gemv_A_strides = (((DLTensor*)A_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)A_handle)[0].device.device_id);
  void* A = (((DLTensor*)A_handle)[0].data);
  if (!(((((DLTensor*)W_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W ndim mismatch, expected 2", (long long)((((DLTensor*)W_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vision_gemv_W_strides = (((DLTensor*)W_handle)[0].strides);
  void* W = (((DLTensor*)W_handle)[0].data);
  if (!(((((DLTensor*)Bias_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input Bias ndim mismatch, expected 1", (long long)((((DLTensor*)Bias_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vision_gemv_Bias_strides = (((DLTensor*)Bias_handle)[0].strides);
  void* Bias = (((DLTensor*)Bias_handle)[0].data);
  if (!(((((DLTensor*)C_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input C ndim mismatch, expected 2", (long long)((((DLTensor*)C_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vision_gemv_C_strides = (((DLTensor*)C_handle)[0].strides);
  void* C = (((DLTensor*)C_handle)[0].data);
  if (!(((((((DLTensor*)A_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)A_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)A_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input A dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_gemv_A_shape)[1]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input A shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_gemv_A_shape)[1])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vision_gemv_A_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vision_gemv_A_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vision_gemv_A_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vision_gemv_A_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input A strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vision_gemv_A_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vision_gemv_A_strides)[0]);
  }
  if (!(((condval_2 == 1024) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input A strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)A_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input A byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)A_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)A_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input A device_type mismatch, expected cuda", (long long)((((DLTensor*)A_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(A == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input A data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)W_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)W_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)W_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input W dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_gemv_W_shape)[0]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_gemv_W_shape)[0])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_gemv_W_shape)[1]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_gemv_W_shape)[1])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vision_gemv_W_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vision_gemv_W_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vision_gemv_W_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vision_gemv_W_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((vision_gemv_W_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)vision_gemv_W_strides)[0]);
  }
  if (!((condval_5 == 1024))) {
    int32_t condval_6;
    if ((vision_gemv_W_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)vision_gemv_W_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W strides[0] violates packed ABI constraint", (long long)(condval_6), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)W_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)W_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W device_id violates packed ABI constraint", (long long)((((DLTensor*)W_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input W device_type mismatch, expected cuda", (long long)((((DLTensor*)W_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(W == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input W data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Bias_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)Bias_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)Bias_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input Bias dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_gemv_Bias_shape)[0]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input Bias shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_gemv_Bias_shape)[0])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((vision_gemv_Bias_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)vision_gemv_Bias_strides)[0]);
  }
  if (!((condval_7 == 1))) {
    int32_t condval_8;
    if ((vision_gemv_Bias_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)vision_gemv_Bias_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input Bias strides[0] violates packed ABI constraint", (long long)(condval_8), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Bias_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input Bias byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Bias_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Bias_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input Bias device_id violates packed ABI constraint", (long long)((((DLTensor*)Bias_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Bias_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input Bias device_type mismatch, expected cuda", (long long)((((DLTensor*)Bias_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Bias == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input Bias data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)C_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)C_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)C_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input C dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_gemv_A_shape)[0]) == ((int32_t)((int64_t*)vision_gemv_C_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input C shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_gemv_A_shape)[0])), (long long)(((int32_t)((int64_t*)vision_gemv_C_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_gemv_C_shape)[1]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input C shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_gemv_C_shape)[1])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((vision_gemv_C_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)vision_gemv_C_strides)[1]);
  }
  if (!((condval_9 == 1))) {
    int32_t condval_10;
    if ((vision_gemv_C_strides == NULL)) {
      condval_10 = 1;
    } else {
      condval_10 = ((int32_t)((int64_t*)vision_gemv_C_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input C strides[1] violates packed ABI constraint", (long long)(condval_10), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((vision_gemv_C_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)vision_gemv_C_strides)[0]);
  }
  if (!(((condval_11 == 1024) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input C strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)C_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input C byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)C_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input C device_id violates packed ABI constraint", (long long)((((DLTensor*)C_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_gemv input C device_type mismatch, expected cuda", (long long)((((DLTensor*)C_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(C == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_gemv input C data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (A == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = A;
  if (Bias == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = Bias;
  if (C == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = C;
  if (W == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = W;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)1024);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)((M + 7) >> 3));
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = (int64_t)0;
  if (vision_gemv_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vision_gemv_kernel", &vision_gemv_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vision_gemv_kernel_packed, (TVMFFIAny*) stack_ffi_any, 11, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vision_gemv(self, args, num_args, result);
}
