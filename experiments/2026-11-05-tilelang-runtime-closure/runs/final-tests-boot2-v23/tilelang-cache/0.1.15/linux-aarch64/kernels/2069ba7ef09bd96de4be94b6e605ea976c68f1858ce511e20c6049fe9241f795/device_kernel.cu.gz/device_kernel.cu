#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gather_logits_kernel(const float* __restrict__ logits, float* __restrict__ output, const int* __restrict__ token_ids, int cols, int64_t id_col, int64_t id_row, int64_t logit_col, int64_t logit_row, int rows, int vocab);
extern "C" __global__ void __launch_bounds__(256, 1) gather_logits_kernel(const float* __restrict__ logits, float* __restrict__ output, const int* __restrict__ token_ids, int cols, int64_t id_col, int64_t id_row, int64_t logit_col, int64_t logit_row, int rows, int vocab) {
  signed char take = (signed char)0;
  float value = 0x0p+0f/*0.000000e+00*/;
  if (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) < (rows * cols)) {
    take = (signed char)1;
    value = -CUDART_INF_F;
    if ((bool)take) {
      int rmod = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rmod_1 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rdiv = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
      int condval_1;
      if (((((((0 <= cols) && (0 <= rmod)) || ((cols < 0) && (rmod <= 0))) ? rmod : (rmod + cols)) < cols) && (((int64_t)((((0 <= cols) && (0 <= rmod_1)) || ((cols < 0) && (rmod_1 <= 0))) ? rdiv : (rdiv - 1))) < ((int64_t)rows)))) {
        int rmod_2 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rdiv_1 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
        int rmod_3 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rmod_4 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rdiv_2 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
        int rmod_5 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        condval_1 = token_ids[((((int64_t)((((0 <= cols) && (0 <= rmod_4)) || ((cols < 0) && (rmod_4 <= 0))) ? rdiv_2 : (rdiv_2 - 1))) * id_row) + (((int64_t)((((0 <= cols) && (0 <= rmod_5)) || ((cols < 0) && (rmod_5 <= 0))) ? rmod_5 : (rmod_5 + cols))) * id_col))];
      } else {
        condval_1 = 0;
      }
      int rmod_6 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rmod_7 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rdiv_3 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
      int condval_2;
      if (((((((0 <= cols) && (0 <= rmod_6)) || ((cols < 0) && (rmod_6 <= 0))) ? rmod_6 : (rmod_6 + cols)) < cols) && (((int64_t)((((0 <= cols) && (0 <= rmod_7)) || ((cols < 0) && (rmod_7 <= 0))) ? rdiv_3 : (rdiv_3 - 1))) < ((int64_t)rows)))) {
        int rmod_8 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rdiv_4 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
        int rmod_9 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rmod_10 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rdiv_5 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
        int rmod_11 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        condval_2 = token_ids[((((int64_t)((((0 <= cols) && (0 <= rmod_10)) || ((cols < 0) && (rmod_10 <= 0))) ? rdiv_5 : (rdiv_5 - 1))) * id_row) + (((int64_t)((((0 <= cols) && (0 <= rmod_11)) || ((cols < 0) && (rmod_11 <= 0))) ? rmod_11 : (rmod_11 + cols))) * id_col))];
      } else {
        condval_2 = 0;
      }
      int rmod_12 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rdiv_6 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
      float condval;
      if ((((0 <= condval_1) && (condval_2 < vocab)) && (((int64_t)((((0 <= cols) && (0 <= rmod_12)) || ((cols < 0) && (rmod_12 <= 0))) ? rdiv_6 : (rdiv_6 - 1))) < ((int64_t)rows)))) {
        int rmod_13 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rdiv_7 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
        int rmod_14 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int condval_3;
        if ((((((0 <= cols) && (0 <= rmod_14)) || ((cols < 0) && (rmod_14 <= 0))) ? rmod_14 : (rmod_14 + cols)) < cols)) {
          int rmod_15 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          int rdiv_8 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
          int rmod_16 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          int rmod_17 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          int rdiv_9 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
          int rmod_18 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          condval_3 = token_ids[((((int64_t)((((0 <= cols) && (0 <= rmod_17)) || ((cols < 0) && (rmod_17 <= 0))) ? rdiv_9 : (rdiv_9 - 1))) * id_row) + (((int64_t)((((0 <= cols) && (0 <= rmod_18)) || ((cols < 0) && (rmod_18 <= 0))) ? rmod_18 : (rmod_18 + cols))) * id_col))];
        } else {
          condval_3 = 0;
        }
        int rmod_19 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int rdiv_10 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
        int rmod_20 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
        int condval_4;
        if ((((((0 <= cols) && (0 <= rmod_20)) || ((cols < 0) && (rmod_20 <= 0))) ? rmod_20 : (rmod_20 + cols)) < cols)) {
          int rmod_21 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          int rdiv_11 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
          int rmod_22 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          int rmod_23 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          int rdiv_12 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
          int rmod_24 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
          condval_4 = token_ids[((((int64_t)((((0 <= cols) && (0 <= rmod_23)) || ((cols < 0) && (rmod_23 <= 0))) ? rdiv_12 : (rdiv_12 - 1))) * id_row) + (((int64_t)((((0 <= cols) && (0 <= rmod_24)) || ((cols < 0) && (rmod_24 <= 0))) ? rmod_24 : (rmod_24 + cols))) * id_col))];
        } else {
          condval_4 = 0;
        }
        condval = logits[((((int64_t)((((0 <= cols) && (0 <= rmod_19)) || ((cols < 0) && (rmod_19 <= 0))) ? rdiv_10 : (rdiv_10 - 1))) * logit_row) + (((int64_t)condval_4) * logit_col))];
      } else {
        condval = 0x0p+0f/*0.000000e+00*/;
      }
      value = condval;
    }
    int rmod_25 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
    int rdiv_13 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
    if (((int64_t)((((0 <= cols) && (0 <= rmod_25)) || ((cols < 0) && (rmod_25 <= 0))) ? rdiv_13 : (rdiv_13 - 1))) < ((int64_t)rows)) {
      int rmod_26 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rdiv_14 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
      int rmod_27 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rmod_28 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      int rdiv_15 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) / cols);
      int rmod_29 = (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) % cols);
      output[((((int64_t)((((0 <= cols) && (0 <= rmod_28)) || ((cols < 0) && (rmod_28 <= 0))) ? rdiv_15 : (rdiv_15 - 1))) * ((int64_t)cols)) + ((int64_t)((((0 <= cols) && (0 <= rmod_29)) || ((cols < 0) && (rmod_29 <= 0))) ? rmod_29 : (rmod_29 + cols))))] = value;
    }
  }
}

