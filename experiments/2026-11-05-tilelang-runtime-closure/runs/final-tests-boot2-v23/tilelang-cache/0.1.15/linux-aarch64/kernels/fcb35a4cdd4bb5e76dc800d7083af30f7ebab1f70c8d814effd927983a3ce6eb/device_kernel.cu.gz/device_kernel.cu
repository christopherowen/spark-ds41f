#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void insert_kernel(int* __restrict__ counts, const int* __restrict__ cu, const int64_t* __restrict__ local_ids, const float* __restrict__ local_max, const int64_t* __restrict__ mapping, int64_t* __restrict__ sampled, const float* __restrict__ temperature, int requests);
extern "C" __global__ void insert_kernel(int* __restrict__ counts, const int* __restrict__ cu, const int64_t* __restrict__ local_ids, const float* __restrict__ local_max, const int64_t* __restrict__ mapping, int64_t* __restrict__ sampled, const float* __restrict__ temperature, int requests) {
  float best = 0x0p+0f/*0.000000e+00*/;
  int winner = 0;
  int count = counts[((int64_t)((int)blockIdx.x))];
  counts[((int64_t)((int)blockIdx.x))] = (count + 1);
  int position = (cu[((int64_t)((int)blockIdx.x))] + count);
  int64_t state = mapping[((int64_t)position)];
  if (0 < (((int)(temperature[state] != 0x0p+0f/*0.000000e+00*/)) | ((int)(position == (cu[(((int64_t)((int)blockIdx.x)) + (int64_t)1)] - 1))))) {
    best = -CUDART_INF_F;
  }
  if (0 < (((int)(temperature[state] != 0x0p+0f/*0.000000e+00*/)) | ((int)(position == (cu[(((int64_t)((int)blockIdx.x)) + (int64_t)1)] - 1))))) {
    winner = 0;
  }
  if (0 < (((int)(temperature[state] != 0x0p+0f/*0.000000e+00*/)) | ((int)(position == (cu[(((int64_t)((int)blockIdx.x)) + (int64_t)1)] - 1))))) {
    float value = local_max[((int64_t)((int)blockIdx.x))];
    bool if_condition = (best < value);
    if (if_condition) {
      best = value;
      winner = 0;
    }
  }
  if (0 < (((int)(temperature[state] != 0x0p+0f/*0.000000e+00*/)) | ((int)(position == (cu[(((int64_t)((int)blockIdx.x)) + (int64_t)1)] - 1))))) {
    sampled[((((int64_t)((int)blockIdx.x)) * (int64_t)4) + ((int64_t)count))] = local_ids[(((int64_t)((int)blockIdx.x)) + ((int64_t)winner))];
  }
}

