// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vocab_packed_markov_greedy_partials_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_markov_greedy_partials(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_markov_greedy_partials(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[19];
  void* stack_ffi_any = stack;
  if (!((num_args == 9))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vocab_packed_markov_greedy_partials: num_args should be 9", (long long)(num_args), (long long)(9));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials: args pointer is NULL");
    return -1;
  }
  int32_t A_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((A_handle_type_index == 0) || (A_handle_type_index == 4)) || (A_handle_type_index == 7)) || (64 <= A_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input A expected pointer or tensor handle");
    return -1;
  }
  int32_t W_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((W_handle_type_index == 0) || (W_handle_type_index == 4)) || (W_handle_type_index == 7)) || (64 <= W_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input W expected pointer or tensor handle");
    return -1;
  }
  int32_t exception_rows_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((exception_rows_handle_type_index == 0) || (exception_rows_handle_type_index == 4)) || (exception_rows_handle_type_index == 7)) || (64 <= exception_rows_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_rows expected pointer or tensor handle");
    return -1;
  }
  int32_t exception_entries_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((exception_entries_handle_type_index == 0) || (exception_entries_handle_type_index == 4)) || (exception_entries_handle_type_index == 7)) || (64 <= exception_entries_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_entries expected pointer or tensor handle");
    return -1;
  }
  int32_t row_offsets_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((row_offsets_handle_type_index == 0) || (row_offsets_handle_type_index == 4)) || (row_offsets_handle_type_index == 7)) || (64 <= row_offsets_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input row_offsets expected pointer or tensor handle");
    return -1;
  }
  int32_t Base_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((Base_handle_type_index == 0) || (Base_handle_type_index == 4)) || (Base_handle_type_index == 7)) || (64 <= Base_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input Base expected pointer or tensor handle");
    return -1;
  }
  int32_t partial_vals_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((partial_vals_handle_type_index == 0) || (partial_vals_handle_type_index == 4)) || (partial_vals_handle_type_index == 7)) || (64 <= partial_vals_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_vals expected pointer or tensor handle");
    return -1;
  }
  int32_t partial_idxs_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((partial_idxs_handle_type_index == 0) || (partial_idxs_handle_type_index == 4)) || (partial_idxs_handle_type_index == 7)) || (64 <= partial_idxs_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_idxs expected pointer or tensor handle");
    return -1;
  }
  int32_t vocab_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((vocab_type_index == 1) || (vocab_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials scalar vocab expected integer");
    return -1;
  }
  void* A_handle = ((A_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* W_handle = ((W_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* exception_rows_handle = ((exception_rows_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* exception_entries_handle = ((exception_entries_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* row_offsets_handle = ((row_offsets_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* Base_handle = ((Base_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* partial_vals_handle = ((partial_vals_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* partial_idxs_handle = ((partial_idxs_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  int32_t vocab = ((int32_t)(((TVMFFIAny*)args)[8].v_int64));
  bool vocab_packed_markov_greedy_partials_A_is_null = (A_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_A_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.A is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_markov_greedy_partials_W_is_null = (W_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_W_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.W is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_markov_greedy_partials_exception_rows_is_null = (exception_rows_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_exception_rows_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.exception_rows is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_markov_greedy_partials_exception_entries_is_null = (exception_entries_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_exception_entries_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.exception_entries is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_markov_greedy_partials_row_offsets_is_null = (row_offsets_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_row_offsets_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.row_offsets is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_markov_greedy_partials_Base_is_null = (Base_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_Base_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.Base is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_markov_greedy_partials_partial_vals_is_null = (partial_vals_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_partial_vals_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.partial_vals is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_markov_greedy_partials_partial_idxs_is_null = (partial_idxs_handle == NULL);
  if (!(!vocab_packed_markov_greedy_partials_partial_idxs_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_markov_greedy_partials.partial_idxs is expected to have non-NULL pointer");
    return -1;
  }
  void* vocab_packed_markov_greedy_partials_A_shape = (((DLTensor*)A_handle)[0].shape);
  void* vocab_packed_markov_greedy_partials_W_shape = (((DLTensor*)W_handle)[0].shape);
  void* vocab_packed_markov_greedy_partials_exception_rows_shape = (((DLTensor*)exception_rows_handle)[0].shape);
  void* vocab_packed_markov_greedy_partials_exception_entries_shape = (((DLTensor*)exception_entries_handle)[0].shape);
  void* vocab_packed_markov_greedy_partials_row_offsets_shape = (((DLTensor*)row_offsets_handle)[0].shape);
  void* vocab_packed_markov_greedy_partials_Base_shape = (((DLTensor*)Base_handle)[0].shape);
  void* vocab_packed_markov_greedy_partials_partial_vals_shape = (((DLTensor*)partial_vals_handle)[0].shape);
  void* vocab_packed_markov_greedy_partials_partial_idxs_shape = (((DLTensor*)partial_idxs_handle)[0].shape);
  if (!(((((DLTensor*)A_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input A ndim mismatch, expected 2", (long long)((((DLTensor*)A_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: vocab_packed_markov_greedy_partials.A, vocab_packed_markov_greedy_partials.Base, vocab_packed_markov_greedy_partials.partial_vals, vocab_packed_markov_greedy_partials.partial_idxs");
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[0]);
  void* vocab_packed_markov_greedy_partials_A_strides = (((DLTensor*)A_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)A_handle)[0].device.device_id);
  void* A = (((DLTensor*)A_handle)[0].data);
  if (!(((((DLTensor*)W_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W ndim mismatch, expected 2", (long long)((((DLTensor*)W_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_markov_greedy_partials_W_strides = (((DLTensor*)W_handle)[0].strides);
  void* W = (((DLTensor*)W_handle)[0].data);
  if (!(((((DLTensor*)exception_rows_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_rows ndim mismatch, expected 1", (long long)((((DLTensor*)exception_rows_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable E requires at least one non-null buffer among: vocab_packed_markov_greedy_partials.exception_rows, vocab_packed_markov_greedy_partials.exception_entries");
    return -1;
  }
  int32_t E = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_exception_rows_shape)[0]);
  void* vocab_packed_markov_greedy_partials_exception_rows_strides = (((DLTensor*)exception_rows_handle)[0].strides);
  void* exception_rows = (((DLTensor*)exception_rows_handle)[0].data);
  if (!(((((DLTensor*)exception_entries_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_entries ndim mismatch, expected 1", (long long)((((DLTensor*)exception_entries_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_markov_greedy_partials_exception_entries_strides = (((DLTensor*)exception_entries_handle)[0].strides);
  void* exception_entries = (((DLTensor*)exception_entries_handle)[0].data);
  if (!(((((DLTensor*)row_offsets_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input row_offsets ndim mismatch, expected 1", (long long)((((DLTensor*)row_offsets_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_markov_greedy_partials_row_offsets_strides = (((DLTensor*)row_offsets_handle)[0].strides);
  void* row_offsets = (((DLTensor*)row_offsets_handle)[0].data);
  if (!(((((DLTensor*)Base_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input Base ndim mismatch, expected 2", (long long)((((DLTensor*)Base_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_markov_greedy_partials_Base_strides = (((DLTensor*)Base_handle)[0].strides);
  int64_t condval;
  if ((vocab_packed_markov_greedy_partials_Base_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)vocab_packed_markov_greedy_partials_Base_strides)[0];
  }
  int64_t base_stride = condval;
  void* Base = (((DLTensor*)Base_handle)[0].data);
  if (!(((((DLTensor*)partial_vals_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_vals ndim mismatch, expected 2", (long long)((((DLTensor*)partial_vals_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_markov_greedy_partials_partial_vals_strides = (((DLTensor*)partial_vals_handle)[0].strides);
  void* partial_vals = (((DLTensor*)partial_vals_handle)[0].data);
  if (!(((((DLTensor*)partial_idxs_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_idxs ndim mismatch, expected 2", (long long)((((DLTensor*)partial_idxs_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_markov_greedy_partials_partial_idxs_strides = (((DLTensor*)partial_idxs_handle)[0].strides);
  void* partial_idxs = (((DLTensor*)partial_idxs_handle)[0].data);
  if (!(((((((DLTensor*)A_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)A_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)A_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input A dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input A shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_1;
  if ((vocab_packed_markov_greedy_partials_A_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_strides)[1]);
  }
  if (!((condval_1 == 1))) {
    int32_t condval_2;
    if ((vocab_packed_markov_greedy_partials_A_strides == NULL)) {
      condval_2 = 1;
    } else {
      condval_2 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input A strides[1] violates packed ABI constraint", (long long)(condval_2), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vocab_packed_markov_greedy_partials_A_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_strides)[0]);
  }
  if (!(((condval_3 == 256) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input A strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)A_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input A byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)A_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)A_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input A device_type mismatch, expected cuda", (long long)((((DLTensor*)A_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(A == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input A data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)W_handle)[0].dtype.code) == (uint8_t)1) && ((((DLTensor*)W_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)W_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input W dtype mismatch, expected uint8");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_shape)[0]) == 43136))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_shape)[0])), (long long)(43136));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_shape)[1]) == 384))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_shape)[1])), (long long)(384));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((vocab_packed_markov_greedy_partials_W_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_strides)[1]);
  }
  if (!((condval_4 == 1))) {
    int32_t condval_5;
    if ((vocab_packed_markov_greedy_partials_W_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W strides[1] violates packed ABI constraint", (long long)(condval_5), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((vocab_packed_markov_greedy_partials_W_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_strides)[0]);
  }
  if (!((condval_6 == 384))) {
    int32_t condval_7;
    if ((vocab_packed_markov_greedy_partials_W_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_W_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W strides[0] violates packed ABI constraint", (long long)(condval_7), (long long)(384));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)W_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)W_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W device_id violates packed ABI constraint", (long long)((((DLTensor*)W_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input W device_type mismatch, expected cuda", (long long)((((DLTensor*)W_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(W == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input W data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)exception_rows_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)exception_rows_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)exception_rows_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_rows dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_8;
  if ((vocab_packed_markov_greedy_partials_exception_rows_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_exception_rows_strides)[0]);
  }
  if (!(((condval_8 == 1) || (E == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_rows strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)exception_rows_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_rows byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)exception_rows_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_rows_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_rows device_id violates packed ABI constraint", (long long)((((DLTensor*)exception_rows_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_rows_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_rows device_type mismatch, expected cuda", (long long)((((DLTensor*)exception_rows_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((E == 0) || !(exception_rows == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_rows data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)exception_entries_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)exception_entries_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)exception_entries_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_entries dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_exception_rows_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_exception_entries_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_entries shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_exception_rows_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_exception_entries_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((vocab_packed_markov_greedy_partials_exception_entries_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_exception_entries_strides)[0]);
  }
  if (!(((condval_9 == 1) || (E == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_entries strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)exception_entries_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_entries byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)exception_entries_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_entries_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_entries device_id violates packed ABI constraint", (long long)((((DLTensor*)exception_entries_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_entries_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input exception_entries device_type mismatch, expected cuda", (long long)((((DLTensor*)exception_entries_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((E == 0) || !(exception_entries == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input exception_entries data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)row_offsets_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)row_offsets_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)row_offsets_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input row_offsets dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_row_offsets_shape)[0]) == 43137))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input row_offsets shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_row_offsets_shape)[0])), (long long)(43137));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((vocab_packed_markov_greedy_partials_row_offsets_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_row_offsets_strides)[0]);
  }
  if (!((condval_10 == 1))) {
    int32_t condval_11;
    if ((vocab_packed_markov_greedy_partials_row_offsets_strides == NULL)) {
      condval_11 = 1;
    } else {
      condval_11 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_row_offsets_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input row_offsets strides[0] violates packed ABI constraint", (long long)(condval_11), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)row_offsets_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input row_offsets byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)row_offsets_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)row_offsets_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input row_offsets device_id violates packed ABI constraint", (long long)((((DLTensor*)row_offsets_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)row_offsets_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input row_offsets device_type mismatch, expected cuda", (long long)((((DLTensor*)row_offsets_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(row_offsets == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input row_offsets data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Base_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Base_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Base_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input Base dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_Base_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input Base shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_Base_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_Base_shape)[1]) == 43136))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input Base shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_Base_shape)[1])), (long long)(43136));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((vocab_packed_markov_greedy_partials_Base_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_Base_strides)[1]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((vocab_packed_markov_greedy_partials_Base_strides == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_Base_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input Base strides[1] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Base_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input Base byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Base_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Base_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input Base device_id violates packed ABI constraint", (long long)((((DLTensor*)Base_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Base_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input Base device_type mismatch, expected cuda", (long long)((((DLTensor*)Base_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(Base == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input Base data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)partial_vals_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)partial_vals_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)partial_vals_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_vals dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_vals_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_vals shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_vals_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_vals_shape)[1]) == 1348))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_vals shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_vals_shape)[1])), (long long)(1348));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_14;
  if ((vocab_packed_markov_greedy_partials_partial_vals_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_vals_strides)[1]);
  }
  if (!((condval_14 == 1))) {
    int32_t condval_15;
    if ((vocab_packed_markov_greedy_partials_partial_vals_strides == NULL)) {
      condval_15 = 1;
    } else {
      condval_15 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_vals_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_vals strides[1] violates packed ABI constraint", (long long)(condval_15), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_16;
  if ((vocab_packed_markov_greedy_partials_partial_vals_strides == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_vals_strides)[0]);
  }
  if (!(((condval_16 == 1348) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_vals strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)partial_vals_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_vals byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)partial_vals_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)partial_vals_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_vals device_id violates packed ABI constraint", (long long)((((DLTensor*)partial_vals_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)partial_vals_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_vals device_type mismatch, expected cuda", (long long)((((DLTensor*)partial_vals_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(partial_vals == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_vals data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)partial_idxs_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)partial_idxs_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)partial_idxs_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_idxs dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_idxs_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_idxs shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_A_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_idxs_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_idxs_shape)[1]) == 1348))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_idxs shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_idxs_shape)[1])), (long long)(1348));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_17;
  if ((vocab_packed_markov_greedy_partials_partial_idxs_strides == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_idxs_strides)[1]);
  }
  if (!((condval_17 == 1))) {
    int32_t condval_18;
    if ((vocab_packed_markov_greedy_partials_partial_idxs_strides == NULL)) {
      condval_18 = 1;
    } else {
      condval_18 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_idxs_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_idxs strides[1] violates packed ABI constraint", (long long)(condval_18), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_19;
  if ((vocab_packed_markov_greedy_partials_partial_idxs_strides == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)vocab_packed_markov_greedy_partials_partial_idxs_strides)[0]);
  }
  if (!(((condval_19 == 1348) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_idxs strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)partial_idxs_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_idxs byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)partial_idxs_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)partial_idxs_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_idxs device_id violates packed ABI constraint", (long long)((((DLTensor*)partial_idxs_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)partial_idxs_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_markov_greedy_partials input partial_idxs device_type mismatch, expected cuda", (long long)((((DLTensor*)partial_idxs_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(partial_idxs == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_markov_greedy_partials input partial_idxs data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (A == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = A;
  if (Base == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = Base;
  if (W == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = W;
  if (exception_entries == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = exception_entries;
  if (exception_rows == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = exception_rows;
  if (partial_idxs == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = partial_idxs;
  if (partial_vals == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = partial_vals;
  if (row_offsets == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = row_offsets;
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)E);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = base_stride;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)vocab);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1348);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)((M + 15) >> 4));
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)18432);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = (int64_t)0;
  if (vocab_packed_markov_greedy_partials_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vocab_packed_markov_greedy_partials_kernel", &vocab_packed_markov_greedy_partials_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vocab_packed_markov_greedy_partials_kernel_packed, (TVMFFIAny*) stack_ffi_any, 18, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vocab_packed_markov_greedy_partials(self, args, num_args, result);
}
