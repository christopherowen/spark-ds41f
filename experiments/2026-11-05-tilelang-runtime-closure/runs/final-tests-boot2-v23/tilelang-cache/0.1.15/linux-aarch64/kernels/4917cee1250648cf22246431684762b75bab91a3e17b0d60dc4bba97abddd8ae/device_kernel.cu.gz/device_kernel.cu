#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_rope_qkv_kernel(const float* __restrict__ inv_freq, bfloat16_t* __restrict__ qkv, int M, int image_width);
extern "C" __global__ void __launch_bounds__(128, 1) vision_rope_qkv_kernel(const float* __restrict__ inv_freq, bfloat16_t* __restrict__ qkv, int M, int image_width) {
  extern __shared__ __align__(1024) float table[];
  bfloat16_t first[8];
  bfloat16_t second[8];
  bfloat16_t first_out[8];
  bfloat16_t second_out[8];
  if (((int)threadIdx.x) < 32) {
    int condval;
    if ((((int)threadIdx.x) < 16)) {
      int rmod = (((int)blockIdx.x) % image_width);
      int rdiv = (((int)blockIdx.x) / image_width);
      condval = ((((0 <= image_width) && (0 <= rmod)) || ((image_width < 0) && (rmod <= 0))) ? rdiv : (rdiv - 1));
    } else {
      int rmod_1 = (((int)blockIdx.x) % image_width);
      condval = ((((0 <= image_width) && (0 <= rmod_1)) || ((image_width < 0) && (rmod_1 <= 0))) ? rmod_1 : (rmod_1 + image_width));
    }
    table[((int)threadIdx.x)] = cosf(__fmul_rn(((float)condval), inv_freq[(((int)threadIdx.x) & 15)]));
    int condval_1;
    if ((((int)threadIdx.x) < 16)) {
      int rmod_2 = (((int)blockIdx.x) % image_width);
      int rdiv_1 = (((int)blockIdx.x) / image_width);
      condval_1 = ((((0 <= image_width) && (0 <= rmod_2)) || ((image_width < 0) && (rmod_2 <= 0))) ? rdiv_1 : (rdiv_1 - 1));
    } else {
      int rmod_3 = (((int)blockIdx.x) % image_width);
      condval_1 = ((((0 <= image_width) && (0 <= rmod_3)) || ((image_width < 0) && (rmod_3 <= 0))) ? rmod_3 : (rmod_3 + image_width));
    }
    table[(((int)threadIdx.x) + 32)] = sinf(__fmul_rn(((float)condval_1), inv_freq[(((int)threadIdx.x) & 15)]));
  }
  __syncthreads();
  if (((int)threadIdx.x) < 48) {
    *(uint4*)(first + 0) = *(uint4*)(qkv + (((((int64_t)((int)blockIdx.x)) * (int64_t)1152) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)8)));
    *(uint4*)(second + 0) = *(uint4*)(qkv + ((((((int64_t)((int)blockIdx.x)) * (int64_t)1152) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)8)) + (int64_t)32));
    #pragma unroll
    for (int v = 0; v < 8; ++v) {
      float x1 = ((float)first[v]);
      float x2 = ((float)second[v]);
      float cosine = table[(((((int)threadIdx.x) & 3) * 8) + v)];
      float sine = table[((((((int)threadIdx.x) & 3) * 8) + v) + 32)];
      first_out[v] = ((bfloat16_t)__fmaf_rn(x1, cosine, (__fmul_rn(x2, sine) * -0x1p+0f/*-1.000000e+00*/)));
      second_out[v] = ((bfloat16_t)__fmaf_rn(x2, cosine, __fmul_rn(x1, sine)));
    }
    *(uint4*)(qkv + (((((int64_t)((int)blockIdx.x)) * (int64_t)1152) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)8))) = *(uint4*)(first_out + 0);
    *(uint4*)(qkv + ((((((int64_t)((int)blockIdx.x)) * (int64_t)1152) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)8)) + (int64_t)32)) = *(uint4*)(second_out + 0);
  }
}

