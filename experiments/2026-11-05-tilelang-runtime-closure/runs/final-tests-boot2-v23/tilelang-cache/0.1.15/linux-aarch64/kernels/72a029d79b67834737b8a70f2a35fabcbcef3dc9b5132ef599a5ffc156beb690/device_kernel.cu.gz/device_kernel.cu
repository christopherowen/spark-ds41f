#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void flatten_sampled_kernel(const int* __restrict__ cu_num_logits, int64_t* __restrict__ flat, const int* __restrict__ num_sampled, const int64_t* __restrict__ sampled, int num_logits, int num_reqs, int sampled_stride, int width);
extern "C" __global__ void __launch_bounds__(128, 1) flatten_sampled_kernel(const int* __restrict__ cu_num_logits, int64_t* __restrict__ flat, const int* __restrict__ num_sampled, const int64_t* __restrict__ sampled, int num_logits, int num_reqs, int sampled_stride, int width) {
  int req = 0;
  req = -1;
  for (int r = 0; r < num_reqs; ++r) {
    if ((cu_num_logits[((int64_t)r)] <= ((((int)blockIdx.x) * 128) + ((int)threadIdx.x))) & (((((int)blockIdx.x) * 128) + ((int)threadIdx.x)) < cu_num_logits[(((int64_t)r) + (int64_t)1)])) {
      req = r;
    }
  }
  if (((((int)blockIdx.x) * 128) + ((int)threadIdx.x)) < num_logits) {
    if (0 <= req) {
      int i = (((((int)blockIdx.x) * 128) + ((int)threadIdx.x)) - cu_num_logits[req]);
      int64_t condval;
      if ((i < num_sampled[req])) {
        condval = sampled[(min(((int64_t)i), (((int64_t)width) - (int64_t)1)) + (((int64_t)req) * ((int64_t)sampled_stride)))];
      } else {
        condval = (int64_t)0;
      }
      flat[((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x)))] = condval;
    } else {
      flat[((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x)))] = (int64_t)0;
    }
  }
}

