// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vocab_packed_projection_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_projection(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_projection(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[15];
  void* stack_ffi_any = stack;
  if (!((num_args == 6))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vocab_packed_projection: num_args should be 6", (long long)(num_args), (long long)(6));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_projection: args pointer is NULL");
    return -1;
  }
  int32_t A_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((A_handle_type_index == 0) || (A_handle_type_index == 4)) || (A_handle_type_index == 7)) || (64 <= A_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input A expected pointer or tensor handle");
    return -1;
  }
  int32_t W_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((W_handle_type_index == 0) || (W_handle_type_index == 4)) || (W_handle_type_index == 7)) || (64 <= W_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input W expected pointer or tensor handle");
    return -1;
  }
  int32_t exception_rows_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((exception_rows_handle_type_index == 0) || (exception_rows_handle_type_index == 4)) || (exception_rows_handle_type_index == 7)) || (64 <= exception_rows_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_rows expected pointer or tensor handle");
    return -1;
  }
  int32_t exception_entries_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((exception_entries_handle_type_index == 0) || (exception_entries_handle_type_index == 4)) || (exception_entries_handle_type_index == 7)) || (64 <= exception_entries_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_entries expected pointer or tensor handle");
    return -1;
  }
  int32_t row_offsets_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((row_offsets_handle_type_index == 0) || (row_offsets_handle_type_index == 4)) || (row_offsets_handle_type_index == 7)) || (64 <= row_offsets_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input row_offsets expected pointer or tensor handle");
    return -1;
  }
  int32_t C_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((C_handle_type_index == 0) || (C_handle_type_index == 4)) || (C_handle_type_index == 7)) || (64 <= C_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input C expected pointer or tensor handle");
    return -1;
  }
  void* A_handle = ((A_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* W_handle = ((W_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* exception_rows_handle = ((exception_rows_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* exception_entries_handle = ((exception_entries_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* row_offsets_handle = ((row_offsets_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* C_handle = ((C_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  bool vocab_packed_projection_A_is_null = (A_handle == NULL);
  if (!(!vocab_packed_projection_A_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_projection.A is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_projection_W_is_null = (W_handle == NULL);
  if (!(!vocab_packed_projection_W_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_projection.W is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_projection_exception_rows_is_null = (exception_rows_handle == NULL);
  if (!(!vocab_packed_projection_exception_rows_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_projection.exception_rows is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_projection_exception_entries_is_null = (exception_entries_handle == NULL);
  if (!(!vocab_packed_projection_exception_entries_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_projection.exception_entries is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_projection_row_offsets_is_null = (row_offsets_handle == NULL);
  if (!(!vocab_packed_projection_row_offsets_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_projection.row_offsets is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_projection_C_is_null = (C_handle == NULL);
  if (!(!vocab_packed_projection_C_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_projection.C is expected to have non-NULL pointer");
    return -1;
  }
  void* vocab_packed_projection_A_shape = (((DLTensor*)A_handle)[0].shape);
  void* vocab_packed_projection_W_shape = (((DLTensor*)W_handle)[0].shape);
  void* vocab_packed_projection_exception_rows_shape = (((DLTensor*)exception_rows_handle)[0].shape);
  void* vocab_packed_projection_exception_entries_shape = (((DLTensor*)exception_entries_handle)[0].shape);
  void* vocab_packed_projection_row_offsets_shape = (((DLTensor*)row_offsets_handle)[0].shape);
  void* vocab_packed_projection_C_shape = (((DLTensor*)C_handle)[0].shape);
  if (!(((((DLTensor*)A_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input A ndim mismatch, expected 2", (long long)((((DLTensor*)A_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: vocab_packed_projection.A, vocab_packed_projection.C");
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vocab_packed_projection_A_shape)[0]);
  void* vocab_packed_projection_A_strides = (((DLTensor*)A_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)A_handle)[0].device.device_id);
  void* A = (((DLTensor*)A_handle)[0].data);
  if (!(((((DLTensor*)W_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W ndim mismatch, expected 2", (long long)((((DLTensor*)W_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_projection_W_strides = (((DLTensor*)W_handle)[0].strides);
  void* W = (((DLTensor*)W_handle)[0].data);
  if (!(((((DLTensor*)exception_rows_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_rows ndim mismatch, expected 1", (long long)((((DLTensor*)exception_rows_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable E requires at least one non-null buffer among: vocab_packed_projection.exception_rows, vocab_packed_projection.exception_entries");
    return -1;
  }
  int32_t E = ((int32_t)((int64_t*)vocab_packed_projection_exception_rows_shape)[0]);
  void* vocab_packed_projection_exception_rows_strides = (((DLTensor*)exception_rows_handle)[0].strides);
  void* exception_rows = (((DLTensor*)exception_rows_handle)[0].data);
  if (!(((((DLTensor*)exception_entries_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_entries ndim mismatch, expected 1", (long long)((((DLTensor*)exception_entries_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_projection_exception_entries_strides = (((DLTensor*)exception_entries_handle)[0].strides);
  void* exception_entries = (((DLTensor*)exception_entries_handle)[0].data);
  if (!(((((DLTensor*)row_offsets_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input row_offsets ndim mismatch, expected 1", (long long)((((DLTensor*)row_offsets_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_projection_row_offsets_strides = (((DLTensor*)row_offsets_handle)[0].strides);
  void* row_offsets = (((DLTensor*)row_offsets_handle)[0].data);
  if (!(((((DLTensor*)C_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input C ndim mismatch, expected 2", (long long)((((DLTensor*)C_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_projection_C_strides = (((DLTensor*)C_handle)[0].strides);
  void* C = (((DLTensor*)C_handle)[0].data);
  if (!(((((((DLTensor*)A_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)A_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)A_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input A dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_projection_A_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input A shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_projection_A_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vocab_packed_projection_A_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vocab_packed_projection_A_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vocab_packed_projection_A_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vocab_packed_projection_A_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input A strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vocab_packed_projection_A_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vocab_packed_projection_A_strides)[0]);
  }
  if (!(((condval_2 == 256) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input A strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)A_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input A byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)A_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)A_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input A device_type mismatch, expected cuda", (long long)((((DLTensor*)A_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(A == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input A data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)W_handle)[0].dtype.code) == (uint8_t)1) && ((((DLTensor*)W_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)W_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input W dtype mismatch, expected uint8");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_projection_W_shape)[0]) == 129280))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_projection_W_shape)[0])), (long long)(129280));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_projection_W_shape)[1]) == 384))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_projection_W_shape)[1])), (long long)(384));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vocab_packed_projection_W_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vocab_packed_projection_W_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vocab_packed_projection_W_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vocab_packed_projection_W_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((vocab_packed_projection_W_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)vocab_packed_projection_W_strides)[0]);
  }
  if (!((condval_5 == 384))) {
    int32_t condval_6;
    if ((vocab_packed_projection_W_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)vocab_packed_projection_W_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W strides[0] violates packed ABI constraint", (long long)(condval_6), (long long)(384));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)W_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)W_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W device_id violates packed ABI constraint", (long long)((((DLTensor*)W_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input W device_type mismatch, expected cuda", (long long)((((DLTensor*)W_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(W == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input W data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)exception_rows_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)exception_rows_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)exception_rows_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_rows dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_7;
  if ((vocab_packed_projection_exception_rows_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)vocab_packed_projection_exception_rows_strides)[0]);
  }
  if (!(((condval_7 == 1) || (E == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_rows strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)exception_rows_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_rows byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)exception_rows_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_rows_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_rows device_id violates packed ABI constraint", (long long)((((DLTensor*)exception_rows_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_rows_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_rows device_type mismatch, expected cuda", (long long)((((DLTensor*)exception_rows_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((E == 0) || !(exception_rows == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_rows data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)exception_entries_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)exception_entries_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)exception_entries_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_entries dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_projection_exception_rows_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_projection_exception_entries_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_entries shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_projection_exception_rows_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_projection_exception_entries_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((vocab_packed_projection_exception_entries_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)vocab_packed_projection_exception_entries_strides)[0]);
  }
  if (!(((condval_8 == 1) || (E == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_entries strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)exception_entries_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_entries byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)exception_entries_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_entries_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_entries device_id violates packed ABI constraint", (long long)((((DLTensor*)exception_entries_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_entries_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input exception_entries device_type mismatch, expected cuda", (long long)((((DLTensor*)exception_entries_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((E == 0) || !(exception_entries == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input exception_entries data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)row_offsets_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)row_offsets_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)row_offsets_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input row_offsets dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_projection_row_offsets_shape)[0]) == 129281))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input row_offsets shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_projection_row_offsets_shape)[0])), (long long)(129281));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((vocab_packed_projection_row_offsets_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)vocab_packed_projection_row_offsets_strides)[0]);
  }
  if (!((condval_9 == 1))) {
    int32_t condval_10;
    if ((vocab_packed_projection_row_offsets_strides == NULL)) {
      condval_10 = 1;
    } else {
      condval_10 = ((int32_t)((int64_t*)vocab_packed_projection_row_offsets_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input row_offsets strides[0] violates packed ABI constraint", (long long)(condval_10), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)row_offsets_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input row_offsets byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)row_offsets_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)row_offsets_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input row_offsets device_id violates packed ABI constraint", (long long)((((DLTensor*)row_offsets_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)row_offsets_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input row_offsets device_type mismatch, expected cuda", (long long)((((DLTensor*)row_offsets_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(row_offsets == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input row_offsets data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)C_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)C_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)C_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input C dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_projection_A_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_projection_C_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input C shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_projection_A_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_projection_C_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_projection_C_shape)[1]) == 129280))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input C shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_projection_C_shape)[1])), (long long)(129280));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((vocab_packed_projection_C_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)vocab_packed_projection_C_strides)[1]);
  }
  if (!((condval_11 == 1))) {
    int32_t condval_12;
    if ((vocab_packed_projection_C_strides == NULL)) {
      condval_12 = 1;
    } else {
      condval_12 = ((int32_t)((int64_t*)vocab_packed_projection_C_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input C strides[1] violates packed ABI constraint", (long long)(condval_12), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((vocab_packed_projection_C_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)vocab_packed_projection_C_strides)[0]);
  }
  if (!(((condval_13 == 129280) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input C strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)C_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input C byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)C_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input C device_id violates packed ABI constraint", (long long)((((DLTensor*)C_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_projection input C device_type mismatch, expected cuda", (long long)((((DLTensor*)C_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(C == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_projection input C data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (A == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = A;
  if (C == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = C;
  if (W == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = W;
  if (exception_entries == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = exception_entries;
  if (exception_rows == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = exception_rows;
  if (row_offsets == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = row_offsets;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)E);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)((M + 31) >> 5));
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)4040);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)22528);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = (int64_t)0;
  if (vocab_packed_projection_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vocab_packed_projection_kernel", &vocab_packed_projection_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vocab_packed_projection_kernel_packed, (TVMFFIAny*) stack_ffi_any, 14, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vocab_packed_projection(self, args, num_args, result);
}
