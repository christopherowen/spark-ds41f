
// Triton 3.5 philox_impl (triton/language/random.py) on 32-bit words, ten
// rounds; the first word.
__device__ __forceinline__ unsigned int vllm_philox(unsigned int c0, unsigned int c1,
                                                   unsigned int c2, unsigned int c3,
                                                   unsigned int k0, unsigned int k1) {
#pragma unroll
  for (int round = 0; round < 10; ++round) {
    const unsigned int a = c0;
    const unsigned int b = c2;
    c0 = __umulhi(0xCD9E8D57u, b) ^ c1 ^ k0;
    c2 = __umulhi(0xD2511F53u, a) ^ c3 ^ k1;
    c1 = 0xCD9E8D57u * b;
    c3 = 0xD2511F53u * a;
    k0 += 0x9E3779B9u;
    k1 += 0xBB67AE85u;
  }
  return c0;
}

// tl.randint(seed, offset) for an int64 seed and an int64 offset: the offset's
// low word, then its arithmetic high word.
__device__ __forceinline__ unsigned int vllm_randint64(long long seed,
                                                      long long offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox((unsigned int)offset, (unsigned int)(offset >> 32), 0u, 0u,
                     (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for an int64 seed and an int32 offset: Triton gives a
// 32-bit offset no high word.
__device__ __forceinline__ unsigned int vllm_randint64_offset32(long long seed,
                                                               unsigned int offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox(offset, 0u, 0u, 0u, (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for a uint32 seed (tl.randint's own result, widened
// with zeros) and an int32 offset (no high word).
__device__ __forceinline__ unsigned int vllm_randint32(unsigned int seed, int offset) {
  return vllm_philox((unsigned int)offset, 0u, 0u, 0u, seed, 0u);
}

// gumbel.py's FP32 noise of one Philox word, as Triton 3.5 compiles
// tl_rand32(includes_zero=False) and -tl.log(-tldevice.log1p(-u)) for sm_121a:
// uint_to_uniform_float, the clamp to _TL_RAND_MIN (0f2FFFFFFF), then libdevice's
// __nv_log1pf of 0 - u and __nv_logf of 0 - that, negated.
__device__ __forceinline__ float vllm_gumbel_noise(unsigned int word) {
  float noise;
  asm("{\n"
      ".reg .pred fin, inside, zero, tiny;\n"
      ".reg .b32 x, s, u, v, t, e, m, k, a, r, f, p, q, l, w, y, z, o;\n"
      // uint_to_uniform_float: where(x < 0, -x - 1, x) * 4.6566127342e-10
      "shr.s32 s, %1, 31;\n"
      "xor.b32 x, s, %1;\n"
      "cvt.rn.f32.s32 u, x;\n"
      "mul.rn.f32 u, u, 0f2FFFFFFF;\n"
      "max.f32 u, u, 0f2FFFFFFF;\n"
      // __nv_log1pf(v), v = 0 - u
      "sub.rn.f32 v, 0f00000000, u;\n"
      "add.rz.ftz.f32 t, v, 0f3F800000;\n"
      "add.s32 e, t, -1061158912;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, v, e;\n"
      "sub.s32 k, 1082130432, e;\n"
      "fma.rn.ftz.f32 a, 0f3E800000, k, 0fBF800000;\n"
      "add.rn.f32 r, a, m;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "mul.rn.f32 f, f, 0f34000000;\n"
      "fma.rn.ftz.f32 p, 0fBD39BF78, r, 0f3DD80012;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE0778E0;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E146475;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2A68DD;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CAF9E;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE800042;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAAE6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not a finite non-negative v: inside [-1, -0] keep, else fma(v, inf, inf);
      // then a zero v gives -0.
      "setp.lt.u32 fin, v, 2139095040;\n"
      "setp.lt.s32 inside, v, -1082130431;\n"
      "fma.rn.ftz.f32 w, v, 0f7F800000, 0f7F800000;\n"
      "selp.f32 w, l, w, inside;\n"
      "setp.eq.f32 zero, v, 0f00000000;\n"
      "selp.f32 w, 0f80000000, w, zero;\n"
      "selp.f32 l, l, w, fin;\n"
      // __nv_logf(y), y = 0 - log1p(v): subnormal y scaled by 2^23
      "sub.rn.f32 y, 0f00000000, l;\n"
      "setp.lt.f32 tiny, y, 0f00800000;\n"
      "mul.rn.f32 z, y, 0f4B000000;\n"
      "selp.f32 z, z, y, tiny;\n"
      "selp.f32 o, 0fC1B80000, 0f00000000, tiny;\n"
      "add.s32 e, z, -1059760811;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, z, e;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "fma.rn.ftz.f32 f, f, 0f34000000, o;\n"
      "add.rn.f32 r, m, 0fBF800000;\n"
      "fma.rn.ftz.f32 p, 0fBE055027, r, 0f3E1039F6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBDF8CDCC;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E0F2955;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2AD8B9;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CED0B;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE7FFF22;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAA78;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not finite non-negative: fma(z, inf, inf). The noise is 0 - logf(y), or
      // +inf where z is zero.
      "setp.lt.u32 fin, z, 2139095040;\n"
      "fma.rn.ftz.f32 w, z, 0f7F800000, 0f7F800000;\n"
      "selp.f32 l, l, w, fin;\n"
      "sub.rn.f32 l, 0f00000000, l;\n"
      "setp.eq.f32 zero, z, 0f00000000;\n"
      "selp.f32 %0, 0f7F800000, l, zero;\n"
      "}"
      : "=f"(noise)
      : "r"(word));
  return noise;
}

// A logit plus the noise of its word: Triton's FP32 add.
__device__ __forceinline__ float vllm_gumbel_score(float logit, unsigned int word) {
  const float noise = vllm_gumbel_noise(word);
  float score;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(score) : "f"(logit), "f"(noise));
  return score;
}

// Triton's FP32 `/`: div.full.f32.
__device__ __forceinline__ float vllm_div_full(float x, float y) {
  float q;
  asm("div.full.f32 %0, %1, %2;" : "=f"(q) : "f"(x), "f"(y));
  return q;
}

// dspark.greedy._first_argmax: keep (av, ai) over (bv, bi) when av is NaN and bv
// is not or has a higher index, or neither is NaN and av > bv, or av == bv with
// ai < bi: torch.argmax's first maximum, NaN above everything. Bitwise, not
// short-circuit, operators: every comparison is evaluated and combined in
// predicates, as Triton's tl.where combine is, instead of a branch for each.
__device__ __forceinline__ int vllm_first_argmax_keep(float av, int ai, float bv,
                                                      int bi) {
  const bool a_nan = av != av;
  const bool b_nan = bv != bv;
  return (a_nan & (!b_nan | (ai < bi))) |
         (!a_nan & !b_nan & ((av > bv) | ((av == bv) & (ai < bi))));
}

// tl.max(..., return_indices=True)'s combine (tie break to the left): keep
// (v, i) over (w, j) when v > w, or v == w and i < j. Comparisons with NaN are
// false. Compiled here, out of the TileLang simplifier's reach; bitwise
// operators, as above.
__device__ __forceinline__ int vllm_argmax_keep(float v, int i, float w, int j) {
  return (v > w) | ((v == w) & (i < j));
}

// tl.exp of an FP32 value: the product with log2(e), then ex2.approx.f32 without
// flush-to-zero (ptxas keeps subnormal results).
__device__ __forceinline__ float vllm_exp(float x) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "mul.rn.f32 t, %1, 0f3FB8AA3B;\n"
      "ex2.approx.f32 %0, t;\n"
      "}"
      : "=f"(y)
      : "f"(x));
  return y;
}

// FP32 arithmetic rounded to nearest, out of nvcc's contraction and the TileLang
// simplifier's reach.
__device__ __forceinline__ float vllm_add(float a, float b) {
  float c;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_sub(float a, float b) {
  float c;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_mul(float a, float b) {
  float c;
  asm("mul.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
// max.f32: a NaN gives way to the other operand.
__device__ __forceinline__ float vllm_max(float a, float b) {
  float c;
  asm("max.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}

// tl.exp(x - m).
__device__ __forceinline__ float vllm_exp_from(float x, float m) {
  return vllm_exp(vllm_sub(x, m));
}

// expm1 within an ULP: CUDA's (libdevice), compiled without fast math.
__device__ __forceinline__ float vllm_expm1(float x) { return expm1f(x); }

// Barron, Gnanapragasam and Tschannen's log-softmax ("A Fix for Softmax and
// Cross-Entropy", Eq. 5), from a row's maximum m. These compute every value and
// select, in PTX: a C conditional lets nvcc predicate the exponential instead,
// which costs a column several instructions.
//
// A logit's shift x - m, exactly 0 where x is the maximum (an infinite one
// included).
__device__ __forceinline__ float vllm_shifted(float x, float m) {
  float y;
  asm("{\n"
      ".reg .pred tie;\n"
      ".reg .b32 d;\n"
      "sub.rn.f32 d, %1, %2;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.f32 %0, 0f00000000, d, tie;\n"
      "}"
      : "=f"(y)
      : "f"(x), "f"(m));
  return y;
}

// tl.exp(x - m) of a column that is not the maximum (NaN is not), 0 for one that is.
__device__ __forceinline__ float vllm_other_exp(float x, float m) {
  float y;
  asm("{\n"
      ".reg .pred tie;\n"
      ".reg .b32 t, e;\n"
      "sub.rn.f32 t, %1, %2;\n"
      "mul.rn.f32 t, t, 0f3FB8AA3B;\n"
      "ex2.approx.f32 e, t;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.f32 %0, 0f00000000, e, tie;\n"
      "}"
      : "=f"(y)
      : "f"(x), "f"(m));
  return y;
}

// 1 for a column holding the maximum, else 0: its ties, counted exactly in FP32.
__device__ __forceinline__ float vllm_tie(float x, float m) {
  float y;
  asm("set.eq.f32.f32 %0, %1, %2;" : "=f"(y) : "f"(x), "f"(m));
  return y;
}

// int: x is the maximum m.
__device__ __forceinline__ int vllm_is_max(float x, float m) {
  int y;
  asm("{\n"
      ".reg .pred tie;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.s32 %0, 1, 0, tie;\n"
      "}"
      : "=r"(y)
      : "f"(x), "f"(m));
  return y;
}

// S, the others' sum: the columns that are not the maximum (sum), and of the
// maximum's ``ties`` all but one, exp(m - m) each (1; NaN for an infinite maximum,
// as the paper's z - z_max).
__device__ __forceinline__ float vllm_others(float sum, float ties, float m) {
  return ties > 1.0f
             ? vllm_add(sum, vllm_mul(vllm_sub(ties, 1.0f), vllm_exp_from(m, m)))
             : sum;
}

// A row's S from its block sums: NaN where its two or more columns are all -inf
// (the paper's z - z_max is -inf - -inf there, as in ``vllm_others``), which the
// block sums cannot tell, since a block whose maximum is -inf sums to 0.
__device__ __forceinline__ float vllm_row_others(float others, float m, int columns) {
  return (m == __uint_as_float(0xff800000u) && columns > 1)
             ? __uint_as_float(0x7fffffffu)
             : others;
}

// The log-sum-exp past the maximum, softplus(-margin) = log1p(S): CUDA's log1pf
// (libdevice, within an ULP).
__device__ __forceinline__ float vllm_softplus(float others) { return log1pf(others); }

// A sampled row's block sum of exponentials, kept while the block's maximum is
// above -inf (a NaN maximum is not), else 0.
__device__ __forceinline__ float vllm_live_sum(float m, float s) {
  float y;
  asm("{\n"
      ".reg .pred live;\n"
      "setp.gt.f32 live, %1, 0fFF800000;\n"
      "selp.f32 %0, %2, 0f00000000, live;\n"
      "}"
      : "=f"(y)
      : "f"(m), "f"(s));
  return y;
}

// A step of the cumulative log ratio: min(log_p + log_prob, 0), min.f32 (a NaN sum
// gives 0).
__device__ __forceinline__ float vllm_log_ratio(float log_p, float log_prob) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "add.rn.f32 t, %1, %2;\n"
      "min.f32 %0, t, 0f00000000;\n"
      "}"
      : "=f"(y)
      : "f"(log_p), "f"(log_prob));
  return y;
}

// tl_rand32(includes_zero=False) of a Philox word: uint_to_uniform_float, then the
// clamp to _TL_RAND_MIN (0f2FFFFFFF).
__device__ __forceinline__ float vllm_uniform(unsigned int word) {
  float u;
  asm("{\n"
      ".reg .b32 s, x, v;\n"
      "shr.s32 s, %1, 31;\n"
      "xor.b32 x, s, %1;\n"
      "cvt.rn.f32.s32 v, x;\n"
      "mul.rn.f32 v, v, 0f2FFFFFFF;\n"
      "max.f32 %0, v, 0f2FFFFFFF;\n"
      "}"
      : "=f"(u)
      : "r"(word));
  return u;
}

// Block verification's acceptance threshold for a one-hot draft followed by a valid
// one, from the logs of the prefix's joint ratio p and of the next draft's target
// probability m: the residual mass p (1 - m) over residual + 1 - p, which is
// 1 - p m. Both complements are -expm1 of a log, never 1 - x of a probability near
// 1, where it cancels (1 - m was 0 once m rounded to 1); the quotient is IEEE's,
// and the threshold 1 where the denominator is not positive (p = m = 1, or NaN).
__device__ __forceinline__ float vllm_block_threshold(float log_p, float log_m) {
  const float residual = vllm_mul(vllm_exp(log_p), -vllm_expm1(log_m));
  const float denom = -vllm_expm1(vllm_add(log_p, log_m));
  float ratio;
  asm("div.rn.f32 %0, %1, %2;" : "=f"(ratio) : "f"(residual), "f"(denom));
  return denom > 0.0f ? ratio : 1.0f;
}

// u <= h, ordered: a NaN threshold accepts nothing.
__device__ __forceinline__ int vllm_at_most(float u, float h) { return u <= h; }
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void verify_kernel(const int* __restrict__ cu_num_logits, float* __restrict__ cumulative, float* __restrict__ draft_lse, const int* __restrict__ drafts, const int64_t* __restrict__ idx_mapping, const int64_t* __restrict__ local_argmax, const float* __restrict__ local_max, const float* __restrict__ local_sumexp, const float* __restrict__ logits, int* __restrict__ num_sampled, const int64_t* __restrict__ pos, int64_t* __restrict__ sampled, const int64_t* __restrict__ seeds, float* __restrict__ target_lse, const float* __restrict__ temperature, int apply_temperature, int64_t argmax_stride, int blocks, int64_t logits_stride, int64_t max_stride, int reqs, int64_t sampled_stride, int64_t sumexp_stride, int vocab);
extern "C" __global__ void __launch_bounds__(32, 1) verify_kernel(const int* __restrict__ cu_num_logits, float* __restrict__ cumulative, float* __restrict__ draft_lse, const int* __restrict__ drafts, const int64_t* __restrict__ idx_mapping, const int64_t* __restrict__ local_argmax, const float* __restrict__ local_max, const float* __restrict__ local_sumexp, const float* __restrict__ logits, int* __restrict__ num_sampled, const int64_t* __restrict__ pos, int64_t* __restrict__ sampled, const int64_t* __restrict__ seeds, float* __restrict__ target_lse, const float* __restrict__ temperature, int apply_temperature, int64_t argmax_stride, int blocks, int64_t logits_stride, int64_t max_stride, int reqs, int64_t sampled_stride, int64_t sumexp_stride, int vocab) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* lse_s = ((void*)((char*)buf_dyn_shmem + 0));
  void* log_prob_s = ((void*)((char*)buf_dyn_shmem + 128));
  void* uniform_s = ((void*)((char*)buf_dyn_shmem + 256));
  void* draft_s = ((void*)((char*)buf_dyn_shmem + 384));
  void* target_s = ((void*)((char*)buf_dyn_shmem + 640));
  void* cumulative_s = ((void*)((char*)buf_dyn_shmem + 896));
  void* threshold_s = ((void*)((char*)buf_dyn_shmem + 1024));
  int start = 0;
  int end = 0;
  int64_t state = (int64_t)0;
  int row = 0;
  int64_t draft = (int64_t)0;
  float maximum = 0x0p+0f/*0.000000e+00*/;
  float sumexp = 0x0p+0f/*0.000000e+00*/;
  int64_t position = (int64_t)0;
  float temp = 0x0p+0f/*0.000000e+00*/;
  int64_t seed = (int64_t)0;
  float logit = 0x0p+0f/*0.000000e+00*/;
  float row_max[1];
  int first[1];
  float total[1];
  float softplus = 0x0p+0f/*0.000000e+00*/;
  float best[1];
  int best_index[1];
  int64_t target = (int64_t)0;
  float log_p = 0x0p+0f/*0.000000e+00*/;
  int after = 0;
  int greedy = 0;
  int64_t accepted = (int64_t)0;
  int verifying = 0;
  int64_t drafted = (int64_t)0;
  int hit = 0;
  int64_t drafted_1 = (int64_t)0;
  int hit_1 = 0;
  int64_t drafted_2 = (int64_t)0;
  int hit_2 = 0;
  start = cu_num_logits[((int64_t)((int)blockIdx.x))];
  end = cu_num_logits[(((int64_t)((int)blockIdx.x)) + (int64_t)1)];
  state = idx_mapping[((int64_t)((int)blockIdx.x))];
  int num_drafts = ((end - start) - 1);
  row = (min(((int)threadIdx.x), num_drafts) + start);
  draft = ((int64_t)drafts[(min((((int64_t)((int)threadIdx.x)) + (int64_t)1), ((int64_t)num_drafts)) + ((int64_t)start))]);
  maximum = local_max[((((int64_t)row) * max_stride) + ((int64_t)min(0, (blocks - 1))))];
  sumexp = local_sumexp[((((int64_t)row) * sumexp_stride) + ((int64_t)min(0, (blocks - 1))))];
  position = pos[row];
  temp = temperature[state];
  seed = seeds[state];
  float condval;
  if (((((int)threadIdx.x) < num_drafts) & (0 < blocks))) {
    condval = maximum;
  } else {
    condval = -CUDART_INF_F;
  }
  maximum = condval;
  float condval_1;
  if (((((int)threadIdx.x) < num_drafts) & (0 < blocks))) {
    condval_1 = sumexp;
  } else {
    condval_1 = 0x0p+0f/*0.000000e+00*/;
  }
  sumexp = condval_1;
  int64_t condval_2;
  if ((((int)threadIdx.x) < num_drafts)) {
    condval_2 = draft;
  } else {
    condval_2 = (int64_t)-1;
  }
  draft = condval_2;
  logit = logits[(max(draft, (int64_t)0) + (((int64_t)row) * logits_stride))];
  if (((apply_temperature != 0) & (temp != 0x0p+0f/*0.000000e+00*/)) & (temp != 0x1p+0f/*1.000000e+00*/)) {
    logit = vllm_div_full(logit, temp);
  }
  row_max[0] = maximum;
  int condval_3;
  if ((vllm_is_max(maximum, row_max[0]) != 0)) {
    condval_3 = 0;
  } else {
    condval_3 = 1;
  }
  first[0] = condval_3;
  float condval_4;
  if ((first[0] == 0)) {
    condval_4 = sumexp;
  } else {
    condval_4 = vllm_mul(vllm_exp_from(maximum, row_max[0]), vllm_add(0x1p+0f/*1.000000e+00*/, sumexp));
  }
  total[0] = condval_4;
  softplus = vllm_softplus(vllm_row_others(total[0], row_max[0], vocab));
  float condval_5;
  if ((maximum != maximum)) {
    condval_5 = -CUDART_INF_F;
  } else {
    condval_5 = maximum;
  }
  best[0] = condval_5;
  best_index[0] = 0;
  target = local_argmax[((((int64_t)row) * argmax_stride) + ((int64_t)best_index[0]))];
  uint word = vllm_randint64((seed ^ (((int64_t)((int)threadIdx.x)) << (int64_t)32)), position);
  ((float*)lse_s)[((int)threadIdx.x)] = vllm_add(row_max[0], softplus);
  ((float*)log_prob_s)[((int)threadIdx.x)] = vllm_sub(vllm_shifted(logit, row_max[0]), softplus);
  ((float*)uniform_s)[((int)threadIdx.x)] = vllm_uniform(word);
  ((int64_t*)draft_s)[((int)threadIdx.x)] = draft;
  ((int64_t*)target_s)[((int)threadIdx.x)] = target;
  __syncthreads();
  if (((int)threadIdx.x) < 3) {
    log_p = 0x0p+0f/*0.000000e+00*/;
    float condval_6;
    if (((int64_t)0 <= ((int64_t*)draft_s)[0])) {
      condval_6 = vllm_log_ratio(log_p, ((float*)log_prob_s)[0]);
    } else {
      condval_6 = log_p;
    }
    log_p = condval_6;
    if (1 <= ((int)threadIdx.x)) {
      float condval_7;
      if (((int64_t)0 <= ((int64_t*)draft_s)[1])) {
        condval_7 = vllm_log_ratio(log_p, ((float*)log_prob_s)[1]);
      } else {
        condval_7 = log_p;
      }
      log_p = condval_7;
    }
    if (((int)threadIdx.x) == 2) {
      float condval_8;
      if (((int64_t)0 <= ((int64_t*)draft_s)[2])) {
        condval_8 = vllm_log_ratio(log_p, ((float*)log_prob_s)[2]);
      } else {
        condval_8 = log_p;
      }
      log_p = condval_8;
    }
    ((float*)cumulative_s)[((int)threadIdx.x)] = log_p;
    after = min((((int)threadIdx.x) + 1), 2);
  }
  __syncthreads();
  if (((int)threadIdx.x) < 3) {
    float condval_9;
    if (((((int)threadIdx.x) < 2) & ((int64_t)0 <= ((int64_t*)draft_s)[after]))) {
      condval_9 = vllm_block_threshold(log_p, ((float*)log_prob_s)[after]);
    } else {
      condval_9 = vllm_exp(log_p);
    }
    ((float*)threshold_s)[((int)threadIdx.x)] = condval_9;
  }
  __syncthreads();
  if (((int)threadIdx.x) == 0) {
    greedy = ((int)(temp == 0x0p+0f/*0.000000e+00*/));
    accepted = (int64_t)0;
    verifying = 1;
    if (0 < num_drafts) {
      drafted = ((int64_t*)draft_s)[0];
      int valid = ((int)((int64_t)0 <= drafted));
      int64_t token = max(drafted, (int64_t)0);
      if (greedy == 0) {
        cumulative[start] = ((float*)cumulative_s)[0];
      }
      if (greedy == 0) {
        verifying = (verifying & valid);
      }
      if (verifying != 0) {
        if (greedy != 0) {
          hit = (((int)(((int64_t*)target_s)[0] == token)) & valid);
          int64_t condval_10;
          if ((hit != 0)) {
            condval_10 = token;
          } else {
            condval_10 = ((int64_t*)target_s)[0];
          }
          sampled[(((int64_t)((int)blockIdx.x)) * sampled_stride)] = condval_10;
          accepted = (accepted + ((int64_t)hit));
          verifying = hit;
        } else {
          int64_t condval_11;
          if ((vllm_at_most(((float*)uniform_s)[0], ((float*)threshold_s)[0]) != 0)) {
            condval_11 = (int64_t)1;
          } else {
            condval_11 = accepted;
          }
          accepted = condval_11;
          sampled[(((int64_t)((int)blockIdx.x)) * sampled_stride)] = token;
        }
      }
    }
    if (1 < num_drafts) {
      drafted_1 = ((int64_t*)draft_s)[1];
      int valid_1 = ((int)((int64_t)0 <= drafted_1));
      int64_t token_1 = max(drafted_1, (int64_t)0);
      if (greedy == 0) {
        cumulative[(((int64_t)start) + (int64_t)1)] = ((float*)cumulative_s)[1];
      }
      if (greedy == 0) {
        verifying = (verifying & valid_1);
      }
      if (verifying != 0) {
        if (greedy != 0) {
          hit_1 = (((int)(((int64_t*)target_s)[1] == token_1)) & valid_1);
          int64_t condval_12;
          if ((hit_1 != 0)) {
            condval_12 = token_1;
          } else {
            condval_12 = ((int64_t*)target_s)[1];
          }
          sampled[((((int64_t)((int)blockIdx.x)) * sampled_stride) + (int64_t)1)] = condval_12;
          accepted = (accepted + ((int64_t)hit_1));
          verifying = hit_1;
        } else {
          int64_t condval_13;
          if ((vllm_at_most(((float*)uniform_s)[1], ((float*)threshold_s)[1]) != 0)) {
            condval_13 = (int64_t)2;
          } else {
            condval_13 = accepted;
          }
          accepted = condval_13;
          sampled[((((int64_t)((int)blockIdx.x)) * sampled_stride) + (int64_t)1)] = token_1;
        }
      }
    }
    if (2 < num_drafts) {
      drafted_2 = ((int64_t*)draft_s)[2];
      int valid_2 = ((int)((int64_t)0 <= drafted_2));
      int64_t token_2 = max(drafted_2, (int64_t)0);
      if (greedy == 0) {
        cumulative[(((int64_t)start) + (int64_t)2)] = ((float*)cumulative_s)[2];
      }
      if (greedy == 0) {
        verifying = (verifying & valid_2);
      }
      if (verifying != 0) {
        if (greedy != 0) {
          hit_2 = (((int)(((int64_t*)target_s)[2] == token_2)) & valid_2);
          int64_t condval_14;
          if ((hit_2 != 0)) {
            condval_14 = token_2;
          } else {
            condval_14 = ((int64_t*)target_s)[2];
          }
          sampled[((((int64_t)((int)blockIdx.x)) * sampled_stride) + (int64_t)2)] = condval_14;
          accepted = (accepted + ((int64_t)hit_2));
          verifying = hit_2;
        } else {
          int64_t condval_15;
          if ((vllm_at_most(((float*)uniform_s)[2], ((float*)threshold_s)[2]) != 0)) {
            condval_15 = (int64_t)3;
          } else {
            condval_15 = accepted;
          }
          accepted = condval_15;
          sampled[((((int64_t)((int)blockIdx.x)) * sampled_stride) + (int64_t)2)] = token_2;
        }
      }
    }
    num_sampled[((int64_t)((int)blockIdx.x))] = ((int)accepted);
    float condval_16;
    if (((greedy == 0) & (accepted < ((int64_t)num_drafts)))) {
      condval_16 = ((float*)lse_s)[min(accepted, (int64_t)31)];
    } else {
      condval_16 = 0x0p+0f/*0.000000e+00*/;
    }
    target_lse[((int64_t)((int)blockIdx.x))] = condval_16;
    draft_lse[((int64_t)((int)blockIdx.x))] = 0x0p+0f/*0.000000e+00*/;
  }
}

