// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* apply_write_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_apply_write(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_apply_write(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[14];
  void* stack_ffi_any = stack;
  if (!((num_args == 7))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "apply_write: num_args should be 7", (long long)(num_args), (long long)(7));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "apply_write: args pointer is NULL");
    return -1;
  }
  int32_t output_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((output_handle_type_index == 0) || (output_handle_type_index == 4)) || (output_handle_type_index == 7)) || (64 <= output_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input output expected pointer or tensor handle");
    return -1;
  }
  int32_t output_stride_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((output_stride_type_index == 1) || (output_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write scalar output_stride expected integer");
    return -1;
  }
  int32_t indices_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((indices_handle_type_index == 0) || (indices_handle_type_index == 4)) || (indices_handle_type_index == 7)) || (64 <= indices_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input indices expected pointer or tensor handle");
    return -1;
  }
  int32_t starts_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((starts_handle_type_index == 0) || (starts_handle_type_index == 4)) || (starts_handle_type_index == 7)) || (64 <= starts_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input starts expected pointer or tensor handle");
    return -1;
  }
  int32_t contents_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((contents_handle_type_index == 0) || (contents_handle_type_index == 4)) || (contents_handle_type_index == 7)) || (64 <= contents_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input contents expected pointer or tensor handle");
    return -1;
  }
  int32_t cu_lens_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((cu_lens_handle_type_index == 0) || (cu_lens_handle_type_index == 4)) || (cu_lens_handle_type_index == 7)) || (64 <= cu_lens_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input cu_lens expected pointer or tensor handle");
    return -1;
  }
  int32_t chunks_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((chunks_type_index == 1) || (chunks_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write scalar chunks expected integer");
    return -1;
  }
  void* output_handle = ((output_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  int64_t output_stride = (((TVMFFIAny*)args)[1].v_int64);
  void* indices_handle = ((indices_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* starts_handle = ((starts_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* contents_handle = ((contents_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* cu_lens_handle = ((cu_lens_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  int32_t chunks = ((int32_t)(((TVMFFIAny*)args)[6].v_int64));
  bool apply_write_output_is_null = (output_handle == NULL);
  if (!(!apply_write_output_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "apply_write.output is expected to have non-NULL pointer");
    return -1;
  }
  bool apply_write_indices_is_null = (indices_handle == NULL);
  if (!(!apply_write_indices_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "apply_write.indices is expected to have non-NULL pointer");
    return -1;
  }
  bool apply_write_starts_is_null = (starts_handle == NULL);
  if (!(!apply_write_starts_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "apply_write.starts is expected to have non-NULL pointer");
    return -1;
  }
  bool apply_write_contents_is_null = (contents_handle == NULL);
  if (!(!apply_write_contents_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "apply_write.contents is expected to have non-NULL pointer");
    return -1;
  }
  bool apply_write_cu_lens_is_null = (cu_lens_handle == NULL);
  if (!(!apply_write_cu_lens_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "apply_write.cu_lens is expected to have non-NULL pointer");
    return -1;
  }
  void* apply_write_output_shape = (((DLTensor*)output_handle)[0].shape);
  void* apply_write_indices_shape = (((DLTensor*)indices_handle)[0].shape);
  void* apply_write_starts_shape = (((DLTensor*)starts_handle)[0].shape);
  void* apply_write_contents_shape = (((DLTensor*)contents_handle)[0].shape);
  void* apply_write_cu_lens_shape = (((DLTensor*)cu_lens_handle)[0].shape);
  if (!(((((DLTensor*)output_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input output ndim mismatch, expected 1", (long long)((((DLTensor*)output_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t out_len = ((int32_t)((int64_t*)apply_write_output_shape)[0]);
  void* apply_write_output_strides = (((DLTensor*)output_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)output_handle)[0].device.device_id);
  void* output = (((DLTensor*)output_handle)[0].data);
  if (!(((((DLTensor*)indices_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input indices ndim mismatch, expected 1", (long long)((((DLTensor*)indices_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t writes = ((int32_t)((int64_t*)apply_write_indices_shape)[0]);
  void* apply_write_indices_strides = (((DLTensor*)indices_handle)[0].strides);
  void* indices = (((DLTensor*)indices_handle)[0].data);
  if (!(((((DLTensor*)starts_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input starts ndim mismatch, expected 1", (long long)((((DLTensor*)starts_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t starts_len = ((int32_t)((int64_t*)apply_write_starts_shape)[0]);
  void* apply_write_starts_strides = (((DLTensor*)starts_handle)[0].strides);
  void* starts = (((DLTensor*)starts_handle)[0].data);
  if (!(((((DLTensor*)contents_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input contents ndim mismatch, expected 1", (long long)((((DLTensor*)contents_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t contents_len = ((int32_t)((int64_t*)apply_write_contents_shape)[0]);
  void* apply_write_contents_strides = (((DLTensor*)contents_handle)[0].strides);
  void* contents = (((DLTensor*)contents_handle)[0].data);
  if (!(((((DLTensor*)cu_lens_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input cu_lens ndim mismatch, expected 1", (long long)((((DLTensor*)cu_lens_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t cu_len = ((int32_t)((int64_t*)apply_write_cu_lens_shape)[0]);
  void* apply_write_cu_lens_strides = (((DLTensor*)cu_lens_handle)[0].strides);
  void* cu_lens = (((DLTensor*)cu_lens_handle)[0].data);
  if (!(((((((DLTensor*)output_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)output_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)output_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input output dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval;
  if ((apply_write_output_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)apply_write_output_strides)[0]);
  }
  if (!(((condval == 1) || (out_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input output strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)output_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input output byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)output_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input output device_type mismatch, expected cuda", (long long)((((DLTensor*)output_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((out_len == 0) || !(output == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input output data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)indices_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)indices_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)indices_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input indices dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_1;
  if ((apply_write_indices_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)apply_write_indices_strides)[0]);
  }
  if (!(((condval_1 == 1) || (writes == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input indices strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)indices_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input indices byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)indices_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input indices device_id violates packed ABI constraint", (long long)((((DLTensor*)indices_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input indices device_type mismatch, expected cuda", (long long)((((DLTensor*)indices_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((writes == 0) || !(indices == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input indices data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)starts_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)starts_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)starts_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input starts dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_2;
  if ((apply_write_starts_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)apply_write_starts_strides)[0]);
  }
  if (!(((condval_2 == 1) || (starts_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input starts strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)starts_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input starts byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)starts_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)starts_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input starts device_id violates packed ABI constraint", (long long)((((DLTensor*)starts_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)starts_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input starts device_type mismatch, expected cuda", (long long)((((DLTensor*)starts_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((starts_len == 0) || !(starts == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input starts data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)contents_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)contents_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)contents_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input contents dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_3;
  if ((apply_write_contents_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)apply_write_contents_strides)[0]);
  }
  if (!(((condval_3 == 1) || (contents_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input contents strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)contents_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input contents byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)contents_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)contents_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input contents device_id violates packed ABI constraint", (long long)((((DLTensor*)contents_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)contents_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input contents device_type mismatch, expected cuda", (long long)((((DLTensor*)contents_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((contents_len == 0) || !(contents == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input contents data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)cu_lens_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)cu_lens_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)cu_lens_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input cu_lens dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_4;
  if ((apply_write_cu_lens_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)apply_write_cu_lens_strides)[0]);
  }
  if (!(((condval_4 == 1) || (cu_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input cu_lens strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)cu_lens_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input cu_lens byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)cu_lens_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_lens_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input cu_lens device_id violates packed ABI constraint", (long long)((((DLTensor*)cu_lens_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_lens_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel apply_write input cu_lens device_type mismatch, expected cuda", (long long)((((DLTensor*)cu_lens_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((cu_len == 0) || !(cu_lens == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel apply_write input cu_lens data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (contents == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = contents;
  if (cu_lens == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = cu_lens;
  if (indices == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = indices;
  if (output == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = output;
  if (starts == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = starts;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)chunks);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = output_stride;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)writes);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)writes);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)chunks);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = (int64_t)0;
  if (apply_write_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "apply_write_kernel", &apply_write_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(apply_write_kernel_packed, (TVMFFIAny*) stack_ffi_any, 13, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_apply_write(self, args, num_args, result);
}
