// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vision_add_norm_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_add_norm(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_add_norm(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[10];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vision_add_norm: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_add_norm: args pointer is NULL");
    return -1;
  }
  int32_t X_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((X_handle_type_index == 0) || (X_handle_type_index == 4)) || (X_handle_type_index == 7)) || (64 <= X_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input X expected pointer or tensor handle");
    return -1;
  }
  int32_t Weight_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((Weight_handle_type_index == 0) || (Weight_handle_type_index == 4)) || (Weight_handle_type_index == 7)) || (64 <= Weight_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input Weight expected pointer or tensor handle");
    return -1;
  }
  int32_t Out_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((Out_handle_type_index == 0) || (Out_handle_type_index == 4)) || (Out_handle_type_index == 7)) || (64 <= Out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input Out expected pointer or tensor handle");
    return -1;
  }
  void* X_handle = ((X_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* Weight_handle = ((Weight_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* Out_handle = ((Out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  bool vision_add_norm_X_is_null = (X_handle == NULL);
  if (!(!vision_add_norm_X_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_add_norm.X is expected to have non-NULL pointer");
    return -1;
  }
  bool vision_add_norm_Weight_is_null = (Weight_handle == NULL);
  if (!(!vision_add_norm_Weight_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_add_norm.Weight is expected to have non-NULL pointer");
    return -1;
  }
  bool vision_add_norm_Out_is_null = (Out_handle == NULL);
  if (!(!vision_add_norm_Out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_add_norm.Out is expected to have non-NULL pointer");
    return -1;
  }
  void* vision_add_norm_X_shape = (((DLTensor*)X_handle)[0].shape);
  void* vision_add_norm_Weight_shape = (((DLTensor*)Weight_handle)[0].shape);
  void* vision_add_norm_Out_shape = (((DLTensor*)Out_handle)[0].shape);
  if (!(((((DLTensor*)X_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input X ndim mismatch, expected 2", (long long)((((DLTensor*)X_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: vision_add_norm.X, vision_add_norm.Out");
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vision_add_norm_X_shape)[0]);
  void* vision_add_norm_X_strides = (((DLTensor*)X_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)X_handle)[0].device.device_id);
  void* X = (((DLTensor*)X_handle)[0].data);
  if (!(((((DLTensor*)Weight_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Weight ndim mismatch, expected 1", (long long)((((DLTensor*)Weight_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vision_add_norm_Weight_strides = (((DLTensor*)Weight_handle)[0].strides);
  void* Weight = (((DLTensor*)Weight_handle)[0].data);
  if (!(((((DLTensor*)Out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Out ndim mismatch, expected 2", (long long)((((DLTensor*)Out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vision_add_norm_Out_strides = (((DLTensor*)Out_handle)[0].strides);
  void* Out = (((DLTensor*)Out_handle)[0].data);
  if (!(((((((DLTensor*)X_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)X_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)X_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input X dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_add_norm_X_shape)[1]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input X shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_add_norm_X_shape)[1])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vision_add_norm_X_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vision_add_norm_X_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vision_add_norm_X_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vision_add_norm_X_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input X strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vision_add_norm_X_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vision_add_norm_X_strides)[0]);
  }
  if (!(((condval_2 == 1024) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input X strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)X_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input X byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)X_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)X_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input X device_type mismatch, expected cuda", (long long)((((DLTensor*)X_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(X == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input X data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Weight_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)Weight_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)Weight_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input Weight dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_add_norm_Weight_shape)[0]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Weight shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_add_norm_Weight_shape)[0])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vision_add_norm_Weight_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vision_add_norm_Weight_strides)[0]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vision_add_norm_Weight_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vision_add_norm_Weight_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Weight strides[0] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Weight_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Weight byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Weight_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Weight_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Weight device_id violates packed ABI constraint", (long long)((((DLTensor*)Weight_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Weight_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Weight device_type mismatch, expected cuda", (long long)((((DLTensor*)Weight_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Weight == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input Weight data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Out_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)Out_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)Out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input Out dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_add_norm_X_shape)[0]) == ((int32_t)((int64_t*)vision_add_norm_Out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_add_norm_X_shape)[0])), (long long)(((int32_t)((int64_t*)vision_add_norm_Out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_add_norm_Out_shape)[1]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_add_norm_Out_shape)[1])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((vision_add_norm_Out_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)vision_add_norm_Out_strides)[1]);
  }
  if (!((condval_5 == 1))) {
    int32_t condval_6;
    if ((vision_add_norm_Out_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)vision_add_norm_Out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Out strides[1] violates packed ABI constraint", (long long)(condval_6), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((vision_add_norm_Out_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)vision_add_norm_Out_strides)[0]);
  }
  if (!(((condval_7 == 1024) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input Out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Out_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Out device_id violates packed ABI constraint", (long long)((((DLTensor*)Out_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_add_norm input Out device_type mismatch, expected cuda", (long long)((((DLTensor*)Out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(Out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_add_norm input Out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (Out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = Out;
  if (Weight == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = Weight;
  if (X == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = X;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = (int64_t)0;
  if (vision_add_norm_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vision_add_norm_kernel", &vision_add_norm_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vision_add_norm_kernel_packed, (TVMFFIAny*) stack_ffi_any, 9, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vision_add_norm(self, args, num_args, result);
}
