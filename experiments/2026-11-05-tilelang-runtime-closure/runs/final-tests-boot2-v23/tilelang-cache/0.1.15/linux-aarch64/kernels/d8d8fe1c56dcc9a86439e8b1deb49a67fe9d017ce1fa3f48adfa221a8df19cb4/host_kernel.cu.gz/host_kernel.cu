// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* verify_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_verify(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_verify(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[30];
  void* stack_ffi_any = stack;
  if (!((num_args == 17))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "verify: num_args should be 17", (long long)(num_args), (long long)(17));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify: args pointer is NULL");
    return -1;
  }
  int32_t sampled_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((sampled_handle_type_index == 0) || (sampled_handle_type_index == 4)) || (sampled_handle_type_index == 7)) || (64 <= sampled_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input sampled expected pointer or tensor handle");
    return -1;
  }
  int32_t num_sampled_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((num_sampled_handle_type_index == 0) || (num_sampled_handle_type_index == 4)) || (num_sampled_handle_type_index == 7)) || (64 <= num_sampled_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input num_sampled expected pointer or tensor handle");
    return -1;
  }
  int32_t target_lse_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((target_lse_handle_type_index == 0) || (target_lse_handle_type_index == 4)) || (target_lse_handle_type_index == 7)) || (64 <= target_lse_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input target_lse expected pointer or tensor handle");
    return -1;
  }
  int32_t draft_lse_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((draft_lse_handle_type_index == 0) || (draft_lse_handle_type_index == 4)) || (draft_lse_handle_type_index == 7)) || (64 <= draft_lse_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input draft_lse expected pointer or tensor handle");
    return -1;
  }
  int32_t cumulative_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((cumulative_handle_type_index == 0) || (cumulative_handle_type_index == 4)) || (cumulative_handle_type_index == 7)) || (64 <= cumulative_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cumulative expected pointer or tensor handle");
    return -1;
  }
  int32_t logits_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((logits_handle_type_index == 0) || (logits_handle_type_index == 4)) || (logits_handle_type_index == 7)) || (64 <= logits_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input logits expected pointer or tensor handle");
    return -1;
  }
  int32_t local_argmax_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((local_argmax_handle_type_index == 0) || (local_argmax_handle_type_index == 4)) || (local_argmax_handle_type_index == 7)) || (64 <= local_argmax_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_argmax expected pointer or tensor handle");
    return -1;
  }
  int32_t local_max_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((local_max_handle_type_index == 0) || (local_max_handle_type_index == 4)) || (local_max_handle_type_index == 7)) || (64 <= local_max_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_max expected pointer or tensor handle");
    return -1;
  }
  int32_t local_sumexp_handle_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((((local_sumexp_handle_type_index == 0) || (local_sumexp_handle_type_index == 4)) || (local_sumexp_handle_type_index == 7)) || (64 <= local_sumexp_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_sumexp expected pointer or tensor handle");
    return -1;
  }
  int32_t drafts_handle_type_index = (((TVMFFIAny*)args)[9].type_index);
  if (!(((((drafts_handle_type_index == 0) || (drafts_handle_type_index == 4)) || (drafts_handle_type_index == 7)) || (64 <= drafts_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input drafts expected pointer or tensor handle");
    return -1;
  }
  int32_t cu_num_logits_handle_type_index = (((TVMFFIAny*)args)[10].type_index);
  if (!(((((cu_num_logits_handle_type_index == 0) || (cu_num_logits_handle_type_index == 4)) || (cu_num_logits_handle_type_index == 7)) || (64 <= cu_num_logits_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cu_num_logits expected pointer or tensor handle");
    return -1;
  }
  int32_t idx_mapping_handle_type_index = (((TVMFFIAny*)args)[11].type_index);
  if (!(((((idx_mapping_handle_type_index == 0) || (idx_mapping_handle_type_index == 4)) || (idx_mapping_handle_type_index == 7)) || (64 <= idx_mapping_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input idx_mapping expected pointer or tensor handle");
    return -1;
  }
  int32_t temperature_handle_type_index = (((TVMFFIAny*)args)[12].type_index);
  if (!(((((temperature_handle_type_index == 0) || (temperature_handle_type_index == 4)) || (temperature_handle_type_index == 7)) || (64 <= temperature_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input temperature expected pointer or tensor handle");
    return -1;
  }
  int32_t seeds_handle_type_index = (((TVMFFIAny*)args)[13].type_index);
  if (!(((((seeds_handle_type_index == 0) || (seeds_handle_type_index == 4)) || (seeds_handle_type_index == 7)) || (64 <= seeds_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input seeds expected pointer or tensor handle");
    return -1;
  }
  int32_t pos_handle_type_index = (((TVMFFIAny*)args)[14].type_index);
  if (!(((((pos_handle_type_index == 0) || (pos_handle_type_index == 4)) || (pos_handle_type_index == 7)) || (64 <= pos_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input pos expected pointer or tensor handle");
    return -1;
  }
  int32_t dead_row_cut_handle_type_index = (((TVMFFIAny*)args)[15].type_index);
  if (!(((((dead_row_cut_handle_type_index == 0) || (dead_row_cut_handle_type_index == 4)) || (dead_row_cut_handle_type_index == 7)) || (64 <= dead_row_cut_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut expected pointer or tensor handle");
    return -1;
  }
  int32_t apply_temperature_type_index = (((TVMFFIAny*)args)[16].type_index);
  if (!(((apply_temperature_type_index == 1) || (apply_temperature_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify scalar apply_temperature expected integer");
    return -1;
  }
  void* sampled_handle = ((sampled_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* num_sampled_handle = ((num_sampled_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* target_lse_handle = ((target_lse_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* draft_lse_handle = ((draft_lse_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* cumulative_handle = ((cumulative_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* logits_handle = ((logits_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* local_argmax_handle = ((local_argmax_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* local_max_handle = ((local_max_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  void* local_sumexp_handle = ((local_sumexp_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[8].v_ptr) + 24)) : (((TVMFFIAny*)args)[8].v_ptr));
  void* drafts_handle = ((drafts_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[9].v_ptr) + 24)) : (((TVMFFIAny*)args)[9].v_ptr));
  void* cu_num_logits_handle = ((cu_num_logits_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[10].v_ptr) + 24)) : (((TVMFFIAny*)args)[10].v_ptr));
  void* idx_mapping_handle = ((idx_mapping_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[11].v_ptr) + 24)) : (((TVMFFIAny*)args)[11].v_ptr));
  void* temperature_handle = ((temperature_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[12].v_ptr) + 24)) : (((TVMFFIAny*)args)[12].v_ptr));
  void* seeds_handle = ((seeds_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[13].v_ptr) + 24)) : (((TVMFFIAny*)args)[13].v_ptr));
  void* pos_handle = ((pos_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[14].v_ptr) + 24)) : (((TVMFFIAny*)args)[14].v_ptr));
  void* dead_row_cut_handle = ((dead_row_cut_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[15].v_ptr) + 24)) : (((TVMFFIAny*)args)[15].v_ptr));
  int32_t apply_temperature = ((int32_t)(((TVMFFIAny*)args)[16].v_int64));
  bool verify_sampled_is_null = (sampled_handle == NULL);
  if (!(!verify_sampled_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.sampled is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_num_sampled_is_null = (num_sampled_handle == NULL);
  if (!(!verify_num_sampled_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.num_sampled is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_target_lse_is_null = (target_lse_handle == NULL);
  if (!(!verify_target_lse_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.target_lse is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_draft_lse_is_null = (draft_lse_handle == NULL);
  if (!(!verify_draft_lse_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.draft_lse is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_cumulative_is_null = (cumulative_handle == NULL);
  if (!(!verify_cumulative_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.cumulative is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_logits_is_null = (logits_handle == NULL);
  if (!(!verify_logits_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.logits is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_local_argmax_is_null = (local_argmax_handle == NULL);
  if (!(!verify_local_argmax_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.local_argmax is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_local_max_is_null = (local_max_handle == NULL);
  if (!(!verify_local_max_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.local_max is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_local_sumexp_is_null = (local_sumexp_handle == NULL);
  if (!(!verify_local_sumexp_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.local_sumexp is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_drafts_is_null = (drafts_handle == NULL);
  if (!(!verify_drafts_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.drafts is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_cu_num_logits_is_null = (cu_num_logits_handle == NULL);
  if (!(!verify_cu_num_logits_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.cu_num_logits is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_idx_mapping_is_null = (idx_mapping_handle == NULL);
  if (!(!verify_idx_mapping_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.idx_mapping is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_temperature_is_null = (temperature_handle == NULL);
  if (!(!verify_temperature_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.temperature is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_seeds_is_null = (seeds_handle == NULL);
  if (!(!verify_seeds_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.seeds is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_pos_is_null = (pos_handle == NULL);
  if (!(!verify_pos_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "verify.pos is expected to have non-NULL pointer");
    return -1;
  }
  bool verify_dead_row_cut_is_null = (dead_row_cut_handle == NULL);
  void* verify_sampled_shape = (((DLTensor*)sampled_handle)[0].shape);
  void* verify_num_sampled_shape = (((DLTensor*)num_sampled_handle)[0].shape);
  void* verify_target_lse_shape = (((DLTensor*)target_lse_handle)[0].shape);
  void* verify_draft_lse_shape = (((DLTensor*)draft_lse_handle)[0].shape);
  void* verify_cumulative_shape = (((DLTensor*)cumulative_handle)[0].shape);
  void* verify_logits_shape = (((DLTensor*)logits_handle)[0].shape);
  void* verify_local_argmax_shape = (((DLTensor*)local_argmax_handle)[0].shape);
  void* verify_local_max_shape = (((DLTensor*)local_max_handle)[0].shape);
  void* verify_local_sumexp_shape = (((DLTensor*)local_sumexp_handle)[0].shape);
  void* verify_drafts_shape = (((DLTensor*)drafts_handle)[0].shape);
  void* verify_cu_num_logits_shape = (((DLTensor*)cu_num_logits_handle)[0].shape);
  void* verify_idx_mapping_shape = (((DLTensor*)idx_mapping_handle)[0].shape);
  void* verify_temperature_shape = (((DLTensor*)temperature_handle)[0].shape);
  void* verify_seeds_shape = (((DLTensor*)seeds_handle)[0].shape);
  void* verify_pos_shape = (((DLTensor*)pos_handle)[0].shape);
  void* condval;
  if (!verify_dead_row_cut_is_null) {
    condval = (((DLTensor*)dead_row_cut_handle)[0].shape);
  } else {
    uint64_t v_ = (uint64_t)0;
    condval = (*(void* *)(&(v_)));
  }
  void* verify_dead_row_cut_shape = condval;
  if (!(((((DLTensor*)sampled_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input sampled ndim mismatch, expected 2", (long long)((((DLTensor*)sampled_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable reqs requires at least one non-null buffer among: verify.sampled, verify.num_sampled, verify.target_lse, verify.draft_lse");
    return -1;
  }
  int32_t reqs = ((int32_t)((int64_t*)verify_sampled_shape)[0]);
  void* verify_sampled_strides = (((DLTensor*)sampled_handle)[0].strides);
  int64_t condval_1;
  if ((verify_sampled_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)verify_sampled_strides)[0];
  }
  int64_t sampled_stride = condval_1;
  int32_t dev_id = (((DLTensor*)sampled_handle)[0].device.device_id);
  void* sampled = (((DLTensor*)sampled_handle)[0].data);
  if (!(((((DLTensor*)num_sampled_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input num_sampled ndim mismatch, expected 1", (long long)((((DLTensor*)num_sampled_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* verify_num_sampled_strides = (((DLTensor*)num_sampled_handle)[0].strides);
  void* num_sampled = (((DLTensor*)num_sampled_handle)[0].data);
  if (!(((((DLTensor*)target_lse_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input target_lse ndim mismatch, expected 1", (long long)((((DLTensor*)target_lse_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* verify_target_lse_strides = (((DLTensor*)target_lse_handle)[0].strides);
  void* target_lse = (((DLTensor*)target_lse_handle)[0].data);
  if (!(((((DLTensor*)draft_lse_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input draft_lse ndim mismatch, expected 1", (long long)((((DLTensor*)draft_lse_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* verify_draft_lse_strides = (((DLTensor*)draft_lse_handle)[0].strides);
  void* draft_lse = (((DLTensor*)draft_lse_handle)[0].data);
  if (!(((((DLTensor*)cumulative_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cumulative ndim mismatch, expected 1", (long long)((((DLTensor*)cumulative_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t num_logits = ((int32_t)((int64_t*)verify_cumulative_shape)[0]);
  void* verify_cumulative_strides = (((DLTensor*)cumulative_handle)[0].strides);
  void* cumulative = (((DLTensor*)cumulative_handle)[0].data);
  if (!(((((DLTensor*)logits_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input logits ndim mismatch, expected 2", (long long)((((DLTensor*)logits_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t vocab = ((int32_t)((int64_t*)verify_logits_shape)[1]);
  void* verify_logits_strides = (((DLTensor*)logits_handle)[0].strides);
  int64_t condval_2;
  if ((verify_logits_strides == NULL)) {
    condval_2 = (int64_t)1;
  } else {
    condval_2 = ((int64_t*)verify_logits_strides)[0];
  }
  int64_t logits_stride = condval_2;
  void* logits = (((DLTensor*)logits_handle)[0].data);
  if (!(((((DLTensor*)local_argmax_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_argmax ndim mismatch, expected 2", (long long)((((DLTensor*)local_argmax_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable blocks requires at least one non-null buffer among: verify.local_argmax, verify.local_max, verify.local_sumexp");
    return -1;
  }
  int32_t blocks = ((int32_t)((int64_t*)verify_local_argmax_shape)[1]);
  void* verify_local_argmax_strides = (((DLTensor*)local_argmax_handle)[0].strides);
  int64_t condval_3;
  if ((verify_local_argmax_strides == NULL)) {
    condval_3 = (int64_t)1;
  } else {
    condval_3 = ((int64_t*)verify_local_argmax_strides)[0];
  }
  int64_t argmax_stride = condval_3;
  void* local_argmax = (((DLTensor*)local_argmax_handle)[0].data);
  if (!(((((DLTensor*)local_max_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_max ndim mismatch, expected 2", (long long)((((DLTensor*)local_max_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* verify_local_max_strides = (((DLTensor*)local_max_handle)[0].strides);
  int64_t condval_4;
  if ((verify_local_max_strides == NULL)) {
    condval_4 = (int64_t)1;
  } else {
    condval_4 = ((int64_t*)verify_local_max_strides)[0];
  }
  int64_t max_stride = condval_4;
  void* local_max = (((DLTensor*)local_max_handle)[0].data);
  if (!(((((DLTensor*)local_sumexp_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_sumexp ndim mismatch, expected 2", (long long)((((DLTensor*)local_sumexp_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* verify_local_sumexp_strides = (((DLTensor*)local_sumexp_handle)[0].strides);
  int64_t condval_5;
  if ((verify_local_sumexp_strides == NULL)) {
    condval_5 = (int64_t)1;
  } else {
    condval_5 = ((int64_t*)verify_local_sumexp_strides)[0];
  }
  int64_t sumexp_stride = condval_5;
  void* local_sumexp = (((DLTensor*)local_sumexp_handle)[0].data);
  if (!(((((DLTensor*)drafts_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input drafts ndim mismatch, expected 1", (long long)((((DLTensor*)drafts_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t drafts_len = ((int32_t)((int64_t*)verify_drafts_shape)[0]);
  void* verify_drafts_strides = (((DLTensor*)drafts_handle)[0].strides);
  void* drafts = (((DLTensor*)drafts_handle)[0].data);
  if (!(((((DLTensor*)cu_num_logits_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cu_num_logits ndim mismatch, expected 1", (long long)((((DLTensor*)cu_num_logits_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* verify_cu_num_logits_strides = (((DLTensor*)cu_num_logits_handle)[0].strides);
  void* cu_num_logits = (((DLTensor*)cu_num_logits_handle)[0].data);
  if (!(((((DLTensor*)idx_mapping_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input idx_mapping ndim mismatch, expected 1", (long long)((((DLTensor*)idx_mapping_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t idx_len = ((int32_t)((int64_t*)verify_idx_mapping_shape)[0]);
  void* verify_idx_mapping_strides = (((DLTensor*)idx_mapping_handle)[0].strides);
  void* idx_mapping = (((DLTensor*)idx_mapping_handle)[0].data);
  if (!(((((DLTensor*)temperature_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input temperature ndim mismatch, expected 1", (long long)((((DLTensor*)temperature_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t temp_len = ((int32_t)((int64_t*)verify_temperature_shape)[0]);
  void* verify_temperature_strides = (((DLTensor*)temperature_handle)[0].strides);
  void* temperature = (((DLTensor*)temperature_handle)[0].data);
  if (!(((((DLTensor*)seeds_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input seeds ndim mismatch, expected 1", (long long)((((DLTensor*)seeds_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t seed_len = ((int32_t)((int64_t*)verify_seeds_shape)[0]);
  void* verify_seeds_strides = (((DLTensor*)seeds_handle)[0].strides);
  void* seeds = (((DLTensor*)seeds_handle)[0].data);
  if (!(((((DLTensor*)pos_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input pos ndim mismatch, expected 1", (long long)((((DLTensor*)pos_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t pos_len = ((int32_t)((int64_t*)verify_pos_shape)[0]);
  void* verify_pos_strides = (((DLTensor*)pos_handle)[0].strides);
  void* pos = (((DLTensor*)pos_handle)[0].data);
  if (!((verify_dead_row_cut_is_null || ((((DLTensor*)dead_row_cut_handle)[0].ndim) == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut ndim mismatch, expected 1");
    return -1;
  }
  int32_t condval_6;
  if (!verify_dead_row_cut_is_null) {
    condval_6 = ((int32_t)((int64_t*)verify_dead_row_cut_shape)[0]);
  } else {
    condval_6 = 0;
  }
  int32_t cut_len = condval_6;
  void* condval_7;
  if (!verify_dead_row_cut_is_null) {
    condval_7 = (((DLTensor*)dead_row_cut_handle)[0].strides);
  } else {
    uint64_t v__1 = (uint64_t)0;
    condval_7 = (*(void* *)(&(v__1)));
  }
  void* verify_dead_row_cut_strides = condval_7;
  void* condval_8;
  if (!verify_dead_row_cut_is_null) {
    condval_8 = (((DLTensor*)dead_row_cut_handle)[0].data);
  } else {
    uint64_t v__2 = (uint64_t)0;
    condval_8 = (*(void* *)(&(v__2)));
  }
  void* dead_row_cut = condval_8;
  if (!(((((((DLTensor*)sampled_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)sampled_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)sampled_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input sampled dtype mismatch, expected int64");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_sampled_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input sampled shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_sampled_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((verify_sampled_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)verify_sampled_strides)[1]);
  }
  if (!((condval_9 == 1))) {
    int32_t condval_10;
    if ((verify_sampled_strides == NULL)) {
      condval_10 = 1;
    } else {
      condval_10 = ((int32_t)((int64_t*)verify_sampled_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input sampled strides[1] violates packed ABI constraint", (long long)(condval_10), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)sampled_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input sampled byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)sampled_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input sampled device_type mismatch, expected cuda", (long long)((((DLTensor*)sampled_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((reqs == 0) || !(sampled == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input sampled data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)num_sampled_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)num_sampled_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)num_sampled_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input num_sampled dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_sampled_shape)[0]) == ((int32_t)((int64_t*)verify_num_sampled_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input num_sampled shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_sampled_shape)[0])), (long long)(((int32_t)((int64_t*)verify_num_sampled_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((verify_num_sampled_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)verify_num_sampled_strides)[0]);
  }
  if (!(((condval_11 == 1) || (reqs == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input num_sampled strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)num_sampled_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input num_sampled byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)num_sampled_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)num_sampled_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input num_sampled device_id violates packed ABI constraint", (long long)((((DLTensor*)num_sampled_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)num_sampled_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input num_sampled device_type mismatch, expected cuda", (long long)((((DLTensor*)num_sampled_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((reqs == 0) || !(num_sampled == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input num_sampled data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)target_lse_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)target_lse_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)target_lse_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input target_lse dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_sampled_shape)[0]) == ((int32_t)((int64_t*)verify_target_lse_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input target_lse shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_sampled_shape)[0])), (long long)(((int32_t)((int64_t*)verify_target_lse_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((verify_target_lse_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)verify_target_lse_strides)[0]);
  }
  if (!(((condval_12 == 1) || (reqs == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input target_lse strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)target_lse_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input target_lse byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)target_lse_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)target_lse_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input target_lse device_id violates packed ABI constraint", (long long)((((DLTensor*)target_lse_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)target_lse_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input target_lse device_type mismatch, expected cuda", (long long)((((DLTensor*)target_lse_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((reqs == 0) || !(target_lse == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input target_lse data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)draft_lse_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)draft_lse_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)draft_lse_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input draft_lse dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_sampled_shape)[0]) == ((int32_t)((int64_t*)verify_draft_lse_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input draft_lse shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_sampled_shape)[0])), (long long)(((int32_t)((int64_t*)verify_draft_lse_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((verify_draft_lse_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)verify_draft_lse_strides)[0]);
  }
  if (!(((condval_13 == 1) || (reqs == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input draft_lse strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)draft_lse_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input draft_lse byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)draft_lse_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)draft_lse_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input draft_lse device_id violates packed ABI constraint", (long long)((((DLTensor*)draft_lse_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)draft_lse_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input draft_lse device_type mismatch, expected cuda", (long long)((((DLTensor*)draft_lse_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((reqs == 0) || !(draft_lse == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input draft_lse data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)cumulative_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)cumulative_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)cumulative_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cumulative dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_14;
  if ((verify_cumulative_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)verify_cumulative_strides)[0]);
  }
  if (!(((condval_14 == 1) || (num_logits == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cumulative strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)cumulative_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cumulative byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)cumulative_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cumulative_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cumulative device_id violates packed ABI constraint", (long long)((((DLTensor*)cumulative_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cumulative_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cumulative device_type mismatch, expected cuda", (long long)((((DLTensor*)cumulative_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((num_logits == 0) || !(cumulative == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cumulative data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)logits_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)logits_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)logits_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input logits dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_cumulative_shape)[0]) == ((int32_t)((int64_t*)verify_logits_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input logits shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_cumulative_shape)[0])), (long long)(((int32_t)((int64_t*)verify_logits_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_15;
  if ((verify_logits_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)verify_logits_strides)[1]);
  }
  if (!(((condval_15 == 1) || (vocab == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input logits strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)logits_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input logits byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)logits_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input logits device_id violates packed ABI constraint", (long long)((((DLTensor*)logits_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input logits device_type mismatch, expected cuda", (long long)((((DLTensor*)logits_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((num_logits == 0) || (vocab == 0)) || !(logits == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input logits data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_argmax_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)local_argmax_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)local_argmax_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_argmax dtype mismatch, expected int64");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_cumulative_shape)[0]) == ((int32_t)((int64_t*)verify_local_argmax_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_argmax shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_cumulative_shape)[0])), (long long)(((int32_t)((int64_t*)verify_local_argmax_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_16;
  if ((verify_local_argmax_strides == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)verify_local_argmax_strides)[1]);
  }
  if (!(((condval_16 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_argmax strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_argmax_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_argmax byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_argmax_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_argmax_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_argmax device_id violates packed ABI constraint", (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_argmax_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_argmax device_type mismatch, expected cuda", (long long)((((DLTensor*)local_argmax_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((num_logits == 0) || (blocks == 0)) || !(local_argmax == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_argmax data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_max_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)local_max_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)local_max_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_max dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_cumulative_shape)[0]) == ((int32_t)((int64_t*)verify_local_max_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_max shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_cumulative_shape)[0])), (long long)(((int32_t)((int64_t*)verify_local_max_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_local_argmax_shape)[1]) == ((int32_t)((int64_t*)verify_local_max_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_max shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_local_argmax_shape)[1])), (long long)(((int32_t)((int64_t*)verify_local_max_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_17;
  if ((verify_local_max_strides == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)verify_local_max_strides)[1]);
  }
  if (!(((condval_17 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_max strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_max_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_max byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_max_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_max device_id violates packed ABI constraint", (long long)((((DLTensor*)local_max_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_max device_type mismatch, expected cuda", (long long)((((DLTensor*)local_max_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((num_logits == 0) || (blocks == 0)) || !(local_max == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_max data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_sumexp_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)local_sumexp_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)local_sumexp_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_sumexp dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_cumulative_shape)[0]) == ((int32_t)((int64_t*)verify_local_sumexp_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_sumexp shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_cumulative_shape)[0])), (long long)(((int32_t)((int64_t*)verify_local_sumexp_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_local_argmax_shape)[1]) == ((int32_t)((int64_t*)verify_local_sumexp_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_sumexp shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_local_argmax_shape)[1])), (long long)(((int32_t)((int64_t*)verify_local_sumexp_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_18;
  if ((verify_local_sumexp_strides == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)verify_local_sumexp_strides)[1]);
  }
  if (!(((condval_18 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_sumexp strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_sumexp_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_sumexp byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_sumexp_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_sumexp_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_sumexp device_id violates packed ABI constraint", (long long)((((DLTensor*)local_sumexp_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_sumexp_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input local_sumexp device_type mismatch, expected cuda", (long long)((((DLTensor*)local_sumexp_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((num_logits == 0) || (blocks == 0)) || !(local_sumexp == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input local_sumexp data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)drafts_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)drafts_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)drafts_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input drafts dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_19;
  if ((verify_drafts_strides == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)verify_drafts_strides)[0]);
  }
  if (!(((condval_19 == 1) || (drafts_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input drafts strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)drafts_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input drafts byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)drafts_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)drafts_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input drafts device_id violates packed ABI constraint", (long long)((((DLTensor*)drafts_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)drafts_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input drafts device_type mismatch, expected cuda", (long long)((((DLTensor*)drafts_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((drafts_len == 0) || !(drafts == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input drafts data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)cu_num_logits_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)cu_num_logits_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)cu_num_logits_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cu_num_logits dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)verify_cu_num_logits_shape)[0]) == (reqs + 1)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cu_num_logits shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)verify_cu_num_logits_shape)[0])), (long long)((reqs + 1)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_20;
  if ((verify_cu_num_logits_strides == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)verify_cu_num_logits_strides)[0]);
  }
  if (!(((condval_20 == 1) || (reqs == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cu_num_logits strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)cu_num_logits_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cu_num_logits byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)cu_num_logits_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_num_logits_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cu_num_logits device_id violates packed ABI constraint", (long long)((((DLTensor*)cu_num_logits_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_num_logits_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input cu_num_logits device_type mismatch, expected cuda", (long long)((((DLTensor*)cu_num_logits_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((reqs == -1) || !(cu_num_logits == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input cu_num_logits data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)idx_mapping_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)idx_mapping_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)idx_mapping_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input idx_mapping dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_21;
  if ((verify_idx_mapping_strides == NULL)) {
    condval_21 = 1;
  } else {
    condval_21 = ((int32_t)((int64_t*)verify_idx_mapping_strides)[0]);
  }
  if (!(((condval_21 == 1) || (idx_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input idx_mapping strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)idx_mapping_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input idx_mapping byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)idx_mapping_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)idx_mapping_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input idx_mapping device_id violates packed ABI constraint", (long long)((((DLTensor*)idx_mapping_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)idx_mapping_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input idx_mapping device_type mismatch, expected cuda", (long long)((((DLTensor*)idx_mapping_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((idx_len == 0) || !(idx_mapping == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input idx_mapping data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)temperature_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)temperature_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)temperature_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input temperature dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_22;
  if ((verify_temperature_strides == NULL)) {
    condval_22 = 1;
  } else {
    condval_22 = ((int32_t)((int64_t*)verify_temperature_strides)[0]);
  }
  if (!(((condval_22 == 1) || (temp_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input temperature strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)temperature_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input temperature byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)temperature_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input temperature device_id violates packed ABI constraint", (long long)((((DLTensor*)temperature_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input temperature device_type mismatch, expected cuda", (long long)((((DLTensor*)temperature_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((temp_len == 0) || !(temperature == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input temperature data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)seeds_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)seeds_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)seeds_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input seeds dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_23;
  if ((verify_seeds_strides == NULL)) {
    condval_23 = 1;
  } else {
    condval_23 = ((int32_t)((int64_t*)verify_seeds_strides)[0]);
  }
  if (!(((condval_23 == 1) || (seed_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input seeds strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)seeds_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input seeds byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)seeds_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)seeds_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input seeds device_id violates packed ABI constraint", (long long)((((DLTensor*)seeds_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)seeds_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input seeds device_type mismatch, expected cuda", (long long)((((DLTensor*)seeds_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seed_len == 0) || !(seeds == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input seeds data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)pos_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)pos_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)pos_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input pos dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_24;
  if ((verify_pos_strides == NULL)) {
    condval_24 = 1;
  } else {
    condval_24 = ((int32_t)((int64_t*)verify_pos_strides)[0]);
  }
  if (!(((condval_24 == 1) || (pos_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input pos strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)pos_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input pos byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)pos_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pos_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input pos device_id violates packed ABI constraint", (long long)((((DLTensor*)pos_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pos_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel verify input pos device_type mismatch, expected cuda", (long long)((((DLTensor*)pos_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((pos_len == 0) || !(pos == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input pos data pointer is NULL");
    return -1;
  }
  uint8_t condval_25;
  if (!verify_dead_row_cut_is_null) {
    condval_25 = (((DLTensor*)dead_row_cut_handle)[0].dtype.code);
  } else {
    condval_25 = (uint8_t)0;
  }
  uint8_t condval_26;
  if (!verify_dead_row_cut_is_null) {
    condval_26 = (((DLTensor*)dead_row_cut_handle)[0].dtype.bits);
  } else {
    condval_26 = (uint8_t)32;
  }
  uint16_t condval_27;
  if (!verify_dead_row_cut_is_null) {
    condval_27 = (((DLTensor*)dead_row_cut_handle)[0].dtype.lanes);
  } else {
    condval_27 = (uint16_t)1;
  }
  if (!((verify_dead_row_cut_is_null || (((condval_25 == (uint8_t)0) && (condval_26 == (uint8_t)32)) && (condval_27 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_28;
  if ((verify_dead_row_cut_strides == NULL)) {
    condval_28 = 1;
  } else {
    condval_28 = ((int32_t)((int64_t*)verify_dead_row_cut_strides)[0]);
  }
  if (!(((verify_dead_row_cut_is_null || (condval_28 == 1)) || (cut_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_29;
  if (!verify_dead_row_cut_is_null) {
    condval_29 = (((DLTensor*)dead_row_cut_handle)[0].byte_offset);
  } else {
    condval_29 = (uint64_t)0;
  }
  if (!((verify_dead_row_cut_is_null || ((uint64_t)0 == condval_29)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_30;
  if (!verify_dead_row_cut_is_null) {
    condval_30 = (((DLTensor*)dead_row_cut_handle)[0].device.device_id);
  } else {
    condval_30 = 0;
  }
  if (!((verify_dead_row_cut_is_null || (condval_30 == (((DLTensor*)sampled_handle)[0].device.device_id))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_31;
  if (!verify_dead_row_cut_is_null) {
    condval_31 = (((DLTensor*)dead_row_cut_handle)[0].device.device_type);
  } else {
    condval_31 = 0;
  }
  if (!((verify_dead_row_cut_is_null || (condval_31 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((verify_dead_row_cut_is_null || (cut_len == 0)) || !(dead_row_cut == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel verify input dead_row_cut data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (cu_num_logits == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = cu_num_logits;
  if (cumulative == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = cumulative;
  if (draft_lse == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = draft_lse;
  if (drafts == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = drafts;
  if (idx_mapping == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = idx_mapping;
  if (local_argmax == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = local_argmax;
  if (local_max == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = local_max;
  if (local_sumexp == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = local_sumexp;
  if (logits == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_ptr) = logits;
  if (num_sampled == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_ptr) = num_sampled;
  if (pos == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_ptr) = pos;
  if (sampled == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_ptr) = sampled;
  if (seeds == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_ptr) = seeds;
  if (target_lse == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_ptr) = target_lse;
  if (temperature == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_ptr) = temperature;
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)apply_temperature);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = argmax_stride;
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)blocks);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = logits_stride;
  (((TVMFFIAny*)stack_ffi_any)[19].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[19].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].v_int64) = max_stride;
  (((TVMFFIAny*)stack_ffi_any)[20].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[20].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[20].v_int64) = ((int64_t)reqs);
  (((TVMFFIAny*)stack_ffi_any)[21].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[21].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[21].v_int64) = sampled_stride;
  (((TVMFFIAny*)stack_ffi_any)[22].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[22].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[22].v_int64) = sumexp_stride;
  (((TVMFFIAny*)stack_ffi_any)[23].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[23].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[23].v_int64) = ((int64_t)vocab);
  (((TVMFFIAny*)stack_ffi_any)[24].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[24].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[24].v_int64) = ((int64_t)reqs);
  (((TVMFFIAny*)stack_ffi_any)[25].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[25].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[25].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[26].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[26].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[26].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[27].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[27].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[27].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[28].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[28].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[28].v_int64) = ((int64_t)1152);
  (((TVMFFIAny*)stack_ffi_any)[29].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[29].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[29].v_int64) = (int64_t)0;
  if (verify_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "verify_kernel", &verify_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(verify_kernel_packed, (TVMFFIAny*) stack_ffi_any, 29, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_verify(self, args, num_args, result);
}
