
__device__ __forceinline__ void vllm_rank_rows_b128(void* d, const void* s) {
  *reinterpret_cast<uint4*>(d) = *reinterpret_cast<const uint4*>(s);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_rows_kernel(int* __restrict__ out, int* __restrict__ src, int out_words, int packs, int rows, int src_words, int world);
extern "C" __global__ void __launch_bounds__(128, 1) collectives_rank_rows_kernel(int* __restrict__ out, int* __restrict__ src, int out_words, int packs, int rows, int src_words, int world) {
  if (((((int)blockIdx.y) * 128) + ((int)threadIdx.x)) < (world * packs)) {
    int64_t rmod = (((((int64_t)((int)blockIdx.y)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)packs));
    int64_t rmod_1 = (((((int64_t)((int)blockIdx.y)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)packs));
    int64_t rdiv = (((((int64_t)((int)blockIdx.y)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) / ((int64_t)packs));
    int64_t rmod_2 = (((((int64_t)((int)blockIdx.y)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)packs));
    int64_t rmod_3 = (((((int64_t)((int)blockIdx.y)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)packs));
    int64_t rdiv_1 = (((((int64_t)((int)blockIdx.y)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) / ((int64_t)packs));
    vllm_rank_rows_b128((&(out[(((((int64_t)((int)blockIdx.y)) * (int64_t)512) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + (((int64_t)((int)blockIdx.x)) * ((int64_t)out_words)))])), (&(src[(((((((int64_t)0 <= ((int64_t)packs)) && ((int64_t)0 <= rmod_2)) || ((((int64_t)packs) < (int64_t)0) && (rmod_2 <= (int64_t)0))) ? rmod_2 : (rmod_2 + ((int64_t)packs))) * (int64_t)4) + ((((((((int64_t)0 <= ((int64_t)packs)) && ((int64_t)0 <= rmod_3)) || ((((int64_t)packs) < (int64_t)0) && (rmod_3 <= (int64_t)0))) ? rdiv_1 : (rdiv_1 - (int64_t)1)) * ((int64_t)rows)) + ((int64_t)((int)blockIdx.x))) * ((int64_t)src_words)))])));
  }
}

