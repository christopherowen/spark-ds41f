#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void copy_logits_kernel(float* __restrict__ dst, const float* __restrict__ src, int cols, int row_stride, int rows);
extern "C" __global__ void __launch_bounds__(256, 1) copy_logits_kernel(float* __restrict__ dst, const float* __restrict__ src, int cols, int row_stride, int rows) {
  if ((((((int)blockIdx.x) * 1024) + (((int)threadIdx.x) * 4)) + 4) <= cols) {
    *(float4*)(dst + (((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + (((int64_t)((int)blockIdx.y)) * ((int64_t)cols)))) = *(float4*)(src + (((((int64_t)((int)blockIdx.x)) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + (((int64_t)((int)blockIdx.y)) * ((int64_t)row_stride))));
  }
}

