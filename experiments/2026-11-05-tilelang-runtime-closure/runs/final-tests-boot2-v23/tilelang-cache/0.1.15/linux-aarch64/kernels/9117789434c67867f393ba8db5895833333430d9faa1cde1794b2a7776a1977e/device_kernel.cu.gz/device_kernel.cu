#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_gemv_kernel(const bfloat16_t* __restrict__ A, bfloat16_t* __restrict__ C, const bfloat16_t* __restrict__ W, int M);
extern "C" __global__ void __launch_bounds__(128, 1) vision_gemv_kernel(const bfloat16_t* __restrict__ A, bfloat16_t* __restrict__ C, const bfloat16_t* __restrict__ W, int M) {
  float acc[8];
  bfloat16_t weights[8];
  bfloat16_t values[8];
  float total = 0x0p+0f/*0.000000e+00*/;
  extern __shared__ __align__(1024) float partial[];
  #pragma unroll
  for (int i = 0; i < 8; ++i) {
    acc[i] = 0x0p+0f/*0.000000e+00*/;
  }
  for (int step = 0; step < 3; ++step) {
    if (((step * 4) + (((int)threadIdx.x) >> 5)) < 11) {
      *(uint4*)(weights + 0) = *(uint4*)(W + (((((int)blockIdx.x) * 2816) + (step * 1024)) + (((int)threadIdx.x) * 8)));
      #pragma unroll
      for (int r = 0; r < 8; ++r) {
        if (((((int)blockIdx.y) * 8) + r) < M) {
          *(uint4*)(values + 0) = *(uint4*)(A + ((((((int64_t)((int)blockIdx.y)) * (int64_t)22528) + (((int64_t)r) * (int64_t)2816)) + (((int64_t)step) * (int64_t)1024)) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
          #pragma unroll
          for (int e = 0; e < 8; ++e) {
            acc[r] = __fmaf_rn(((float)weights[e]), ((float)values[e]), acc[r]);
          }
        }
      }
    }
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 8; ++i_1) {
    total = acc[i_1];
    #pragma unroll
    for (int level = 0; level < 5; ++level) {
      total = (total + __shfl_xor_sync((uint)4294967295, total, (1 << level), 32));
    }
    if ((((int)threadIdx.x) % 32) == 0) {
      partial[((i_1 * 4) + (((int)threadIdx.x) >> 5))] = total;
    }
  }
  __syncthreads();
  if (((int)threadIdx.x) < 32) {
    #pragma unroll
    for (int i_2 = 0; i_2 < 8; ++i_2) {
      float condval;
      if ((((int)threadIdx.x) < 4)) {
        condval = partial[((i_2 * 4) + ((int)threadIdx.x))];
      } else {
        condval = 0x0p+0f/*0.000000e+00*/;
      }
      total = condval;
      #pragma unroll
      for (int level_1 = 0; level_1 < 5; ++level_1) {
        total = (total + __shfl_xor_sync((uint)4294967295, total, (1 << level_1), 32));
      }
      acc[i_2] = total;
    }
    if (((int)threadIdx.x) == 0) {
      #pragma unroll
      for (int r_1 = 0; r_1 < 8; ++r_1) {
        if (((((int)blockIdx.y) * 8) + r_1) < M) {
          C[(((((int64_t)((int)blockIdx.y)) * (int64_t)8192) + (((int64_t)r_1) * (int64_t)1024)) + ((int64_t)((int)blockIdx.x)))] = ((bfloat16_t)acc[r_1]);
        }
      }
    }
  }
}

