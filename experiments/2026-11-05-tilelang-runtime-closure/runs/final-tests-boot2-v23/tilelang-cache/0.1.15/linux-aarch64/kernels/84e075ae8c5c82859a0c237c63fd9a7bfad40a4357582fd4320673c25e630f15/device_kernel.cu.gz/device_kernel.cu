#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_linear_kernel(__grid_constant__ const CUtensorMap A_desc, const bfloat16_t* __restrict__ Bias, bfloat16_t* __restrict__ C, __grid_constant__ const CUtensorMap W_desc, int M);
extern "C" __global__ void __launch_bounds__(384, 1) vision_linear_kernel(__grid_constant__ const CUtensorMap A_desc, const bfloat16_t* __restrict__ Bias, bfloat16_t* __restrict__ C, __grid_constant__ const CUtensorMap W_desc, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* W_shared = ((void*)((char*)buf_dyn_shmem + 32768));
  __shared__ __align__(16) uint64_t mbarrier_mem[4];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float acc[64];
  bfloat16_t out[64];
  float part[64];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(A_desc);
    tl::prefetch_tma_descriptor(W_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(256);
    mbarrier[3].init(256);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int ko = 0; ko < 16; ++ko) {
      mbarrier[((ko & 1) + 2)].wait((((ko & 3) >> 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[(ko & 1)].expect_transaction(16384);
        tl::tma_load(A_desc, mbarrier[(ko & 1)], (&(((bfloat16_t*)A_shared)[((ko & 1) * 8192)])), (ko * 64), (((int)blockIdx.y) * 128));
        mbarrier[(ko & 1)].arrive_and_expect_tx(16384);
        tl::tma_load(W_desc, mbarrier[(ko & 1)], (&(((bfloat16_t*)W_shared)[((ko & 1) * 8192)])), (ko * 64), (((int)blockIdx.x) * 128));
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i = 0; i < 16; ++i) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(acc + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    for (int ko_1 = 0; ko_1 < 16; ++ko_1) {
      mbarrier[(ko_1 & 1)].wait(((ko_1 & 3) >> 1));
      {
        bfloat16_t A_local[32];
        bfloat16_t B_local[16];
        #pragma unroll
        for (int i_1 = 0; i_1 < 16; ++i_1) {
          float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
          *(float4*)(part + (i_1 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
        }
        for (int ki = 0; ki < 4; ++ki) {
          #pragma unroll
          for (int i_2 = 0; i_2 < 4; ++i_2) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((ko_1 & 1) * 8192) + (((((int)threadIdx.x) & 63) >> 5) * 4096)) + (i_2 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_2 * 8)])));
          }
          #pragma unroll
          for (int i_3 = 0; i_3 < 2; ++i_3) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)W_shared)[(((((((((ko_1 & 1) * 8192) + ((((((int)threadIdx.x) >> 6) + 2) & 3) * 2048)) + (i_3 * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[(i_3 * 8)])));
          }
          for (int i_4 = 0; i_4 < 4; ++i_4) {
            for (int j = 0; j < 2; ++j) {
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(part + ((i_4 * 16) + (j * 8))), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + (j * 8)));
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(part + (((i_4 * 16) + (j * 8)) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + ((j * 8) + 4)));
            }
          }
        }
      }
      mbarrier[((ko_1 & 1) + 2)].arrive();
      #pragma unroll
      for (int i_5 = 0; i_5 < 16; ++i_5) {
        float4 __1;
          float4 v_ = *(float4*)(acc + (i_5 * 4));
          float4 v__1 = *(float4*)(part + (i_5 * 4));
          *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
          *(float2*)(&(__1.z)) = tl::add2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
        *(float4*)(acc + (i_5 * 4)) = __1;
      }
    }
    #pragma unroll
    for (int i_6 = 0; i_6 < 64; ++i_6) {
      bfloat16_t biased = ((bfloat16_t)__fadd_rn(acc[i_6], ((float)Bias[((((((((int)blockIdx.x) * 128) + ((((int)threadIdx.x) >> 6) * 32)) + (((i_6 & 15) >> 2) * 8)) + ((((int)threadIdx.x) & 3) * 2)) + (i_6 & 1)) - 64)])));
      out[i_6] = biased;
    }
    #pragma unroll
    for (int i_7 = 0; i_7 < 32; ++i_7) {
      if ((((((((int)blockIdx.y) * 128) + (((((int)threadIdx.x) & 63) >> 5) * 64)) + ((i_7 >> 3) * 16)) + ((i_7 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M) {
        *(uint1*)(C + ((((((((((((int64_t)((int)blockIdx.y)) * (int64_t)32768) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)16384)) + ((((int64_t)i_7) >> (int64_t)3) * (int64_t)4096)) + ((((int64_t)i_7) & (int64_t)1) * (int64_t)2048)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)256)) + (((int64_t)((int)blockIdx.x)) * (int64_t)128)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)32)) + (((((int64_t)i_7) & (int64_t)7) >> (int64_t)1) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2)) - (int64_t)64)) = *(uint1*)(out + (i_7 * 2));
      }
    }
  }
}

