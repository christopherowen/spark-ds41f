
// Triton's bundled libdevice __nv_logf, as used by the sampling family.
// CUDA's logf and lg2.approx * ln(2) can move a min-p threshold by one ULP.
__device__ __forceinline__ float vllm_control_log(float x) {
  float result;
  asm("{\n"
      ".reg .pred tiny, fin, zero;\n"
      ".reg .b32 z, o, e, m, f, r, p, q, l, w;\n"
      "setp.lt.f32 tiny, %1, 0f00800000;\n"
      "mul.rn.f32 z, %1, 0f4B000000;\n"
      "selp.f32 z, z, %1, tiny;\n"
      "selp.f32 o, 0fC1B80000, 0f00000000, tiny;\n"
      "add.s32 e, z, -1059760811;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, z, e;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "fma.rn.ftz.f32 f, f, 0f34000000, o;\n"
      "add.rn.f32 r, m, 0fBF800000;\n"
      "fma.rn.ftz.f32 p, 0fBE055027, r, 0f3E1039F6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBDF8CDCC;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E0F2955;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2AD8B9;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CED0B;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE7FFF22;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAA78;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Preserve the bundled libdevice exceptional-value handling.
      "setp.lt.u32 fin, z, 2139095040;\n"
      "fma.rn.ftz.f32 w, z, 0f7F800000, 0f7F800000;\n"
      "selp.f32 l, l, w, fin;\n"
      "setp.eq.f32 zero, z, 0f00000000;\n"
      "selp.f32 %0, 0fFF800000, l, zero;\n"
      "}"
      : "=f"(result) : "f"(x));
  return result;
}
// Triton's masked loads and stores: a masked lane keeps ``other`` and never waits on
// memory, and nothing branches, so a tile's loads issue together.
__device__ __forceinline__ int vllm_control_load_if_b32(const void* p, int other,
                                                       bool ok) {
  int v = other;
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q ld.global.b32 %0, [%1];\n}"
               : "+r"(v) : "l"(p), "r"((int)ok));
  return v;
}
__device__ __forceinline__ float vllm_control_load_if_f32(const void* p, float other,
                                                         bool ok) {
  float v = other;
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q ld.global.f32 %0, [%1];\n}"
               : "+f"(v) : "l"(p), "r"((int)ok));
  return v;
}
__device__ __forceinline__ void vllm_control_store_if_b64(void* p, long long v,
                                                          bool ok) {
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q st.global.b64 [%0], %1;\n}"
               :: "l"(p), "l"(v), "r"((int)ok) : "memory");
}
__device__ __forceinline__ void vllm_control_store_if(void* p, float v, bool ok) {
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q st.global.f32 [%0], %1;\n}"
               :: "l"(p), "f"(v), "r"((int)ok) : "memory");
}
__device__ __forceinline__ float vllm_control_reciprocal(float x) {
  float y;
  asm("rcp.approx.ftz.f32 %0, %1;" : "=f"(y) : "f"(x));
  return y;
}
__device__ __forceinline__ float vllm_control_penalty(float x, float scale,
    float freq, int count, float presence) {
  x = __fmul_rn(x, scale);
  x = __fmaf_rn(-freq, (float)count, x);
  return __fmaf_rn(-presence, (float)(count > 0), x);
}

// tl.exp of an FP32 value: the product with log2(e), then ex2.approx.f32 without
// flush-to-zero.
__device__ __forceinline__ float vllm_topk_exp(float x) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "mul.rn.f32 t, %1, 0f3FB8AA3B;\n"
      "ex2.approx.f32 %0, t;\n"
      "}"
      : "=f"(y)
      : "f"(x));
  return y;
}

// Triton's FP32 `/`: div.full.f32.
__device__ __forceinline__ float vllm_topk_div(float x, float y) {
  float q;
  asm("div.full.f32 %0, %1, %2;" : "=f"(q) : "f"(x), "f"(y));
  return q;
}

// tl.sqrt: sqrt.approx.ftz.f32.
__device__ __forceinline__ float vllm_topk_sqrt(float x) {
  float y;
  asm("sqrt.approx.ftz.f32 %0, %1;" : "=f"(y) : "f"(x));
  return y;
}

// FP32 arithmetic rounded to nearest, out of nvcc's contraction and the TileLang
// simplifier's reach.
__device__ __forceinline__ float vllm_topk_add(float a, float b) {
  float c;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_sub(float a, float b) {
  float c;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_mul(float a, float b) {
  float c;
  asm("mul.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_fma(float a, float b, float c) {
  float d;
  asm("fma.rn.f32 %0, %1, %2, %3;" : "=f"(d) : "f"(a), "f"(b), "f"(c));
  return d;
}

// max.f32 and min.f32: a NaN gives way to the other operand.
__device__ __forceinline__ float vllm_topk_max(float a, float b) {
  float c;
  asm("max.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_min(float a, float b) {
  float c;
  asm("min.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}

// Ordered comparisons: false when either side is NaN.
__device__ __forceinline__ int vllm_topk_lt(float a, float b) { return a < b; }
__device__ __forceinline__ int vllm_topk_le(float a, float b) { return a <= b; }
__device__ __forceinline__ int vllm_topk_gt(float a, float b) { return a > b; }
__device__ __forceinline__ int vllm_topk_ge(float a, float b) { return a >= b; }
__device__ __forceinline__ int vllm_topk_eq(float a, float b) { return a == b; }

// tl.abs(a - b) < 1e-9, the tolerance of the pivot searches.
__device__ __forceinline__ int vllm_topk_near(float a, float b) {
  float d;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(d) : "f"(a), "f"(b));
  return fabsf(d) < __int_as_float(0x3089705F);
}

// tl.cast to uint32 and to int32: cvt.rzi, saturating, NaN to 0.
__device__ __forceinline__ unsigned int vllm_topk_u32(float x) {
  unsigned int y;
  asm("cvt.rzi.u32.f32 %0, %1;" : "=r"(y) : "f"(x));
  return y;
}
__device__ __forceinline__ int vllm_topk_i32(float x) {
  int y;
  asm("cvt.rzi.s32.f32 %0, %1;" : "=r"(y) : "f"(x));
  return y;
}

// The warp's ballot of a flag, a ballot's flags, and its flags below this lane.
__device__ __forceinline__ unsigned int vllm_topk_ballot(int flag) {
  return __ballot_sync(0xffffffffu, flag);
}
__device__ __forceinline__ int vllm_topk_popc(unsigned int mask) {
  return __popc(mask);
}
__device__ __forceinline__ int vllm_topk_below(unsigned int mask) {
  unsigned int lower;
  asm("mov.u32 %0, %%lanemask_lt;" : "=r"(lower));
  return __popc(mask & lower);
}

// The warp's sum of an integer, its inclusive prefix sums over the lanes, and the
// value of a lane.
__device__ __forceinline__ int vllm_topk_warp_count(int v) {
  return __reduce_add_sync(0xffffffffu, v);
}
__device__ __forceinline__ int vllm_topk_warp_scan(int v) {
  const int lane = threadIdx.x & 31;
#pragma unroll
  for (int d = 1; d < 32; d <<= 1) {
    const int u = __shfl_up_sync(0xffffffffu, v, d);
    if (lane >= d) v += u;
  }
  return v;
}
__device__ __forceinline__ int vllm_topk_lane(int v, int lane) {
  return __shfl_sync(0xffffffffu, v, lane);
}

// Whether any thread of the block passes a nonzero flag (a barrier).
__device__ __forceinline__ int vllm_topk_any(int flag) {
  return __syncthreads_or(flag);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void topp_step_kernel(const float* __restrict__ logits, const float* __restrict__ p, float* __restrict__ parts, const float* __restrict__ stats, int64_t logits_stride, int round_, int rows);
extern "C" __global__ void __launch_bounds__(256, 1) topp_step_kernel(const float* __restrict__ logits, const float* __restrict__ p, float* __restrict__ parts, const float* __restrict__ stats, int64_t logits_stride, int round_, int rows) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* wide = ((void*)((char*)buf_dyn_shmem + 0));
  void* red = ((void*)((char*)buf_dyn_shmem + 8192));
  void* red_i = ((void*)((char*)buf_dyn_shmem + 8704));
  float part_max = 0x0p+0f/*0.000000e+00*/;
  float part_sum = 0x0p+0f/*0.000000e+00*/;
  float least[1];
  float finite[1];
  float top[1];
  float weight = 0x0p+0f/*0.000000e+00*/;
  float norm_1[1];
  float hi[1];
  float lo[1];
  int live[1];
  int done[1];
  float ladder[8];
  float log_ratio = 0x0p+0f/*0.000000e+00*/;
  float slot_mass[8];
  float slot_minl[8];
  float slot_nmin[8];
  float part_minl = 0x0p+0f/*0.000000e+00*/;
  float part_nmin = 0x0p+0f/*0.000000e+00*/;
  float mass[1];
  float gmin[1];
  float nmin[1];
  float mark[4];
  float values[8];
  float probs[8];
  float sums[8];
  float lows[8];
  int counts[8];
  float tally = 0x0p+0f/*0.000000e+00*/;
  float threshold = p[(((int64_t)((int)blockIdx.x)) >> (int64_t)5)];
  bool if_condition = (vllm_topk_ge(p[(((int64_t)((int)blockIdx.x)) >> (int64_t)5)], 0x1p+0f/*1.000000e+00*/) == 0);
  if (if_condition) {
    part_max = stats[(((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4))];
    part_sum = stats[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4)) + (int64_t)1)];
    least[0] = stats[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4)) + (int64_t)2)];
    finite[0] = stats[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4)) + (int64_t)3)];
    top[0] = part_max;
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 16, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 8, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 4, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 2, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 1, 32));
    float condval;
    if ((vllm_topk_eq(part_max, -CUDART_INF_F) != 0)) {
      condval = 0x0p+0f/*0.000000e+00*/;
    } else {
      condval = vllm_topk_exp(vllm_topk_sub(part_max, top[0]));
    }
    weight = condval;
    norm_1[0] = vllm_topk_fma(weight, part_sum, __shfl_xor_sync((uint)4294967295, vllm_topk_mul(weight, part_sum), 16, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 8, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 4, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 2, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 1, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 16, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 8, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 4, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 2, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 1, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 16, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 8, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 4, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 2, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 1, 32));
    hi[0] = vllm_topk_div(0x1p+0f/*1.000000e+00*/, norm_1[0]);
    lo[0] = vllm_topk_max(vllm_topk_div(vllm_topk_exp(vllm_topk_sub(least[0], top[0])), norm_1[0]), 0x1.4484bfeebc2ap-100f/*1.000000e-30*/);
    live[0] = ((int)(((vllm_topk_le(norm_1[0], 0x0p+0f/*0.000000e+00*/) == 0) & (vllm_topk_lt(finite[0], 0x1p+0f/*1.000000e+00*/) == 0)) & (vllm_topk_le(hi[0], vllm_topk_mul(lo[0], 0x1.000010c6f7a0bp+0f/*1.000001e+00*/)) == 0)));
    done[0] = (1 - live[0]);
    bool if_condition_1 = (vllm_topk_any(live[0]) != 0);
    if (if_condition_1) {
      for (int j = 0; j < round_; ++j) {
        bool if_condition_2 = (vllm_topk_any(((int)(done[0] == 0))) != 0);
        if (if_condition_2) {
          part_minl = parts[(((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)j) * (int64_t)768)) + (((int64_t)((int)threadIdx.x)) * (int64_t)3)) + (int64_t)1)];
          part_nmin = parts[(((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)j) * (int64_t)768)) + (((int64_t)((int)threadIdx.x)) * (int64_t)3)) + (int64_t)2)];
          mass[0] = parts[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)j) * (int64_t)768)) + (((int64_t)((int)threadIdx.x)) * (int64_t)3))];
          gmin[0] = part_minl;
          mass[0] = vllm_topk_add(mass[0], __shfl_xor_sync((uint)4294967295, mass[0], 16, 32));
          mass[0] = vllm_topk_add(mass[0], __shfl_xor_sync((uint)4294967295, mass[0], 8, 32));
          gmin[0] = vllm_topk_min(gmin[0], __shfl_xor_sync((uint)4294967295, gmin[0], 16, 32));
          gmin[0] = vllm_topk_min(gmin[0], __shfl_xor_sync((uint)4294967295, gmin[0], 8, 32));
          __syncthreads();
          if (((((int)threadIdx.x) & 31) < 8) & (bool)1) {
            ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + (((int)threadIdx.x) >> 5))] = mass[0];
            ((float*)red)[((((((int)threadIdx.x) & 7) * 8) + (((int)threadIdx.x) >> 5)) + 64)] = gmin[0];
          }
          __syncthreads();
          mass[0] = vllm_topk_add(vllm_topk_add(vllm_topk_add(((float*)red)[((((int)threadIdx.x) & 7) * 8)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 4)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 2)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 6)])), vllm_topk_add(vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 1)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 5)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 3)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 7)])));
          gmin[0] = vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 64)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 65)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 66)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 67)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 68)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 69)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 70)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 71)]);
          float condval_1;
          if ((vllm_topk_near(part_minl, gmin[0]) != 0)) {
            condval_1 = part_nmin;
          } else {
            condval_1 = 0x0p+0f/*0.000000e+00*/;
          }
          nmin[0] = condval_1;
          nmin[0] = vllm_topk_add(nmin[0], __shfl_xor_sync((uint)4294967295, nmin[0], 16, 32));
          nmin[0] = vllm_topk_add(nmin[0], __shfl_xor_sync((uint)4294967295, nmin[0], 8, 32));
          __syncthreads();
          if (((((int)threadIdx.x) & 31) < 8) & (bool)1) {
            ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + (((int)threadIdx.x) >> 5))] = nmin[0];
          }
          __syncthreads();
          nmin[0] = vllm_topk_add(vllm_topk_add(vllm_topk_add(((float*)red)[((((int)threadIdx.x) & 7) * 8)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 4)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 2)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 6)])), vllm_topk_add(vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 1)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 5)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 3)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 7)])));
          ladder[0] = vllm_topk_mul(lo[0], vllm_topk_exp(vllm_topk_div(vllm_topk_mul(vllm_control_log(vllm_topk_div(hi[0], lo[0])), ((float)((((int)threadIdx.x) & 7) + 1))), 0x1.2p+3f/*9.000000e+00*/)));
          bool ge = (vllm_topk_ge(mass[0], threshold) != 0);
          float condval_2;
          if ((ge & (vllm_topk_lt(vllm_topk_fma((gmin[0] * -0x1p+0f/*-1.000000e+00*/), nmin[0], mass[0]), threshold) != 0))) {
            condval_2 = ((float)(((int)threadIdx.x) & 7));
          } else {
            condval_2 = -0x1p+0f/*-1.000000e+00*/;
          }
          mark[0] = condval_2;
          float condval_3;
          if (ge) {
            condval_3 = ((float)(((int)threadIdx.x) & 7));
          } else {
            condval_3 = -0x1p+0f/*-1.000000e+00*/;
          }
          mark[1] = condval_3;
          float condval_4;
          if (ge) {
            condval_4 = ladder[0];
          } else {
            condval_4 = -CUDART_INF_F;
          }
          mark[2] = condval_4;
          float condval_5;
          if (ge) {
            condval_5 = CUDART_INF_F;
          } else {
            condval_5 = ladder[0];
          }
          mark[3] = condval_5;
          mark[0] = vllm_topk_max(mark[0], __shfl_xor_sync((uint)4294967295, mark[0], 4, 32));
          mark[0] = vllm_topk_max(mark[0], __shfl_xor_sync((uint)4294967295, mark[0], 2, 32));
          mark[0] = vllm_topk_max(mark[0], __shfl_xor_sync((uint)4294967295, mark[0], 1, 32));
          mark[1] = vllm_topk_max(mark[1], __shfl_xor_sync((uint)4294967295, mark[1], 4, 32));
          mark[1] = vllm_topk_max(mark[1], __shfl_xor_sync((uint)4294967295, mark[1], 2, 32));
          mark[1] = vllm_topk_max(mark[1], __shfl_xor_sync((uint)4294967295, mark[1], 1, 32));
          mark[2] = vllm_topk_max(mark[2], __shfl_xor_sync((uint)4294967295, mark[2], 4, 32));
          mark[2] = vllm_topk_max(mark[2], __shfl_xor_sync((uint)4294967295, mark[2], 2, 32));
          mark[2] = vllm_topk_max(mark[2], __shfl_xor_sync((uint)4294967295, mark[2], 1, 32));
          mark[3] = vllm_topk_min(mark[3], __shfl_xor_sync((uint)4294967295, mark[3], 4, 32));
          mark[3] = vllm_topk_min(mark[3], __shfl_xor_sync((uint)4294967295, mark[3], 2, 32));
          mark[3] = vllm_topk_min(mark[3], __shfl_xor_sync((uint)4294967295, mark[3], 1, 32));
          if (done[0] == 0) {
            if (vllm_topk_ge(mark[0], 0x0p+0f/*0.000000e+00*/) != 0) {
              done[0] = 1;
            } else {
              lo[0] = vllm_topk_max(lo[0], mark[2]);
              hi[0] = vllm_topk_min(hi[0], mark[3]);
              int condval_6;
              if ((vllm_topk_gt(hi[0], vllm_topk_mul(lo[0], 0x1.000001ad7f29bp+0f/*1.000000e+00*/)) != 0)) {
                condval_6 = 0;
              } else {
                condval_6 = 1;
              }
              done[0] = condval_6;
            }
          }
        }
      }
      bool if_condition_3 = (vllm_topk_any(((int)(done[0] == 0))) != 0);
      if (if_condition_3) {
        log_ratio = vllm_control_log(vllm_topk_div(hi[0], lo[0]));
        #pragma unroll
        for (int f = 0; f < 8; ++f) {
          ladder[f] = vllm_topk_mul(lo[0], vllm_topk_exp(vllm_topk_div(vllm_topk_mul(log_ratio, ((float)(f + 1))), 0x1.2p+3f/*9.000000e+00*/)));
          slot_mass[f] = 0x0p+0f/*0.000000e+00*/;
          slot_minl[f] = 0x1p+0f/*1.000000e+00*/;
          slot_nmin[f] = 0x0p+0f/*0.000000e+00*/;
        }
        #pragma unroll
        for (int r = 0; r < 2; ++r) {
          if ((((r * 1024) + (((int)threadIdx.x) * 4)) + ((((int)blockIdx.x) & 31) * 4)) == ((((int)blockIdx.x) & 31) * 4)) {
            *(float4*)(values + (r * 4)) = *(float4*)(logits + ((((((int64_t)r) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride)));
          } else {
            #pragma unroll
            for (int v = 0; v < 4; ++v) {
              values[((r * 4) + v)] = -CUDART_INF_F;
              if (((r * 256) + ((int)threadIdx.x)) < 1) {
                values[((r * 4) + v)] = logits[(((((((int64_t)r) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride)) + ((int64_t)v))];
              }
            }
          }
        }
        __syncthreads();
        #pragma unroll
        for (int e = 0; e < 8; ++e) {
          ((float*)wide)[((((e >> 2) * 1024) + (((int)threadIdx.x) * 4)) + (e & 3))] = vllm_topk_div(vllm_topk_exp(vllm_topk_sub(values[e], top[0])), norm_1[0]);
        }
        __syncthreads();
        #pragma unroll
        for (int i = 0; i < 8; ++i) {
          probs[i] = ((float*)wide)[((i * 256) + ((int)threadIdx.x))];
        }
        #pragma unroll
        for (int index = 0; index < 8; ++index) {
          #pragma unroll
          for (int i_1 = 0; i_1 < 8; ++i_1) {
            float condval_7;
            if ((vllm_topk_gt(probs[i_1], ladder[index]) != 0)) {
              condval_7 = probs[i_1];
            } else {
              condval_7 = 0x0p+0f/*0.000000e+00*/;
            }
            values[i_1] = condval_7;
          }
          sums[index] = vllm_topk_add(values[0], values[1]);
          #pragma unroll
          for (int i_2 = 2; i_2 < 8; ++i_2) {
            sums[index] = vllm_topk_add(sums[index], values[i_2]);
          }
          lows[index] = CUDART_INF_F;
          #pragma unroll
          for (int i_3 = 0; i_3 < 8; ++i_3) {
            float condval_8;
            if ((vllm_topk_gt(probs[i_3], ladder[index]) != 0)) {
              condval_8 = probs[i_3];
            } else {
              condval_8 = CUDART_INF_F;
            }
            lows[index] = vllm_topk_min(lows[index], condval_8);
          }
          sums[index] = vllm_topk_add(sums[index], __shfl_xor_sync((uint)4294967295, sums[index], 16, 32));
          sums[index] = vllm_topk_add(sums[index], __shfl_xor_sync((uint)4294967295, sums[index], 8, 32));
          sums[index] = vllm_topk_add(sums[index], __shfl_xor_sync((uint)4294967295, sums[index], 4, 32));
          sums[index] = vllm_topk_add(sums[index], __shfl_xor_sync((uint)4294967295, sums[index], 2, 32));
          sums[index] = vllm_topk_add(sums[index], __shfl_xor_sync((uint)4294967295, sums[index], 1, 32));
          lows[index] = vllm_topk_min(lows[index], __shfl_xor_sync((uint)4294967295, lows[index], 16, 32));
          lows[index] = vllm_topk_min(lows[index], __shfl_xor_sync((uint)4294967295, lows[index], 8, 32));
          lows[index] = vllm_topk_min(lows[index], __shfl_xor_sync((uint)4294967295, lows[index], 4, 32));
          lows[index] = vllm_topk_min(lows[index], __shfl_xor_sync((uint)4294967295, lows[index], 2, 32));
          lows[index] = vllm_topk_min(lows[index], __shfl_xor_sync((uint)4294967295, lows[index], 1, 32));
        }
        __syncthreads();
        if ((((int)threadIdx.x) % 32) == 0) {
          #pragma unroll
          for (int f_1 = 0; f_1 < 8; ++f_1) {
            ((float*)red)[((f_1 * 8) + (((int)threadIdx.x) >> 5))] = sums[f_1];
            ((float*)red)[(((f_1 * 8) + (((int)threadIdx.x) >> 5)) + 64)] = lows[f_1];
          }
        }
        __syncthreads();
        #pragma unroll
        for (int f_2 = 0; f_2 < 8; ++f_2) {
          sums[f_2] = vllm_topk_add(vllm_topk_add(vllm_topk_add(((float*)red)[(f_2 * 8)], ((float*)red)[((f_2 * 8) + 4)]), vllm_topk_add(((float*)red)[((f_2 * 8) + 2)], ((float*)red)[((f_2 * 8) + 6)])), vllm_topk_add(vllm_topk_add(((float*)red)[((f_2 * 8) + 1)], ((float*)red)[((f_2 * 8) + 5)]), vllm_topk_add(((float*)red)[((f_2 * 8) + 3)], ((float*)red)[((f_2 * 8) + 7)])));
          lows[f_2] = vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(((float*)red)[((f_2 * 8) + 64)], ((float*)red)[((f_2 * 8) + 65)]), ((float*)red)[((f_2 * 8) + 66)]), ((float*)red)[((f_2 * 8) + 67)]), ((float*)red)[((f_2 * 8) + 68)]), ((float*)red)[((f_2 * 8) + 69)]), ((float*)red)[((f_2 * 8) + 70)]), ((float*)red)[((f_2 * 8) + 71)]);
          counts[f_2] = 0;
          #pragma unroll
          for (int i_4 = 0; i_4 < 8; ++i_4) {
            counts[f_2] = (counts[f_2] + ((int)((vllm_topk_gt(probs[i_4], ladder[f_2]) != 0) & (vllm_topk_near(probs[i_4], lows[f_2]) != 0))));
          }
          counts[f_2] = vllm_topk_warp_count(counts[f_2]);
        }
        __syncthreads();
        if ((((int)threadIdx.x) % 32) == 0) {
          #pragma unroll
          for (int f_3 = 0; f_3 < 8; ++f_3) {
            ((int*)red_i)[((f_3 * 8) + (((int)threadIdx.x) >> 5))] = counts[f_3];
          }
        }
        __syncthreads();
        #pragma unroll
        for (int f_4 = 0; f_4 < 8; ++f_4) {
          tally = ((float)(((((((((int*)red_i)[(f_4 * 8)] + ((int*)red_i)[((f_4 * 8) + 1)]) + ((int*)red_i)[((f_4 * 8) + 2)]) + ((int*)red_i)[((f_4 * 8) + 3)]) + ((int*)red_i)[((f_4 * 8) + 4)]) + ((int*)red_i)[((f_4 * 8) + 5)]) + ((int*)red_i)[((f_4 * 8) + 6)]) + ((int*)red_i)[((f_4 * 8) + 7)]));
          float condval_9;
          if ((vllm_topk_lt(lows[f_4], slot_minl[f_4]) != 0)) {
            condval_9 = tally;
          } else {
            float condval_10;
            if ((vllm_topk_near(lows[f_4], slot_minl[f_4]) != 0)) {
              condval_10 = tally;
            } else {
              condval_10 = 0x0p+0f/*0.000000e+00*/;
            }
            condval_9 = vllm_topk_add(slot_nmin[f_4], condval_10);
          }
          slot_nmin[f_4] = condval_9;
          slot_minl[f_4] = vllm_topk_min(slot_minl[f_4], lows[f_4]);
          slot_mass[f_4] = vllm_topk_add(slot_mass[f_4], sums[f_4]);
        }
        if (done[0] == 0) {
          #pragma unroll
          for (int f_5 = 0; f_5 < 8; ++f_5) {
            if (((int)threadIdx.x) == f_5) {
              parts[(((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)round_) * (int64_t)768)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)24)) + (((int64_t)f_5) * (int64_t)3))] = slot_mass[f_5];
              parts[((((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)round_) * (int64_t)768)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)24)) + (((int64_t)f_5) * (int64_t)3)) + (int64_t)1)] = slot_minl[f_5];
              parts[((((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)round_) * (int64_t)768)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)24)) + (((int64_t)f_5) * (int64_t)3)) + (int64_t)2)] = slot_nmin[f_5];
            }
          }
        }
      }
    }
  }
}

