
#include <stdint.h>

template <int BASE_MINUS_ONE>
__device__ __forceinline__ void vllm_embed_decode_vec16(
    const void* __restrict__ low_a_ptr,
    const void* __restrict__ low_b_ptr,
    const void* __restrict__ codes_ptr,
    void* __restrict__ out_a_ptr,
    void* __restrict__ out_b_ptr) {
  const uint4 low_a4 = *reinterpret_cast<const uint4*>(low_a_ptr);
  const uint4 low_b4 = *reinterpret_cast<const uint4*>(low_b_ptr);
  const uint4 codes4 = *reinterpret_cast<const uint4*>(codes_ptr);
  const unsigned int* la = reinterpret_cast<const unsigned int*>(&low_a4);
  const unsigned int* lb = reinterpret_cast<const unsigned int*>(&low_b4);
  const unsigned int* cd = reinterpret_cast<const unsigned int*>(&codes4);
  unsigned int* oa = reinterpret_cast<unsigned int*>(out_a_ptr);
  unsigned int* ob = reinterpret_cast<unsigned int*>(out_b_ptr);
  constexpr unsigned int BASE_SCALAR = (unsigned int)(BASE_MINUS_ONE & 0xFFFF);

  #pragma unroll
  for (int w = 0; w < 4; ++w) {
    const unsigned int c_word = cd[w];
    const unsigned int la_word = la[w];
    const unsigned int lb_word = lb[w];

    const unsigned int c01 = __byte_perm(c_word, 0u, 0x4140u);
    const unsigned int c23 = __byte_perm(c_word, 0u, 0x4342u);

    const unsigned int ca01 = c01 & 0x000F000Fu;
    const unsigned int cb01 = (c01 >> 4) & 0x000F000Fu;
    const unsigned int ca23 = c23 & 0x000F000Fu;
    const unsigned int cb23 = (c23 >> 4) & 0x000F000Fu;

    const unsigned int nza01 = ((ca01 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nzb01 = ((cb01 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nza23 = ((ca23 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nzb23 = ((cb23 + 0x000F000Fu) >> 4) & 0x00010001u;

    const unsigned int expa01 = (ca01 + nza01 * BASE_SCALAR) << 7;
    const unsigned int expb01 = (cb01 + nzb01 * BASE_SCALAR) << 7;
    const unsigned int expa23 = (ca23 + nza23 * BASE_SCALAR) << 7;
    const unsigned int expb23 = (cb23 + nzb23 * BASE_SCALAR) << 7;

    const unsigned int la01 = __byte_perm(la_word, 0u, 0x1100u);
    const unsigned int la23 = __byte_perm(la_word, 0u, 0x3322u);
    const unsigned int lb01 = __byte_perm(lb_word, 0u, 0x1100u);
    const unsigned int lb23 = __byte_perm(lb_word, 0u, 0x3322u);

    oa[2 * w + 0] = (la01 & 0x807F807Fu) | expa01;
    oa[2 * w + 1] = (la23 & 0x807F807Fu) | expa23;
    ob[2 * w + 0] = (lb01 & 0x807F807Fu) | expb01;
    ob[2 * w + 1] = (lb23 & 0x807F807Fu) | expb23;
  }
}

template <int K, int BASE_MINUS_ONE, int THREADS>
__device__ __forceinline__ void vllm_packed_vocab_embedding_row(
    const uint8_t* values,
    const int* exception_entries,
    const int* row_offsets,
    void* __restrict__ out_ptr,
    int64_t row,
    int t,
    int tx) {
  constexpr int GROUP = 128;
  constexpr int HALF = 64;
  constexpr int TOTAL_SLICES = K / 32;
  constexpr int64_t ROW_BYTES = K + K / 2;
  constexpr int ITERS = (TOTAL_SLICES + THREADS - 1) / THREADS;
  uint16_t* __restrict__ out_row = reinterpret_cast<uint16_t*>(out_ptr) + (int64_t)t * K;
  if (row >= 0) {
    const int exc_start = row_offsets[row];
    const int exc_end = row_offsets[row + 1];
    const uint8_t* w_row = values + row * ROW_BYTES;
    uint4 out_a[ITERS][2];
    uint4 out_b[ITERS][2];
    #pragma unroll
    for (int it = 0; it < ITERS; ++it) {
      const int s = it * THREADS + tx;
      if (s < TOTAL_SLICES) {
        const int g = s >> 2;
        const int c = (s & 3) << 4;
        vllm_embed_decode_vec16<BASE_MINUS_ONE>(
            w_row + g * GROUP + c,
            w_row + g * GROUP + HALF + c,
            w_row + K + g * HALF + c,
            out_a[it],
            out_b[it]);
      }
    }
    #pragma unroll
    for (int it = 0; it < ITERS; ++it) {
      const int s = it * THREADS + tx;
      if (s < TOTAL_SLICES) {
        const int g = s >> 2;
        const int c = (s & 3) << 4;
        uint4* dst_a = reinterpret_cast<uint4*>(out_row + g * GROUP + c);
        uint4* dst_b = reinterpret_cast<uint4*>(out_row + g * GROUP + HALF + c);
        dst_a[0] = out_a[it][0];
        dst_a[1] = out_a[it][1];
        dst_b[0] = out_b[it][0];
        dst_b[1] = out_b[it][1];
      }
    }
    if (exc_start < exc_end) {
      __syncthreads();
      for (int idx = exc_start + tx; idx < exc_end; idx += THREADS) {
        const unsigned int entry = (unsigned int)exception_entries[idx];
        out_row[entry >> 16] = (uint16_t)(entry & 0xFFFFu);
      }
    }
  } else {
    const uint4 zero4 = make_uint4(0u, 0u, 0u, 0u);
    #pragma unroll
    for (int it = 0; it < ITERS; ++it) {
      const int s = it * THREADS + tx;
      if (s < TOTAL_SLICES) {
        const int g = s >> 2;
        const int c = (s & 3) << 4;
        uint4* dst_a = reinterpret_cast<uint4*>(out_row + g * GROUP + c);
        uint4* dst_b = reinterpret_cast<uint4*>(out_row + g * GROUP + HALF + c);
        dst_a[0] = zero4;
        dst_a[1] = zero4;
        dst_b[0] = zero4;
        dst_b[1] = zero4;
      }
    }
  }
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vocab_packed_embedding_kernel(int* exception_entries, const int64_t* ids, bfloat16_t* __restrict__ out, int* row_offsets, uchar* values, int64_t added_end, int64_t added_offset, int64_t added_start, int64_t org_end, int64_t org_start, int tokens);
extern "C" __global__ void __launch_bounds__(128, 1) vocab_packed_embedding_kernel(int* exception_entries, const int64_t* ids, bfloat16_t* __restrict__ out, int* row_offsets, uchar* values, int64_t added_end, int64_t added_offset, int64_t added_start, int64_t org_end, int64_t org_start, int tokens) {
  int64_t token = (int64_t)0;
  int64_t row = (int64_t)0;
  token = ids[((int64_t)((int)blockIdx.x))];
  int64_t condval;
  if (((org_start <= token) & (token < org_end))) {
    condval = (token - org_start);
  } else {
    int64_t condval_1;
    if (((added_start <= token) & (token < added_end))) {
      condval_1 = (token + added_offset);
    } else {
      condval_1 = (int64_t)-1;
    }
    condval = condval_1;
  }
  row = condval;
  vllm_packed_vocab_embedding_row<5120, 109, 128>((&(values[0])), (&(exception_entries[0])), (&(row_offsets[0])), (&(out[0])), row, ((int)blockIdx.x), ((int)threadIdx.x));
}

