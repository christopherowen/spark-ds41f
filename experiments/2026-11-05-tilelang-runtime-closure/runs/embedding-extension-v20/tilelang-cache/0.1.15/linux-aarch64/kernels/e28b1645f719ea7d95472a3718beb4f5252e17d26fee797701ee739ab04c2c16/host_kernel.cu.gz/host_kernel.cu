// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vocab_packed_histogram_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_histogram(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_histogram(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[9];
  void* stack_ffi_any = stack;
  if (!((num_args == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vocab_packed_histogram: num_args should be 2", (long long)(num_args), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_histogram: args pointer is NULL");
    return -1;
  }
  int32_t weight_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((weight_handle_type_index == 0) || (weight_handle_type_index == 4)) || (weight_handle_type_index == 7)) || (64 <= weight_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_histogram input weight expected pointer or tensor handle");
    return -1;
  }
  int32_t histogram_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((histogram_handle_type_index == 0) || (histogram_handle_type_index == 4)) || (histogram_handle_type_index == 7)) || (64 <= histogram_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_histogram input histogram expected pointer or tensor handle");
    return -1;
  }
  void* weight_handle = ((weight_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* histogram_handle = ((histogram_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  bool vocab_packed_histogram_weight_is_null = (weight_handle == NULL);
  if (!(!vocab_packed_histogram_weight_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_histogram.weight is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_histogram_histogram_is_null = (histogram_handle == NULL);
  if (!(!vocab_packed_histogram_histogram_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_histogram.histogram is expected to have non-NULL pointer");
    return -1;
  }
  void* vocab_packed_histogram_weight_shape = (((DLTensor*)weight_handle)[0].shape);
  void* vocab_packed_histogram_histogram_shape = (((DLTensor*)histogram_handle)[0].shape);
  if (!(((((DLTensor*)weight_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input weight ndim mismatch, expected 2", (long long)((((DLTensor*)weight_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vocab_packed_histogram_weight_shape)[0]);
  void* vocab_packed_histogram_weight_strides = (((DLTensor*)weight_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)weight_handle)[0].device.device_id);
  void* weight = (((DLTensor*)weight_handle)[0].data);
  if (!(((((DLTensor*)histogram_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input histogram ndim mismatch, expected 1", (long long)((((DLTensor*)histogram_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_histogram_histogram_strides = (((DLTensor*)histogram_handle)[0].strides);
  void* histogram = (((DLTensor*)histogram_handle)[0].data);
  if (!(((((((DLTensor*)weight_handle)[0].dtype.code) == (uint8_t)1) && ((((DLTensor*)weight_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)weight_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_histogram input weight dtype mismatch, expected uint16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_histogram_weight_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input weight shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_histogram_weight_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vocab_packed_histogram_weight_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vocab_packed_histogram_weight_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vocab_packed_histogram_weight_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vocab_packed_histogram_weight_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input weight strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vocab_packed_histogram_weight_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vocab_packed_histogram_weight_strides)[0]);
  }
  if (!(((condval_2 == 5120) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_histogram input weight strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)weight_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input weight byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)weight_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)weight_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input weight device_type mismatch, expected cuda", (long long)((((DLTensor*)weight_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(weight == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_histogram input weight data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)histogram_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)histogram_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)histogram_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_histogram input histogram dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_histogram_histogram_shape)[0]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input histogram shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_histogram_histogram_shape)[0])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vocab_packed_histogram_histogram_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vocab_packed_histogram_histogram_strides)[0]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vocab_packed_histogram_histogram_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vocab_packed_histogram_histogram_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input histogram strides[0] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)histogram_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input histogram byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)histogram_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)histogram_handle)[0].device.device_id) == (((DLTensor*)weight_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input histogram device_id violates packed ABI constraint", (long long)((((DLTensor*)histogram_handle)[0].device.device_id)), (long long)((((DLTensor*)weight_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)histogram_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_histogram input histogram device_type mismatch, expected cuda", (long long)((((DLTensor*)histogram_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(histogram == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_histogram input histogram data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (histogram == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = histogram;
  if (weight == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = weight;
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1024);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = (int64_t)0;
  if (vocab_packed_histogram_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vocab_packed_histogram_kernel", &vocab_packed_histogram_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vocab_packed_histogram_kernel_packed, (TVMFFIAny*) stack_ffi_any, 8, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vocab_packed_histogram(self, args, num_args, result);
}
