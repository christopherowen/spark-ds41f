// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vocab_packed_pack_rows_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_pack_rows(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_pack_rows(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[15];
  void* stack_ffi_any = stack;
  if (!((num_args == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vocab_packed_pack_rows: num_args should be 8", (long long)(num_args), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_pack_rows: args pointer is NULL");
    return -1;
  }
  int32_t weight_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((weight_handle_type_index == 0) || (weight_handle_type_index == 4)) || (weight_handle_type_index == 7)) || (64 <= weight_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input weight expected pointer or tensor handle");
    return -1;
  }
  int32_t values_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((values_handle_type_index == 0) || (values_handle_type_index == 4)) || (values_handle_type_index == 7)) || (64 <= values_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input values expected pointer or tensor handle");
    return -1;
  }
  int32_t offsets_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((offsets_handle_type_index == 0) || (offsets_handle_type_index == 4)) || (offsets_handle_type_index == 7)) || (64 <= offsets_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input offsets expected pointer or tensor handle");
    return -1;
  }
  int32_t rows_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((rows_handle_type_index == 0) || (rows_handle_type_index == 4)) || (rows_handle_type_index == 7)) || (64 <= rows_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input rows expected pointer or tensor handle");
    return -1;
  }
  int32_t entries_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((entries_handle_type_index == 0) || (entries_handle_type_index == 4)) || (entries_handle_type_index == 7)) || (64 <= entries_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input entries expected pointer or tensor handle");
    return -1;
  }
  int32_t mismatches_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((mismatches_handle_type_index == 0) || (mismatches_handle_type_index == 4)) || (mismatches_handle_type_index == 7)) || (64 <= mismatches_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input mismatches expected pointer or tensor handle");
    return -1;
  }
  int32_t base_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((base_type_index == 1) || (base_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows scalar base expected integer");
    return -1;
  }
  int32_t row_start_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((row_start_type_index == 1) || (row_start_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows scalar row_start expected integer");
    return -1;
  }
  void* weight_handle = ((weight_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* values_handle = ((values_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* offsets_handle = ((offsets_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* rows_handle = ((rows_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* entries_handle = ((entries_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* mismatches_handle = ((mismatches_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  int32_t base = ((int32_t)(((TVMFFIAny*)args)[6].v_int64));
  int32_t row_start = ((int32_t)(((TVMFFIAny*)args)[7].v_int64));
  bool vocab_packed_pack_rows_weight_is_null = (weight_handle == NULL);
  if (!(!vocab_packed_pack_rows_weight_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_pack_rows.weight is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_pack_rows_values_is_null = (values_handle == NULL);
  if (!(!vocab_packed_pack_rows_values_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_pack_rows.values is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_pack_rows_offsets_is_null = (offsets_handle == NULL);
  if (!(!vocab_packed_pack_rows_offsets_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_pack_rows.offsets is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_pack_rows_rows_is_null = (rows_handle == NULL);
  if (!(!vocab_packed_pack_rows_rows_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_pack_rows.rows is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_pack_rows_entries_is_null = (entries_handle == NULL);
  if (!(!vocab_packed_pack_rows_entries_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_pack_rows.entries is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_pack_rows_mismatches_is_null = (mismatches_handle == NULL);
  if (!(!vocab_packed_pack_rows_mismatches_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_pack_rows.mismatches is expected to have non-NULL pointer");
    return -1;
  }
  void* vocab_packed_pack_rows_weight_shape = (((DLTensor*)weight_handle)[0].shape);
  void* vocab_packed_pack_rows_values_shape = (((DLTensor*)values_handle)[0].shape);
  void* vocab_packed_pack_rows_offsets_shape = (((DLTensor*)offsets_handle)[0].shape);
  void* vocab_packed_pack_rows_rows_shape = (((DLTensor*)rows_handle)[0].shape);
  void* vocab_packed_pack_rows_entries_shape = (((DLTensor*)entries_handle)[0].shape);
  void* vocab_packed_pack_rows_mismatches_shape = (((DLTensor*)mismatches_handle)[0].shape);
  if (!(((((DLTensor*)weight_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input weight ndim mismatch, expected 2", (long long)((((DLTensor*)weight_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t N = ((int32_t)((int64_t*)vocab_packed_pack_rows_weight_shape)[0]);
  void* vocab_packed_pack_rows_weight_strides = (((DLTensor*)weight_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)weight_handle)[0].device.device_id);
  void* weight = (((DLTensor*)weight_handle)[0].data);
  if (!(((((DLTensor*)values_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input values ndim mismatch, expected 2", (long long)((((DLTensor*)values_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vocab_packed_pack_rows_values_shape)[0]);
  void* vocab_packed_pack_rows_values_strides = (((DLTensor*)values_handle)[0].strides);
  void* values = (((DLTensor*)values_handle)[0].data);
  if (!(((((DLTensor*)offsets_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input offsets ndim mismatch, expected 1", (long long)((((DLTensor*)offsets_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t O = ((int32_t)((int64_t*)vocab_packed_pack_rows_offsets_shape)[0]);
  void* vocab_packed_pack_rows_offsets_strides = (((DLTensor*)offsets_handle)[0].strides);
  void* offsets = (((DLTensor*)offsets_handle)[0].data);
  if (!(((((DLTensor*)rows_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input rows ndim mismatch, expected 1", (long long)((((DLTensor*)rows_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t E = ((int32_t)((int64_t*)vocab_packed_pack_rows_rows_shape)[0]);
  void* vocab_packed_pack_rows_rows_strides = (((DLTensor*)rows_handle)[0].strides);
  void* rows = (((DLTensor*)rows_handle)[0].data);
  if (!(((((DLTensor*)entries_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input entries ndim mismatch, expected 1", (long long)((((DLTensor*)entries_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_pack_rows_entries_strides = (((DLTensor*)entries_handle)[0].strides);
  void* entries = (((DLTensor*)entries_handle)[0].data);
  if (!(((((DLTensor*)mismatches_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input mismatches ndim mismatch, expected 1", (long long)((((DLTensor*)mismatches_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_pack_rows_mismatches_strides = (((DLTensor*)mismatches_handle)[0].strides);
  void* mismatches = (((DLTensor*)mismatches_handle)[0].data);
  if (!(((((((DLTensor*)weight_handle)[0].dtype.code) == (uint8_t)1) && ((((DLTensor*)weight_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)weight_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input weight dtype mismatch, expected uint16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_pack_rows_weight_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input weight shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_pack_rows_weight_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vocab_packed_pack_rows_weight_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vocab_packed_pack_rows_weight_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vocab_packed_pack_rows_weight_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vocab_packed_pack_rows_weight_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input weight strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vocab_packed_pack_rows_weight_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vocab_packed_pack_rows_weight_strides)[0]);
  }
  if (!(((condval_2 == 5120) || (N == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input weight strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)weight_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input weight byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)weight_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)weight_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input weight device_type mismatch, expected cuda", (long long)((((DLTensor*)weight_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((N == 0) || !(weight == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input weight data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)values_handle)[0].dtype.code) == (uint8_t)1) && ((((DLTensor*)values_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)values_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input values dtype mismatch, expected uint8");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_pack_rows_values_shape)[1]) == 7680))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input values shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_pack_rows_values_shape)[1])), (long long)(7680));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vocab_packed_pack_rows_values_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vocab_packed_pack_rows_values_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vocab_packed_pack_rows_values_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vocab_packed_pack_rows_values_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input values strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((vocab_packed_pack_rows_values_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)vocab_packed_pack_rows_values_strides)[0]);
  }
  if (!(((condval_5 == 7680) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input values strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)values_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input values byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)values_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)values_handle)[0].device.device_id) == (((DLTensor*)weight_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input values device_id violates packed ABI constraint", (long long)((((DLTensor*)values_handle)[0].device.device_id)), (long long)((((DLTensor*)weight_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)values_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input values device_type mismatch, expected cuda", (long long)((((DLTensor*)values_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(values == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input values data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)offsets_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)offsets_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)offsets_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input offsets dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_6;
  if ((vocab_packed_pack_rows_offsets_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)vocab_packed_pack_rows_offsets_strides)[0]);
  }
  if (!(((condval_6 == 1) || (O == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input offsets strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)offsets_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input offsets byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)offsets_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)offsets_handle)[0].device.device_id) == (((DLTensor*)weight_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input offsets device_id violates packed ABI constraint", (long long)((((DLTensor*)offsets_handle)[0].device.device_id)), (long long)((((DLTensor*)weight_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)offsets_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input offsets device_type mismatch, expected cuda", (long long)((((DLTensor*)offsets_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((O == 0) || !(offsets == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input offsets data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)rows_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)rows_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)rows_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input rows dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_7;
  if ((vocab_packed_pack_rows_rows_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)vocab_packed_pack_rows_rows_strides)[0]);
  }
  if (!(((condval_7 == 1) || (E == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input rows strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)rows_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input rows byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)rows_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)rows_handle)[0].device.device_id) == (((DLTensor*)weight_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input rows device_id violates packed ABI constraint", (long long)((((DLTensor*)rows_handle)[0].device.device_id)), (long long)((((DLTensor*)weight_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)rows_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input rows device_type mismatch, expected cuda", (long long)((((DLTensor*)rows_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((E == 0) || !(rows == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input rows data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)entries_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)entries_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)entries_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input entries dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_pack_rows_rows_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_pack_rows_entries_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input entries shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_pack_rows_rows_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_pack_rows_entries_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((vocab_packed_pack_rows_entries_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)vocab_packed_pack_rows_entries_strides)[0]);
  }
  if (!(((condval_8 == 1) || (E == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input entries strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)entries_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input entries byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)entries_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)entries_handle)[0].device.device_id) == (((DLTensor*)weight_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input entries device_id violates packed ABI constraint", (long long)((((DLTensor*)entries_handle)[0].device.device_id)), (long long)((((DLTensor*)weight_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)entries_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input entries device_type mismatch, expected cuda", (long long)((((DLTensor*)entries_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((E == 0) || !(entries == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input entries data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)mismatches_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)mismatches_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)mismatches_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input mismatches dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_pack_rows_mismatches_shape)[0]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input mismatches shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_pack_rows_mismatches_shape)[0])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)mismatches_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input mismatches byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)mismatches_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)mismatches_handle)[0].device.device_id) == (((DLTensor*)weight_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input mismatches device_id violates packed ABI constraint", (long long)((((DLTensor*)mismatches_handle)[0].device.device_id)), (long long)((((DLTensor*)weight_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)mismatches_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_pack_rows input mismatches device_type mismatch, expected cuda", (long long)((((DLTensor*)mismatches_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(mismatches == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_pack_rows input mismatches data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (entries == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = entries;
  if (mismatches == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = mismatches;
  if (offsets == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = offsets;
  if (rows == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = rows;
  if (values == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = values;
  if (weight == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = weight;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)base);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)row_start);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)64);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)8);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = (int64_t)0;
  if (vocab_packed_pack_rows_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vocab_packed_pack_rows_kernel", &vocab_packed_pack_rows_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vocab_packed_pack_rows_kernel_packed, (TVMFFIAny*) stack_ffi_any, 14, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vocab_packed_pack_rows(self, args, num_args, result);
}
