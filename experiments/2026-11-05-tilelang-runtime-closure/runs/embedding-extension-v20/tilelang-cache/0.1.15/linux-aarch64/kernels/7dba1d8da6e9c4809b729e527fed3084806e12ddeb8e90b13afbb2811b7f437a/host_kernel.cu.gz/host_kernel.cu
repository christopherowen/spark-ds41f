// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vocab_packed_embedding_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_embedding(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_packed_embedding(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[17];
  void* stack_ffi_any = stack;
  if (!((num_args == 10))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vocab_packed_embedding: num_args should be 10", (long long)(num_args), (long long)(10));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_embedding: args pointer is NULL");
    return -1;
  }
  int32_t ids_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((ids_handle_type_index == 0) || (ids_handle_type_index == 4)) || (ids_handle_type_index == 7)) || (64 <= ids_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input ids expected pointer or tensor handle");
    return -1;
  }
  int32_t values_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((values_handle_type_index == 0) || (values_handle_type_index == 4)) || (values_handle_type_index == 7)) || (64 <= values_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input values expected pointer or tensor handle");
    return -1;
  }
  int32_t exception_entries_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((exception_entries_handle_type_index == 0) || (exception_entries_handle_type_index == 4)) || (exception_entries_handle_type_index == 7)) || (64 <= exception_entries_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input exception_entries expected pointer or tensor handle");
    return -1;
  }
  int32_t row_offsets_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((row_offsets_handle_type_index == 0) || (row_offsets_handle_type_index == 4)) || (row_offsets_handle_type_index == 7)) || (64 <= row_offsets_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input row_offsets expected pointer or tensor handle");
    return -1;
  }
  int32_t out_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((out_handle_type_index == 0) || (out_handle_type_index == 4)) || (out_handle_type_index == 7)) || (64 <= out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input out expected pointer or tensor handle");
    return -1;
  }
  int32_t org_start_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((org_start_type_index == 1) || (org_start_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding scalar org_start expected integer");
    return -1;
  }
  int32_t org_end_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((org_end_type_index == 1) || (org_end_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding scalar org_end expected integer");
    return -1;
  }
  int32_t added_start_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((added_start_type_index == 1) || (added_start_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding scalar added_start expected integer");
    return -1;
  }
  int32_t added_end_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((added_end_type_index == 1) || (added_end_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding scalar added_end expected integer");
    return -1;
  }
  int32_t added_offset_type_index = (((TVMFFIAny*)args)[9].type_index);
  if (!(((added_offset_type_index == 1) || (added_offset_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding scalar added_offset expected integer");
    return -1;
  }
  void* ids_handle = ((ids_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* values_handle = ((values_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* exception_entries_handle = ((exception_entries_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* row_offsets_handle = ((row_offsets_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* out_handle = ((out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  int64_t org_start = (((TVMFFIAny*)args)[5].v_int64);
  int64_t org_end = (((TVMFFIAny*)args)[6].v_int64);
  int64_t added_start = (((TVMFFIAny*)args)[7].v_int64);
  int64_t added_end = (((TVMFFIAny*)args)[8].v_int64);
  int64_t added_offset = (((TVMFFIAny*)args)[9].v_int64);
  bool vocab_packed_embedding_ids_is_null = (ids_handle == NULL);
  if (!(!vocab_packed_embedding_ids_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_embedding.ids is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_embedding_values_is_null = (values_handle == NULL);
  if (!(!vocab_packed_embedding_values_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_embedding.values is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_embedding_exception_entries_is_null = (exception_entries_handle == NULL);
  if (!(!vocab_packed_embedding_exception_entries_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_embedding.exception_entries is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_embedding_row_offsets_is_null = (row_offsets_handle == NULL);
  if (!(!vocab_packed_embedding_row_offsets_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_embedding.row_offsets is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_packed_embedding_out_is_null = (out_handle == NULL);
  if (!(!vocab_packed_embedding_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_packed_embedding.out is expected to have non-NULL pointer");
    return -1;
  }
  void* vocab_packed_embedding_ids_shape = (((DLTensor*)ids_handle)[0].shape);
  void* vocab_packed_embedding_values_shape = (((DLTensor*)values_handle)[0].shape);
  void* vocab_packed_embedding_exception_entries_shape = (((DLTensor*)exception_entries_handle)[0].shape);
  void* vocab_packed_embedding_row_offsets_shape = (((DLTensor*)row_offsets_handle)[0].shape);
  void* vocab_packed_embedding_out_shape = (((DLTensor*)out_handle)[0].shape);
  if (!(((((DLTensor*)ids_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input ids ndim mismatch, expected 1", (long long)((((DLTensor*)ids_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable tokens requires at least one non-null buffer among: vocab_packed_embedding.ids, vocab_packed_embedding.out");
    return -1;
  }
  int32_t tokens = ((int32_t)((int64_t*)vocab_packed_embedding_ids_shape)[0]);
  void* vocab_packed_embedding_ids_strides = (((DLTensor*)ids_handle)[0].strides);
  int64_t condval;
  if ((vocab_packed_embedding_ids_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)vocab_packed_embedding_ids_strides)[0];
  }
  int64_t id_stride = condval;
  int32_t dev_id = (((DLTensor*)ids_handle)[0].device.device_id);
  void* ids = (((DLTensor*)ids_handle)[0].data);
  if (!(((((DLTensor*)values_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input values ndim mismatch, expected 2", (long long)((((DLTensor*)values_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)vocab_packed_embedding_values_shape)[0]);
  void* vocab_packed_embedding_values_strides = (((DLTensor*)values_handle)[0].strides);
  void* values = (((DLTensor*)values_handle)[0].data);
  if (!(((((DLTensor*)exception_entries_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input exception_entries ndim mismatch, expected 1", (long long)((((DLTensor*)exception_entries_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t exceptions = ((int32_t)((int64_t*)vocab_packed_embedding_exception_entries_shape)[0]);
  void* vocab_packed_embedding_exception_entries_strides = (((DLTensor*)exception_entries_handle)[0].strides);
  void* exception_entries = (((DLTensor*)exception_entries_handle)[0].data);
  if (!(((((DLTensor*)row_offsets_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input row_offsets ndim mismatch, expected 1", (long long)((((DLTensor*)row_offsets_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t offsets = ((int32_t)((int64_t*)vocab_packed_embedding_row_offsets_shape)[0]);
  void* vocab_packed_embedding_row_offsets_strides = (((DLTensor*)row_offsets_handle)[0].strides);
  void* row_offsets = (((DLTensor*)row_offsets_handle)[0].data);
  if (!(((((DLTensor*)out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input out ndim mismatch, expected 2", (long long)((((DLTensor*)out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_packed_embedding_out_strides = (((DLTensor*)out_handle)[0].strides);
  void* out = (((DLTensor*)out_handle)[0].data);
  if (!(((((((DLTensor*)ids_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)ids_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)ids_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input ids dtype mismatch, expected int64");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)ids_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input ids byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)ids_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)ids_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input ids device_type mismatch, expected cuda", (long long)((((DLTensor*)ids_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((tokens == 0) || !(ids == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input ids data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)values_handle)[0].dtype.code) == (uint8_t)1) && ((((DLTensor*)values_handle)[0].dtype.bits) == (uint8_t)8)) && ((((DLTensor*)values_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input values dtype mismatch, expected uint8");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_embedding_values_shape)[1]) == 7680))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input values shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_embedding_values_shape)[1])), (long long)(7680));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_1;
  if ((vocab_packed_embedding_values_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)vocab_packed_embedding_values_strides)[1]);
  }
  if (!((condval_1 == 1))) {
    int32_t condval_2;
    if ((vocab_packed_embedding_values_strides == NULL)) {
      condval_2 = 1;
    } else {
      condval_2 = ((int32_t)((int64_t*)vocab_packed_embedding_values_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input values strides[1] violates packed ABI constraint", (long long)(condval_2), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vocab_packed_embedding_values_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vocab_packed_embedding_values_strides)[0]);
  }
  if (!(((condval_3 == 7680) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input values strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)values_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input values byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)values_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)values_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input values device_id violates packed ABI constraint", (long long)((((DLTensor*)values_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)values_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input values device_type mismatch, expected cuda", (long long)((((DLTensor*)values_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(values == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input values data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)exception_entries_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)exception_entries_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)exception_entries_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input exception_entries dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_4;
  if ((vocab_packed_embedding_exception_entries_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)vocab_packed_embedding_exception_entries_strides)[0]);
  }
  if (!(((condval_4 == 1) || (exceptions == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input exception_entries strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)exception_entries_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input exception_entries byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)exception_entries_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_entries_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input exception_entries device_id violates packed ABI constraint", (long long)((((DLTensor*)exception_entries_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)exception_entries_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input exception_entries device_type mismatch, expected cuda", (long long)((((DLTensor*)exception_entries_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((exceptions == 0) || !(exception_entries == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input exception_entries data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)row_offsets_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)row_offsets_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)row_offsets_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input row_offsets dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_5;
  if ((vocab_packed_embedding_row_offsets_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)vocab_packed_embedding_row_offsets_strides)[0]);
  }
  if (!(((condval_5 == 1) || (offsets == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input row_offsets strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)row_offsets_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input row_offsets byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)row_offsets_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)row_offsets_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input row_offsets device_id violates packed ABI constraint", (long long)((((DLTensor*)row_offsets_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)row_offsets_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input row_offsets device_type mismatch, expected cuda", (long long)((((DLTensor*)row_offsets_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((offsets == 0) || !(row_offsets == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input row_offsets data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)out_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input out dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_embedding_ids_shape)[0]) == ((int32_t)((int64_t*)vocab_packed_embedding_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_embedding_ids_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_packed_embedding_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_packed_embedding_out_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_packed_embedding_out_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((vocab_packed_embedding_out_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)vocab_packed_embedding_out_strides)[1]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((vocab_packed_embedding_out_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)vocab_packed_embedding_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input out strides[1] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((vocab_packed_embedding_out_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)vocab_packed_embedding_out_strides)[0]);
  }
  if (!(((condval_8 == 5120) || (tokens == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input out device_id violates packed ABI constraint", (long long)((((DLTensor*)out_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_packed_embedding input out device_type mismatch, expected cuda", (long long)((((DLTensor*)out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((tokens == 0) || !(out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_packed_embedding input out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (exception_entries == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = exception_entries;
  if (ids == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = ids;
  if (out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = out;
  if (row_offsets == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = row_offsets;
  if (values == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = values;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = added_end;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = added_offset;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = added_start;
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = id_stride;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = org_end;
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = org_start;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)tokens);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)tokens);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = (int64_t)0;
  if (vocab_packed_embedding_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vocab_packed_embedding_kernel", &vocab_packed_embedding_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vocab_packed_embedding_kernel_packed, (TVMFFIAny*) stack_ffi_any, 16, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vocab_packed_embedding(self, args, num_args, result);
}
