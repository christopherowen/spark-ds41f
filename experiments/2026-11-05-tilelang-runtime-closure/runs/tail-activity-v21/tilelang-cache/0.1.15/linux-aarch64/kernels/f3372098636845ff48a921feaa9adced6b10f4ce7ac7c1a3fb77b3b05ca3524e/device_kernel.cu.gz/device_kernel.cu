#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void copy_logits_kernel(float* __restrict__ dst, const half_t* __restrict__ src, int col_stride, int cols, int row_stride, int rows);
extern "C" __global__ void __launch_bounds__(256, 1) copy_logits_kernel(float* __restrict__ dst, const half_t* __restrict__ src, int col_stride, int cols, int row_stride, int rows) {
  #pragma unroll
  for (int j = 0; j < 4; ++j) {
    if ((((((int)blockIdx.y) * 1024) + (j * 256)) + ((int)threadIdx.x)) < cols) {
      dst[((((((int64_t)((int)blockIdx.y)) * (int64_t)1024) + (((int64_t)j) * (int64_t)256)) + (((int64_t)((int)blockIdx.x)) * ((int64_t)cols))) + ((int64_t)((int)threadIdx.x)))] = ((float)src[((((int64_t)((int)blockIdx.x)) * ((int64_t)row_stride)) + ((((((int64_t)((int)blockIdx.y)) * (int64_t)1024) + (((int64_t)j) * (int64_t)256)) + ((int64_t)((int)threadIdx.x))) * ((int64_t)col_stride)))]);
    }
  }
}

