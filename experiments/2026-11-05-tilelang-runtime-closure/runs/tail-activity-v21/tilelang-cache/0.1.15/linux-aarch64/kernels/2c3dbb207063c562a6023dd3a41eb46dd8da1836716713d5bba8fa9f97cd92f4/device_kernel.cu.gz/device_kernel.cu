#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_rows_small_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int row_units, int rows, int world);
extern "C" __global__ void __launch_bounds__(32, 1) collectives_rank_rows_small_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int row_units, int rows, int world) {
  for (int step = 0; step < ((row_units + 31) >> 5); ++step) {
    if (((step * 32) + ((int)threadIdx.x)) < row_units) {
      dst[(((((int64_t)step) * (int64_t)32) + (((((int64_t)((int)blockIdx.y)) * ((int64_t)world)) + ((int64_t)((int)blockIdx.x))) * ((int64_t)row_units))) + ((int64_t)((int)threadIdx.x)))] = src[(((((int64_t)step) * (int64_t)32) + (((((int64_t)((int)blockIdx.x)) * ((int64_t)rows)) + ((int64_t)((int)blockIdx.y))) * ((int64_t)row_units))) + ((int64_t)((int)threadIdx.x)))];
    }
  }
}

