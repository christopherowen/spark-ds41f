// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* flatten_sampled_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_flatten_sampled(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_flatten_sampled(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[13];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "flatten_sampled: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "flatten_sampled: args pointer is NULL");
    return -1;
  }
  int32_t flat_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((flat_handle_type_index == 0) || (flat_handle_type_index == 4)) || (flat_handle_type_index == 7)) || (64 <= flat_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input flat expected pointer or tensor handle");
    return -1;
  }
  int32_t sampled_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((sampled_handle_type_index == 0) || (sampled_handle_type_index == 4)) || (sampled_handle_type_index == 7)) || (64 <= sampled_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input sampled expected pointer or tensor handle");
    return -1;
  }
  int32_t num_sampled_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((num_sampled_handle_type_index == 0) || (num_sampled_handle_type_index == 4)) || (num_sampled_handle_type_index == 7)) || (64 <= num_sampled_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input num_sampled expected pointer or tensor handle");
    return -1;
  }
  int32_t cu_num_logits_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((cu_num_logits_handle_type_index == 0) || (cu_num_logits_handle_type_index == 4)) || (cu_num_logits_handle_type_index == 7)) || (64 <= cu_num_logits_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input cu_num_logits expected pointer or tensor handle");
    return -1;
  }
  void* flat_handle = ((flat_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* sampled_handle = ((sampled_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* num_sampled_handle = ((num_sampled_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* cu_num_logits_handle = ((cu_num_logits_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool flatten_sampled_flat_is_null = (flat_handle == NULL);
  if (!(!flatten_sampled_flat_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "flatten_sampled.flat is expected to have non-NULL pointer");
    return -1;
  }
  bool flatten_sampled_sampled_is_null = (sampled_handle == NULL);
  if (!(!flatten_sampled_sampled_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "flatten_sampled.sampled is expected to have non-NULL pointer");
    return -1;
  }
  bool flatten_sampled_num_sampled_is_null = (num_sampled_handle == NULL);
  if (!(!flatten_sampled_num_sampled_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "flatten_sampled.num_sampled is expected to have non-NULL pointer");
    return -1;
  }
  bool flatten_sampled_cu_num_logits_is_null = (cu_num_logits_handle == NULL);
  if (!(!flatten_sampled_cu_num_logits_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "flatten_sampled.cu_num_logits is expected to have non-NULL pointer");
    return -1;
  }
  void* flatten_sampled_flat_shape = (((DLTensor*)flat_handle)[0].shape);
  void* flatten_sampled_sampled_shape = (((DLTensor*)sampled_handle)[0].shape);
  void* flatten_sampled_num_sampled_shape = (((DLTensor*)num_sampled_handle)[0].shape);
  void* flatten_sampled_cu_num_logits_shape = (((DLTensor*)cu_num_logits_handle)[0].shape);
  if (!(((((DLTensor*)flat_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input flat ndim mismatch, expected 1", (long long)((((DLTensor*)flat_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t num_logits = ((int32_t)((int64_t*)flatten_sampled_flat_shape)[0]);
  void* flatten_sampled_flat_strides = (((DLTensor*)flat_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)flat_handle)[0].device.device_id);
  void* flat = (((DLTensor*)flat_handle)[0].data);
  if (!(((((DLTensor*)sampled_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input sampled ndim mismatch, expected 2", (long long)((((DLTensor*)sampled_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t sampled_rows = ((int32_t)((int64_t*)flatten_sampled_sampled_shape)[0]);
  int32_t width = ((int32_t)((int64_t*)flatten_sampled_sampled_shape)[1]);
  void* flatten_sampled_sampled_strides = (((DLTensor*)sampled_handle)[0].strides);
  int32_t condval;
  if ((flatten_sampled_sampled_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)flatten_sampled_sampled_strides)[0]);
  }
  int32_t sampled_stride = condval;
  void* sampled = (((DLTensor*)sampled_handle)[0].data);
  if (!(((((DLTensor*)num_sampled_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input num_sampled ndim mismatch, expected 1", (long long)((((DLTensor*)num_sampled_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t num_reqs = ((int32_t)((int64_t*)flatten_sampled_num_sampled_shape)[0]);
  void* flatten_sampled_num_sampled_strides = (((DLTensor*)num_sampled_handle)[0].strides);
  void* num_sampled = (((DLTensor*)num_sampled_handle)[0].data);
  if (!(((((DLTensor*)cu_num_logits_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input cu_num_logits ndim mismatch, expected 1", (long long)((((DLTensor*)cu_num_logits_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t cu_len = ((int32_t)((int64_t*)flatten_sampled_cu_num_logits_shape)[0]);
  void* flatten_sampled_cu_num_logits_strides = (((DLTensor*)cu_num_logits_handle)[0].strides);
  void* cu_num_logits = (((DLTensor*)cu_num_logits_handle)[0].data);
  if (!(((((((DLTensor*)flat_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)flat_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)flat_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input flat dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_1;
  if ((flatten_sampled_flat_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)flatten_sampled_flat_strides)[0]);
  }
  if (!(((condval_1 == 1) || (num_logits == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input flat strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)flat_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input flat byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)flat_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)flat_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input flat device_type mismatch, expected cuda", (long long)((((DLTensor*)flat_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((num_logits == 0) || !(flat == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input flat data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)sampled_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)sampled_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)sampled_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input sampled dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_2;
  if ((flatten_sampled_sampled_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)flatten_sampled_sampled_strides)[1]);
  }
  if (!(((condval_2 == 1) || (width == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input sampled strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)sampled_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input sampled byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)sampled_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_id) == (((DLTensor*)flat_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input sampled device_id violates packed ABI constraint", (long long)((((DLTensor*)sampled_handle)[0].device.device_id)), (long long)((((DLTensor*)flat_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input sampled device_type mismatch, expected cuda", (long long)((((DLTensor*)sampled_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((sampled_rows == 0) || (width == 0)) || !(sampled == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input sampled data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)num_sampled_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)num_sampled_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)num_sampled_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input num_sampled dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_3;
  if ((flatten_sampled_num_sampled_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)flatten_sampled_num_sampled_strides)[0]);
  }
  if (!(((condval_3 == 1) || (num_reqs == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input num_sampled strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)num_sampled_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input num_sampled byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)num_sampled_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)num_sampled_handle)[0].device.device_id) == (((DLTensor*)flat_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input num_sampled device_id violates packed ABI constraint", (long long)((((DLTensor*)num_sampled_handle)[0].device.device_id)), (long long)((((DLTensor*)flat_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)num_sampled_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input num_sampled device_type mismatch, expected cuda", (long long)((((DLTensor*)num_sampled_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((num_reqs == 0) || !(num_sampled == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input num_sampled data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)cu_num_logits_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)cu_num_logits_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)cu_num_logits_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input cu_num_logits dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_4;
  if ((flatten_sampled_cu_num_logits_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)flatten_sampled_cu_num_logits_strides)[0]);
  }
  if (!(((condval_4 == 1) || (cu_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input cu_num_logits strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)cu_num_logits_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input cu_num_logits byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)cu_num_logits_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_num_logits_handle)[0].device.device_id) == (((DLTensor*)flat_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input cu_num_logits device_id violates packed ABI constraint", (long long)((((DLTensor*)cu_num_logits_handle)[0].device.device_id)), (long long)((((DLTensor*)flat_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_num_logits_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel flatten_sampled input cu_num_logits device_type mismatch, expected cuda", (long long)((((DLTensor*)cu_num_logits_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((cu_len == 0) || !(cu_num_logits == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel flatten_sampled input cu_num_logits data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (cu_num_logits == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = cu_num_logits;
  if (flat == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = flat;
  if (num_sampled == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = num_sampled;
  if (sampled == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = sampled;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)num_logits);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)num_reqs);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)sampled_stride);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)width);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)((num_logits + 127) >> 7));
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = (int64_t)0;
  if (flatten_sampled_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "flatten_sampled_kernel", &flatten_sampled_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(flatten_sampled_kernel_packed, (TVMFFIAny*) stack_ffi_any, 12, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_flatten_sampled(self, args, num_args, result);
}
