// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vision_spatial_merge_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_spatial_merge(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_spatial_merge(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[11];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vision_spatial_merge: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_spatial_merge: args pointer is NULL");
    return -1;
  }
  int32_t x_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((x_handle_type_index == 0) || (x_handle_type_index == 4)) || (x_handle_type_index == 7)) || (64 <= x_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input x expected pointer or tensor handle");
    return -1;
  }
  int32_t y_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((y_handle_type_index == 0) || (y_handle_type_index == 4)) || (y_handle_type_index == 7)) || (64 <= y_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input y expected pointer or tensor handle");
    return -1;
  }
  int32_t height_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((height_type_index == 1) || (height_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge scalar height expected integer");
    return -1;
  }
  int32_t width_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((width_type_index == 1) || (width_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge scalar width expected integer");
    return -1;
  }
  void* x_handle = ((x_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* y_handle = ((y_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  int32_t height = ((int32_t)(((TVMFFIAny*)args)[2].v_int64));
  int32_t width = ((int32_t)(((TVMFFIAny*)args)[3].v_int64));
  bool vision_spatial_merge_x_is_null = (x_handle == NULL);
  if (!(!vision_spatial_merge_x_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_spatial_merge.x is expected to have non-NULL pointer");
    return -1;
  }
  bool vision_spatial_merge_y_is_null = (y_handle == NULL);
  if (!(!vision_spatial_merge_y_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_spatial_merge.y is expected to have non-NULL pointer");
    return -1;
  }
  void* vision_spatial_merge_x_shape = (((DLTensor*)x_handle)[0].shape);
  void* vision_spatial_merge_y_shape = (((DLTensor*)y_handle)[0].shape);
  if (!(((((DLTensor*)x_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input x ndim mismatch, expected 2", (long long)((((DLTensor*)x_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)vision_spatial_merge_x_shape)[0]);
  void* vision_spatial_merge_x_strides = (((DLTensor*)x_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)x_handle)[0].device.device_id);
  void* x = (((DLTensor*)x_handle)[0].data);
  if (!(((((DLTensor*)y_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input y ndim mismatch, expected 2", (long long)((((DLTensor*)y_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t merged = ((int32_t)((int64_t*)vision_spatial_merge_y_shape)[0]);
  void* vision_spatial_merge_y_strides = (((DLTensor*)y_handle)[0].strides);
  void* y = (((DLTensor*)y_handle)[0].data);
  if (!(((((((DLTensor*)x_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)x_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)x_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input x dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_spatial_merge_x_shape)[1]) == 1024))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input x shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_spatial_merge_x_shape)[1])), (long long)(1024));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vision_spatial_merge_x_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vision_spatial_merge_x_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vision_spatial_merge_x_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vision_spatial_merge_x_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input x strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vision_spatial_merge_x_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vision_spatial_merge_x_strides)[0]);
  }
  if (!(((condval_2 == 1024) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input x strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)x_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input x byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)x_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)x_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input x device_type mismatch, expected cuda", (long long)((((DLTensor*)x_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(x == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input x data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)y_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)y_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)y_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input y dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_spatial_merge_y_shape)[1]) == 9216))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input y shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_spatial_merge_y_shape)[1])), (long long)(9216));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vision_spatial_merge_y_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vision_spatial_merge_y_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vision_spatial_merge_y_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vision_spatial_merge_y_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input y strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((vision_spatial_merge_y_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)vision_spatial_merge_y_strides)[0]);
  }
  if (!(((condval_5 == 9216) || (merged == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input y strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)y_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input y byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)y_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)y_handle)[0].device.device_id) == (((DLTensor*)x_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input y device_id violates packed ABI constraint", (long long)((((DLTensor*)y_handle)[0].device.device_id)), (long long)((((DLTensor*)x_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)y_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_spatial_merge input y device_type mismatch, expected cuda", (long long)((((DLTensor*)y_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((merged == 0) || !(y == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_spatial_merge input y data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (x == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = x;
  if (y == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = y;
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)height);
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)merged);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)width);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)merged);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)18576);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = (int64_t)0;
  if (vision_spatial_merge_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vision_spatial_merge_kernel", &vision_spatial_merge_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vision_spatial_merge_kernel_packed, (TVMFFIAny*) stack_ffi_any, 10, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vision_spatial_merge(self, args, num_args, result);
}
