
#include <math_constants.h>

template <int BASE_MINUS_ONE>
__device__ __forceinline__ void vllm_vocab_decode_vec16(
    const void* __restrict__ low_a_ptr,
    const void* __restrict__ low_b_ptr,
    const void* __restrict__ codes_ptr,
    void* __restrict__ out_a_ptr,
    void* __restrict__ out_b_ptr) {
  const uint4 low_a4 = *reinterpret_cast<const uint4*>(low_a_ptr);
  const uint4 low_b4 = *reinterpret_cast<const uint4*>(low_b_ptr);
  const uint4 codes4 = *reinterpret_cast<const uint4*>(codes_ptr);
  const unsigned int* la = reinterpret_cast<const unsigned int*>(&low_a4);
  const unsigned int* lb = reinterpret_cast<const unsigned int*>(&low_b4);
  const unsigned int* cd = reinterpret_cast<const unsigned int*>(&codes4);
  unsigned int* oa = reinterpret_cast<unsigned int*>(out_a_ptr);
  unsigned int* ob = reinterpret_cast<unsigned int*>(out_b_ptr);
  constexpr unsigned int BASE_SCALAR = (unsigned int)(BASE_MINUS_ONE & 0xFFFF);

  #pragma unroll
  for (int w = 0; w < 4; ++w) {
    const unsigned int c_word = cd[w];
    const unsigned int la_word = la[w];
    const unsigned int lb_word = lb[w];

    const unsigned int c01 = __byte_perm(c_word, 0u, 0x4140u);
    const unsigned int c23 = __byte_perm(c_word, 0u, 0x4342u);

    const unsigned int ca01 = c01 & 0x000F000Fu;
    const unsigned int cb01 = (c01 >> 4) & 0x000F000Fu;
    const unsigned int ca23 = c23 & 0x000F000Fu;
    const unsigned int cb23 = (c23 >> 4) & 0x000F000Fu;

    const unsigned int nza01 = ((ca01 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nzb01 = ((cb01 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nza23 = ((ca23 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nzb23 = ((cb23 + 0x000F000Fu) >> 4) & 0x00010001u;

    const unsigned int expa01 = (ca01 + nza01 * BASE_SCALAR) << 7;
    const unsigned int expb01 = (cb01 + nzb01 * BASE_SCALAR) << 7;
    const unsigned int expa23 = (ca23 + nza23 * BASE_SCALAR) << 7;
    const unsigned int expb23 = (cb23 + nzb23 * BASE_SCALAR) << 7;

    const unsigned int la01 = __byte_perm(la_word, 0u, 0x1100u);
    const unsigned int la23 = __byte_perm(la_word, 0u, 0x3322u);
    const unsigned int lb01 = __byte_perm(lb_word, 0u, 0x1100u);
    const unsigned int lb23 = __byte_perm(lb_word, 0u, 0x3322u);

    oa[2 * w + 0] = (la01 & 0x807F807Fu) | expa01;
    oa[2 * w + 1] = (la23 & 0x807F807Fu) | expa23;
    ob[2 * w + 0] = (lb01 & 0x807F807Fu) | expb01;
    ob[2 * w + 1] = (lb23 & 0x807F807Fu) | expb23;
  }
}

__device__ __forceinline__ int vllm_vocab_first_argmax_keep(
    float av, int ai, float bv, int bi) {
  const bool a_nan = av != av;
  const bool b_nan = bv != bv;
  return (a_nan & (!b_nan | (ai < bi))) |
         (!a_nan & !b_nan & ((av > bv) | ((av == bv) & (ai < bi))));
}

template <int BM, int BN, int THREADS>
__device__ __forceinline__ void vllm_vocab_tile_argmax(
    const float* __restrict__ smem_c,
    float* __restrict__ partial_vals,
    int* __restrict__ partial_idxs,
    int by, int bx, int M, int vocab, int num_tiles, int tx) {
  const int warp_id = tx >> 5;
  const int lane = tx & 31;
  constexpr int WARPS = THREADS >> 5;
  for (int r = warp_id; r < BM; r += WARPS) {
    const int row = by * BM + r;
    if (row < M) {
      float best_v = -CUDART_INF_F;
      int best_i = 2147483647;
      for (int c = lane; c < BN; c += 32) {
        const int col = bx * BN + c;
        if (col < vocab) {
          const float v = smem_c[r * BN + c];
          if (vllm_vocab_first_argmax_keep(v, col, best_v, best_i)) {
            best_v = v;
            best_i = col;
          }
        }
      }
      #pragma unroll
      for (int offset = 16; offset > 0; offset >>= 1) {
        const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
        const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
        if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
          best_v = ov;
          best_i = oi;
        }
      }
      if (lane == 0) {
        const int slot = row * num_tiles + bx;
        partial_vals[slot] = best_v;
        partial_idxs[slot] = best_i;
      }
    }
  }
}

template <int THREADS, int PAIR_WIDTH>
__device__ __forceinline__ void vllm_vocab_finish_argmax(
    const float* __restrict__ partial_vals,
    const int* __restrict__ partial_idxs,
    float* __restrict__ pairs,
    int row, int num_tiles, int vocab_start, int tx,
    float* __restrict__ smem_v, int* __restrict__ smem_i) {
  float best_v = -CUDART_INF_F;
  int best_i = 2147483647;
  const int base = row * num_tiles;
  for (int t = tx; t < num_tiles; t += THREADS) {
    const float v = partial_vals[base + t];
    const int idx = partial_idxs[base + t];
    if (vllm_vocab_first_argmax_keep(v, idx, best_v, best_i)) {
      best_v = v;
      best_i = idx;
    }
  }
  const int lane = tx & 31;
  const int warp_id = tx >> 5;
  constexpr int WARPS = THREADS >> 5;
  #pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1) {
    const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
    const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
    if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
      best_v = ov;
      best_i = oi;
    }
  }
  if (lane == 0) {
    smem_v[warp_id] = best_v;
    smem_i[warp_id] = best_i;
  }
  __syncthreads();
  if (warp_id == 0) {
    best_v = (lane < WARPS) ? smem_v[lane] : -CUDART_INF_F;
    best_i = (lane < WARPS) ? smem_i[lane] : 2147483647;
    #pragma unroll
    for (int offset = (WARPS >> 1); offset > 0; offset >>= 1) {
      const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
      const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
      if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
        best_v = ov;
        best_i = oi;
      }
    }
    if (lane == 0) {
      pairs[row * PAIR_WIDTH + 0] = best_v;
      pairs[row * PAIR_WIDTH + 1] = (float)(best_i + vocab_start);
    }
  }
}

// The block's first maximum of ``count`` (value, shard index) partials outside
// the PART-column part ``skip_part`` (-1: none), in every thread.
template <int THREADS, int PART>
__device__ __forceinline__ void vllm_vocab_block_first_argmax(
    const float* __restrict__ vals,
    const int* __restrict__ idxs,
    int count, int skip_part, int tx,
    float* __restrict__ smem_v, int* __restrict__ smem_i,
    float& out_v, int& out_i) {
  float best_v = -CUDART_INF_F;
  int best_i = 2147483647;
  for (int t = tx; t < count; t += THREADS) {
    const float v = vals[t];
    const int idx = idxs[t];
    if (idx / PART != skip_part &&
        vllm_vocab_first_argmax_keep(v, idx, best_v, best_i)) {
      best_v = v;
      best_i = idx;
    }
  }
  const int lane = tx & 31;
  const int warp_id = tx >> 5;
  constexpr int WARPS = THREADS >> 5;
  #pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1) {
    const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
    const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
    if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
      best_v = ov;
      best_i = oi;
    }
  }
  if (lane == 0) {
    smem_v[warp_id] = best_v;
    smem_i[warp_id] = best_i;
  }
  __syncthreads();
  best_v = smem_v[0];
  best_i = smem_i[0];
  #pragma unroll
  for (int w = 1; w < WARPS; ++w) {
    if (vllm_vocab_first_argmax_keep(smem_v[w], smem_i[w], best_v, best_i)) {
      best_v = smem_v[w];
      best_i = smem_i[w];
    }
  }
  __syncthreads();
  out_v = best_v;
  out_i = best_i;
}

// vllm_vocab_finish_argmax and the row's runner-up as
// dspark.greedy.greedy_markov_shard_pair(top2=True) reports it: the first
// maximum of the tiles outside the pair's PART-column part, into columns 2 and
// 3 (index 2**30 when the shard has no other part).
template <int THREADS, int PAIR_WIDTH, int PART>
__device__ __forceinline__ void vllm_vocab_finish_argmax_top2(
    const float* __restrict__ partial_vals,
    const int* __restrict__ partial_idxs,
    float* __restrict__ pairs,
    int row, int num_tiles, int vocab_start, int tx,
    float* __restrict__ smem_v, int* __restrict__ smem_i) {
  const int base = row * num_tiles;
  float best_v, second_v;
  int best_i, second_i;
  vllm_vocab_block_first_argmax<THREADS, PART>(
      partial_vals + base, partial_idxs + base, num_tiles, -1, tx, smem_v, smem_i,
      best_v, best_i);
  vllm_vocab_block_first_argmax<THREADS, PART>(
      partial_vals + base, partial_idxs + base, num_tiles, best_i / PART, tx,
      smem_v, smem_i, second_v, second_i);
  if (tx == 0) {
    pairs[row * PAIR_WIDTH + 0] = best_v;
    pairs[row * PAIR_WIDTH + 1] = (float)(best_i + vocab_start);
    pairs[row * PAIR_WIDTH + 2] = second_v;
    pairs[row * PAIR_WIDTH + 3] = second_i < 2147483647
                                      ? (float)(second_i + vocab_start)
                                      : (float)(1 << 30);
  }
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vocab_packed_markov_greedy_partials_kernel(const bfloat16_t* A, const float* Base, const uchar* W, const int* exception_entries, const int* exception_rows, int* partial_idxs, float* partial_vals, const int* row_offsets, int E, int M, int64_t base_stride, int vocab);
extern "C" __global__ void __launch_bounds__(128, 1) vocab_packed_markov_greedy_partials_kernel(const bfloat16_t* A, const float* Base, const uchar* W, const int* exception_entries, const int* exception_rows, int* partial_idxs, float* partial_vals, const int* row_offsets, int E, int M, int64_t base_stride, int vocab) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* C_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 16384));
  void* low_shared = ((void*)((char*)buf_dyn_shmem + 24576));
  void* code_shared = ((void*)((char*)buf_dyn_shmem + 28672));
  float C_local[16];
  uchar low_a[16];
  uchar low_b[16];
  uchar codes[16];
  bfloat16_t out_a[16];
  bfloat16_t out_b[16];
  int start = 0;
  int end = 0;
  int row = 0;
  int entry = 0;
  float value = 0x0p+0f/*0.000000e+00*/;
  int column = 0;
  cudaGridDependencySynchronize();
  cudaTriggerProgrammaticLaunchCompletion();
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    float broadcast_var = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_local + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  for (int s = 0; s < 2; ++s) {
    __syncthreads();
    #pragma unroll
    for (int i_1 = 0; i_1 < 8; ++i_1) {
      bfloat16_t broadcast_var_1 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
      uint4 condval;
      if (((((((int)blockIdx.y) * 64) + (i_1 * 8)) + (((int)threadIdx.x) >> 4)) < M)) {
        condval = *(uint4*)(A + (((((((int64_t)((int)blockIdx.y)) * (int64_t)16384) + (((int64_t)i_1) * (int64_t)2048)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)4) * (int64_t)256)) + (((int64_t)s) * (int64_t)128)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)15) * (int64_t)8)));
      } else {
        condval = make_uint4(__pack_nv_bfloat162(broadcast_var_1, broadcast_var_1), __pack_nv_bfloat162(broadcast_var_1, broadcast_var_1), __pack_nv_bfloat162(broadcast_var_1, broadcast_var_1), __pack_nv_bfloat162(broadcast_var_1, broadcast_var_1));
      }
      *(uint4*)(((bfloat16_t*)A_shared) + ((((((((((int)threadIdx.x) & 15) >> 3) * 4096) + (i_1 * 512)) + ((((int)threadIdx.x) >> 4) * 64)) + ((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))) = condval;
    }
    #pragma unroll
    for (int i_2 = 0; i_2 < 2; ++i_2) {
      *(uint4*)(((uchar*)low_shared) + ((i_2 * 2048) + (((int)threadIdx.x) * 16))) = *(uint4*)(W + (((((((int)blockIdx.x) * 12288) + (i_2 * 6144)) + ((((int)threadIdx.x) >> 3) * 384)) + (s * 128)) + ((((int)threadIdx.x) & 7) * 16)));
    }
    *(uint4*)(((uchar*)code_shared) + (((int)threadIdx.x) * 16)) = *(uint4*)(W + (((((((int)blockIdx.x) * 12288) + ((((int)threadIdx.x) >> 2) * 384)) + (s * 64)) + ((((int)threadIdx.x) & 3) * 16)) + 256));
    __syncthreads();
    *(uint4*)(low_a + 0) = *(uint4*)(((uchar*)low_shared) + (((((int)threadIdx.x) >> 2) * 128) + ((((int)threadIdx.x) & 3) * 16)));
    *(uint4*)(low_b + 0) = *(uint4*)(((uchar*)low_shared) + ((((((int)threadIdx.x) >> 2) * 128) + ((((int)threadIdx.x) & 3) * 16)) + 64));
    *(uint4*)(codes + 0) = *(uint4*)(((uchar*)code_shared) + (((int)threadIdx.x) * 16));
    vllm_vocab_decode_vec16<109>((&(low_a[0])), (&(low_b[0])), (&(codes[0])), (&(out_a[0])), (&(out_b[0])));
    for (int v = 0; v < 2; ++v) {
      *(uint4*)(((bfloat16_t*)B_shared) + (((((((int)threadIdx.x) >> 2) * 64) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 7) >> 2) + v) & 1) * 8))) = *(uint4*)(out_a + (v * 8));
    }
    for (int v_1 = 0; v_1 < 2; ++v_1) {
      *(uint4*)(((bfloat16_t*)B_shared) + ((((((((int)threadIdx.x) >> 2) * 64) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 7) >> 2) + v_1) & 1) * 8)) + 2048)) = *(uint4*)(out_b + (v_1 * 8));
    }
    {
      bfloat16_t A_local[16];
      bfloat16_t B_local[8];
      __syncthreads();
      for (int ki = 0; ki < 8; ++ki) {
        #pragma unroll
        for (int i_3 = 0; i_3 < 2; ++i_3) {
          tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((ki >> 2) * 4096) + (((((int)threadIdx.x) & 63) >> 5) * 2048)) + (i_3 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_3 * 8)])));
        }
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)B_shared)[((((((((ki >> 2) * 2048) + ((((int)threadIdx.x) >> 6) * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[0])));
        for (int i_4 = 0; i_4 < 2; ++i_4) {
          tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + 0));
          tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_local + ((i_4 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + 4));
        }
      }
    }
  }
  if (0 < E) {
    start = row_offsets[(((int)blockIdx.x) * 32)];
    end = row_offsets[((((int)blockIdx.x) * 32) + 32)];
    if (start < end) {
      for (int index = start; index < end; ++index) {
        int condval_1;
        if (((index < E) && (0 <= index))) {
          condval_1 = exception_rows[((int64_t)index)];
        } else {
          condval_1 = 0;
        }
        row = (condval_1 - (((int)blockIdx.x) * 32));
        int condval_2;
        if (((index < E) && (0 <= index))) {
          condval_2 = exception_entries[((int64_t)index)];
        } else {
          condval_2 = 0;
        }
        entry = condval_2;
        ushort v_ = (ushort)(entry & 65535);
        value = ((float)(*(bfloat16_t *)(&(v_))));
        column = (entry >> 16);
        #pragma unroll
        for (int i_5 = 0; i_5 < 16; ++i_5) {
          if ((((((((int)threadIdx.x) >> 6) * 16) + (((i_5 & 7) >> 2) * 8)) + ((((int)threadIdx.x) & 3) * 2)) + (i_5 & 1)) == row) {
            bfloat16_t condval_3;
            if ((((0 <= column) && (column < 256)) && (1 <= M))) {
              condval_3 = A[((min((((((((int64_t)((int)blockIdx.y)) * (int64_t)64) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)32)) + ((((int64_t)i_5) >> (int64_t)3) * (int64_t)16)) + (((((int64_t)i_5) & (int64_t)3) >> (int64_t)1) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2)), (((int64_t)M) - (int64_t)1)) * (int64_t)256) + ((int64_t)column))];
            } else {
              condval_3 = bfloat16_t(0x0p+0f/*0.000000e+00*/);
            }
            C_local[i_5] = (C_local[i_5] + (value * ((float)condval_3)));
          }
        }
      }
    }
  }
  #pragma unroll
  for (int i_6 = 0; i_6 < 16; ++i_6) {
    float condval_4;
    if ((1 <= M)) {
      condval_4 = Base[((((((((int64_t)((int)blockIdx.x)) * (int64_t)32) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)16)) + (((((int64_t)i_6) & (int64_t)7) >> (int64_t)2) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2)) + (((int64_t)min((((((((int)blockIdx.y) * 64) + (((((int)threadIdx.x) & 63) >> 5) * 32)) + ((i_6 >> 3) * 16)) + (((i_6 & 3) >> 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)), (M - 1))) * base_stride)) + (((int64_t)i_6) & (int64_t)1))];
    } else {
      condval_4 = 0x0p+0f/*0.000000e+00*/;
    }
    C_local[i_6] = (condval_4 + C_local[i_6]);
  }
  __syncthreads();
  #pragma unroll
  for (int i_7 = 0; i_7 < 8; ++i_7) {
    *(float2*)(((float*)C_shared) + (((((((((((int)threadIdx.x) & 63) >> 5) * 1024) + ((i_7 >> 2) * 512)) + ((i_7 & 1) * 256)) + (((((int)threadIdx.x) & 31) >> 2) * 32)) + ((((int)threadIdx.x) >> 6) * 16)) + (((i_7 & 3) >> 1) * 8)) + ((((int)threadIdx.x) & 3) * 2))) = *(float2*)(C_local + (i_7 * 2));
  }
  __syncthreads();
  vllm_vocab_tile_argmax<64, 32, 128>((&(((float*)C_shared)[0])), (&(partial_vals[0])), (&(partial_idxs[0])), ((int)blockIdx.y), ((int)blockIdx.x), M, vocab, 1348, ((int)threadIdx.x));
}

