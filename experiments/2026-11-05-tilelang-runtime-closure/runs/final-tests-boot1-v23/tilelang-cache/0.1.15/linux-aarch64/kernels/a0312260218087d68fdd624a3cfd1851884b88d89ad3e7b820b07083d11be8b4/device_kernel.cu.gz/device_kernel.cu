#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void apply_write_kernel(const int* __restrict__ contents, const int* __restrict__ cu_lens, const int* __restrict__ indices, int* __restrict__ output, const int* __restrict__ starts, int chunks, int64_t output_stride, int writes);
extern "C" __global__ void __launch_bounds__(256, 1) apply_write_kernel(const int* __restrict__ contents, const int* __restrict__ cu_lens, const int* __restrict__ indices, int* __restrict__ output, const int* __restrict__ starts, int chunks, int64_t output_stride, int writes) {
  int condval;
  if ((0 < ((int)blockIdx.x))) {
    condval = cu_lens[(((int64_t)((int)blockIdx.x)) - (int64_t)1)];
  } else {
    condval = 0;
  }
  int begin = condval;
  int length = (cu_lens[((int64_t)((int)blockIdx.x))] - begin);
  int64_t base = ((((int64_t)indices[((int64_t)((int)blockIdx.x))]) * output_stride) + ((int64_t)starts[((int64_t)((int)blockIdx.x))]));
  #pragma unroll
  for (int k = 0; k < 4; ++k) {
    if ((((((int)blockIdx.y) * 1024) + (k * 256)) + ((int)threadIdx.x)) < length) {
      output[((((((int64_t)((int)blockIdx.y)) * (int64_t)1024) + (((int64_t)k) * (int64_t)256)) + base) + ((int64_t)((int)threadIdx.x)))] = contents[((((((int64_t)((int)blockIdx.y)) * (int64_t)1024) + (((int64_t)k) * (int64_t)256)) + ((int64_t)begin)) + ((int64_t)((int)threadIdx.x)))];
    }
  }
}

