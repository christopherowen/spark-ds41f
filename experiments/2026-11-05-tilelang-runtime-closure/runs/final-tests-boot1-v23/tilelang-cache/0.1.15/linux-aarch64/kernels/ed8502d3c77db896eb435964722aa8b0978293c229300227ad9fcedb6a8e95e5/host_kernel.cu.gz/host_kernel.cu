// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* gemm_bf16_splitk_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gemm_bf16_splitk(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gemm_bf16_splitk(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[15];
  void* stack_ffi_any = stack;
  if (!((num_args == 5))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "gemm_bf16_splitk: num_args should be 5", (long long)(num_args), (long long)(5));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gemm_bf16_splitk: args pointer is NULL");
    return -1;
  }
  int32_t A_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((A_handle_type_index == 0) || (A_handle_type_index == 4)) || (A_handle_type_index == 7)) || (64 <= A_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input A expected pointer or tensor handle");
    return -1;
  }
  int32_t B_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((B_handle_type_index == 0) || (B_handle_type_index == 4)) || (B_handle_type_index == 7)) || (64 <= B_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input B expected pointer or tensor handle");
    return -1;
  }
  int32_t P_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((P_handle_type_index == 0) || (P_handle_type_index == 4)) || (P_handle_type_index == 7)) || (64 <= P_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input P expected pointer or tensor handle");
    return -1;
  }
  int32_t counters_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((counters_handle_type_index == 0) || (counters_handle_type_index == 4)) || (counters_handle_type_index == 7)) || (64 <= counters_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input counters expected pointer or tensor handle");
    return -1;
  }
  int32_t C0_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((C0_handle_type_index == 0) || (C0_handle_type_index == 4)) || (C0_handle_type_index == 7)) || (64 <= C0_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input C0 expected pointer or tensor handle");
    return -1;
  }
  void* A_handle = ((A_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* B_handle = ((B_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* P_handle = ((P_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* counters_handle = ((counters_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* C0_handle = ((C0_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  bool gemm_bf16_splitk_A_is_null = (A_handle == NULL);
  if (!(!gemm_bf16_splitk_A_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gemm_bf16_splitk.A is expected to have non-NULL pointer");
    return -1;
  }
  bool gemm_bf16_splitk_B_is_null = (B_handle == NULL);
  if (!(!gemm_bf16_splitk_B_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gemm_bf16_splitk.B is expected to have non-NULL pointer");
    return -1;
  }
  bool gemm_bf16_splitk_P_is_null = (P_handle == NULL);
  if (!(!gemm_bf16_splitk_P_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gemm_bf16_splitk.P is expected to have non-NULL pointer");
    return -1;
  }
  bool gemm_bf16_splitk_counters_is_null = (counters_handle == NULL);
  if (!(!gemm_bf16_splitk_counters_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gemm_bf16_splitk.counters is expected to have non-NULL pointer");
    return -1;
  }
  bool gemm_bf16_splitk_C0_is_null = (C0_handle == NULL);
  if (!(!gemm_bf16_splitk_C0_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gemm_bf16_splitk.C0 is expected to have non-NULL pointer");
    return -1;
  }
  void* gemm_bf16_splitk_A_shape = (((DLTensor*)A_handle)[0].shape);
  void* gemm_bf16_splitk_B_shape = (((DLTensor*)B_handle)[0].shape);
  void* gemm_bf16_splitk_P_shape = (((DLTensor*)P_handle)[0].shape);
  void* gemm_bf16_splitk_counters_shape = (((DLTensor*)counters_handle)[0].shape);
  void* gemm_bf16_splitk_C0_shape = (((DLTensor*)C0_handle)[0].shape);
  if (!(((((DLTensor*)A_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input A ndim mismatch, expected 2", (long long)((((DLTensor*)A_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: gemm_bf16_splitk.A, gemm_bf16_splitk.P, gemm_bf16_splitk.C0");
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)gemm_bf16_splitk_A_shape)[0]);
  void* gemm_bf16_splitk_A_strides = (((DLTensor*)A_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)A_handle)[0].device.device_id);
  void* A = (((DLTensor*)A_handle)[0].data);
  if (!(((((DLTensor*)B_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B ndim mismatch, expected 2", (long long)((((DLTensor*)B_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gemm_bf16_splitk_B_strides = (((DLTensor*)B_handle)[0].strides);
  void* B = (((DLTensor*)B_handle)[0].data);
  if (!(((((DLTensor*)P_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P ndim mismatch, expected 3", (long long)((((DLTensor*)P_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gemm_bf16_splitk_P_strides = (((DLTensor*)P_handle)[0].strides);
  void* P = (((DLTensor*)P_handle)[0].data);
  if (!(((((DLTensor*)counters_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input counters ndim mismatch, expected 1", (long long)((((DLTensor*)counters_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t tiles = ((int32_t)((int64_t*)gemm_bf16_splitk_counters_shape)[0]);
  void* gemm_bf16_splitk_counters_strides = (((DLTensor*)counters_handle)[0].strides);
  void* counters = (((DLTensor*)counters_handle)[0].data);
  if (!(((((DLTensor*)C0_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input C0 ndim mismatch, expected 2", (long long)((((DLTensor*)C0_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gemm_bf16_splitk_C0_strides = (((DLTensor*)C0_handle)[0].strides);
  void* C0 = (((DLTensor*)C0_handle)[0].data);
  if (!(((((((DLTensor*)A_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)A_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)A_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input A dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_A_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input A shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_A_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((gemm_bf16_splitk_A_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)gemm_bf16_splitk_A_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((gemm_bf16_splitk_A_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)gemm_bf16_splitk_A_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input A strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((gemm_bf16_splitk_A_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)gemm_bf16_splitk_A_strides)[0]);
  }
  if (!(((condval_2 == 5120) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input A strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)A_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input A byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)A_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)A_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input A device_type mismatch, expected cuda", (long long)((((DLTensor*)A_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(A == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input A data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)B_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)B_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)B_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input B dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_B_shape)[0]) == 128))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_B_shape)[0])), (long long)(128));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_B_shape)[1]) == 5120))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_B_shape)[1])), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((gemm_bf16_splitk_B_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)gemm_bf16_splitk_B_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((gemm_bf16_splitk_B_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)gemm_bf16_splitk_B_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((gemm_bf16_splitk_B_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)gemm_bf16_splitk_B_strides)[0]);
  }
  if (!((condval_5 == 5120))) {
    int32_t condval_6;
    if ((gemm_bf16_splitk_B_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)gemm_bf16_splitk_B_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B strides[0] violates packed ABI constraint", (long long)(condval_6), (long long)(5120));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)B_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)B_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)B_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B device_id violates packed ABI constraint", (long long)((((DLTensor*)B_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)B_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input B device_type mismatch, expected cuda", (long long)((((DLTensor*)B_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(B == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input B data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)P_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)P_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)P_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input P dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_P_shape)[0]) == 5))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_P_shape)[0])), (long long)(5));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_A_shape)[0]) == ((int32_t)((int64_t*)gemm_bf16_splitk_P_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_A_shape)[0])), (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_P_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_P_shape)[2]) == 128))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_P_shape)[2])), (long long)(128));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((gemm_bf16_splitk_P_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)gemm_bf16_splitk_P_strides)[2]);
  }
  if (!((condval_7 == 1))) {
    int32_t condval_8;
    if ((gemm_bf16_splitk_P_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)gemm_bf16_splitk_P_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P strides[2] violates packed ABI constraint", (long long)(condval_8), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((gemm_bf16_splitk_P_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)gemm_bf16_splitk_P_strides)[1]);
  }
  if (!(((condval_9 == 128) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input P strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_10;
  if ((gemm_bf16_splitk_P_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)gemm_bf16_splitk_P_strides)[0]);
  }
  if (!((((M * 128) == condval_10) || (M == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input P strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)P_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)P_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)P_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P device_id violates packed ABI constraint", (long long)((((DLTensor*)P_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)P_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input P device_type mismatch, expected cuda", (long long)((((DLTensor*)P_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(P == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input P data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)counters_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)counters_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)counters_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input counters dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_11;
  if ((gemm_bf16_splitk_counters_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)gemm_bf16_splitk_counters_strides)[0]);
  }
  if (!(((condval_11 == 1) || (tiles == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input counters strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)counters_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input counters byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)counters_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)counters_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input counters device_id violates packed ABI constraint", (long long)((((DLTensor*)counters_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)counters_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input counters device_type mismatch, expected cuda", (long long)((((DLTensor*)counters_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((tiles == 0) || !(counters == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input counters data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)C0_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)C0_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)C0_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input C0 dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_A_shape)[0]) == ((int32_t)((int64_t*)gemm_bf16_splitk_C0_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input C0 shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_A_shape)[0])), (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_C0_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gemm_bf16_splitk_C0_shape)[1]) == 128))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input C0 shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gemm_bf16_splitk_C0_shape)[1])), (long long)(128));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((gemm_bf16_splitk_C0_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)gemm_bf16_splitk_C0_strides)[1]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((gemm_bf16_splitk_C0_strides == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)gemm_bf16_splitk_C0_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input C0 strides[1] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_14;
  if ((gemm_bf16_splitk_C0_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)gemm_bf16_splitk_C0_strides)[0]);
  }
  if (!(((condval_14 == 128) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input C0 strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)C0_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input C0 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)C0_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C0_handle)[0].device.device_id) == (((DLTensor*)A_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input C0 device_id violates packed ABI constraint", (long long)((((DLTensor*)C0_handle)[0].device.device_id)), (long long)((((DLTensor*)A_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)C0_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gemm_bf16_splitk input C0 device_type mismatch, expected cuda", (long long)((((DLTensor*)C0_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(C0 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gemm_bf16_splitk input C0 data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (A == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = A;
  if (B == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = B;
  if (C0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = C0;
  if (P == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = P;
  if (counters == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = counters;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)tiles);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)4);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)5);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)((M + 63) >> 6));
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)24576);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = (int64_t)0;
  if (gemm_bf16_splitk_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "gemm_bf16_splitk_kernel", &gemm_bf16_splitk_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(gemm_bf16_splitk_kernel_packed, (TVMFFIAny*) stack_ffi_any, 14, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_gemm_bf16_splitk(self, args, num_args, result);
}
