// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vocab_greedy_finish_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_greedy_finish(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vocab_greedy_finish(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[11];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vocab_greedy_finish: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_greedy_finish: args pointer is NULL");
    return -1;
  }
  int32_t partial_vals_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((partial_vals_handle_type_index == 0) || (partial_vals_handle_type_index == 4)) || (partial_vals_handle_type_index == 7)) || (64 <= partial_vals_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_vals expected pointer or tensor handle");
    return -1;
  }
  int32_t partial_idxs_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((partial_idxs_handle_type_index == 0) || (partial_idxs_handle_type_index == 4)) || (partial_idxs_handle_type_index == 7)) || (64 <= partial_idxs_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_idxs expected pointer or tensor handle");
    return -1;
  }
  int32_t pairs_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((pairs_handle_type_index == 0) || (pairs_handle_type_index == 4)) || (pairs_handle_type_index == 7)) || (64 <= pairs_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input pairs expected pointer or tensor handle");
    return -1;
  }
  int32_t vocab_start_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((vocab_start_type_index == 1) || (vocab_start_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish scalar vocab_start expected integer");
    return -1;
  }
  void* partial_vals_handle = ((partial_vals_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* partial_idxs_handle = ((partial_idxs_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* pairs_handle = ((pairs_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  int32_t vocab_start = ((int32_t)(((TVMFFIAny*)args)[3].v_int64));
  bool vocab_greedy_finish_partial_vals_is_null = (partial_vals_handle == NULL);
  if (!(!vocab_greedy_finish_partial_vals_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_greedy_finish.partial_vals is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_greedy_finish_partial_idxs_is_null = (partial_idxs_handle == NULL);
  if (!(!vocab_greedy_finish_partial_idxs_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_greedy_finish.partial_idxs is expected to have non-NULL pointer");
    return -1;
  }
  bool vocab_greedy_finish_pairs_is_null = (pairs_handle == NULL);
  if (!(!vocab_greedy_finish_pairs_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vocab_greedy_finish.pairs is expected to have non-NULL pointer");
    return -1;
  }
  void* vocab_greedy_finish_partial_vals_shape = (((DLTensor*)partial_vals_handle)[0].shape);
  void* vocab_greedy_finish_partial_idxs_shape = (((DLTensor*)partial_idxs_handle)[0].shape);
  void* vocab_greedy_finish_pairs_shape = (((DLTensor*)pairs_handle)[0].shape);
  if (!(((((DLTensor*)partial_vals_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_vals ndim mismatch, expected 2", (long long)((((DLTensor*)partial_vals_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable M requires at least one non-null buffer among: vocab_greedy_finish.partial_vals, vocab_greedy_finish.partial_idxs, vocab_greedy_finish.pairs");
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_shape)[0]);
  void* vocab_greedy_finish_partial_vals_strides = (((DLTensor*)partial_vals_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)partial_vals_handle)[0].device.device_id);
  void* partial_vals = (((DLTensor*)partial_vals_handle)[0].data);
  if (!(((((DLTensor*)partial_idxs_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_idxs ndim mismatch, expected 2", (long long)((((DLTensor*)partial_idxs_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_greedy_finish_partial_idxs_strides = (((DLTensor*)partial_idxs_handle)[0].strides);
  void* partial_idxs = (((DLTensor*)partial_idxs_handle)[0].data);
  if (!(((((DLTensor*)pairs_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input pairs ndim mismatch, expected 2", (long long)((((DLTensor*)pairs_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vocab_greedy_finish_pairs_strides = (((DLTensor*)pairs_handle)[0].strides);
  void* pairs = (((DLTensor*)pairs_handle)[0].data);
  if (!(((((((DLTensor*)partial_vals_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)partial_vals_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)partial_vals_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_vals dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_shape)[1]) == 1348))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_vals shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_shape)[1])), (long long)(1348));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vocab_greedy_finish_partial_vals_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vocab_greedy_finish_partial_vals_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_vals strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vocab_greedy_finish_partial_vals_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_strides)[0]);
  }
  if (!(((condval_2 == 1348) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_vals strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)partial_vals_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_vals byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)partial_vals_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)partial_vals_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_vals device_type mismatch, expected cuda", (long long)((((DLTensor*)partial_vals_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(partial_vals == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_vals data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)partial_idxs_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)partial_idxs_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)partial_idxs_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_idxs dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_shape)[0]) == ((int32_t)((int64_t*)vocab_greedy_finish_partial_idxs_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_idxs shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_greedy_finish_partial_idxs_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_greedy_finish_partial_idxs_shape)[1]) == 1348))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_idxs shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_greedy_finish_partial_idxs_shape)[1])), (long long)(1348));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vocab_greedy_finish_partial_idxs_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vocab_greedy_finish_partial_idxs_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vocab_greedy_finish_partial_idxs_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vocab_greedy_finish_partial_idxs_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_idxs strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((vocab_greedy_finish_partial_idxs_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)vocab_greedy_finish_partial_idxs_strides)[0]);
  }
  if (!(((condval_5 == 1348) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_idxs strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)partial_idxs_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_idxs byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)partial_idxs_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)partial_idxs_handle)[0].device.device_id) == (((DLTensor*)partial_vals_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_idxs device_id violates packed ABI constraint", (long long)((((DLTensor*)partial_idxs_handle)[0].device.device_id)), (long long)((((DLTensor*)partial_vals_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)partial_idxs_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input partial_idxs device_type mismatch, expected cuda", (long long)((((DLTensor*)partial_idxs_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(partial_idxs == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input partial_idxs data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)pairs_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)pairs_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)pairs_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input pairs dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_shape)[0]) == ((int32_t)((int64_t*)vocab_greedy_finish_pairs_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input pairs shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_greedy_finish_partial_vals_shape)[0])), (long long)(((int32_t)((int64_t*)vocab_greedy_finish_pairs_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)vocab_greedy_finish_pairs_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input pairs shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vocab_greedy_finish_pairs_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((vocab_greedy_finish_pairs_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)vocab_greedy_finish_pairs_strides)[1]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((vocab_greedy_finish_pairs_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)vocab_greedy_finish_pairs_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input pairs strides[1] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((vocab_greedy_finish_pairs_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)vocab_greedy_finish_pairs_strides)[0]);
  }
  if (!(((condval_8 == 4) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input pairs strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)pairs_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input pairs byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)pairs_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pairs_handle)[0].device.device_id) == (((DLTensor*)partial_vals_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input pairs device_id violates packed ABI constraint", (long long)((((DLTensor*)pairs_handle)[0].device.device_id)), (long long)((((DLTensor*)partial_vals_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pairs_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vocab_greedy_finish input pairs device_type mismatch, expected cuda", (long long)((((DLTensor*)pairs_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(pairs == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vocab_greedy_finish input pairs data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (pairs == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = pairs;
  if (partial_idxs == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = partial_idxs;
  if (partial_vals == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = partial_vals;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)vocab_start);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)64);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = (int64_t)0;
  if (vocab_greedy_finish_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vocab_greedy_finish_kernel", &vocab_greedy_finish_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vocab_greedy_finish_kernel_packed, (TVMFFIAny*) stack_ffi_any, 10, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vocab_greedy_finish(self, args, num_args, result);
}
