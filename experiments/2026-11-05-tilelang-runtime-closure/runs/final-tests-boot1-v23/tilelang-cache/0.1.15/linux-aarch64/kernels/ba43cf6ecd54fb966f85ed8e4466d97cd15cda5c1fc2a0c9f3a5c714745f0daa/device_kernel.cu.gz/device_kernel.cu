
#include <math_constants.h>

template <int BASE_MINUS_ONE>
__device__ __forceinline__ void vllm_vocab_decode_vec16(
    const void* __restrict__ low_a_ptr,
    const void* __restrict__ low_b_ptr,
    const void* __restrict__ codes_ptr,
    void* __restrict__ out_a_ptr,
    void* __restrict__ out_b_ptr) {
  const uint4 low_a4 = *reinterpret_cast<const uint4*>(low_a_ptr);
  const uint4 low_b4 = *reinterpret_cast<const uint4*>(low_b_ptr);
  const uint4 codes4 = *reinterpret_cast<const uint4*>(codes_ptr);
  const unsigned int* la = reinterpret_cast<const unsigned int*>(&low_a4);
  const unsigned int* lb = reinterpret_cast<const unsigned int*>(&low_b4);
  const unsigned int* cd = reinterpret_cast<const unsigned int*>(&codes4);
  unsigned int* oa = reinterpret_cast<unsigned int*>(out_a_ptr);
  unsigned int* ob = reinterpret_cast<unsigned int*>(out_b_ptr);
  constexpr unsigned int BASE_SCALAR = (unsigned int)(BASE_MINUS_ONE & 0xFFFF);

  #pragma unroll
  for (int w = 0; w < 4; ++w) {
    const unsigned int c_word = cd[w];
    const unsigned int la_word = la[w];
    const unsigned int lb_word = lb[w];

    const unsigned int c01 = __byte_perm(c_word, 0u, 0x4140u);
    const unsigned int c23 = __byte_perm(c_word, 0u, 0x4342u);

    const unsigned int ca01 = c01 & 0x000F000Fu;
    const unsigned int cb01 = (c01 >> 4) & 0x000F000Fu;
    const unsigned int ca23 = c23 & 0x000F000Fu;
    const unsigned int cb23 = (c23 >> 4) & 0x000F000Fu;

    const unsigned int nza01 = ((ca01 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nzb01 = ((cb01 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nza23 = ((ca23 + 0x000F000Fu) >> 4) & 0x00010001u;
    const unsigned int nzb23 = ((cb23 + 0x000F000Fu) >> 4) & 0x00010001u;

    const unsigned int expa01 = (ca01 + nza01 * BASE_SCALAR) << 7;
    const unsigned int expb01 = (cb01 + nzb01 * BASE_SCALAR) << 7;
    const unsigned int expa23 = (ca23 + nza23 * BASE_SCALAR) << 7;
    const unsigned int expb23 = (cb23 + nzb23 * BASE_SCALAR) << 7;

    const unsigned int la01 = __byte_perm(la_word, 0u, 0x1100u);
    const unsigned int la23 = __byte_perm(la_word, 0u, 0x3322u);
    const unsigned int lb01 = __byte_perm(lb_word, 0u, 0x1100u);
    const unsigned int lb23 = __byte_perm(lb_word, 0u, 0x3322u);

    oa[2 * w + 0] = (la01 & 0x807F807Fu) | expa01;
    oa[2 * w + 1] = (la23 & 0x807F807Fu) | expa23;
    ob[2 * w + 0] = (lb01 & 0x807F807Fu) | expb01;
    ob[2 * w + 1] = (lb23 & 0x807F807Fu) | expb23;
  }
}

__device__ __forceinline__ int vllm_vocab_first_argmax_keep(
    float av, int ai, float bv, int bi) {
  const bool a_nan = av != av;
  const bool b_nan = bv != bv;
  return (a_nan & (!b_nan | (ai < bi))) |
         (!a_nan & !b_nan & ((av > bv) | ((av == bv) & (ai < bi))));
}

template <int BM, int BN, int THREADS>
__device__ __forceinline__ void vllm_vocab_tile_argmax(
    const float* __restrict__ smem_c,
    float* __restrict__ partial_vals,
    int* __restrict__ partial_idxs,
    int by, int bx, int M, int vocab, int num_tiles, int tx) {
  const int warp_id = tx >> 5;
  const int lane = tx & 31;
  constexpr int WARPS = THREADS >> 5;
  for (int r = warp_id; r < BM; r += WARPS) {
    const int row = by * BM + r;
    if (row < M) {
      float best_v = -CUDART_INF_F;
      int best_i = 2147483647;
      for (int c = lane; c < BN; c += 32) {
        const int col = bx * BN + c;
        if (col < vocab) {
          const float v = smem_c[r * BN + c];
          if (vllm_vocab_first_argmax_keep(v, col, best_v, best_i)) {
            best_v = v;
            best_i = col;
          }
        }
      }
      #pragma unroll
      for (int offset = 16; offset > 0; offset >>= 1) {
        const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
        const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
        if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
          best_v = ov;
          best_i = oi;
        }
      }
      if (lane == 0) {
        const int slot = row * num_tiles + bx;
        partial_vals[slot] = best_v;
        partial_idxs[slot] = best_i;
      }
    }
  }
}

template <int THREADS, int PAIR_WIDTH>
__device__ __forceinline__ void vllm_vocab_finish_argmax(
    const float* __restrict__ partial_vals,
    const int* __restrict__ partial_idxs,
    float* __restrict__ pairs,
    int row, int num_tiles, int vocab_start, int tx,
    float* __restrict__ smem_v, int* __restrict__ smem_i) {
  float best_v = -CUDART_INF_F;
  int best_i = 2147483647;
  const int base = row * num_tiles;
  for (int t = tx; t < num_tiles; t += THREADS) {
    const float v = partial_vals[base + t];
    const int idx = partial_idxs[base + t];
    if (vllm_vocab_first_argmax_keep(v, idx, best_v, best_i)) {
      best_v = v;
      best_i = idx;
    }
  }
  const int lane = tx & 31;
  const int warp_id = tx >> 5;
  constexpr int WARPS = THREADS >> 5;
  #pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1) {
    const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
    const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
    if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
      best_v = ov;
      best_i = oi;
    }
  }
  if (lane == 0) {
    smem_v[warp_id] = best_v;
    smem_i[warp_id] = best_i;
  }
  __syncthreads();
  if (warp_id == 0) {
    best_v = (lane < WARPS) ? smem_v[lane] : -CUDART_INF_F;
    best_i = (lane < WARPS) ? smem_i[lane] : 2147483647;
    #pragma unroll
    for (int offset = (WARPS >> 1); offset > 0; offset >>= 1) {
      const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
      const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
      if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
        best_v = ov;
        best_i = oi;
      }
    }
    if (lane == 0) {
      pairs[row * PAIR_WIDTH + 0] = best_v;
      pairs[row * PAIR_WIDTH + 1] = (float)(best_i + vocab_start);
    }
  }
}

// The block's first maximum of ``count`` (value, shard index) partials outside
// the PART-column part ``skip_part`` (-1: none), in every thread.
template <int THREADS, int PART>
__device__ __forceinline__ void vllm_vocab_block_first_argmax(
    const float* __restrict__ vals,
    const int* __restrict__ idxs,
    int count, int skip_part, int tx,
    float* __restrict__ smem_v, int* __restrict__ smem_i,
    float& out_v, int& out_i) {
  float best_v = -CUDART_INF_F;
  int best_i = 2147483647;
  for (int t = tx; t < count; t += THREADS) {
    const float v = vals[t];
    const int idx = idxs[t];
    if (idx / PART != skip_part &&
        vllm_vocab_first_argmax_keep(v, idx, best_v, best_i)) {
      best_v = v;
      best_i = idx;
    }
  }
  const int lane = tx & 31;
  const int warp_id = tx >> 5;
  constexpr int WARPS = THREADS >> 5;
  #pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1) {
    const float ov = __shfl_xor_sync(0xffffffffu, best_v, offset);
    const int oi = __shfl_xor_sync(0xffffffffu, best_i, offset);
    if (vllm_vocab_first_argmax_keep(ov, oi, best_v, best_i)) {
      best_v = ov;
      best_i = oi;
    }
  }
  if (lane == 0) {
    smem_v[warp_id] = best_v;
    smem_i[warp_id] = best_i;
  }
  __syncthreads();
  best_v = smem_v[0];
  best_i = smem_i[0];
  #pragma unroll
  for (int w = 1; w < WARPS; ++w) {
    if (vllm_vocab_first_argmax_keep(smem_v[w], smem_i[w], best_v, best_i)) {
      best_v = smem_v[w];
      best_i = smem_i[w];
    }
  }
  __syncthreads();
  out_v = best_v;
  out_i = best_i;
}

// vllm_vocab_finish_argmax and the row's runner-up as
// dspark.greedy.greedy_markov_shard_pair(top2=True) reports it: the first
// maximum of the tiles outside the pair's PART-column part, into columns 2 and
// 3 (index 2**30 when the shard has no other part).
template <int THREADS, int PAIR_WIDTH, int PART>
__device__ __forceinline__ void vllm_vocab_finish_argmax_top2(
    const float* __restrict__ partial_vals,
    const int* __restrict__ partial_idxs,
    float* __restrict__ pairs,
    int row, int num_tiles, int vocab_start, int tx,
    float* __restrict__ smem_v, int* __restrict__ smem_i) {
  const int base = row * num_tiles;
  float best_v, second_v;
  int best_i, second_i;
  vllm_vocab_block_first_argmax<THREADS, PART>(
      partial_vals + base, partial_idxs + base, num_tiles, -1, tx, smem_v, smem_i,
      best_v, best_i);
  vllm_vocab_block_first_argmax<THREADS, PART>(
      partial_vals + base, partial_idxs + base, num_tiles, best_i / PART, tx,
      smem_v, smem_i, second_v, second_i);
  if (tx == 0) {
    pairs[row * PAIR_WIDTH + 0] = best_v;
    pairs[row * PAIR_WIDTH + 1] = (float)(best_i + vocab_start);
    pairs[row * PAIR_WIDTH + 2] = second_v;
    pairs[row * PAIR_WIDTH + 3] = second_i < 2147483647
                                      ? (float)(second_i + vocab_start)
                                      : (float)(1 << 30);
  }
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vocab_greedy_finish_kernel(float* pairs, int* partial_idxs, float* partial_vals, int M, int vocab_start);
extern "C" __global__ void __launch_bounds__(256, 1) vocab_greedy_finish_kernel(float* pairs, int* partial_idxs, float* partial_vals, int M, int vocab_start) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* smem_i = ((void*)((char*)buf_dyn_shmem + 0));
  void* smem_v = ((void*)((char*)buf_dyn_shmem + 32));
  cudaGridDependencySynchronize();
  cudaTriggerProgrammaticLaunchCompletion();
  vllm_vocab_finish_argmax<256, 4>((&(partial_vals[0])), (&(partial_idxs[0])), (&(pairs[0])), ((int)blockIdx.x), 1010, vocab_start, ((int)threadIdx.x), (&(((float*)smem_v)[0])), (&(((int*)smem_i)[0])));
}

