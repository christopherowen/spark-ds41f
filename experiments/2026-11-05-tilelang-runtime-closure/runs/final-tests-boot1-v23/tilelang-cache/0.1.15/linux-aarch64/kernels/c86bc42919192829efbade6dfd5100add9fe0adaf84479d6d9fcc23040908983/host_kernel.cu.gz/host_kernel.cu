// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* select_first_argmax_top2_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_select_first_argmax_top2(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_select_first_argmax_top2(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[14];
  void* stack_ffi_any = stack;
  if (!((num_args == 7))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "select_first_argmax_top2: num_args should be 7", (long long)(num_args), (long long)(7));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_top2: args pointer is NULL");
    return -1;
  }
  int32_t pairs_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((pairs_handle_type_index == 0) || (pairs_handle_type_index == 4)) || (pairs_handle_type_index == 7)) || (64 <= pairs_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input pairs expected pointer or tensor handle");
    return -1;
  }
  int32_t out_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((out_handle_type_index == 0) || (out_handle_type_index == 4)) || (out_handle_type_index == 7)) || (64 <= out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input out expected pointer or tensor handle");
    return -1;
  }
  int32_t out_stride_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((out_stride_type_index == 1) || (out_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 scalar out_stride expected integer");
    return -1;
  }
  int32_t runner_up_out_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((runner_up_out_handle_type_index == 0) || (runner_up_out_handle_type_index == 4)) || (runner_up_out_handle_type_index == 7)) || (64 <= runner_up_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input runner_up_out expected pointer or tensor handle");
    return -1;
  }
  int32_t runner_up_stride_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((runner_up_stride_type_index == 1) || (runner_up_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 scalar runner_up_stride expected integer");
    return -1;
  }
  int32_t margin_out_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((margin_out_handle_type_index == 0) || (margin_out_handle_type_index == 4)) || (margin_out_handle_type_index == 7)) || (64 <= margin_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input margin_out expected pointer or tensor handle");
    return -1;
  }
  int32_t margin_stride_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((margin_stride_type_index == 1) || (margin_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 scalar margin_stride expected integer");
    return -1;
  }
  void* pairs_handle = ((pairs_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* out_handle = ((out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  int64_t out_stride = (((TVMFFIAny*)args)[2].v_int64);
  void* runner_up_out_handle = ((runner_up_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  int64_t runner_up_stride = (((TVMFFIAny*)args)[4].v_int64);
  void* margin_out_handle = ((margin_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  int64_t margin_stride = (((TVMFFIAny*)args)[6].v_int64);
  bool select_first_argmax_top2_pairs_is_null = (pairs_handle == NULL);
  if (!(!select_first_argmax_top2_pairs_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_top2.pairs is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_top2_out_is_null = (out_handle == NULL);
  if (!(!select_first_argmax_top2_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_top2.out is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_top2_runner_up_out_is_null = (runner_up_out_handle == NULL);
  if (!(!select_first_argmax_top2_runner_up_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_top2.runner_up_out is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_top2_margin_out_is_null = (margin_out_handle == NULL);
  if (!(!select_first_argmax_top2_margin_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_top2.margin_out is expected to have non-NULL pointer");
    return -1;
  }
  void* select_first_argmax_top2_pairs_shape = (((DLTensor*)pairs_handle)[0].shape);
  void* select_first_argmax_top2_out_shape = (((DLTensor*)out_handle)[0].shape);
  void* select_first_argmax_top2_runner_up_out_shape = (((DLTensor*)runner_up_out_handle)[0].shape);
  void* select_first_argmax_top2_margin_out_shape = (((DLTensor*)margin_out_handle)[0].shape);
  if (!(((((DLTensor*)pairs_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input pairs ndim mismatch, expected 2", (long long)((((DLTensor*)pairs_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)select_first_argmax_top2_pairs_shape)[0]);
  int32_t width = ((int32_t)((int64_t*)select_first_argmax_top2_pairs_shape)[1]);
  void* select_first_argmax_top2_pairs_strides = (((DLTensor*)pairs_handle)[0].strides);
  int64_t condval;
  if ((select_first_argmax_top2_pairs_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)select_first_argmax_top2_pairs_strides)[0];
  }
  int64_t pairs_stride = condval;
  int32_t dev_id = (((DLTensor*)pairs_handle)[0].device.device_id);
  void* pairs = (((DLTensor*)pairs_handle)[0].data);
  if (!(((((DLTensor*)out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input out ndim mismatch, expected 1", (long long)((((DLTensor*)out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t out_len = ((int32_t)((int64_t*)select_first_argmax_top2_out_shape)[0]);
  void* select_first_argmax_top2_out_strides = (((DLTensor*)out_handle)[0].strides);
  void* out = (((DLTensor*)out_handle)[0].data);
  if (!(((((DLTensor*)runner_up_out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input runner_up_out ndim mismatch, expected 1", (long long)((((DLTensor*)runner_up_out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t runner_up_len = ((int32_t)((int64_t*)select_first_argmax_top2_runner_up_out_shape)[0]);
  void* select_first_argmax_top2_runner_up_out_strides = (((DLTensor*)runner_up_out_handle)[0].strides);
  void* runner_up_out = (((DLTensor*)runner_up_out_handle)[0].data);
  if (!(((((DLTensor*)margin_out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input margin_out ndim mismatch, expected 1", (long long)((((DLTensor*)margin_out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t margin_len = ((int32_t)((int64_t*)select_first_argmax_top2_margin_out_shape)[0]);
  void* select_first_argmax_top2_margin_out_strides = (((DLTensor*)margin_out_handle)[0].strides);
  void* margin_out = (((DLTensor*)margin_out_handle)[0].data);
  if (!(((((((DLTensor*)pairs_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)pairs_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)pairs_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input pairs dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_1;
  if ((select_first_argmax_top2_pairs_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)select_first_argmax_top2_pairs_strides)[1]);
  }
  if (!(((condval_1 == 1) || (width == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input pairs strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)pairs_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input pairs byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)pairs_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pairs_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input pairs device_type mismatch, expected cuda", (long long)((((DLTensor*)pairs_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (width == 0)) || !(pairs == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input pairs data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)out_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input out dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_2;
  if ((select_first_argmax_top2_out_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)select_first_argmax_top2_out_strides)[0]);
  }
  if (!(((condval_2 == 1) || (out_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input out device_id violates packed ABI constraint", (long long)((((DLTensor*)out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input out device_type mismatch, expected cuda", (long long)((((DLTensor*)out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((out_len == 0) || !(out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)runner_up_out_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)runner_up_out_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)runner_up_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input runner_up_out dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_3;
  if ((select_first_argmax_top2_runner_up_out_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)select_first_argmax_top2_runner_up_out_strides)[0]);
  }
  if (!(((condval_3 == 1) || (runner_up_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input runner_up_out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)runner_up_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input runner_up_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)runner_up_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)runner_up_out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input runner_up_out device_id violates packed ABI constraint", (long long)((((DLTensor*)runner_up_out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)runner_up_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input runner_up_out device_type mismatch, expected cuda", (long long)((((DLTensor*)runner_up_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((runner_up_len == 0) || !(runner_up_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input runner_up_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)margin_out_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)margin_out_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)margin_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input margin_out dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_4;
  if ((select_first_argmax_top2_margin_out_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)select_first_argmax_top2_margin_out_strides)[0]);
  }
  if (!(((condval_4 == 1) || (margin_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input margin_out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)margin_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input margin_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)margin_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)margin_out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input margin_out device_id violates packed ABI constraint", (long long)((((DLTensor*)margin_out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)margin_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_top2 input margin_out device_type mismatch, expected cuda", (long long)((((DLTensor*)margin_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((margin_len == 0) || !(margin_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_top2 input margin_out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (margin_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = margin_out;
  if (out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = out;
  if (pairs == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = pairs;
  if (runner_up_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = runner_up_out;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = margin_stride;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = out_stride;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = pairs_stride;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = runner_up_stride;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = (int64_t)0;
  if (select_first_argmax_top2_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "select_first_argmax_top2_kernel", &select_first_argmax_top2_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(select_first_argmax_top2_kernel_packed, (TVMFFIAny*) stack_ffi_any, 13, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_select_first_argmax_top2(self, args, num_args, result);
}
