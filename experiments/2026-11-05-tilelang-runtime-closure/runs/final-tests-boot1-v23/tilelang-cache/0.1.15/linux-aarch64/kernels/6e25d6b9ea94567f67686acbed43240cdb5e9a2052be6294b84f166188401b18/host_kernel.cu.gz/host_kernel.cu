// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* gather_columns_into_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gather_columns_into(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gather_columns_into(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[12];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "gather_columns_into: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gather_columns_into: args pointer is NULL");
    return -1;
  }
  int32_t src_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((src_handle_type_index == 0) || (src_handle_type_index == 4)) || (src_handle_type_index == 7)) || (64 <= src_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input src expected pointer or tensor handle");
    return -1;
  }
  int32_t out0_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((out0_handle_type_index == 0) || (out0_handle_type_index == 4)) || (out0_handle_type_index == 7)) || (64 <= out0_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input out0 expected pointer or tensor handle");
    return -1;
  }
  int32_t out1_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((out1_handle_type_index == 0) || (out1_handle_type_index == 4)) || (out1_handle_type_index == 7)) || (64 <= out1_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input out1 expected pointer or tensor handle");
    return -1;
  }
  void* src_handle = ((src_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* out0_handle = ((out0_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* out1_handle = ((out1_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  bool gather_columns_into_src_is_null = (src_handle == NULL);
  if (!(!gather_columns_into_src_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gather_columns_into.src is expected to have non-NULL pointer");
    return -1;
  }
  bool gather_columns_into_out0_is_null = (out0_handle == NULL);
  if (!(!gather_columns_into_out0_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gather_columns_into.out0 is expected to have non-NULL pointer");
    return -1;
  }
  bool gather_columns_into_out1_is_null = (out1_handle == NULL);
  if (!(!gather_columns_into_out1_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gather_columns_into.out1 is expected to have non-NULL pointer");
    return -1;
  }
  void* gather_columns_into_src_shape = (((DLTensor*)src_handle)[0].shape);
  void* gather_columns_into_out0_shape = (((DLTensor*)out0_handle)[0].shape);
  void* gather_columns_into_out1_shape = (((DLTensor*)out1_handle)[0].shape);
  if (!(((((DLTensor*)src_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input src ndim mismatch, expected 2", (long long)((((DLTensor*)src_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t source_rows = ((int32_t)((int64_t*)gather_columns_into_src_shape)[0]);
  void* gather_columns_into_src_strides = (((DLTensor*)src_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)src_handle)[0].device.device_id);
  void* src = (((DLTensor*)src_handle)[0].data);
  if (!(((((DLTensor*)out0_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out0 ndim mismatch, expected 2", (long long)((((DLTensor*)out0_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: gather_columns_into.out0, gather_columns_into.out1");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)gather_columns_into_out0_shape)[0]);
  void* gather_columns_into_out0_strides = (((DLTensor*)out0_handle)[0].strides);
  int32_t condval;
  if ((gather_columns_into_out0_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)gather_columns_into_out0_strides)[0]);
  }
  int32_t stride0 = condval;
  void* out0 = (((DLTensor*)out0_handle)[0].data);
  if (!(((((DLTensor*)out1_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out1 ndim mismatch, expected 2", (long long)((((DLTensor*)out1_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gather_columns_into_out1_strides = (((DLTensor*)out1_handle)[0].strides);
  int32_t condval_1;
  if ((gather_columns_into_out1_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)gather_columns_into_out1_strides)[0]);
  }
  int32_t stride1 = condval_1;
  void* out1 = (((DLTensor*)out1_handle)[0].data);
  if (!(((((((DLTensor*)src_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)src_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)src_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input src dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gather_columns_into_src_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input src shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gather_columns_into_src_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((gather_columns_into_src_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)gather_columns_into_src_strides)[1]);
  }
  if (!((condval_2 == 1))) {
    int32_t condval_3;
    if ((gather_columns_into_src_strides == NULL)) {
      condval_3 = 1;
    } else {
      condval_3 = ((int32_t)((int64_t*)gather_columns_into_src_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input src strides[1] violates packed ABI constraint", (long long)(condval_3), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((gather_columns_into_src_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)gather_columns_into_src_strides)[0]);
  }
  if (!(((condval_4 == 64) || (source_rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)src_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)src_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)src_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input src device_type mismatch, expected cuda", (long long)((((DLTensor*)src_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((source_rows == 0) || !(src == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out0_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)out0_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)out0_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input out0 dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gather_columns_into_out0_shape)[1]) == 512))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out0 shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gather_columns_into_out0_shape)[1])), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((gather_columns_into_out0_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)gather_columns_into_out0_strides)[1]);
  }
  if (!((condval_5 == 1))) {
    int32_t condval_6;
    if ((gather_columns_into_out0_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)gather_columns_into_out0_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out0 strides[1] violates packed ABI constraint", (long long)(condval_6), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out0_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out0 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out0_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out0_handle)[0].device.device_id) == (((DLTensor*)src_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out0 device_id violates packed ABI constraint", (long long)((((DLTensor*)out0_handle)[0].device.device_id)), (long long)((((DLTensor*)src_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out0_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out0 device_type mismatch, expected cuda", (long long)((((DLTensor*)out0_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(out0 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input out0 data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out1_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)out1_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)out1_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input out1 dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gather_columns_into_out0_shape)[0]) == ((int32_t)((int64_t*)gather_columns_into_out1_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out1 shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gather_columns_into_out0_shape)[0])), (long long)(((int32_t)((int64_t*)gather_columns_into_out1_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gather_columns_into_out1_shape)[1]) == 512))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out1 shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gather_columns_into_out1_shape)[1])), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((gather_columns_into_out1_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)gather_columns_into_out1_strides)[1]);
  }
  if (!((condval_7 == 1))) {
    int32_t condval_8;
    if ((gather_columns_into_out1_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)gather_columns_into_out1_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out1 strides[1] violates packed ABI constraint", (long long)(condval_8), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out1_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out1 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out1_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out1_handle)[0].device.device_id) == (((DLTensor*)src_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out1 device_id violates packed ABI constraint", (long long)((((DLTensor*)out1_handle)[0].device.device_id)), (long long)((((DLTensor*)src_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out1_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gather_columns_into input out1 device_type mismatch, expected cuda", (long long)((((DLTensor*)out1_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(out1 == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gather_columns_into input out1 data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (out0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = out0;
  if (out1 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = out1;
  if (src == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = src;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)stride0);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)stride1);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)4);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = (int64_t)0;
  if (gather_columns_into_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "gather_columns_into_kernel", &gather_columns_into_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(gather_columns_into_kernel_packed, (TVMFFIAny*) stack_ffi_any, 11, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_gather_columns_into(self, args, num_args, result);
}
