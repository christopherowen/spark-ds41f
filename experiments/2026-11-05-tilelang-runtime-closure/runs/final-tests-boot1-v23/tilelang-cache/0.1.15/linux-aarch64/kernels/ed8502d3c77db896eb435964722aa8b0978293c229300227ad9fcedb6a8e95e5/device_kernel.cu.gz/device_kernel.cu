
__device__ __forceinline__ void splitk_fence() { __threadfence(); }
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/atomic.h>
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gemm_bf16_splitk_kernel(const bfloat16_t* A, const bfloat16_t* B, bfloat16_t* C0, float* P, int* counters, int M, int tiles);
extern "C" __global__ void __launch_bounds__(256, 1) gemm_bf16_splitk_kernel(const bfloat16_t* A, const bfloat16_t* B, bfloat16_t* C0, float* P, int* counters, int M, int tiles) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* last = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 16384));
  float C_local[8];
  float C_block[8];
  float acc = 0x0p+0f/*0.000000e+00*/;
  cudaGridDependencySynchronize();
  cudaTriggerProgrammaticLaunchCompletion();
  #pragma unroll
  for (int i = 0; i < 2; ++i) {
    float broadcast_var = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_local + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 2; ++i_1) {
    tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[(((((i_1 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A[(((((((int64_t)((int)blockIdx.z)) * (int64_t)327680) + (((int64_t)i_1) * (int64_t)163840)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8))])), (((((((int)blockIdx.z) * 64) + (i_1 * 32)) + (((int)threadIdx.x) >> 3)) < M) && ((((((int)blockIdx.z) * 64) + (i_1 * 32)) + (((int)threadIdx.x) >> 3)) < M)));
  }
  tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[(((((((int)threadIdx.x) >> 3) * 64) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B[((((((int)blockIdx.x) * 163840) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8))])));
  tl::cp_async_commit();
  #pragma unroll
  for (int i_2 = 0; i_2 < 2; ++i_2) {
    tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[((((((i_2 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(A[((((((((int64_t)((int)blockIdx.z)) * (int64_t)327680) + (((int64_t)i_2) * (int64_t)163840)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)64)])), (((((((int)blockIdx.z) * 64) + (i_2 * 32)) + (((int)threadIdx.x) >> 3)) < M) && ((((((int)blockIdx.z) * 64) + (i_2 * 32)) + (((int)threadIdx.x) >> 3)) < M)));
  }
  tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[((((((((int)threadIdx.x) >> 3) * 64) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 2048)])), (&(B[(((((((int)blockIdx.x) * 163840) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8)) + 64)])));
  tl::cp_async_commit();
  for (int kb = 0; kb < 14; ++kb) {
    #pragma unroll
    for (int i_3 = 0; i_3 < 2; ++i_3) {
      float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(C_block + (i_3 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    }
    tl::cp_async_wait<1>();
    __syncthreads();
    {
      bfloat16_t A_local[16];
      bfloat16_t B_local[4];
      for (int ki = 0; ki < 4; ++ki) {
        #pragma unroll
        for (int i_4 = 0; i_4 < 2; ++i_4) {
          tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((kb & 1) * 4096) + (((((int)threadIdx.x) & 63) >> 5) * 2048)) + (i_4 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_4 * 8)])));
        }
        tl::ptx_ldmatrix_x2((&(((bfloat16_t*)B_shared)[(((((((kb & 1) * 2048) + ((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 31) >> 4)) & 3) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[0])));
        for (int i_5 = 0; i_5 < 2; ++i_5) {
          tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (i_5 * 4)), reinterpret_cast<const unsigned*>(A_local + (i_5 * 8)), reinterpret_cast<const unsigned*>(B_local + 0));
        }
      }
    }
    __syncthreads();
    #pragma unroll
    for (int i_6 = 0; i_6 < 2; ++i_6) {
      tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[(((((((kb & 1) * 4096) + (i_6 * 2048)) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A[(((((((((int64_t)((int)blockIdx.z)) * (int64_t)327680) + (((int64_t)i_6) * (int64_t)163840)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + (((int64_t)kb) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)128)])), (((((((int)blockIdx.z) * 64) + (i_6 * 32)) + (((int)threadIdx.x) >> 3)) < M) && ((((((int)blockIdx.z) * 64) + (i_6 * 32)) + (((int)threadIdx.x) >> 3)) < M)));
    }
    tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[((((((kb & 1) * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B[((((((((int)blockIdx.x) * 163840) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + (kb * 64)) + ((((int)threadIdx.x) & 7) * 8)) + 128)])));
    tl::cp_async_commit();
    #pragma unroll
    for (int i_7 = 0; i_7 < 2; ++i_7) {
      float4 __1;
        float4 v_ = *(float4*)(C_local + (i_7 * 4));
        float4 v__1 = *(float4*)(C_block + (i_7 * 4));
        *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
        *(float2*)(&(__1.z)) = tl::add2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
      *(float4*)(C_local + (i_7 * 4)) = __1;
    }
  }
  #pragma unroll
  for (int i_8 = 0; i_8 < 2; ++i_8) {
    float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_block + (i_8 * 4)) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
  }
  tl::cp_async_wait<1>();
  __syncthreads();
  {
    bfloat16_t A_local_1[16];
    bfloat16_t B_local_1[4];
    for (int ki_1 = 0; ki_1 < 4; ++ki_1) {
      #pragma unroll
      for (int i_9 = 0; i_9 < 2; ++i_9) {
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((((int)threadIdx.x) & 63) >> 5) * 2048) + (i_9 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local_1[(i_9 * 8)])));
      }
      tl::ptx_ldmatrix_x2((&(((bfloat16_t*)B_shared)[((((((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 31) >> 4)) & 3) * 512) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_1[0])));
      for (int i_10 = 0; i_10 < 2; ++i_10) {
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (i_10 * 4)), reinterpret_cast<const unsigned*>(A_local_1 + (i_10 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + 0));
      }
    }
  }
  #pragma unroll
  for (int i_11 = 0; i_11 < 2; ++i_11) {
    float4 __2;
      float4 v__2 = *(float4*)(C_local + (i_11 * 4));
      float4 v__3 = *(float4*)(C_block + (i_11 * 4));
      *(float2*)(&(__2.x)) = tl::add2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
      *(float2*)(&(__2.z)) = tl::add2(*(float2*)(&(v__2.z)), *(float2*)(&(v__3.z)));
    *(float4*)(C_local + (i_11 * 4)) = __2;
  }
  #pragma unroll
  for (int i_12 = 0; i_12 < 2; ++i_12) {
    float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_block + (i_12 * 4)) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
  }
  tl::cp_async_wait<0>();
  __syncthreads();
  {
    bfloat16_t A_local_2[16];
    bfloat16_t B_local_2[4];
    for (int ki_2 = 0; ki_2 < 4; ++ki_2) {
      #pragma unroll
      for (int i_13 = 0; i_13 < 2; ++i_13) {
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[(((((((((((int)threadIdx.x) & 63) >> 5) * 2048) + (i_13 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_2 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(A_local_2[(i_13 * 8)])));
      }
      tl::ptx_ldmatrix_x2((&(((bfloat16_t*)B_shared)[(((((((((((int)threadIdx.x) >> 6) + ((((int)threadIdx.x) & 31) >> 4)) & 3) * 512) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_2 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 2048)])), (&(B_local_2[0])));
      for (int i_14 = 0; i_14 < 2; ++i_14) {
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (i_14 * 4)), reinterpret_cast<const unsigned*>(A_local_2 + (i_14 * 8)), reinterpret_cast<const unsigned*>(B_local_2 + 0));
      }
    }
  }
  #pragma unroll
  for (int i_15 = 0; i_15 < 2; ++i_15) {
    float4 __3;
      float4 v__4 = *(float4*)(C_local + (i_15 * 4));
      float4 v__5 = *(float4*)(C_block + (i_15 * 4));
      *(float2*)(&(__3.x)) = tl::add2(*(float2*)(&(v__4.x)), *(float2*)(&(v__5.x)));
      *(float2*)(&(__3.z)) = tl::add2(*(float2*)(&(v__4.z)), *(float2*)(&(v__5.z)));
    *(float4*)(C_local + (i_15 * 4)) = __3;
  }
  #pragma unroll
  for (int i_16 = 0; i_16 < 4; ++i_16) {
    if (((((((int)blockIdx.z) * 64) + (((((int)threadIdx.x) & 63) >> 5) * 32)) + (i_16 * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M) {
      *(float2*)(P + ((((((((((int64_t)((int)blockIdx.z)) * (int64_t)8192) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)4096)) + (((int64_t)i_16) * (int64_t)1024)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)128)) + ((((int64_t)((int)blockIdx.y)) * ((int64_t)M)) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2))) = *(float2*)(C_local + (i_16 * 2));
    }
  }
  splitk_fence();
  __syncthreads();
  if (((int)threadIdx.x) == 0) {
    int condval;
    if ((((((int)blockIdx.z) * 4) + ((int)blockIdx.x)) < tiles)) {
      condval = AtomicAddRet((&(counters[((((int64_t)((int)blockIdx.z)) * (int64_t)4) + ((int64_t)((int)blockIdx.x)))])), 1, 4);
    } else {
      condval = 0;
    }
    int arrived = condval;
    int condval_1;
    if ((arrived == 4)) {
      condval_1 = 1;
    } else {
      condval_1 = 0;
    }
    ((int*)last)[0] = condval_1;
  }
  __syncthreads();
  if (((int*)last)[0] == 1) {
    splitk_fence();
  }
  if (((int*)last)[0] == 1) {
    #pragma unroll
    for (int i_17 = 0; i_17 < 8; ++i_17) {
      if ((((((int)blockIdx.z) * 64) + (i_17 * 8)) + (((int)threadIdx.x) >> 5)) < M) {
        acc = P[(((((((int64_t)((int)blockIdx.z)) * (int64_t)8192) + (((int64_t)i_17) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + (((int64_t)((int)threadIdx.x)) & (int64_t)31))];
        for (int t = 1; t < 5; ++t) {
          acc = (acc + P[((((((((int64_t)((int)blockIdx.z)) * (int64_t)8192) + (((int64_t)i_17) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)128)) + ((((int64_t)t) * ((int64_t)M)) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + (((int64_t)((int)threadIdx.x)) & (int64_t)31))]);
        }
        C0[(((((((int64_t)((int)blockIdx.z)) * (int64_t)8192) + (((int64_t)i_17) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + (((int64_t)((int)threadIdx.x)) & (int64_t)31))] = ((bfloat16_t)acc);
      }
    }
  }
  if (((int*)last)[0] == 1) {
    if (((int)threadIdx.x) == 0) {
      if (((((int)blockIdx.z) * 4) + ((int)blockIdx.x)) < tiles) {
        counters[((((int64_t)((int)blockIdx.z)) * (int64_t)4) + ((int64_t)((int)blockIdx.x)))] = 0;
      }
    }
  }
}

