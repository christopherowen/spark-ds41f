// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* token_ranks_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_token_ranks(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_token_ranks(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[11];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "token_ranks: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "token_ranks: args pointer is NULL");
    return -1;
  }
  int32_t logits_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((logits_handle_type_index == 0) || (logits_handle_type_index == 4)) || (logits_handle_type_index == 7)) || (64 <= logits_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input logits expected pointer or tensor handle");
    return -1;
  }
  int32_t token_ids_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((token_ids_handle_type_index == 0) || (token_ids_handle_type_index == 4)) || (token_ids_handle_type_index == 7)) || (64 <= token_ids_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input token_ids expected pointer or tensor handle");
    return -1;
  }
  int32_t output_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((output_handle_type_index == 0) || (output_handle_type_index == 4)) || (output_handle_type_index == 7)) || (64 <= output_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input output expected pointer or tensor handle");
    return -1;
  }
  void* logits_handle = ((logits_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* token_ids_handle = ((token_ids_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* output_handle = ((output_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  bool token_ranks_logits_is_null = (logits_handle == NULL);
  if (!(!token_ranks_logits_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "token_ranks.logits is expected to have non-NULL pointer");
    return -1;
  }
  bool token_ranks_token_ids_is_null = (token_ids_handle == NULL);
  if (!(!token_ranks_token_ids_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "token_ranks.token_ids is expected to have non-NULL pointer");
    return -1;
  }
  bool token_ranks_output_is_null = (output_handle == NULL);
  if (!(!token_ranks_output_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "token_ranks.output is expected to have non-NULL pointer");
    return -1;
  }
  void* token_ranks_logits_shape = (((DLTensor*)logits_handle)[0].shape);
  void* token_ranks_token_ids_shape = (((DLTensor*)token_ids_handle)[0].shape);
  void* token_ranks_output_shape = (((DLTensor*)output_handle)[0].shape);
  if (!(((((DLTensor*)logits_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input logits ndim mismatch, expected 2", (long long)((((DLTensor*)logits_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: token_ranks.logits, token_ranks.token_ids, token_ranks.output");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)token_ranks_logits_shape)[0]);
  void* token_ranks_logits_strides = (((DLTensor*)logits_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)logits_handle)[0].device.device_id);
  void* logits = (((DLTensor*)logits_handle)[0].data);
  if (!(((((DLTensor*)token_ids_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input token_ids ndim mismatch, expected 1", (long long)((((DLTensor*)token_ids_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* token_ranks_token_ids_strides = (((DLTensor*)token_ids_handle)[0].strides);
  int64_t condval;
  if ((token_ranks_token_ids_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)token_ranks_token_ids_strides)[0];
  }
  int64_t id_stride = condval;
  void* token_ids = (((DLTensor*)token_ids_handle)[0].data);
  if (!(((((DLTensor*)output_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input output ndim mismatch, expected 1", (long long)((((DLTensor*)output_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* token_ranks_output_strides = (((DLTensor*)output_handle)[0].strides);
  void* output = (((DLTensor*)output_handle)[0].data);
  if (!(((((((DLTensor*)logits_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)logits_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)logits_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input logits dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)token_ranks_logits_shape)[1]) == 257))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input logits shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)token_ranks_logits_shape)[1])), (long long)(257));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_1;
  if ((token_ranks_logits_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)token_ranks_logits_strides)[1]);
  }
  if (!((condval_1 == 1))) {
    int32_t condval_2;
    if ((token_ranks_logits_strides == NULL)) {
      condval_2 = 1;
    } else {
      condval_2 = ((int32_t)((int64_t*)token_ranks_logits_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input logits strides[1] violates packed ABI constraint", (long long)(condval_2), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((token_ranks_logits_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)token_ranks_logits_strides)[0]);
  }
  if (!(((condval_3 == 257) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input logits strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)logits_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input logits byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)logits_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input logits device_type mismatch, expected cuda", (long long)((((DLTensor*)logits_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(logits == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input logits data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)token_ids_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)token_ids_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)token_ids_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input token_ids dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)token_ranks_logits_shape)[0]) == ((int32_t)((int64_t*)token_ranks_token_ids_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input token_ids shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)token_ranks_logits_shape)[0])), (long long)(((int32_t)((int64_t*)token_ranks_token_ids_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)token_ids_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input token_ids byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)token_ids_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)token_ids_handle)[0].device.device_id) == (((DLTensor*)logits_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input token_ids device_id violates packed ABI constraint", (long long)((((DLTensor*)token_ids_handle)[0].device.device_id)), (long long)((((DLTensor*)logits_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)token_ids_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input token_ids device_type mismatch, expected cuda", (long long)((((DLTensor*)token_ids_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(token_ids == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input token_ids data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)output_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)output_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)output_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input output dtype mismatch, expected int64");
    return -1;
  }
  if (!((((int32_t)((int64_t*)token_ranks_logits_shape)[0]) == ((int32_t)((int64_t*)token_ranks_output_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input output shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)token_ranks_logits_shape)[0])), (long long)(((int32_t)((int64_t*)token_ranks_output_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((token_ranks_output_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)token_ranks_output_strides)[0]);
  }
  if (!(((condval_4 == 1) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input output strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)output_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input output byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)output_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_id) == (((DLTensor*)logits_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input output device_id violates packed ABI constraint", (long long)((((DLTensor*)output_handle)[0].device.device_id)), (long long)((((DLTensor*)logits_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel token_ranks input output device_type mismatch, expected cuda", (long long)((((DLTensor*)output_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(output == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel token_ranks input output data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (logits == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = logits;
  if (output == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = output;
  if (token_ids == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = token_ids;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = id_stride;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1024);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = (int64_t)0;
  if (token_ranks_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "token_ranks_kernel", &token_ranks_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(token_ranks_kernel_packed, (TVMFFIAny*) stack_ffi_any, 10, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_token_ranks(self, args, num_args, result);
}
