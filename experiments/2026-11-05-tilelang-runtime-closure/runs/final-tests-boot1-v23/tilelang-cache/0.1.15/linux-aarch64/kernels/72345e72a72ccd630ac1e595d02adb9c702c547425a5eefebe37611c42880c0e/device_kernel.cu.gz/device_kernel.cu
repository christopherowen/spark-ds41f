#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gather_rows_kernel(const int64_t* __restrict__ idx_mapping, float* __restrict__ out, const float* __restrict__ state, int num_reqs, int state_rows, int state_stride, int width);
extern "C" __global__ void __launch_bounds__(128, 1) gather_rows_kernel(const int64_t* __restrict__ idx_mapping, float* __restrict__ out, const float* __restrict__ state, int num_reqs, int state_rows, int state_stride, int width) {
  int64_t index = (int64_t)0;
  int64_t rmod = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)width));
  int64_t rdiv = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) / ((int64_t)width));
  int64_t rmod_1 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)width));
  int64_t rdiv_1 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) / ((int64_t)width));
  index = idx_mapping[min((((((int64_t)0 <= ((int64_t)width)) && ((int64_t)0 <= rmod_1)) || ((((int64_t)width) < (int64_t)0) && (rmod_1 <= (int64_t)0))) ? rdiv_1 : (rdiv_1 - (int64_t)1)), (((int64_t)num_reqs) - (int64_t)1))];
  if (((((int)blockIdx.x) * 128) + ((int)threadIdx.x)) < (num_reqs * width)) {
    int64_t condval;
    if ((index < (int64_t)0)) {
      condval = (index + ((int64_t)state_rows));
    } else {
      condval = index;
    }
    int rmod_2 = (((((int)blockIdx.x) * 128) + ((int)threadIdx.x)) % width);
    int64_t condval_1;
    if ((index < (int64_t)0)) {
      condval_1 = (index + ((int64_t)state_rows));
    } else {
      condval_1 = index;
    }
    int rmod_3 = (((((int)blockIdx.x) * 128) + ((int)threadIdx.x)) % width);
    int64_t rmod_4 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)width));
    int64_t rdiv_2 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) / ((int64_t)width));
    int64_t rmod_5 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)width));
    int64_t rmod_6 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)width));
    int64_t rdiv_3 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) / ((int64_t)width));
    int64_t rmod_7 = (((((int64_t)((int)blockIdx.x)) * (int64_t)128) + ((int64_t)((int)threadIdx.x))) % ((int64_t)width));
    out[((min((((((int64_t)0 <= ((int64_t)width)) && ((int64_t)0 <= rmod_6)) || ((((int64_t)width) < (int64_t)0) && (rmod_6 <= (int64_t)0))) ? rdiv_3 : (rdiv_3 - (int64_t)1)), (((int64_t)num_reqs) - (int64_t)1)) * ((int64_t)width)) + (((((int64_t)0 <= ((int64_t)width)) && ((int64_t)0 <= rmod_7)) || ((((int64_t)width) < (int64_t)0) && (rmod_7 <= (int64_t)0))) ? rmod_7 : (rmod_7 + ((int64_t)width))))] = state[((condval_1 * ((int64_t)state_stride)) + ((int64_t)((((0 <= width) && (0 <= rmod_3)) || ((width < 0) && (rmod_3 <= 0))) ? rmod_3 : (rmod_3 + width))))];
  }
}

