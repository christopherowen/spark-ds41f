#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void token_ranks_scores_kernel(const int64_t* __restrict__ ids, const half_t* __restrict__ logits, int64_t* __restrict__ output, float* __restrict__ scores, const int64_t* __restrict__ token_ids, int columns, int64_t id_col, int64_t id_row, int64_t id_stride, int rows);
extern "C" __global__ void __launch_bounds__(512, 1) token_ranks_scores_kernel(const int64_t* __restrict__ ids, const half_t* __restrict__ logits, int64_t* __restrict__ output, float* __restrict__ scores, const int64_t* __restrict__ token_ids, int columns, int64_t id_col, int64_t id_row, int64_t id_stride, int rows) {
  float selected[1];
  int counts[16];
  int total[1];
  extern __shared__ __align__(1024) int workspace[];
  half_t condval;
  if ((((int64_t)0 <= token_ids[(((int64_t)((int)blockIdx.x)) * id_stride)]) && (token_ids[(((int64_t)((int)blockIdx.x)) * id_stride)] < (int64_t)257))) {
    condval = logits[((((int64_t)((int)blockIdx.x)) * (int64_t)257) + token_ids[(((int64_t)((int)blockIdx.x)) * id_stride)])];
  } else {
    condval = half_t(0x0p+0f/*0.000000e+00*/);
  }
  selected[0] = ((float)condval);
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    int broadcast_var = 0;
    *(int4*)(counts + (i * 4)) = make_int4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 16; ++i_1) {
    float condval_1;
    if ((((i_1 * 512) + ((int)threadIdx.x)) < 257)) {
      condval_1 = ((float)logits[(((((int64_t)i_1) * (int64_t)512) + (((int64_t)((int)blockIdx.x)) * (int64_t)257)) + ((int64_t)((int)threadIdx.x)))]);
    } else {
      condval_1 = -CUDART_INF_F;
    }
    float value = condval_1;
    counts[i_1] = (counts[i_1] + ((int)((((i_1 * 512) + ((int)threadIdx.x)) < 257) & (selected[0] <= value))));
  }
  total[0] = 0;
  #pragma unroll
  for (int rv = 0; rv < 16; ++rv) {
    total[0] = (total[0] + counts[rv]);
  }
  total[0] = tl::AllReduce<tl::SumOp, 512, 1, 0, tl::NamedBarrier<512>>::run(total[0], (&(workspace[0])));
  output[((int64_t)((int)blockIdx.x))] = ((int64_t)total[0]);
  for (int group = 0; group < ((columns + 511) >> 9); ++group) {
    if (((group * 512) + ((int)threadIdx.x)) < columns) {
      half_t condval_2;
      if ((((int64_t)0 <= ids[((((int64_t)((int)blockIdx.x)) * id_row) + (((((int64_t)group) * (int64_t)512) + ((int64_t)((int)threadIdx.x))) * id_col))]) && (ids[((((int64_t)((int)blockIdx.x)) * id_row) + (((((int64_t)group) * (int64_t)512) + ((int64_t)((int)threadIdx.x))) * id_col))] < (int64_t)257))) {
        condval_2 = logits[((((int64_t)((int)blockIdx.x)) * (int64_t)257) + ids[((((int64_t)((int)blockIdx.x)) * id_row) + (((((int64_t)group) * (int64_t)512) + ((int64_t)((int)threadIdx.x))) * id_col))])];
      } else {
        condval_2 = half_t(0x0p+0f/*0.000000e+00*/);
      }
      scores[(((((int64_t)group) * (int64_t)512) + (((int64_t)((int)blockIdx.x)) * ((int64_t)columns))) + ((int64_t)((int)threadIdx.x)))] = ((float)condval_2);
    }
  }
}

