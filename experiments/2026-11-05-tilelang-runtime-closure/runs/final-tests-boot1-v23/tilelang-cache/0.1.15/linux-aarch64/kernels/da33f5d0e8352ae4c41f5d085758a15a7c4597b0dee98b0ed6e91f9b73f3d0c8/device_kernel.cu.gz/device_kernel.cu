
// Triton 3.5 philox_impl (triton/language/random.py) on 32-bit words, ten
// rounds; the first word.
__device__ __forceinline__ unsigned int vllm_philox(unsigned int c0, unsigned int c1,
                                                   unsigned int c2, unsigned int c3,
                                                   unsigned int k0, unsigned int k1) {
#pragma unroll
  for (int round = 0; round < 10; ++round) {
    const unsigned int a = c0;
    const unsigned int b = c2;
    c0 = __umulhi(0xCD9E8D57u, b) ^ c1 ^ k0;
    c2 = __umulhi(0xD2511F53u, a) ^ c3 ^ k1;
    c1 = 0xCD9E8D57u * b;
    c3 = 0xD2511F53u * a;
    k0 += 0x9E3779B9u;
    k1 += 0xBB67AE85u;
  }
  return c0;
}

// tl.randint(seed, offset) for an int64 seed and an int64 offset: the offset's
// low word, then its arithmetic high word.
__device__ __forceinline__ unsigned int vllm_randint64(long long seed,
                                                      long long offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox((unsigned int)offset, (unsigned int)(offset >> 32), 0u, 0u,
                     (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for an int64 seed and an int32 offset: Triton gives a
// 32-bit offset no high word.
__device__ __forceinline__ unsigned int vllm_randint64_offset32(long long seed,
                                                               unsigned int offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox(offset, 0u, 0u, 0u, (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for a uint32 seed (tl.randint's own result, widened
// with zeros) and an int32 offset (no high word).
__device__ __forceinline__ unsigned int vllm_randint32(unsigned int seed, int offset) {
  return vllm_philox((unsigned int)offset, 0u, 0u, 0u, seed, 0u);
}

// gumbel.py's FP32 noise of one Philox word, as Triton 3.5 compiles
// tl_rand32(includes_zero=False) and -tl.log(-tldevice.log1p(-u)) for sm_121a:
// uint_to_uniform_float, the clamp to _TL_RAND_MIN (0f2FFFFFFF), then libdevice's
// __nv_log1pf of 0 - u and __nv_logf of 0 - that, negated.
__device__ __forceinline__ float vllm_gumbel_noise(unsigned int word) {
  float noise;
  asm("{\n"
      ".reg .pred fin, inside, zero, tiny;\n"
      ".reg .b32 x, s, u, v, t, e, m, k, a, r, f, p, q, l, w, y, z, o;\n"
      // uint_to_uniform_float: where(x < 0, -x - 1, x) * 4.6566127342e-10
      "shr.s32 s, %1, 31;\n"
      "xor.b32 x, s, %1;\n"
      "cvt.rn.f32.s32 u, x;\n"
      "mul.rn.f32 u, u, 0f2FFFFFFF;\n"
      "max.f32 u, u, 0f2FFFFFFF;\n"
      // __nv_log1pf(v), v = 0 - u
      "sub.rn.f32 v, 0f00000000, u;\n"
      "add.rz.ftz.f32 t, v, 0f3F800000;\n"
      "add.s32 e, t, -1061158912;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, v, e;\n"
      "sub.s32 k, 1082130432, e;\n"
      "fma.rn.ftz.f32 a, 0f3E800000, k, 0fBF800000;\n"
      "add.rn.f32 r, a, m;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "mul.rn.f32 f, f, 0f34000000;\n"
      "fma.rn.ftz.f32 p, 0fBD39BF78, r, 0f3DD80012;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE0778E0;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E146475;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2A68DD;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CAF9E;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE800042;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAAE6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not a finite non-negative v: inside [-1, -0] keep, else fma(v, inf, inf);
      // then a zero v gives -0.
      "setp.lt.u32 fin, v, 2139095040;\n"
      "setp.lt.s32 inside, v, -1082130431;\n"
      "fma.rn.ftz.f32 w, v, 0f7F800000, 0f7F800000;\n"
      "selp.f32 w, l, w, inside;\n"
      "setp.eq.f32 zero, v, 0f00000000;\n"
      "selp.f32 w, 0f80000000, w, zero;\n"
      "selp.f32 l, l, w, fin;\n"
      // __nv_logf(y), y = 0 - log1p(v): subnormal y scaled by 2^23
      "sub.rn.f32 y, 0f00000000, l;\n"
      "setp.lt.f32 tiny, y, 0f00800000;\n"
      "mul.rn.f32 z, y, 0f4B000000;\n"
      "selp.f32 z, z, y, tiny;\n"
      "selp.f32 o, 0fC1B80000, 0f00000000, tiny;\n"
      "add.s32 e, z, -1059760811;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, z, e;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "fma.rn.ftz.f32 f, f, 0f34000000, o;\n"
      "add.rn.f32 r, m, 0fBF800000;\n"
      "fma.rn.ftz.f32 p, 0fBE055027, r, 0f3E1039F6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBDF8CDCC;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E0F2955;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2AD8B9;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CED0B;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE7FFF22;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAA78;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not finite non-negative: fma(z, inf, inf). The noise is 0 - logf(y), or
      // +inf where z is zero.
      "setp.lt.u32 fin, z, 2139095040;\n"
      "fma.rn.ftz.f32 w, z, 0f7F800000, 0f7F800000;\n"
      "selp.f32 l, l, w, fin;\n"
      "sub.rn.f32 l, 0f00000000, l;\n"
      "setp.eq.f32 zero, z, 0f00000000;\n"
      "selp.f32 %0, 0f7F800000, l, zero;\n"
      "}"
      : "=f"(noise)
      : "r"(word));
  return noise;
}

// A logit plus the noise of its word: Triton's FP32 add.
__device__ __forceinline__ float vllm_gumbel_score(float logit, unsigned int word) {
  const float noise = vllm_gumbel_noise(word);
  float score;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(score) : "f"(logit), "f"(noise));
  return score;
}

// Triton's FP32 `/`: div.full.f32.
__device__ __forceinline__ float vllm_div_full(float x, float y) {
  float q;
  asm("div.full.f32 %0, %1, %2;" : "=f"(q) : "f"(x), "f"(y));
  return q;
}

// dspark.greedy._first_argmax: keep (av, ai) over (bv, bi) when av is NaN and bv
// is not or has a higher index, or neither is NaN and av > bv, or av == bv with
// ai < bi: torch.argmax's first maximum, NaN above everything. Bitwise, not
// short-circuit, operators: every comparison is evaluated and combined in
// predicates, as Triton's tl.where combine is, instead of a branch for each.
__device__ __forceinline__ int vllm_first_argmax_keep(float av, int ai, float bv,
                                                      int bi) {
  const bool a_nan = av != av;
  const bool b_nan = bv != bv;
  return (a_nan & (!b_nan | (ai < bi))) |
         (!a_nan & !b_nan & ((av > bv) | ((av == bv) & (ai < bi))));
}

// tl.max(..., return_indices=True)'s combine (tie break to the left): keep
// (v, i) over (w, j) when v > w, or v == w and i < j. Comparisons with NaN are
// false. Compiled here, out of the TileLang simplifier's reach; bitwise
// operators, as above.
__device__ __forceinline__ int vllm_argmax_keep(float v, int i, float w, int j) {
  return (v > w) | ((v == w) & (i < j));
}

// tl.exp of an FP32 value: the product with log2(e), then ex2.approx.f32 without
// flush-to-zero (ptxas keeps subnormal results).
__device__ __forceinline__ float vllm_exp(float x) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "mul.rn.f32 t, %1, 0f3FB8AA3B;\n"
      "ex2.approx.f32 %0, t;\n"
      "}"
      : "=f"(y)
      : "f"(x));
  return y;
}

// FP32 arithmetic rounded to nearest, out of nvcc's contraction and the TileLang
// simplifier's reach.
__device__ __forceinline__ float vllm_add(float a, float b) {
  float c;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_sub(float a, float b) {
  float c;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_mul(float a, float b) {
  float c;
  asm("mul.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
// max.f32: a NaN gives way to the other operand.
__device__ __forceinline__ float vllm_max(float a, float b) {
  float c;
  asm("max.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}

// tl.exp(x - m).
__device__ __forceinline__ float vllm_exp_from(float x, float m) {
  return vllm_exp(vllm_sub(x, m));
}

// expm1 within an ULP: CUDA's (libdevice), compiled without fast math.
__device__ __forceinline__ float vllm_expm1(float x) { return expm1f(x); }

// Barron, Gnanapragasam and Tschannen's log-softmax ("A Fix for Softmax and
// Cross-Entropy", Eq. 5), from a row's maximum m. These compute every value and
// select, in PTX: a C conditional lets nvcc predicate the exponential instead,
// which costs a column several instructions.
//
// A logit's shift x - m, exactly 0 where x is the maximum (an infinite one
// included).
__device__ __forceinline__ float vllm_shifted(float x, float m) {
  float y;
  asm("{\n"
      ".reg .pred tie;\n"
      ".reg .b32 d;\n"
      "sub.rn.f32 d, %1, %2;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.f32 %0, 0f00000000, d, tie;\n"
      "}"
      : "=f"(y)
      : "f"(x), "f"(m));
  return y;
}

// tl.exp(x - m) of a column that is not the maximum (NaN is not), 0 for one that is.
__device__ __forceinline__ float vllm_other_exp(float x, float m) {
  float y;
  asm("{\n"
      ".reg .pred tie;\n"
      ".reg .b32 t, e;\n"
      "sub.rn.f32 t, %1, %2;\n"
      "mul.rn.f32 t, t, 0f3FB8AA3B;\n"
      "ex2.approx.f32 e, t;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.f32 %0, 0f00000000, e, tie;\n"
      "}"
      : "=f"(y)
      : "f"(x), "f"(m));
  return y;
}

// 1 for a column holding the maximum, else 0: its ties, counted exactly in FP32.
__device__ __forceinline__ float vllm_tie(float x, float m) {
  float y;
  asm("set.eq.f32.f32 %0, %1, %2;" : "=f"(y) : "f"(x), "f"(m));
  return y;
}

// int: x is the maximum m.
__device__ __forceinline__ int vllm_is_max(float x, float m) {
  int y;
  asm("{\n"
      ".reg .pred tie;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.s32 %0, 1, 0, tie;\n"
      "}"
      : "=r"(y)
      : "f"(x), "f"(m));
  return y;
}

// S, the others' sum: the columns that are not the maximum (sum), and of the
// maximum's ``ties`` all but one, exp(m - m) each (1; NaN for an infinite maximum,
// as the paper's z - z_max).
__device__ __forceinline__ float vllm_others(float sum, float ties, float m) {
  return ties > 1.0f
             ? vllm_add(sum, vllm_mul(vllm_sub(ties, 1.0f), vllm_exp_from(m, m)))
             : sum;
}

// A row's S from its block sums: NaN where its two or more columns are all -inf
// (the paper's z - z_max is -inf - -inf there, as in ``vllm_others``), which the
// block sums cannot tell, since a block whose maximum is -inf sums to 0.
__device__ __forceinline__ float vllm_row_others(float others, float m, int columns) {
  return (m == __uint_as_float(0xff800000u) && columns > 1)
             ? __uint_as_float(0x7fffffffu)
             : others;
}

// The log-sum-exp past the maximum, softplus(-margin) = log1p(S): CUDA's log1pf
// (libdevice, within an ULP).
__device__ __forceinline__ float vllm_softplus(float others) { return log1pf(others); }

// A sampled row's block sum of exponentials, kept while the block's maximum is
// above -inf (a NaN maximum is not), else 0.
__device__ __forceinline__ float vllm_live_sum(float m, float s) {
  float y;
  asm("{\n"
      ".reg .pred live;\n"
      "setp.gt.f32 live, %1, 0fFF800000;\n"
      "selp.f32 %0, %2, 0f00000000, live;\n"
      "}"
      : "=f"(y)
      : "f"(m), "f"(s));
  return y;
}

// A step of the cumulative log ratio: min(log_p + log_prob, 0), min.f32 (a NaN sum
// gives 0).
__device__ __forceinline__ float vllm_log_ratio(float log_p, float log_prob) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "add.rn.f32 t, %1, %2;\n"
      "min.f32 %0, t, 0f00000000;\n"
      "}"
      : "=f"(y)
      : "f"(log_p), "f"(log_prob));
  return y;
}

// tl_rand32(includes_zero=False) of a Philox word: uint_to_uniform_float, then the
// clamp to _TL_RAND_MIN (0f2FFFFFFF).
__device__ __forceinline__ float vllm_uniform(unsigned int word) {
  float u;
  asm("{\n"
      ".reg .b32 s, x, v;\n"
      "shr.s32 s, %1, 31;\n"
      "xor.b32 x, s, %1;\n"
      "cvt.rn.f32.s32 v, x;\n"
      "mul.rn.f32 v, v, 0f2FFFFFFF;\n"
      "max.f32 %0, v, 0f2FFFFFFF;\n"
      "}"
      : "=f"(u)
      : "r"(word));
  return u;
}

// Block verification's acceptance threshold for a one-hot draft followed by a valid
// one, from the logs of the prefix's joint ratio p and of the next draft's target
// probability m: the residual mass p (1 - m) over residual + 1 - p, which is
// 1 - p m. Both complements are -expm1 of a log, never 1 - x of a probability near
// 1, where it cancels (1 - m was 0 once m rounded to 1); the quotient is IEEE's,
// and the threshold 1 where the denominator is not positive (p = m = 1, or NaN).
__device__ __forceinline__ float vllm_block_threshold(float log_p, float log_m) {
  const float residual = vllm_mul(vllm_exp(log_p), -vllm_expm1(log_m));
  const float denom = -vllm_expm1(vllm_add(log_p, log_m));
  float ratio;
  asm("div.rn.f32 %0, %1, %2;" : "=f"(ratio) : "f"(residual), "f"(denom));
  return denom > 0.0f ? ratio : 1.0f;
}

// u <= h, ordered: a NaN threshold accepts nothing.
__device__ __forceinline__ int vllm_at_most(float u, float h) { return u <= h; }
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void local_stats_kernel(const int64_t* __restrict__ expanded_idx_mapping, const int* __restrict__ expanded_local_pos, int64_t* __restrict__ local_argmax, float* __restrict__ local_max, float* __restrict__ local_sumexp, const float* __restrict__ logits, const float* __restrict__ temperature, int apply_temperature, int64_t argmax_stride, int blocks, int64_t logits_stride, int64_t max_stride, int num_speculative_steps, int rows, int64_t sumexp_stride, int vocab);
extern "C" __global__ void __launch_bounds__(128, 1) local_stats_kernel(const int64_t* __restrict__ expanded_idx_mapping, const int* __restrict__ expanded_local_pos, int64_t* __restrict__ local_argmax, float* __restrict__ local_max, float* __restrict__ local_sumexp, const float* __restrict__ logits, const float* __restrict__ temperature, int apply_temperature, int64_t argmax_stride, int blocks, int64_t logits_stride, int64_t max_stride, int num_speculative_steps, int rows, int64_t sumexp_stride, int vocab) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* partial = ((void*)((char*)buf_dyn_shmem + 0));
  void* partial_index = ((void*)((char*)buf_dyn_shmem + 16));
  void* partial_sum = ((void*)((char*)buf_dyn_shmem + 32));
  void* partial_ties = ((void*)((char*)buf_dyn_shmem + 48));
  void* maximum = ((void*)((char*)buf_dyn_shmem + 64));
  int64_t state = (int64_t)0;
  float raw[64];
  float temp = 0x0p+0f/*0.000000e+00*/;
  float values[64];
  float best[1];
  int best_index[1];
  float other[1];
  int other_index[1];
  int keep = 0;
  int keep_1 = 0;
  int keep_2 = 0;
  int keep_3 = 0;
  int keep_4 = 0;
  int keep_5 = 0;
  int keep_6 = 0;
  float total[1];
  float ties[1];
  int keep_7 = 0;
  if (expanded_local_pos[((int64_t)((int)blockIdx.x))] < num_speculative_steps) {
    state = expanded_idx_mapping[((int64_t)((int)blockIdx.x))];
  }
  if (expanded_local_pos[((int64_t)((int)blockIdx.x))] < num_speculative_steps) {
    #pragma unroll
    for (int r = 0; r < 16; ++r) {
      if (((((((int)blockIdx.y) * 8192) + (r * 512)) + (((int)threadIdx.x) * 4)) + 4) <= vocab) {
        *(float4*)(raw + (r * 4)) = *(float4*)(logits + ((((((int64_t)((int)blockIdx.y)) * (int64_t)8192) + (((int64_t)r) * (int64_t)512)) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + (((int64_t)((int)blockIdx.x)) * logits_stride)));
      } else {
        #pragma unroll
        for (int k = 0; k < 4; ++k) {
          if (((((((int)blockIdx.y) * 8192) + (r * 512)) + (((int)threadIdx.x) * 4)) + k) < vocab) {
            raw[((r * 4) + k)] = logits[(((((((int64_t)((int)blockIdx.y)) * (int64_t)8192) + (((int64_t)r) * (int64_t)512)) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + (((int64_t)((int)blockIdx.x)) * logits_stride)) + ((int64_t)k))];
          }
        }
      }
    }
  }
  if (expanded_local_pos[((int64_t)((int)blockIdx.x))] < num_speculative_steps) {
    temp = temperature[state];
  }
  if (expanded_local_pos[((int64_t)((int)blockIdx.x))] < num_speculative_steps) {
    #pragma unroll
    for (int j = 0; j < 64; ++j) {
      float condval;
      if ((((((((int)blockIdx.y) * 8192) + ((j >> 2) * 512)) + (((int)threadIdx.x) * 4)) + (j & 3)) < vocab)) {
        condval = raw[j];
      } else {
        condval = -CUDART_INF_F;
      }
      values[j] = condval;
    }
  }
  if (expanded_local_pos[((int64_t)((int)blockIdx.x))] < num_speculative_steps) {
    best[0] = values[0];
  }
  if (expanded_local_pos[((int64_t)((int)blockIdx.x))] < num_speculative_steps) {
    #pragma unroll
    for (int j_1 = 1; j_1 < 64; ++j_1) {
      best[0] = vllm_max(best[0], values[j_1]);
    }
  }
  if (expanded_local_pos[((int64_t)((int)blockIdx.x))] < num_speculative_steps) {
    if (temp == 0x0p+0f/*0.000000e+00*/) {
      best[0] = values[0];
      best_index[0] = (((int)threadIdx.x) * 4);
      #pragma unroll
      for (int j_2 = 1; j_2 < 64; ++j_2) {
        float value = values[j_2];
        keep_7 = vllm_argmax_keep(best[0], best_index[0], value, ((((j_2 >> 2) * 512) + (((int)threadIdx.x) * 4)) + (j_2 & 3)));
        int condval_1;
        if ((keep_7 != 0)) {
          condval_1 = best_index[0];
        } else {
          condval_1 = ((((j_2 >> 2) * 512) + (((int)threadIdx.x) * 4)) + (j_2 & 3));
        }
        best_index[0] = condval_1;
        float condval_2;
        if ((keep_7 != 0)) {
          condval_2 = best[0];
        } else {
          condval_2 = value;
        }
        best[0] = condval_2;
      }
      other[0] = __shfl_xor_sync((uint)4294967295, best[0], 16, 32);
      other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 16, 32);
      float value_1 = other[0];
      int index = other_index[0];
      keep = vllm_argmax_keep(best[0], best_index[0], value_1, index);
      int condval_3;
      if ((keep != 0)) {
        condval_3 = best_index[0];
      } else {
        condval_3 = index;
      }
      best_index[0] = condval_3;
      float condval_4;
      if ((keep != 0)) {
        condval_4 = best[0];
      } else {
        condval_4 = value_1;
      }
      best[0] = condval_4;
      other[0] = __shfl_xor_sync((uint)4294967295, best[0], 8, 32);
      other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 8, 32);
      float value_2 = other[0];
      int index_1 = other_index[0];
      keep_1 = vllm_argmax_keep(best[0], best_index[0], value_2, index_1);
      int condval_5;
      if ((keep_1 != 0)) {
        condval_5 = best_index[0];
      } else {
        condval_5 = index_1;
      }
      best_index[0] = condval_5;
      float condval_6;
      if ((keep_1 != 0)) {
        condval_6 = best[0];
      } else {
        condval_6 = value_2;
      }
      best[0] = condval_6;
      other[0] = __shfl_xor_sync((uint)4294967295, best[0], 4, 32);
      other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 4, 32);
      float value_3 = other[0];
      int index_2 = other_index[0];
      keep_2 = vllm_argmax_keep(best[0], best_index[0], value_3, index_2);
      int condval_7;
      if ((keep_2 != 0)) {
        condval_7 = best_index[0];
      } else {
        condval_7 = index_2;
      }
      best_index[0] = condval_7;
      float condval_8;
      if ((keep_2 != 0)) {
        condval_8 = best[0];
      } else {
        condval_8 = value_3;
      }
      best[0] = condval_8;
      other[0] = __shfl_xor_sync((uint)4294967295, best[0], 2, 32);
      other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 2, 32);
      float value_4 = other[0];
      int index_3 = other_index[0];
      keep_3 = vllm_argmax_keep(best[0], best_index[0], value_4, index_3);
      int condval_9;
      if ((keep_3 != 0)) {
        condval_9 = best_index[0];
      } else {
        condval_9 = index_3;
      }
      best_index[0] = condval_9;
      float condval_10;
      if ((keep_3 != 0)) {
        condval_10 = best[0];
      } else {
        condval_10 = value_4;
      }
      best[0] = condval_10;
      other[0] = __shfl_xor_sync((uint)4294967295, best[0], 1, 32);
      other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 1, 32);
      float value_5 = other[0];
      int index_4 = other_index[0];
      keep_4 = vllm_argmax_keep(best[0], best_index[0], value_5, index_4);
      int condval_11;
      if ((keep_4 != 0)) {
        condval_11 = best_index[0];
      } else {
        condval_11 = index_4;
      }
      best_index[0] = condval_11;
      float condval_12;
      if ((keep_4 != 0)) {
        condval_12 = best[0];
      } else {
        condval_12 = value_5;
      }
      best[0] = condval_12;
      if ((((int)threadIdx.x) % 32) == 0) {
        ((float*)partial)[(((int)threadIdx.x) >> 5)] = best[0];
        ((int*)partial_index)[(((int)threadIdx.x) >> 5)] = best_index[0];
      }
      __syncthreads();
      if (((int)threadIdx.x) < 4) {
        best[0] = ((float*)partial)[((int)threadIdx.x)];
        best_index[0] = ((int*)partial_index)[((int)threadIdx.x)];
      }
      other[0] = __shfl_xor_sync((uint)4294967295, best[0], 2, 32);
      other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 2, 32);
      float value_6 = other[0];
      int index_5 = other_index[0];
      keep_5 = vllm_argmax_keep(best[0], best_index[0], value_6, index_5);
      int condval_13;
      if ((keep_5 != 0)) {
        condval_13 = best_index[0];
      } else {
        condval_13 = index_5;
      }
      best_index[0] = condval_13;
      float condval_14;
      if ((keep_5 != 0)) {
        condval_14 = best[0];
      } else {
        condval_14 = value_6;
      }
      best[0] = condval_14;
      other[0] = __shfl_xor_sync((uint)4294967295, best[0], 1, 32);
      other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 1, 32);
      float value_7 = other[0];
      int index_6 = other_index[0];
      keep_6 = vllm_argmax_keep(best[0], best_index[0], value_7, index_6);
      int condval_15;
      if ((keep_6 != 0)) {
        condval_15 = best_index[0];
      } else {
        condval_15 = index_6;
      }
      best_index[0] = condval_15;
      float condval_16;
      if ((keep_6 != 0)) {
        condval_16 = best[0];
      } else {
        condval_16 = value_7;
      }
      best[0] = condval_16;
      if (((int)threadIdx.x) == 0) {
        local_argmax[((((int64_t)((int)blockIdx.x)) * argmax_stride) + ((int64_t)((int)blockIdx.y)))] = ((((int64_t)((int)blockIdx.y)) * (int64_t)8192) + ((int64_t)best_index[0]));
        local_max[((((int64_t)((int)blockIdx.x)) * max_stride) + ((int64_t)((int)blockIdx.y)))] = best[0];
      }
    } else {
      if ((apply_temperature != 0) & (temp != 0x1p+0f/*1.000000e+00*/)) {
        #pragma unroll
        for (int j_3 = 0; j_3 < 64; ++j_3) {
          if (((((((int)blockIdx.y) * 8192) + ((j_3 >> 2) * 512)) + (((int)threadIdx.x) * 4)) + (j_3 & 3)) < vocab) {
            values[j_3] = vllm_div_full(values[j_3], temp);
          }
        }
      }
      if ((apply_temperature != 0) & (temp != 0x1p+0f/*1.000000e+00*/)) {
        best[0] = values[0];
      }
      if ((apply_temperature != 0) & (temp != 0x1p+0f/*1.000000e+00*/)) {
        #pragma unroll
        for (int j_4 = 1; j_4 < 64; ++j_4) {
          best[0] = vllm_max(best[0], values[j_4]);
        }
      }
      best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 16, 32));
      best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 8, 32));
      best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 4, 32));
      best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 2, 32));
      best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 1, 32));
      if ((((int)threadIdx.x) % 32) == 0) {
        ((float*)partial)[(((int)threadIdx.x) >> 5)] = best[0];
      }
      __syncthreads();
      if (((int)threadIdx.x) < 4) {
        best[0] = ((float*)partial)[((int)threadIdx.x)];
      }
      best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 2, 32));
      best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 1, 32));
      if (((int)threadIdx.x) == 0) {
        ((float*)maximum)[0] = best[0];
      }
      __syncthreads();
      best[0] = ((float*)maximum)[0];
      total[0] = vllm_other_exp(values[0], best[0]);
      ties[0] = vllm_tie(values[0], best[0]);
      #pragma unroll
      for (int j_5 = 1; j_5 < 64; ++j_5) {
        total[0] = vllm_add(total[0], vllm_other_exp(values[j_5], best[0]));
        ties[0] = vllm_add(ties[0], vllm_tie(values[j_5], best[0]));
      }
      total[0] = vllm_add(total[0], __shfl_xor_sync((uint)4294967295, total[0], 16, 32));
      total[0] = vllm_add(total[0], __shfl_xor_sync((uint)4294967295, total[0], 8, 32));
      total[0] = vllm_add(total[0], __shfl_xor_sync((uint)4294967295, total[0], 4, 32));
      total[0] = vllm_add(total[0], __shfl_xor_sync((uint)4294967295, total[0], 2, 32));
      total[0] = vllm_add(total[0], __shfl_xor_sync((uint)4294967295, total[0], 1, 32));
      if ((((int)threadIdx.x) % 32) == 0) {
        ((float*)partial_sum)[(((int)threadIdx.x) >> 5)] = total[0];
      }
      __syncthreads();
      if (((int)threadIdx.x) < 4) {
        total[0] = ((float*)partial_sum)[((int)threadIdx.x)];
      }
      total[0] = vllm_add(total[0], __shfl_xor_sync((uint)4294967295, total[0], 2, 32));
      total[0] = vllm_add(total[0], __shfl_xor_sync((uint)4294967295, total[0], 1, 32));
      ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 16, 32));
      ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 8, 32));
      ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 4, 32));
      ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 2, 32));
      ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 1, 32));
      if ((((int)threadIdx.x) % 32) == 0) {
        ((float*)partial_ties)[(((int)threadIdx.x) >> 5)] = ties[0];
      }
      __syncthreads();
      if (((int)threadIdx.x) < 4) {
        ties[0] = ((float*)partial_ties)[((int)threadIdx.x)];
      }
      ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 2, 32));
      ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 1, 32));
      if (((int)threadIdx.x) == 0) {
        local_max[((((int64_t)((int)blockIdx.x)) * max_stride) + ((int64_t)((int)blockIdx.y)))] = best[0];
        local_sumexp[((((int64_t)((int)blockIdx.x)) * sumexp_stride) + ((int64_t)((int)blockIdx.y)))] = vllm_live_sum(best[0], vllm_others(total[0], ties[0], best[0]));
      }
    }
  }
}

