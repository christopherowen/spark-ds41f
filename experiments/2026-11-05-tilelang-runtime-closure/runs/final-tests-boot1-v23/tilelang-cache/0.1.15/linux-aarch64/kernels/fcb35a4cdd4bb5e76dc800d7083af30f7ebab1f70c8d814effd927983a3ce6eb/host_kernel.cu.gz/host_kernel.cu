// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* insert_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_insert(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_insert(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[13];
  void* stack_ffi_any = stack;
  if (!((num_args == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "insert: num_args should be 8", (long long)(num_args), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert: args pointer is NULL");
    return -1;
  }
  int32_t sampled_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((sampled_handle_type_index == 0) || (sampled_handle_type_index == 4)) || (sampled_handle_type_index == 7)) || (64 <= sampled_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input sampled expected pointer or tensor handle");
    return -1;
  }
  int32_t counts_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((counts_handle_type_index == 0) || (counts_handle_type_index == 4)) || (counts_handle_type_index == 7)) || (64 <= counts_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input counts expected pointer or tensor handle");
    return -1;
  }
  int32_t local_ids_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((local_ids_handle_type_index == 0) || (local_ids_handle_type_index == 4)) || (local_ids_handle_type_index == 7)) || (64 <= local_ids_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_ids expected pointer or tensor handle");
    return -1;
  }
  int32_t local_max_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((local_max_handle_type_index == 0) || (local_max_handle_type_index == 4)) || (local_max_handle_type_index == 7)) || (64 <= local_max_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_max expected pointer or tensor handle");
    return -1;
  }
  int32_t cu_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((cu_handle_type_index == 0) || (cu_handle_type_index == 4)) || (cu_handle_type_index == 7)) || (64 <= cu_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input cu expected pointer or tensor handle");
    return -1;
  }
  int32_t mapping_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((mapping_handle_type_index == 0) || (mapping_handle_type_index == 4)) || (mapping_handle_type_index == 7)) || (64 <= mapping_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input mapping expected pointer or tensor handle");
    return -1;
  }
  int32_t temperature_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((temperature_handle_type_index == 0) || (temperature_handle_type_index == 4)) || (temperature_handle_type_index == 7)) || (64 <= temperature_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input temperature expected pointer or tensor handle");
    return -1;
  }
  int32_t dead_row_cut_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((dead_row_cut_handle_type_index == 0) || (dead_row_cut_handle_type_index == 4)) || (dead_row_cut_handle_type_index == 7)) || (64 <= dead_row_cut_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut expected pointer or tensor handle");
    return -1;
  }
  void* sampled_handle = ((sampled_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* counts_handle = ((counts_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* local_ids_handle = ((local_ids_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* local_max_handle = ((local_max_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* cu_handle = ((cu_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* mapping_handle = ((mapping_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* temperature_handle = ((temperature_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* dead_row_cut_handle = ((dead_row_cut_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  bool insert_sampled_is_null = (sampled_handle == NULL);
  if (!(!insert_sampled_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert.sampled is expected to have non-NULL pointer");
    return -1;
  }
  bool insert_counts_is_null = (counts_handle == NULL);
  if (!(!insert_counts_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert.counts is expected to have non-NULL pointer");
    return -1;
  }
  bool insert_local_ids_is_null = (local_ids_handle == NULL);
  if (!(!insert_local_ids_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert.local_ids is expected to have non-NULL pointer");
    return -1;
  }
  bool insert_local_max_is_null = (local_max_handle == NULL);
  if (!(!insert_local_max_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert.local_max is expected to have non-NULL pointer");
    return -1;
  }
  bool insert_cu_is_null = (cu_handle == NULL);
  if (!(!insert_cu_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert.cu is expected to have non-NULL pointer");
    return -1;
  }
  bool insert_mapping_is_null = (mapping_handle == NULL);
  if (!(!insert_mapping_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert.mapping is expected to have non-NULL pointer");
    return -1;
  }
  bool insert_temperature_is_null = (temperature_handle == NULL);
  if (!(!insert_temperature_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "insert.temperature is expected to have non-NULL pointer");
    return -1;
  }
  bool insert_dead_row_cut_is_null = (dead_row_cut_handle == NULL);
  void* insert_sampled_shape = (((DLTensor*)sampled_handle)[0].shape);
  void* insert_counts_shape = (((DLTensor*)counts_handle)[0].shape);
  void* insert_local_ids_shape = (((DLTensor*)local_ids_handle)[0].shape);
  void* insert_local_max_shape = (((DLTensor*)local_max_handle)[0].shape);
  void* insert_cu_shape = (((DLTensor*)cu_handle)[0].shape);
  void* insert_mapping_shape = (((DLTensor*)mapping_handle)[0].shape);
  void* insert_temperature_shape = (((DLTensor*)temperature_handle)[0].shape);
  void* condval;
  if (!insert_dead_row_cut_is_null) {
    condval = (((DLTensor*)dead_row_cut_handle)[0].shape);
  } else {
    uint64_t v_ = (uint64_t)0;
    condval = (*(void* *)(&(v_)));
  }
  void* insert_dead_row_cut_shape = condval;
  if (!(((((DLTensor*)sampled_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input sampled ndim mismatch, expected 2", (long long)((((DLTensor*)sampled_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable requests requires at least one non-null buffer among: insert.sampled, insert.counts, insert.local_ids, insert.local_max");
    return -1;
  }
  int32_t requests = ((int32_t)((int64_t*)insert_sampled_shape)[0]);
  int32_t width = ((int32_t)((int64_t*)insert_sampled_shape)[1]);
  void* insert_sampled_strides = (((DLTensor*)sampled_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)sampled_handle)[0].device.device_id);
  void* sampled = (((DLTensor*)sampled_handle)[0].data);
  if (!(((((DLTensor*)counts_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input counts ndim mismatch, expected 1", (long long)((((DLTensor*)counts_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* insert_counts_strides = (((DLTensor*)counts_handle)[0].strides);
  void* counts = (((DLTensor*)counts_handle)[0].data);
  if (!(((((DLTensor*)local_ids_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_ids ndim mismatch, expected 2", (long long)((((DLTensor*)local_ids_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* insert_local_ids_strides = (((DLTensor*)local_ids_handle)[0].strides);
  void* local_ids = (((DLTensor*)local_ids_handle)[0].data);
  if (!(((((DLTensor*)local_max_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_max ndim mismatch, expected 2", (long long)((((DLTensor*)local_max_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* insert_local_max_strides = (((DLTensor*)local_max_handle)[0].strides);
  void* local_max = (((DLTensor*)local_max_handle)[0].data);
  if (!(((((DLTensor*)cu_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input cu ndim mismatch, expected 1", (long long)((((DLTensor*)cu_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* insert_cu_strides = (((DLTensor*)cu_handle)[0].strides);
  void* cu = (((DLTensor*)cu_handle)[0].data);
  if (!(((((DLTensor*)mapping_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input mapping ndim mismatch, expected 1", (long long)((((DLTensor*)mapping_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t mapping_len = ((int32_t)((int64_t*)insert_mapping_shape)[0]);
  void* insert_mapping_strides = (((DLTensor*)mapping_handle)[0].strides);
  void* mapping = (((DLTensor*)mapping_handle)[0].data);
  if (!(((((DLTensor*)temperature_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input temperature ndim mismatch, expected 1", (long long)((((DLTensor*)temperature_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t state_len = ((int32_t)((int64_t*)insert_temperature_shape)[0]);
  void* insert_temperature_strides = (((DLTensor*)temperature_handle)[0].strides);
  void* temperature = (((DLTensor*)temperature_handle)[0].data);
  if (!((insert_dead_row_cut_is_null || ((((DLTensor*)dead_row_cut_handle)[0].ndim) == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut ndim mismatch, expected 1");
    return -1;
  }
  int32_t condval_1;
  if (!insert_dead_row_cut_is_null) {
    condval_1 = ((int32_t)((int64_t*)insert_dead_row_cut_shape)[0]);
  } else {
    condval_1 = 0;
  }
  int32_t cut_len = condval_1;
  void* condval_2;
  if (!insert_dead_row_cut_is_null) {
    condval_2 = (((DLTensor*)dead_row_cut_handle)[0].strides);
  } else {
    uint64_t v__1 = (uint64_t)0;
    condval_2 = (*(void* *)(&(v__1)));
  }
  void* insert_dead_row_cut_strides = condval_2;
  void* condval_3;
  if (!insert_dead_row_cut_is_null) {
    condval_3 = (((DLTensor*)dead_row_cut_handle)[0].data);
  } else {
    uint64_t v__2 = (uint64_t)0;
    condval_3 = (*(void* *)(&(v__2)));
  }
  void* dead_row_cut = condval_3;
  if (!(((((((DLTensor*)sampled_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)sampled_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)sampled_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input sampled dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_4;
  if ((insert_sampled_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)insert_sampled_strides)[1]);
  }
  if (!(((condval_4 == 1) || (width == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input sampled strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_5;
  if ((insert_sampled_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)insert_sampled_strides)[0]);
  }
  if (!(((condval_5 == 4) || (requests == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input sampled strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)sampled_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input sampled byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)sampled_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input sampled device_type mismatch, expected cuda", (long long)((((DLTensor*)sampled_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((requests == 0) || (width == 0)) || !(sampled == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input sampled data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)counts_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)counts_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)counts_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input counts dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)insert_sampled_shape)[0]) == ((int32_t)((int64_t*)insert_counts_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input counts shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)insert_sampled_shape)[0])), (long long)(((int32_t)((int64_t*)insert_counts_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((insert_counts_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)insert_counts_strides)[0]);
  }
  if (!(((condval_6 == 1) || (requests == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input counts strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)counts_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input counts byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)counts_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)counts_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input counts device_id violates packed ABI constraint", (long long)((((DLTensor*)counts_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)counts_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input counts device_type mismatch, expected cuda", (long long)((((DLTensor*)counts_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((requests == 0) || !(counts == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input counts data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_ids_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)local_ids_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)local_ids_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_ids dtype mismatch, expected int64");
    return -1;
  }
  if (!((((int32_t)((int64_t*)insert_sampled_shape)[0]) == ((int32_t)((int64_t*)insert_local_ids_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_ids shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)insert_sampled_shape)[0])), (long long)(((int32_t)((int64_t*)insert_local_ids_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)insert_local_ids_shape)[1]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_ids shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)insert_local_ids_shape)[1])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((insert_local_ids_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)insert_local_ids_strides)[0]);
  }
  if (!(((condval_7 == 1) || (requests == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_ids strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_ids_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_ids byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_ids_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_ids_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_ids device_id violates packed ABI constraint", (long long)((((DLTensor*)local_ids_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_ids_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_ids device_type mismatch, expected cuda", (long long)((((DLTensor*)local_ids_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((requests == 0) || !(local_ids == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_ids data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_max_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)local_max_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)local_max_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_max dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)insert_sampled_shape)[0]) == ((int32_t)((int64_t*)insert_local_max_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_max shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)insert_sampled_shape)[0])), (long long)(((int32_t)((int64_t*)insert_local_max_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)insert_local_max_shape)[1]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_max shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)insert_local_max_shape)[1])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((insert_local_max_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)insert_local_max_strides)[0]);
  }
  if (!(((condval_8 == 1) || (requests == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_max strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_max_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_max byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_max_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_max device_id violates packed ABI constraint", (long long)((((DLTensor*)local_max_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input local_max device_type mismatch, expected cuda", (long long)((((DLTensor*)local_max_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((requests == 0) || !(local_max == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input local_max data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)cu_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)cu_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)cu_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input cu dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)insert_cu_shape)[0]) == (requests + 1)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input cu shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)insert_cu_shape)[0])), (long long)((requests + 1)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((insert_cu_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)insert_cu_strides)[0]);
  }
  if (!(((condval_9 == 1) || (requests == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input cu strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)cu_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input cu byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)cu_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input cu device_id violates packed ABI constraint", (long long)((((DLTensor*)cu_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)cu_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input cu device_type mismatch, expected cuda", (long long)((((DLTensor*)cu_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((requests == -1) || !(cu == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input cu data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)mapping_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)mapping_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)mapping_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input mapping dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_10;
  if ((insert_mapping_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)insert_mapping_strides)[0]);
  }
  if (!(((condval_10 == 1) || (mapping_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input mapping strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)mapping_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input mapping byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)mapping_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)mapping_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input mapping device_id violates packed ABI constraint", (long long)((((DLTensor*)mapping_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)mapping_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input mapping device_type mismatch, expected cuda", (long long)((((DLTensor*)mapping_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((mapping_len == 0) || !(mapping == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input mapping data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)temperature_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)temperature_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)temperature_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input temperature dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_11;
  if ((insert_temperature_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)insert_temperature_strides)[0]);
  }
  if (!(((condval_11 == 1) || (state_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input temperature strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)temperature_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input temperature byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)temperature_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_id) == (((DLTensor*)sampled_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input temperature device_id violates packed ABI constraint", (long long)((((DLTensor*)temperature_handle)[0].device.device_id)), (long long)((((DLTensor*)sampled_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)temperature_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel insert input temperature device_type mismatch, expected cuda", (long long)((((DLTensor*)temperature_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((state_len == 0) || !(temperature == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input temperature data pointer is NULL");
    return -1;
  }
  uint8_t condval_12;
  if (!insert_dead_row_cut_is_null) {
    condval_12 = (((DLTensor*)dead_row_cut_handle)[0].dtype.code);
  } else {
    condval_12 = (uint8_t)0;
  }
  uint8_t condval_13;
  if (!insert_dead_row_cut_is_null) {
    condval_13 = (((DLTensor*)dead_row_cut_handle)[0].dtype.bits);
  } else {
    condval_13 = (uint8_t)32;
  }
  uint16_t condval_14;
  if (!insert_dead_row_cut_is_null) {
    condval_14 = (((DLTensor*)dead_row_cut_handle)[0].dtype.lanes);
  } else {
    condval_14 = (uint16_t)1;
  }
  if (!((insert_dead_row_cut_is_null || (((condval_12 == (uint8_t)0) && (condval_13 == (uint8_t)32)) && (condval_14 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_15;
  if ((insert_dead_row_cut_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)insert_dead_row_cut_strides)[0]);
  }
  if (!(((insert_dead_row_cut_is_null || (condval_15 == 1)) || (cut_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_16;
  if (!insert_dead_row_cut_is_null) {
    condval_16 = (((DLTensor*)dead_row_cut_handle)[0].byte_offset);
  } else {
    condval_16 = (uint64_t)0;
  }
  if (!((insert_dead_row_cut_is_null || ((uint64_t)0 == condval_16)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_17;
  if (!insert_dead_row_cut_is_null) {
    condval_17 = (((DLTensor*)dead_row_cut_handle)[0].device.device_id);
  } else {
    condval_17 = 0;
  }
  if (!((insert_dead_row_cut_is_null || (condval_17 == (((DLTensor*)sampled_handle)[0].device.device_id))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_18;
  if (!insert_dead_row_cut_is_null) {
    condval_18 = (((DLTensor*)dead_row_cut_handle)[0].device.device_type);
  } else {
    condval_18 = 0;
  }
  if (!((insert_dead_row_cut_is_null || (condval_18 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut device_type mismatch, expected cuda");
    return -1;
  }
  if (!(((insert_dead_row_cut_is_null || (cut_len == 0)) || !(dead_row_cut == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel insert input dead_row_cut data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (counts == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = counts;
  if (cu == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = cu;
  if (local_ids == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = local_ids;
  if (local_max == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = local_max;
  if (mapping == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = mapping;
  if (sampled == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = sampled;
  if (temperature == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = temperature;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)requests);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)requests);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = (int64_t)0;
  if (insert_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "insert_kernel", &insert_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(insert_kernel_packed, (TVMFFIAny*) stack_ffi_any, 12, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_insert(self, args, num_args, result);
}
