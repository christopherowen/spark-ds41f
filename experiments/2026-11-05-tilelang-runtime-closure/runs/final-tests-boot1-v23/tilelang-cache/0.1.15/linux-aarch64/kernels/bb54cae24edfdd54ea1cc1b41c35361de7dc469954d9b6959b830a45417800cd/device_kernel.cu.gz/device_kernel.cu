
__device__ __forceinline__ void vllm_gather_b128(const void* d, const void* s) {
  *reinterpret_cast<uint4*>(const_cast<void*>(d)) = *reinterpret_cast<const uint4*>(s);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gather_columns_into_kernel(float* __restrict__ out0, float* __restrict__ out1, float* __restrict__ src, int rows, int stride0, int stride1);
extern "C" __global__ void __launch_bounds__(128, 1) gather_columns_into_kernel(float* __restrict__ out0, float* __restrict__ out1, float* __restrict__ src, int rows, int stride0, int stride1) {
  vllm_gather_b128((&(out0[((((int64_t)((int)threadIdx.x)) * (int64_t)4) + (((int64_t)((int)blockIdx.x)) * ((int64_t)stride0)))])), (&(src[(((((((int64_t)((int)threadIdx.x)) >> (int64_t)4) * ((int64_t)rows)) * (int64_t)128) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)15) * (int64_t)4))])));
  vllm_gather_b128((&(out1[((((int64_t)((int)threadIdx.x)) * (int64_t)4) + (((int64_t)((int)blockIdx.x)) * ((int64_t)stride1)))])), (&(src[(((((((((int64_t)((int)threadIdx.x)) >> (int64_t)4) * (int64_t)2) + (int64_t)1) * ((int64_t)rows)) * (int64_t)64) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)15) * (int64_t)4))])));
}

