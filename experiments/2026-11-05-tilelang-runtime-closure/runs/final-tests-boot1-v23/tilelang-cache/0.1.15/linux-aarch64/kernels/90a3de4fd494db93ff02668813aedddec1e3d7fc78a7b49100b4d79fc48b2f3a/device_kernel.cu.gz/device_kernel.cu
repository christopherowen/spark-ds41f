#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gemm_bf16_two_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, float* __restrict__ C0, float* __restrict__ C1, int M);
extern "C" __global__ void __launch_bounds__(256, 1) gemm_bf16_two_kernel(__grid_constant__ const CUtensorMap A_desc, __grid_constant__ const CUtensorMap B_desc, float* __restrict__ C0, float* __restrict__ C1, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 24576));
  __shared__ __align__(16) uint64_t mbarrier_mem[6];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float C_local[32];
  float C_total[32];
  float C_block[32];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(A_desc);
    tl::prefetch_tma_descriptor(B_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(1);
    mbarrier[3].init(128);
    mbarrier[4].init(128);
    mbarrier[5].init(128);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int ko = 0; ko < 80; ++ko) {
      mbarrier[((ko % 3) + 3)].wait((((ko % 6) / 3) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[(ko % 3)].expect_transaction(8192);
        tl::tma_load(A_desc, mbarrier[(ko % 3)], (&(((bfloat16_t*)A_shared)[((ko % 3) * 4096)])), (ko * 64), (((int)blockIdx.y) * 64));
        mbarrier[(ko % 3)].arrive_and_expect_tx(8192);
        tl::tma_load(B_desc, mbarrier[(ko % 3)], (&(((bfloat16_t*)B_shared)[((ko % 3) * 4096)])), (ko * 64), (((int)blockIdx.x) * 64));
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i = 0; i < 8; ++i) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(C_local + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    #pragma unroll
    for (int i_1 = 0; i_1 < 8; ++i_1) {
      float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(C_total + (i_1 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    }
    for (int ko_1 = 0; ko_1 < 80; ++ko_1) {
      #pragma unroll
      for (int i_2 = 0; i_2 < 8; ++i_2) {
        float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
        *(float4*)(C_block + (i_2 * 4)) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
      }
      mbarrier[(ko_1 % 3)].wait(((ko_1 % 6) / 3));
      {
        bfloat16_t A_local[16];
        bfloat16_t B_local[16];
        for (int ki = 0; ki < 4; ++ki) {
          #pragma unroll
          for (int i_3 = 0; i_3 < 2; ++i_3) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((ko_1 % 3) * 4096) + (((((int)threadIdx.x) & 63) >> 5) * 2048)) + (i_3 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_3 * 8)])));
          }
          #pragma unroll
          for (int i_4 = 0; i_4 < 2; ++i_4) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)B_shared)[(((((((((ko_1 % 3) * 4096) + (((((int)threadIdx.x) & 127) >> 6) * 2048)) + (i_4 * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[(i_4 * 8)])));
          }
          for (int i_5 = 0; i_5 < 2; ++i_5) {
            for (int j = 0; j < 2; ++j) {
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + ((i_5 * 16) + (j * 8))), reinterpret_cast<const unsigned*>(A_local + (i_5 * 8)), reinterpret_cast<const unsigned*>(B_local + (j * 8)));
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (((i_5 * 16) + (j * 8)) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_5 * 8)), reinterpret_cast<const unsigned*>(B_local + ((j * 8) + 4)));
            }
          }
        }
      }
      mbarrier[((ko_1 % 3) + 3)].arrive();
      #pragma unroll
      for (int i_6 = 0; i_6 < 8; ++i_6) {
        float4 __1;
          float4 v_ = *(float4*)(C_local + (i_6 * 4));
          float4 v__1 = *(float4*)(C_block + (i_6 * 4));
          *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
          *(float2*)(&(__1.z)) = tl::add2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
        *(float4*)(C_local + (i_6 * 4)) = __1;
      }
      if (((ko_1 + 1) % 16) == 0) {
        #pragma unroll
        for (int i_7 = 0; i_7 < 8; ++i_7) {
          float4 condval;
          if ((ko_1 == 15)) {
            condval = *(float4*)(C_local + (i_7 * 4));
          } else {
            float4 __2;
              float4 v__2 = *(float4*)(C_total + (i_7 * 4));
              float4 v__3 = *(float4*)(C_local + (i_7 * 4));
              *(float2*)(&(__2.x)) = tl::add2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
              *(float2*)(&(__2.z)) = tl::add2(*(float2*)(&(v__2.z)), *(float2*)(&(v__3.z)));
            condval = __2;
          }
          *(float4*)(C_total + (i_7 * 4)) = condval;
        }
        #pragma unroll
        for (int i_8 = 0; i_8 < 8; ++i_8) {
          float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
          *(float4*)(C_local + (i_8 * 4)) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
        }
      }
    }
    if (((int)blockIdx.x) < 2) {
      #pragma unroll
      for (int i_9 = 0; i_9 < 16; ++i_9) {
        if ((((((((int)blockIdx.y) * 64) + (((((int)threadIdx.x) & 63) >> 5) * 32)) + ((i_9 >> 3) * 16)) + ((i_9 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M) {
          *(float2*)(C0 + ((((((((((((int64_t)((int)blockIdx.y)) * (int64_t)8192) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)4096)) + ((((int64_t)i_9) >> (int64_t)3) * (int64_t)2048)) + ((((int64_t)i_9) & (int64_t)1) * (int64_t)1024)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)32)) + (((((int64_t)i_9) & (int64_t)7) >> (int64_t)1) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2)) - (int64_t)64)) = *(float2*)(C_total + (i_9 * 2));
        }
      }
    } else {
      #pragma unroll
      for (int i_10 = 0; i_10 < 16; ++i_10) {
        if ((((((((int)blockIdx.y) * 64) + (((((int)threadIdx.x) & 63) >> 5) * 32)) + ((i_10 >> 3) * 16)) + ((i_10 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M) {
          *(float2*)(C1 + ((((((((((((int64_t)((int)blockIdx.y)) * (int64_t)8192) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)4096)) + ((((int64_t)i_10) >> (int64_t)3) * (int64_t)2048)) + ((((int64_t)i_10) & (int64_t)1) * (int64_t)1024)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)32)) + (((((int64_t)i_10) & (int64_t)7) >> (int64_t)1) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2)) - (int64_t)192)) = *(float2*)(C_total + (i_10 * 2));
        }
      }
    }
  }
}

