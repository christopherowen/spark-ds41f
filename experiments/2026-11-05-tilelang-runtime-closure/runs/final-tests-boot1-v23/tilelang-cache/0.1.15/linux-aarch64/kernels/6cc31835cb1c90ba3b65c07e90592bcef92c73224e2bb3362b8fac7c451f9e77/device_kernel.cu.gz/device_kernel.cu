
// Triton's bundled libdevice __nv_logf, as used by the sampling family.
// CUDA's logf and lg2.approx * ln(2) can move a min-p threshold by one ULP.
__device__ __forceinline__ float vllm_control_log(float x) {
  float result;
  asm("{\n"
      ".reg .pred tiny, fin, zero;\n"
      ".reg .b32 z, o, e, m, f, r, p, q, l, w;\n"
      "setp.lt.f32 tiny, %1, 0f00800000;\n"
      "mul.rn.f32 z, %1, 0f4B000000;\n"
      "selp.f32 z, z, %1, tiny;\n"
      "selp.f32 o, 0fC1B80000, 0f00000000, tiny;\n"
      "add.s32 e, z, -1059760811;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, z, e;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "fma.rn.ftz.f32 f, f, 0f34000000, o;\n"
      "add.rn.f32 r, m, 0fBF800000;\n"
      "fma.rn.ftz.f32 p, 0fBE055027, r, 0f3E1039F6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBDF8CDCC;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E0F2955;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2AD8B9;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CED0B;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE7FFF22;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAA78;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Preserve the bundled libdevice exceptional-value handling.
      "setp.lt.u32 fin, z, 2139095040;\n"
      "fma.rn.ftz.f32 w, z, 0f7F800000, 0f7F800000;\n"
      "selp.f32 l, l, w, fin;\n"
      "setp.eq.f32 zero, z, 0f00000000;\n"
      "selp.f32 %0, 0fFF800000, l, zero;\n"
      "}"
      : "=f"(result) : "f"(x));
  return result;
}
// Triton's masked loads and stores: a masked lane keeps ``other`` and never waits on
// memory, and nothing branches, so a tile's loads issue together.
__device__ __forceinline__ int vllm_control_load_if_b32(const void* p, int other,
                                                       bool ok) {
  int v = other;
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q ld.global.b32 %0, [%1];\n}"
               : "+r"(v) : "l"(p), "r"((int)ok));
  return v;
}
__device__ __forceinline__ float vllm_control_load_if_f32(const void* p, float other,
                                                         bool ok) {
  float v = other;
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q ld.global.f32 %0, [%1];\n}"
               : "+f"(v) : "l"(p), "r"((int)ok));
  return v;
}
__device__ __forceinline__ void vllm_control_store_if_b64(void* p, long long v,
                                                          bool ok) {
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q st.global.b64 [%0], %1;\n}"
               :: "l"(p), "l"(v), "r"((int)ok) : "memory");
}
__device__ __forceinline__ void vllm_control_store_if(void* p, float v, bool ok) {
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q st.global.f32 [%0], %1;\n}"
               :: "l"(p), "f"(v), "r"((int)ok) : "memory");
}
__device__ __forceinline__ float vllm_control_reciprocal(float x) {
  float y;
  asm("rcp.approx.ftz.f32 %0, %1;" : "=f"(y) : "f"(x));
  return y;
}
__device__ __forceinline__ float vllm_control_penalty(float x, float scale,
    float freq, int count, float presence) {
  x = __fmul_rn(x, scale);
  x = __fmaf_rn(-freq, (float)count, x);
  return __fmaf_rn(-presence, (float)(count > 0), x);
}

// tl.exp of an FP32 value: the product with log2(e), then ex2.approx.f32 without
// flush-to-zero.
__device__ __forceinline__ float vllm_topk_exp(float x) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "mul.rn.f32 t, %1, 0f3FB8AA3B;\n"
      "ex2.approx.f32 %0, t;\n"
      "}"
      : "=f"(y)
      : "f"(x));
  return y;
}

// Triton's FP32 `/`: div.full.f32.
__device__ __forceinline__ float vllm_topk_div(float x, float y) {
  float q;
  asm("div.full.f32 %0, %1, %2;" : "=f"(q) : "f"(x), "f"(y));
  return q;
}

// tl.sqrt: sqrt.approx.ftz.f32.
__device__ __forceinline__ float vllm_topk_sqrt(float x) {
  float y;
  asm("sqrt.approx.ftz.f32 %0, %1;" : "=f"(y) : "f"(x));
  return y;
}

// FP32 arithmetic rounded to nearest, out of nvcc's contraction and the TileLang
// simplifier's reach.
__device__ __forceinline__ float vllm_topk_add(float a, float b) {
  float c;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_sub(float a, float b) {
  float c;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_mul(float a, float b) {
  float c;
  asm("mul.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_fma(float a, float b, float c) {
  float d;
  asm("fma.rn.f32 %0, %1, %2, %3;" : "=f"(d) : "f"(a), "f"(b), "f"(c));
  return d;
}

// max.f32 and min.f32: a NaN gives way to the other operand.
__device__ __forceinline__ float vllm_topk_max(float a, float b) {
  float c;
  asm("max.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_min(float a, float b) {
  float c;
  asm("min.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}

// Ordered comparisons: false when either side is NaN.
__device__ __forceinline__ int vllm_topk_lt(float a, float b) { return a < b; }
__device__ __forceinline__ int vllm_topk_le(float a, float b) { return a <= b; }
__device__ __forceinline__ int vllm_topk_gt(float a, float b) { return a > b; }
__device__ __forceinline__ int vllm_topk_ge(float a, float b) { return a >= b; }
__device__ __forceinline__ int vllm_topk_eq(float a, float b) { return a == b; }

// tl.abs(a - b) < 1e-9, the tolerance of the pivot searches.
__device__ __forceinline__ int vllm_topk_near(float a, float b) {
  float d;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(d) : "f"(a), "f"(b));
  return fabsf(d) < __int_as_float(0x3089705F);
}

// tl.cast to uint32 and to int32: cvt.rzi, saturating, NaN to 0.
__device__ __forceinline__ unsigned int vllm_topk_u32(float x) {
  unsigned int y;
  asm("cvt.rzi.u32.f32 %0, %1;" : "=r"(y) : "f"(x));
  return y;
}
__device__ __forceinline__ int vllm_topk_i32(float x) {
  int y;
  asm("cvt.rzi.s32.f32 %0, %1;" : "=r"(y) : "f"(x));
  return y;
}

// The warp's ballot of a flag, a ballot's flags, and its flags below this lane.
__device__ __forceinline__ unsigned int vllm_topk_ballot(int flag) {
  return __ballot_sync(0xffffffffu, flag);
}
__device__ __forceinline__ int vllm_topk_popc(unsigned int mask) {
  return __popc(mask);
}
__device__ __forceinline__ int vllm_topk_below(unsigned int mask) {
  unsigned int lower;
  asm("mov.u32 %0, %%lanemask_lt;" : "=r"(lower));
  return __popc(mask & lower);
}

// The warp's sum of an integer, its inclusive prefix sums over the lanes, and the
// value of a lane.
__device__ __forceinline__ int vllm_topk_warp_count(int v) {
  return __reduce_add_sync(0xffffffffu, v);
}
__device__ __forceinline__ int vllm_topk_warp_scan(int v) {
  const int lane = threadIdx.x & 31;
#pragma unroll
  for (int d = 1; d < 32; d <<= 1) {
    const int u = __shfl_up_sync(0xffffffffu, v, d);
    if (lane >= d) v += u;
  }
  return v;
}
__device__ __forceinline__ int vllm_topk_lane(int v, int lane) {
  return __shfl_sync(0xffffffffu, v, lane);
}

// Whether any thread of the block passes a nonzero flag (a barrier).
__device__ __forceinline__ int vllm_topk_any(int flag) {
  return __syncthreads_or(flag);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void topp_mask_kernel(float* __restrict__ logits, const float* __restrict__ p, const float* __restrict__ parts, const float* __restrict__ stats, int64_t logits_stride, int rows);
extern "C" __global__ void __launch_bounds__(256, 1) topp_mask_kernel(float* __restrict__ logits, const float* __restrict__ p, const float* __restrict__ parts, const float* __restrict__ stats, int64_t logits_stride, int rows) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* red_i = ((void*)((char*)buf_dyn_shmem + 0));
  void* red = ((void*)((char*)buf_dyn_shmem + 1152));
  float part_max = 0x0p+0f/*0.000000e+00*/;
  float part_sum = 0x0p+0f/*0.000000e+00*/;
  float least[1];
  float finite[1];
  float top[1];
  float weight = 0x0p+0f/*0.000000e+00*/;
  float norm_1[1];
  float hi[1];
  float lo[1];
  int live[1];
  float state[12];
  int masking = 0;
  float pivot_logit = 0x0p+0f/*0.000000e+00*/;
  int ties = 0;
  int fin_round = 0;
  int fin_slot = 0;
  float preceding[1];
  int counting = 0;
  float part_minl = 0x0p+0f/*0.000000e+00*/;
  float part_nmin = 0x0p+0f/*0.000000e+00*/;
  float mass[1];
  float gmin[1];
  float nmin[1];
  float ladder[1];
  float mark[4];
  float pick[8];
  float best_sel = 0x0p+0f/*0.000000e+00*/;
  float sel_mass = 0x0p+0f/*0.000000e+00*/;
  float values[32];
  int flags[32];
  uint masks[32];
  int runs[32];
  int total[1];
  int entries[8];
  int inclusive = 0;
  int before = 0;
  int ranks[32];
  int rank = 0;
  int keep = 0;
  float threshold = p[(((int64_t)((int)blockIdx.x)) >> (int64_t)5)];
  bool if_condition = (vllm_topk_ge(p[(((int64_t)((int)blockIdx.x)) >> (int64_t)5)], 0x1p+0f/*1.000000e+00*/) == 0);
  if (if_condition) {
    part_max = stats[(((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4))];
    part_sum = stats[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4)) + (int64_t)1)];
    least[0] = stats[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4)) + (int64_t)2)];
    finite[0] = stats[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)128) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)4)) + (int64_t)3)];
    top[0] = part_max;
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 16, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 8, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 4, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 2, 32));
    top[0] = vllm_topk_max(top[0], __shfl_xor_sync((uint)4294967295, top[0], 1, 32));
    float condval;
    if ((vllm_topk_eq(part_max, -CUDART_INF_F) != 0)) {
      condval = 0x0p+0f/*0.000000e+00*/;
    } else {
      condval = vllm_topk_exp(vllm_topk_sub(part_max, top[0]));
    }
    weight = condval;
    norm_1[0] = vllm_topk_fma(weight, part_sum, __shfl_xor_sync((uint)4294967295, vllm_topk_mul(weight, part_sum), 16, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 8, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 4, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 2, 32));
    norm_1[0] = vllm_topk_add(norm_1[0], __shfl_xor_sync((uint)4294967295, norm_1[0], 1, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 16, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 8, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 4, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 2, 32));
    least[0] = vllm_topk_min(least[0], __shfl_xor_sync((uint)4294967295, least[0], 1, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 16, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 8, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 4, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 2, 32));
    finite[0] = vllm_topk_add(finite[0], __shfl_xor_sync((uint)4294967295, finite[0], 1, 32));
    hi[0] = vllm_topk_div(0x1p+0f/*1.000000e+00*/, norm_1[0]);
    lo[0] = vllm_topk_max(vllm_topk_div(vllm_topk_exp(vllm_topk_sub(least[0], top[0])), norm_1[0]), 0x1.4484bfeebc2ap-100f/*1.000000e-30*/);
    live[0] = ((int)(((vllm_topk_le(norm_1[0], 0x0p+0f/*0.000000e+00*/) == 0) & (vllm_topk_lt(finite[0], 0x1p+0f/*1.000000e+00*/) == 0)) & (vllm_topk_le(hi[0], vllm_topk_mul(lo[0], 0x1.000010c6f7a0bp+0f/*1.000001e+00*/)) == 0)));
    state[0] = -0x1p+0f/*-1.000000e+00*/;
    state[1] = 0x0p+0f/*0.000000e+00*/;
    state[2] = 0x1p+0f/*1.000000e+00*/;
    state[3] = 0x0p+0f/*0.000000e+00*/;
    state[4] = ((float)(1 - live[0]));
    state[5] = ((float)(1 - live[0]));
    state[6] = 0x0p+0f/*0.000000e+00*/;
    state[7] = 0x1p+0f/*1.000000e+00*/;
    state[8] = 0x1p+0f/*1.000000e+00*/;
    state[9] = 0x1p+0f/*1.000000e+00*/;
    state[10] = -0x1p+0f/*-1.000000e+00*/;
    state[11] = -0x1p+0f/*-1.000000e+00*/;
    bool if_condition_1 = (vllm_topk_any(live[0]) != 0);
    if (if_condition_1) {
      for (int round_index = 0; round_index < 5; ++round_index) {
        bool if_condition_2 = (vllm_topk_any(((int)(vllm_topk_eq(state[4], 0x0p+0f/*0.000000e+00*/) != 0))) != 0);
        if (if_condition_2) {
          part_minl = parts[(((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)round_index) * (int64_t)768)) + (((int64_t)((int)threadIdx.x)) * (int64_t)3)) + (int64_t)1)];
          part_nmin = parts[(((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)round_index) * (int64_t)768)) + (((int64_t)((int)threadIdx.x)) * (int64_t)3)) + (int64_t)2)];
          mass[0] = parts[((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)round_index) * (int64_t)768)) + (((int64_t)((int)threadIdx.x)) * (int64_t)3))];
          gmin[0] = part_minl;
          mass[0] = vllm_topk_add(mass[0], __shfl_xor_sync((uint)4294967295, mass[0], 16, 32));
          mass[0] = vllm_topk_add(mass[0], __shfl_xor_sync((uint)4294967295, mass[0], 8, 32));
          gmin[0] = vllm_topk_min(gmin[0], __shfl_xor_sync((uint)4294967295, gmin[0], 16, 32));
          gmin[0] = vllm_topk_min(gmin[0], __shfl_xor_sync((uint)4294967295, gmin[0], 8, 32));
          __syncthreads();
          if (((((int)threadIdx.x) & 31) < 8) & (bool)1) {
            ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + (((int)threadIdx.x) >> 5))] = mass[0];
            ((float*)red)[((((((int)threadIdx.x) & 7) * 8) + (((int)threadIdx.x) >> 5)) + 64)] = gmin[0];
          }
          __syncthreads();
          mass[0] = vllm_topk_add(vllm_topk_add(vllm_topk_add(((float*)red)[((((int)threadIdx.x) & 7) * 8)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 4)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 2)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 6)])), vllm_topk_add(vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 1)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 5)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 3)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 7)])));
          gmin[0] = vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 64)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 65)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 66)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 67)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 68)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 69)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 70)]), ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 71)]);
          float condval_1;
          if ((vllm_topk_near(part_minl, gmin[0]) != 0)) {
            condval_1 = part_nmin;
          } else {
            condval_1 = 0x0p+0f/*0.000000e+00*/;
          }
          nmin[0] = condval_1;
          nmin[0] = vllm_topk_add(nmin[0], __shfl_xor_sync((uint)4294967295, nmin[0], 16, 32));
          nmin[0] = vllm_topk_add(nmin[0], __shfl_xor_sync((uint)4294967295, nmin[0], 8, 32));
          __syncthreads();
          if (((((int)threadIdx.x) & 31) < 8) & (bool)1) {
            ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + (((int)threadIdx.x) >> 5))] = nmin[0];
          }
          __syncthreads();
          nmin[0] = vllm_topk_add(vllm_topk_add(vllm_topk_add(((float*)red)[((((int)threadIdx.x) & 7) * 8)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 4)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 2)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 6)])), vllm_topk_add(vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 1)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 5)]), vllm_topk_add(((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 3)], ((float*)red)[(((((int)threadIdx.x) & 7) * 8) + 7)])));
          ladder[0] = vllm_topk_mul(lo[0], vllm_topk_exp(vllm_topk_div(vllm_topk_mul(vllm_control_log(vllm_topk_div(hi[0], lo[0])), ((float)((((int)threadIdx.x) & 7) + 1))), 0x1.2p+3f/*9.000000e+00*/)));
          bool ge = (vllm_topk_ge(mass[0], threshold) != 0);
          float condval_2;
          if ((ge & (vllm_topk_lt(vllm_topk_fma((gmin[0] * -0x1p+0f/*-1.000000e+00*/), nmin[0], mass[0]), threshold) != 0))) {
            condval_2 = ((float)(((int)threadIdx.x) & 7));
          } else {
            condval_2 = -0x1p+0f/*-1.000000e+00*/;
          }
          mark[0] = condval_2;
          float condval_3;
          if (ge) {
            condval_3 = ((float)(((int)threadIdx.x) & 7));
          } else {
            condval_3 = -0x1p+0f/*-1.000000e+00*/;
          }
          mark[1] = condval_3;
          float condval_4;
          if (ge) {
            condval_4 = ladder[0];
          } else {
            condval_4 = -CUDART_INF_F;
          }
          mark[2] = condval_4;
          float condval_5;
          if (ge) {
            condval_5 = CUDART_INF_F;
          } else {
            condval_5 = ladder[0];
          }
          mark[3] = condval_5;
          mark[0] = vllm_topk_max(mark[0], __shfl_xor_sync((uint)4294967295, mark[0], 4, 32));
          mark[0] = vllm_topk_max(mark[0], __shfl_xor_sync((uint)4294967295, mark[0], 2, 32));
          mark[0] = vllm_topk_max(mark[0], __shfl_xor_sync((uint)4294967295, mark[0], 1, 32));
          mark[1] = vllm_topk_max(mark[1], __shfl_xor_sync((uint)4294967295, mark[1], 4, 32));
          mark[1] = vllm_topk_max(mark[1], __shfl_xor_sync((uint)4294967295, mark[1], 2, 32));
          mark[1] = vllm_topk_max(mark[1], __shfl_xor_sync((uint)4294967295, mark[1], 1, 32));
          mark[2] = vllm_topk_max(mark[2], __shfl_xor_sync((uint)4294967295, mark[2], 4, 32));
          mark[2] = vllm_topk_max(mark[2], __shfl_xor_sync((uint)4294967295, mark[2], 2, 32));
          mark[2] = vllm_topk_max(mark[2], __shfl_xor_sync((uint)4294967295, mark[2], 1, 32));
          mark[3] = vllm_topk_min(mark[3], __shfl_xor_sync((uint)4294967295, mark[3], 4, 32));
          mark[3] = vllm_topk_min(mark[3], __shfl_xor_sync((uint)4294967295, mark[3], 2, 32));
          mark[3] = vllm_topk_min(mark[3], __shfl_xor_sync((uint)4294967295, mark[3], 1, 32));
          #pragma unroll
          for (int half = 0; half < 2; ++half) {
            bool mine = ((((int)threadIdx.x) & 7) == vllm_topk_i32(mark[half]));
            float condval_6;
            if (mine) {
              condval_6 = ladder[0];
            } else {
              condval_6 = 0x0p+0f/*0.000000e+00*/;
            }
            pick[(half * 4)] = condval_6;
            float condval_7;
            if (mine) {
              condval_7 = mass[0];
            } else {
              condval_7 = 0x0p+0f/*0.000000e+00*/;
            }
            pick[((half * 4) + 1)] = condval_7;
            float condval_8;
            if (mine) {
              condval_8 = gmin[0];
            } else {
              condval_8 = 0x0p+0f/*0.000000e+00*/;
            }
            pick[((half * 4) + 2)] = condval_8;
            float condval_9;
            if (mine) {
              condval_9 = nmin[0];
            } else {
              condval_9 = 0x0p+0f/*0.000000e+00*/;
            }
            pick[((half * 4) + 3)] = condval_9;
          }
          #pragma unroll
          for (int index = 0; index < 8; ++index) {
            pick[index] = vllm_topk_add(pick[index], __shfl_xor_sync((uint)4294967295, pick[index], 4, 32));
            pick[index] = vllm_topk_add(pick[index], __shfl_xor_sync((uint)4294967295, pick[index], 2, 32));
            pick[index] = vllm_topk_add(pick[index], __shfl_xor_sync((uint)4294967295, pick[index], 1, 32));
          }
          bool if_condition_3 = (vllm_topk_eq(state[4], 0x0p+0f/*0.000000e+00*/) != 0);
          if (if_condition_3) {
            best_sel = -0x1p+0f/*-1.000000e+00*/;
            if (vllm_topk_ge(mark[1], 0x0p+0f/*0.000000e+00*/) != 0) {
              bool if_condition_4 = (vllm_topk_gt(pick[4], state[0]) != 0);
              if (if_condition_4) {
                state[0] = pick[4];
                state[1] = pick[5];
                state[2] = pick[6];
                state[3] = pick[7];
                best_sel = mark[1];
              }
            }
            sel_mass = 0x0p+0f/*0.000000e+00*/;
            state[5] = 0x0p+0f/*0.000000e+00*/;
            state[6] = 0x0p+0f/*0.000000e+00*/;
            state[7] = 0x1p+0f/*1.000000e+00*/;
            state[8] = 0x1p+0f/*1.000000e+00*/;
            state[9] = 0x1p+0f/*1.000000e+00*/;
            if (vllm_topk_ge(mark[0], 0x0p+0f/*0.000000e+00*/) != 0) {
              state[6] = pick[0];
              sel_mass = pick[1];
              state[7] = pick[2];
              state[8] = pick[3];
              state[4] = 0x1p+0f/*1.000000e+00*/;
            } else {
              lo[0] = vllm_topk_max(lo[0], mark[2]);
              hi[0] = vllm_topk_min(hi[0], mark[3]);
              bool if_condition_5 = ((round_index == 4) | (vllm_topk_gt(hi[0], vllm_topk_mul(lo[0], 0x1.000001ad7f29bp+0f/*1.000000e+00*/)) == 0));
              if (if_condition_5) {
                if (vllm_topk_gt(state[0], 0x0p+0f/*0.000000e+00*/) != 0) {
                  state[6] = state[0];
                  sel_mass = state[1];
                  state[7] = state[2];
                  state[8] = state[3];
                } else {
                  state[5] = 0x1p+0f/*1.000000e+00*/;
                }
                state[4] = 0x1p+0f/*1.000000e+00*/;
              }
            }
            bool if_condition_6 = ((vllm_topk_eq(state[4], 0x0p+0f/*0.000000e+00*/) == 0) & (vllm_topk_eq(state[5], 0x0p+0f/*0.000000e+00*/) != 0));
            if (if_condition_6) {
              float condval_10;
              if ((vllm_topk_ge(vllm_topk_mul(state[6], norm_1[0]), 0x1p+0f/*1.000000e+00*/) != 0)) {
                condval_10 = 0x1p+0f/*1.000000e+00*/;
              } else {
                condval_10 = 0x0p+0f/*0.000000e+00*/;
              }
              state[5] = condval_10;
              state[9] = vllm_topk_min(vllm_topk_max(vllm_topk_sub(state[8], ((float)vllm_topk_u32(vllm_topk_div(vllm_topk_max(vllm_topk_sub(sel_mass, threshold), 0x0p+0f/*0.000000e+00*/), state[7])))), 0x1p+0f/*1.000000e+00*/), state[8]);
            }
            if (vllm_topk_ge(mark[0], 0x0p+0f/*0.000000e+00*/) != 0) {
              state[10] = vllm_topk_add(((float)(round_index * 8)), mark[0]);
            }
            if (vllm_topk_ge(best_sel, 0x0p+0f/*0.000000e+00*/) != 0) {
              state[11] = vllm_topk_add(((float)(round_index * 8)), best_sel);
            }
          }
        }
      }
      masking = ((int)(vllm_topk_eq(state[5], 0x0p+0f/*0.000000e+00*/) != 0));
      bool if_condition_7 = (vllm_topk_any(masking) != 0);
      if (if_condition_7) {
        if (vllm_topk_lt(state[10], 0x0p+0f/*0.000000e+00*/) != 0) {
          state[10] = state[11];
        }
        pivot_logit = vllm_topk_add(vllm_topk_add(vllm_control_log(state[6]), vllm_control_log(norm_1[0])), top[0]);
        ties = ((int)((masking != 0) & (vllm_topk_lt(state[9], state[8]) != 0)));
        fin_round = vllm_topk_i32(vllm_topk_div(state[10], 0x1p+3f/*8.000000e+00*/));
        fin_slot = vllm_topk_i32(vllm_topk_fma(((float)fin_round), -0x1p+3f/*-8.000000e+00*/, state[10]));
        preceding[0] = 0x0p+0f/*0.000000e+00*/;
        if (ties != 0) {
          if (((((int)threadIdx.x) & 31) < (((int)blockIdx.x) & 31)) & (vllm_topk_near(parts[((((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)fin_round) * (int64_t)768)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)24)) + (((int64_t)fin_slot) * (int64_t)3)) + (int64_t)1)], state[7]) != 0)) {
            preceding[0] = parts[((((((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * (int64_t)3840) + (((int64_t)fin_round) * (int64_t)768)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)31) * (int64_t)24)) + (((int64_t)fin_slot) * (int64_t)3)) + (int64_t)2)];
          }
        }
        preceding[0] = vllm_topk_add(preceding[0], __shfl_xor_sync((uint)4294967295, preceding[0], 16, 32));
        preceding[0] = vllm_topk_add(preceding[0], __shfl_xor_sync((uint)4294967295, preceding[0], 8, 32));
        preceding[0] = vllm_topk_add(preceding[0], __shfl_xor_sync((uint)4294967295, preceding[0], 4, 32));
        preceding[0] = vllm_topk_add(preceding[0], __shfl_xor_sync((uint)4294967295, preceding[0], 2, 32));
        preceding[0] = vllm_topk_add(preceding[0], __shfl_xor_sync((uint)4294967295, preceding[0], 1, 32));
        counting = ((int)(vllm_topk_any(((int)(ties != 0))) != 0));
        #pragma unroll
        for (int r = 0; r < 8; ++r) {
          if ((((r * 1024) + (((int)threadIdx.x) * 4)) + ((((int)blockIdx.x) & 31) * 4)) == ((((int)blockIdx.x) & 31) * 4)) {
            *(float4*)(values + (r * 4)) = *(float4*)(logits + ((((((int64_t)r) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride)));
          } else {
            #pragma unroll
            for (int v = 0; v < 4; ++v) {
              values[((r * 4) + v)] = -CUDART_INF_F;
              if (((r * 256) + ((int)threadIdx.x)) < 1) {
                values[((r * 4) + v)] = logits[(((((((int64_t)r) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride)) + ((int64_t)v))];
              }
            }
          }
        }
        if (counting != 0) {
          #pragma unroll
          for (int e = 0; e < 32; ++e) {
            flags[e] = ((int)((ties != 0) & (vllm_topk_eq(vllm_topk_div(vllm_topk_exp(vllm_topk_sub(values[e], top[0])), norm_1[0]), state[7]) != 0)));
          }
        }
        if (counting != 0) {
          #pragma unroll
          for (int e_1 = 0; e_1 < 32; ++e_1) {
            masks[e_1] = vllm_topk_ballot(flags[e_1]);
          }
        }
        if (counting != 0) {
          #pragma unroll
          for (int c = 0; c < 8; ++c) {
            runs[c] = 0;
            #pragma unroll
            for (int v_1 = 0; v_1 < 4; ++v_1) {
              runs[c] = (runs[c] + vllm_topk_popc(masks[((c * 4) + v_1)]));
            }
          }
        }
        if (counting != 0) {
          __syncthreads();
        }
        if (counting != 0) {
          if ((((int)threadIdx.x) % 32) == 0) {
            #pragma unroll
            for (int c_1 = 0; c_1 < 8; ++c_1) {
              ((int*)red_i)[(((c_1 * 8) + (((int)threadIdx.x) >> 5)) + 32)] = runs[c_1];
            }
          }
        }
        if (counting != 0) {
          __syncthreads();
        }
        if (counting != 0) {
          total[0] = 0;
        }
        if (counting != 0) {
          #pragma unroll
          for (int q = 0; q < 2; ++q) {
            entries[q] = ((int*)red_i)[((((((int)threadIdx.x) & 31) * 2) + q) + 32)];
            total[0] = (total[0] + entries[q]);
          }
        }
        if (counting != 0) {
          inclusive = vllm_topk_warp_scan(total[0]);
        }
        if (counting != 0) {
          before = (inclusive - total[0]);
        }
        if (counting != 0) {
          #pragma unroll
          for (int q_1 = 0; q_1 < 2; ++q_1) {
            int condval_11;
            if ((q_1 < ((((int)threadIdx.x) & 63) >> 5))) {
              condval_11 = entries[q_1];
            } else {
              condval_11 = 0;
            }
            before = (before + condval_11);
          }
        }
        if (counting != 0) {
          total[0] = vllm_topk_lane(inclusive, 31);
        }
        if (counting != 0) {
          #pragma unroll
          for (int c_2 = 0; c_2 < 8; ++c_2) {
            rank = vllm_topk_lane(before, ((c_2 * 4) + (((int)threadIdx.x) >> 6)));
            #pragma unroll
            for (int v_2 = 0; v_2 < 4; ++v_2) {
              rank = (rank + vllm_topk_below(masks[((c_2 * 4) + v_2)]));
            }
            #pragma unroll
            for (int v_3 = 0; v_3 < 4; ++v_3) {
              ranks[((c_2 * 4) + v_3)] = rank;
              rank = (rank + flags[((c_2 * 4) + v_3)]);
            }
          }
        }
        #pragma unroll
        for (int e_2 = 0; e_2 < 32; ++e_2) {
          keep = ((int)(vllm_topk_gt(values[e_2], pivot_logit) != 0));
          if (counting != 0) {
            if (flags[e_2] != 0) {
              keep = (keep & ((int)(vllm_topk_le(vllm_topk_add(((float)(ranks[e_2] + 1)), preceding[0]), state[9]) != 0)));
            }
          }
          float condval_12;
          if ((keep != 0)) {
            condval_12 = values[e_2];
          } else {
            condval_12 = -CUDART_INF_F;
          }
          values[e_2] = condval_12;
        }
        if (masking != 0) {
          #pragma unroll
          for (int r_1 = 0; r_1 < 8; ++r_1) {
            if ((((r_1 * 1024) + (((int)threadIdx.x) * 4)) + ((((int)blockIdx.x) & 31) * 4)) == ((((int)blockIdx.x) & 31) * 4)) {
              *(float4*)(logits + ((((((int64_t)r_1) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride))) = *(float4*)(values + (r_1 * 4));
            } else {
              if (((r_1 * 256) + ((int)threadIdx.x)) < 1) {
                #pragma unroll
                for (int v_4 = 0; v_4 < 4; ++v_4) {
                  logits[(((((((int64_t)r_1) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride)) + ((int64_t)v_4))] = values[((r_1 * 4) + v_4)];
                }
              }
            }
          }
        }
      }
    }
  }
}

