
// Triton 3.5 philox_impl (triton/language/random.py) on 32-bit words, ten
// rounds; the first word.
__device__ __forceinline__ unsigned int vllm_philox(unsigned int c0, unsigned int c1,
                                                   unsigned int c2, unsigned int c3,
                                                   unsigned int k0, unsigned int k1) {
#pragma unroll
  for (int round = 0; round < 10; ++round) {
    const unsigned int a = c0;
    const unsigned int b = c2;
    c0 = __umulhi(0xCD9E8D57u, b) ^ c1 ^ k0;
    c2 = __umulhi(0xD2511F53u, a) ^ c3 ^ k1;
    c1 = 0xCD9E8D57u * b;
    c3 = 0xD2511F53u * a;
    k0 += 0x9E3779B9u;
    k1 += 0xBB67AE85u;
  }
  return c0;
}

// tl.randint(seed, offset) for an int64 seed and an int64 offset: the offset's
// low word, then its arithmetic high word.
__device__ __forceinline__ unsigned int vllm_randint64(long long seed,
                                                      long long offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox((unsigned int)offset, (unsigned int)(offset >> 32), 0u, 0u,
                     (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for an int64 seed and an int32 offset: Triton gives a
// 32-bit offset no high word.
__device__ __forceinline__ unsigned int vllm_randint64_offset32(long long seed,
                                                               unsigned int offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox(offset, 0u, 0u, 0u, (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for a uint32 seed (tl.randint's own result, widened
// with zeros) and an int32 offset (no high word).
__device__ __forceinline__ unsigned int vllm_randint32(unsigned int seed, int offset) {
  return vllm_philox((unsigned int)offset, 0u, 0u, 0u, seed, 0u);
}

// gumbel.py's FP32 noise of one Philox word, as Triton 3.5 compiles
// tl_rand32(includes_zero=False) and -tl.log(-tldevice.log1p(-u)) for sm_121a:
// uint_to_uniform_float, the clamp to _TL_RAND_MIN (0f2FFFFFFF), then libdevice's
// __nv_log1pf of 0 - u and __nv_logf of 0 - that, negated.
__device__ __forceinline__ float vllm_gumbel_noise(unsigned int word) {
  float noise;
  asm("{\n"
      ".reg .pred fin, inside, zero, tiny;\n"
      ".reg .b32 x, s, u, v, t, e, m, k, a, r, f, p, q, l, w, y, z, o;\n"
      // uint_to_uniform_float: where(x < 0, -x - 1, x) * 4.6566127342e-10
      "shr.s32 s, %1, 31;\n"
      "xor.b32 x, s, %1;\n"
      "cvt.rn.f32.s32 u, x;\n"
      "mul.rn.f32 u, u, 0f2FFFFFFF;\n"
      "max.f32 u, u, 0f2FFFFFFF;\n"
      // __nv_log1pf(v), v = 0 - u
      "sub.rn.f32 v, 0f00000000, u;\n"
      "add.rz.ftz.f32 t, v, 0f3F800000;\n"
      "add.s32 e, t, -1061158912;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, v, e;\n"
      "sub.s32 k, 1082130432, e;\n"
      "fma.rn.ftz.f32 a, 0f3E800000, k, 0fBF800000;\n"
      "add.rn.f32 r, a, m;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "mul.rn.f32 f, f, 0f34000000;\n"
      "fma.rn.ftz.f32 p, 0fBD39BF78, r, 0f3DD80012;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE0778E0;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E146475;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2A68DD;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CAF9E;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE800042;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAAE6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not a finite non-negative v: inside [-1, -0] keep, else fma(v, inf, inf);
      // then a zero v gives -0.
      "setp.lt.u32 fin, v, 2139095040;\n"
      "setp.lt.s32 inside, v, -1082130431;\n"
      "fma.rn.ftz.f32 w, v, 0f7F800000, 0f7F800000;\n"
      "selp.f32 w, l, w, inside;\n"
      "setp.eq.f32 zero, v, 0f00000000;\n"
      "selp.f32 w, 0f80000000, w, zero;\n"
      "selp.f32 l, l, w, fin;\n"
      // __nv_logf(y), y = 0 - log1p(v): subnormal y scaled by 2^23
      "sub.rn.f32 y, 0f00000000, l;\n"
      "setp.lt.f32 tiny, y, 0f00800000;\n"
      "mul.rn.f32 z, y, 0f4B000000;\n"
      "selp.f32 z, z, y, tiny;\n"
      "selp.f32 o, 0fC1B80000, 0f00000000, tiny;\n"
      "add.s32 e, z, -1059760811;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, z, e;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "fma.rn.ftz.f32 f, f, 0f34000000, o;\n"
      "add.rn.f32 r, m, 0fBF800000;\n"
      "fma.rn.ftz.f32 p, 0fBE055027, r, 0f3E1039F6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBDF8CDCC;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E0F2955;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2AD8B9;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CED0B;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE7FFF22;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAA78;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not finite non-negative: fma(z, inf, inf). The noise is 0 - logf(y), or
      // +inf where z is zero.
      "setp.lt.u32 fin, z, 2139095040;\n"
      "fma.rn.ftz.f32 w, z, 0f7F800000, 0f7F800000;\n"
      "selp.f32 l, l, w, fin;\n"
      "sub.rn.f32 l, 0f00000000, l;\n"
      "setp.eq.f32 zero, z, 0f00000000;\n"
      "selp.f32 %0, 0f7F800000, l, zero;\n"
      "}"
      : "=f"(noise)
      : "r"(word));
  return noise;
}

// A logit plus the noise of its word: Triton's FP32 add.
__device__ __forceinline__ float vllm_gumbel_score(float logit, unsigned int word) {
  const float noise = vllm_gumbel_noise(word);
  float score;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(score) : "f"(logit), "f"(noise));
  return score;
}

// Triton's FP32 `/`: div.full.f32.
__device__ __forceinline__ float vllm_div_full(float x, float y) {
  float q;
  asm("div.full.f32 %0, %1, %2;" : "=f"(q) : "f"(x), "f"(y));
  return q;
}

// dspark.greedy._first_argmax: keep (av, ai) over (bv, bi) when av is NaN and bv
// is not or has a higher index, or neither is NaN and av > bv, or av == bv with
// ai < bi: torch.argmax's first maximum, NaN above everything. Bitwise, not
// short-circuit, operators: every comparison is evaluated and combined in
// predicates, as Triton's tl.where combine is, instead of a branch for each.
__device__ __forceinline__ int vllm_first_argmax_keep(float av, int ai, float bv,
                                                      int bi) {
  const bool a_nan = av != av;
  const bool b_nan = bv != bv;
  return (a_nan & (!b_nan | (ai < bi))) |
         (!a_nan & !b_nan & ((av > bv) | ((av == bv) & (ai < bi))));
}

// tl.max(..., return_indices=True)'s combine (tie break to the left): keep
// (v, i) over (w, j) when v > w, or v == w and i < j. Comparisons with NaN are
// false. Compiled here, out of the TileLang simplifier's reach; bitwise
// operators, as above.
__device__ __forceinline__ int vllm_argmax_keep(float v, int i, float w, int j) {
  return (v > w) | ((v == w) & (i < j));
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void finish_argmax_kernel(const int* __restrict__ indices, int64_t* __restrict__ out, const float* __restrict__ values, int out_rows, int64_t out_stride, int parts);
extern "C" __global__ void __launch_bounds__(32, 1) finish_argmax_kernel(const int* __restrict__ indices, int64_t* __restrict__ out, const float* __restrict__ values, int out_rows, int64_t out_stride, int parts) {
  float v[1];
  int ix[1];
  float best[1];
  int best_index[1];
  float other[1];
  int other_index[1];
  int keep = 0;
  int keep_1 = 0;
  int keep_2 = 0;
  int keep_3 = 0;
  int keep_4 = 0;
  float condval;
  if ((((int)threadIdx.x) < parts)) {
    condval = values[((((int64_t)((int)blockIdx.x)) * ((int64_t)parts)) + ((int64_t)min(((int)threadIdx.x), (parts - 1))))];
  } else {
    condval = -CUDART_INF_F;
  }
  v[0] = condval;
  int condval_1;
  if ((((int)threadIdx.x) < parts)) {
    condval_1 = indices[((((int64_t)((int)blockIdx.x)) * ((int64_t)parts)) + ((int64_t)min(((int)threadIdx.x), (parts - 1))))];
  } else {
    condval_1 = 2147483647;
  }
  ix[0] = condval_1;
  best[0] = v[0];
  best_index[0] = ix[0];
  other[0] = __shfl_xor_sync((uint)4294967295, best[0], 16, 32);
  other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 16, 32);
  float value = other[0];
  int index = other_index[0];
  keep = vllm_first_argmax_keep(best[0], best_index[0], value, index);
  int condval_2;
  if ((keep != 0)) {
    condval_2 = best_index[0];
  } else {
    condval_2 = index;
  }
  best_index[0] = condval_2;
  float condval_3;
  if ((keep != 0)) {
    condval_3 = best[0];
  } else {
    condval_3 = value;
  }
  best[0] = condval_3;
  other[0] = __shfl_xor_sync((uint)4294967295, best[0], 8, 32);
  other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 8, 32);
  float value_1 = other[0];
  int index_1 = other_index[0];
  keep_1 = vllm_first_argmax_keep(best[0], best_index[0], value_1, index_1);
  int condval_4;
  if ((keep_1 != 0)) {
    condval_4 = best_index[0];
  } else {
    condval_4 = index_1;
  }
  best_index[0] = condval_4;
  float condval_5;
  if ((keep_1 != 0)) {
    condval_5 = best[0];
  } else {
    condval_5 = value_1;
  }
  best[0] = condval_5;
  other[0] = __shfl_xor_sync((uint)4294967295, best[0], 4, 32);
  other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 4, 32);
  float value_2 = other[0];
  int index_2 = other_index[0];
  keep_2 = vllm_first_argmax_keep(best[0], best_index[0], value_2, index_2);
  int condval_6;
  if ((keep_2 != 0)) {
    condval_6 = best_index[0];
  } else {
    condval_6 = index_2;
  }
  best_index[0] = condval_6;
  float condval_7;
  if ((keep_2 != 0)) {
    condval_7 = best[0];
  } else {
    condval_7 = value_2;
  }
  best[0] = condval_7;
  other[0] = __shfl_xor_sync((uint)4294967295, best[0], 2, 32);
  other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 2, 32);
  float value_3 = other[0];
  int index_3 = other_index[0];
  keep_3 = vllm_first_argmax_keep(best[0], best_index[0], value_3, index_3);
  int condval_8;
  if ((keep_3 != 0)) {
    condval_8 = best_index[0];
  } else {
    condval_8 = index_3;
  }
  best_index[0] = condval_8;
  float condval_9;
  if ((keep_3 != 0)) {
    condval_9 = best[0];
  } else {
    condval_9 = value_3;
  }
  best[0] = condval_9;
  other[0] = __shfl_xor_sync((uint)4294967295, best[0], 1, 32);
  other_index[0] = __shfl_xor_sync((uint)4294967295, best_index[0], 1, 32);
  float value_4 = other[0];
  int index_4 = other_index[0];
  keep_4 = vllm_first_argmax_keep(best[0], best_index[0], value_4, index_4);
  int condval_10;
  if ((keep_4 != 0)) {
    condval_10 = best_index[0];
  } else {
    condval_10 = index_4;
  }
  best_index[0] = condval_10;
  float condval_11;
  if ((keep_4 != 0)) {
    condval_11 = best[0];
  } else {
    condval_11 = value_4;
  }
  best[0] = condval_11;
  if (((int)threadIdx.x) == 0) {
    out[(((int64_t)((int)blockIdx.x)) * out_stride)] = ((int64_t)best_index[0]);
  }
}

