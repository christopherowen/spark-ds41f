// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* finish_argmax_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_finish_argmax(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_finish_argmax(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[11];
  void* stack_ffi_any = stack;
  if (!((num_args == 7))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "finish_argmax: num_args should be 7", (long long)(num_args), (long long)(7));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "finish_argmax: args pointer is NULL");
    return -1;
  }
  int32_t values_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((values_handle_type_index == 0) || (values_handle_type_index == 4)) || (values_handle_type_index == 7)) || (64 <= values_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input values expected pointer or tensor handle");
    return -1;
  }
  int32_t indices_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((indices_handle_type_index == 0) || (indices_handle_type_index == 4)) || (indices_handle_type_index == 7)) || (64 <= indices_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input indices expected pointer or tensor handle");
    return -1;
  }
  int32_t out_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((out_handle_type_index == 0) || (out_handle_type_index == 4)) || (out_handle_type_index == 7)) || (64 <= out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input out expected pointer or tensor handle");
    return -1;
  }
  int32_t parts_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((parts_type_index == 1) || (parts_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax scalar parts expected integer");
    return -1;
  }
  int32_t out_rows_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((out_rows_type_index == 1) || (out_rows_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax scalar out_rows expected integer");
    return -1;
  }
  int32_t out_stride_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((out_stride_type_index == 1) || (out_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax scalar out_stride expected integer");
    return -1;
  }
  int32_t vocab_start_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((vocab_start_type_index == 1) || (vocab_start_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax scalar vocab_start expected integer");
    return -1;
  }
  void* values_handle = ((values_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* indices_handle = ((indices_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* out_handle = ((out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  int32_t parts = ((int32_t)(((TVMFFIAny*)args)[3].v_int64));
  int32_t out_rows = ((int32_t)(((TVMFFIAny*)args)[4].v_int64));
  int64_t out_stride = (((TVMFFIAny*)args)[5].v_int64);
  bool finish_argmax_values_is_null = (values_handle == NULL);
  if (!(!finish_argmax_values_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "finish_argmax.values is expected to have non-NULL pointer");
    return -1;
  }
  bool finish_argmax_indices_is_null = (indices_handle == NULL);
  if (!(!finish_argmax_indices_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "finish_argmax.indices is expected to have non-NULL pointer");
    return -1;
  }
  bool finish_argmax_out_is_null = (out_handle == NULL);
  if (!(!finish_argmax_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "finish_argmax.out is expected to have non-NULL pointer");
    return -1;
  }
  void* finish_argmax_values_shape = (((DLTensor*)values_handle)[0].shape);
  void* finish_argmax_indices_shape = (((DLTensor*)indices_handle)[0].shape);
  void* finish_argmax_out_shape = (((DLTensor*)out_handle)[0].shape);
  if (!(((((DLTensor*)values_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input values ndim mismatch, expected 1", (long long)((((DLTensor*)values_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t values_len = ((int32_t)((int64_t*)finish_argmax_values_shape)[0]);
  void* finish_argmax_values_strides = (((DLTensor*)values_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)values_handle)[0].device.device_id);
  void* values = (((DLTensor*)values_handle)[0].data);
  if (!(((((DLTensor*)indices_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input indices ndim mismatch, expected 1", (long long)((((DLTensor*)indices_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t indices_len = ((int32_t)((int64_t*)finish_argmax_indices_shape)[0]);
  void* finish_argmax_indices_strides = (((DLTensor*)indices_handle)[0].strides);
  void* indices = (((DLTensor*)indices_handle)[0].data);
  if (!(((((DLTensor*)out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input out ndim mismatch, expected 1", (long long)((((DLTensor*)out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t out_len = ((int32_t)((int64_t*)finish_argmax_out_shape)[0]);
  void* finish_argmax_out_strides = (((DLTensor*)out_handle)[0].strides);
  void* out = (((DLTensor*)out_handle)[0].data);
  if (!(((((((DLTensor*)values_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)values_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)values_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input values dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval;
  if ((finish_argmax_values_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)finish_argmax_values_strides)[0]);
  }
  if (!(((condval == 1) || (values_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input values strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)values_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input values byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)values_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)values_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input values device_type mismatch, expected cuda", (long long)((((DLTensor*)values_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((values_len == 0) || !(values == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input values data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)indices_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)indices_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)indices_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input indices dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_1;
  if ((finish_argmax_indices_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)finish_argmax_indices_strides)[0]);
  }
  if (!(((condval_1 == 1) || (indices_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input indices strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)indices_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input indices byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)indices_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_id) == (((DLTensor*)values_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input indices device_id violates packed ABI constraint", (long long)((((DLTensor*)indices_handle)[0].device.device_id)), (long long)((((DLTensor*)values_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input indices device_type mismatch, expected cuda", (long long)((((DLTensor*)indices_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((indices_len == 0) || !(indices == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input indices data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)out_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input out dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_2;
  if ((finish_argmax_out_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)finish_argmax_out_strides)[0]);
  }
  if (!(((condval_2 == 1) || (out_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_id) == (((DLTensor*)values_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input out device_id violates packed ABI constraint", (long long)((((DLTensor*)out_handle)[0].device.device_id)), (long long)((((DLTensor*)values_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel finish_argmax input out device_type mismatch, expected cuda", (long long)((((DLTensor*)out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((out_len == 0) || !(out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel finish_argmax input out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (indices == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = indices;
  if (out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = out;
  if (values == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = values;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)out_rows);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = out_stride;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)parts);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)out_rows);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = (int64_t)0;
  if (finish_argmax_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "finish_argmax_kernel", &finish_argmax_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(finish_argmax_kernel_packed, (TVMFFIAny*) stack_ffi_any, 10, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_finish_argmax(self, args, num_args, result);
}
