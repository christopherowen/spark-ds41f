// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* topk_log_softmax_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_topk_log_softmax(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_topk_log_softmax(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[13];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "topk_log_softmax: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "topk_log_softmax: args pointer is NULL");
    return -1;
  }
  int32_t output_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((output_handle_type_index == 0) || (output_handle_type_index == 4)) || (output_handle_type_index == 7)) || (64 <= output_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input output expected pointer or tensor handle");
    return -1;
  }
  int32_t logits_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((logits_handle_type_index == 0) || (logits_handle_type_index == 4)) || (logits_handle_type_index == 7)) || (64 <= logits_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input logits expected pointer or tensor handle");
    return -1;
  }
  int32_t token_ids_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((token_ids_handle_type_index == 0) || (token_ids_handle_type_index == 4)) || (token_ids_handle_type_index == 7)) || (64 <= token_ids_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input token_ids expected pointer or tensor handle");
    return -1;
  }
  int32_t valid_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((valid_handle_type_index == 0) || (valid_handle_type_index == 4)) || (valid_handle_type_index == 7)) || (64 <= valid_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid expected pointer or tensor handle");
    return -1;
  }
  void* output_handle = ((output_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* logits_handle = ((logits_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* token_ids_handle = ((token_ids_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* valid_handle = ((valid_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool topk_log_softmax_output_is_null = (output_handle == NULL);
  if (!(!topk_log_softmax_output_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "topk_log_softmax.output is expected to have non-NULL pointer");
    return -1;
  }
  bool topk_log_softmax_logits_is_null = (logits_handle == NULL);
  if (!(!topk_log_softmax_logits_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "topk_log_softmax.logits is expected to have non-NULL pointer");
    return -1;
  }
  bool topk_log_softmax_token_ids_is_null = (token_ids_handle == NULL);
  if (!(!topk_log_softmax_token_ids_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "topk_log_softmax.token_ids is expected to have non-NULL pointer");
    return -1;
  }
  bool topk_log_softmax_valid_is_null = (valid_handle == NULL);
  void* topk_log_softmax_output_shape = (((DLTensor*)output_handle)[0].shape);
  void* topk_log_softmax_logits_shape = (((DLTensor*)logits_handle)[0].shape);
  void* topk_log_softmax_token_ids_shape = (((DLTensor*)token_ids_handle)[0].shape);
  void* condval;
  if (!topk_log_softmax_valid_is_null) {
    condval = (((DLTensor*)valid_handle)[0].shape);
  } else {
    uint64_t v_ = (uint64_t)0;
    condval = (*(void* *)(&(v_)));
  }
  void* topk_log_softmax_valid_shape = condval;
  if (!(((((DLTensor*)output_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input output ndim mismatch, expected 2", (long long)((((DLTensor*)output_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: topk_log_softmax.output, topk_log_softmax.logits, topk_log_softmax.token_ids");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)topk_log_softmax_output_shape)[0]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable topk requires at least one non-null buffer among: topk_log_softmax.output, topk_log_softmax.token_ids");
    return -1;
  }
  int32_t topk = ((int32_t)((int64_t*)topk_log_softmax_output_shape)[1]);
  void* topk_log_softmax_output_strides = (((DLTensor*)output_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)output_handle)[0].device.device_id);
  void* output = (((DLTensor*)output_handle)[0].data);
  if (!(((((DLTensor*)logits_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input logits ndim mismatch, expected 2", (long long)((((DLTensor*)logits_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t vocab = ((int32_t)((int64_t*)topk_log_softmax_logits_shape)[1]);
  void* topk_log_softmax_logits_strides = (((DLTensor*)logits_handle)[0].strides);
  int64_t condval_1;
  if ((topk_log_softmax_logits_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)topk_log_softmax_logits_strides)[0];
  }
  int64_t logits_stride = condval_1;
  void* logits = (((DLTensor*)logits_handle)[0].data);
  if (!(((((DLTensor*)token_ids_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input token_ids ndim mismatch, expected 2", (long long)((((DLTensor*)token_ids_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* topk_log_softmax_token_ids_strides = (((DLTensor*)token_ids_handle)[0].strides);
  void* token_ids = (((DLTensor*)token_ids_handle)[0].data);
  if (!((topk_log_softmax_valid_is_null || ((((DLTensor*)valid_handle)[0].ndim) == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid ndim mismatch, expected 2");
    return -1;
  }
  int32_t condval_2;
  if (!topk_log_softmax_valid_is_null) {
    condval_2 = ((int32_t)((int64_t*)topk_log_softmax_valid_shape)[0]);
  } else {
    condval_2 = 0;
  }
  int32_t valid_rows = condval_2;
  int32_t condval_3;
  if (!topk_log_softmax_valid_is_null) {
    condval_3 = ((int32_t)((int64_t*)topk_log_softmax_valid_shape)[1]);
  } else {
    condval_3 = 0;
  }
  int32_t valid_cols = condval_3;
  void* condval_4;
  if (!topk_log_softmax_valid_is_null) {
    condval_4 = (((DLTensor*)valid_handle)[0].strides);
  } else {
    uint64_t v__1 = (uint64_t)0;
    condval_4 = (*(void* *)(&(v__1)));
  }
  void* topk_log_softmax_valid_strides = condval_4;
  void* condval_5;
  if (!topk_log_softmax_valid_is_null) {
    condval_5 = (((DLTensor*)valid_handle)[0].data);
  } else {
    uint64_t v__2 = (uint64_t)0;
    condval_5 = (*(void* *)(&(v__2)));
  }
  void* valid = condval_5;
  if (!(((((((DLTensor*)output_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)output_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)output_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input output dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_6;
  if ((topk_log_softmax_output_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)topk_log_softmax_output_strides)[1]);
  }
  if (!(((condval_6 == 1) || (topk == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input output strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_7;
  if ((topk_log_softmax_output_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)topk_log_softmax_output_strides)[0]);
  }
  if (!((((((int32_t)((int64_t*)topk_log_softmax_output_shape)[1]) == condval_7) || (((int32_t)((int64_t*)topk_log_softmax_output_shape)[1]) == 0)) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input output strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)output_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input output byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)output_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input output device_type mismatch, expected cuda", (long long)((((DLTensor*)output_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (topk == 0)) || !(output == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input output data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)logits_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)logits_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)logits_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input logits dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)topk_log_softmax_output_shape)[0]) == ((int32_t)((int64_t*)topk_log_softmax_logits_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input logits shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)topk_log_softmax_output_shape)[0])), (long long)(((int32_t)((int64_t*)topk_log_softmax_logits_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((topk_log_softmax_logits_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)topk_log_softmax_logits_strides)[1]);
  }
  if (!(((condval_8 == 1) || (vocab == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input logits strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)logits_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input logits byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)logits_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input logits device_id violates packed ABI constraint", (long long)((((DLTensor*)logits_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)logits_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input logits device_type mismatch, expected cuda", (long long)((((DLTensor*)logits_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (vocab == 0)) || !(logits == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input logits data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)token_ids_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)token_ids_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)token_ids_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input token_ids dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)topk_log_softmax_output_shape)[0]) == ((int32_t)((int64_t*)topk_log_softmax_token_ids_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input token_ids shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)topk_log_softmax_output_shape)[0])), (long long)(((int32_t)((int64_t*)topk_log_softmax_token_ids_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)topk_log_softmax_output_shape)[1]) == ((int32_t)((int64_t*)topk_log_softmax_token_ids_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input token_ids shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)topk_log_softmax_output_shape)[1])), (long long)(((int32_t)((int64_t*)topk_log_softmax_token_ids_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((topk_log_softmax_token_ids_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)topk_log_softmax_token_ids_strides)[1]);
  }
  if (!(((condval_9 == 1) || (topk == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input token_ids strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_10;
  if ((topk_log_softmax_token_ids_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)topk_log_softmax_token_ids_strides)[0]);
  }
  if (!((((((int32_t)((int64_t*)topk_log_softmax_output_shape)[1]) == condval_10) || (((int32_t)((int64_t*)topk_log_softmax_output_shape)[1]) == 0)) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input token_ids strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)token_ids_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input token_ids byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)token_ids_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)token_ids_handle)[0].device.device_id) == (((DLTensor*)output_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input token_ids device_id violates packed ABI constraint", (long long)((((DLTensor*)token_ids_handle)[0].device.device_id)), (long long)((((DLTensor*)output_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)token_ids_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel topk_log_softmax input token_ids device_type mismatch, expected cuda", (long long)((((DLTensor*)token_ids_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (topk == 0)) || !(token_ids == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input token_ids data pointer is NULL");
    return -1;
  }
  uint8_t condval_11;
  if (!topk_log_softmax_valid_is_null) {
    condval_11 = (((DLTensor*)valid_handle)[0].dtype.code);
  } else {
    condval_11 = (uint8_t)6;
  }
  uint8_t condval_12;
  if (!topk_log_softmax_valid_is_null) {
    condval_12 = (((DLTensor*)valid_handle)[0].dtype.bits);
  } else {
    condval_12 = (uint8_t)8;
  }
  uint16_t condval_13;
  if (!topk_log_softmax_valid_is_null) {
    condval_13 = (((DLTensor*)valid_handle)[0].dtype.lanes);
  } else {
    condval_13 = (uint16_t)1;
  }
  uint8_t condval_14;
  if (!topk_log_softmax_valid_is_null) {
    condval_14 = (((DLTensor*)valid_handle)[0].dtype.code);
  } else {
    condval_14 = (uint8_t)6;
  }
  uint8_t condval_15;
  if (!topk_log_softmax_valid_is_null) {
    condval_15 = (((DLTensor*)valid_handle)[0].dtype.bits);
  } else {
    condval_15 = (uint8_t)8;
  }
  uint16_t condval_16;
  if (!topk_log_softmax_valid_is_null) {
    condval_16 = (((DLTensor*)valid_handle)[0].dtype.lanes);
  } else {
    condval_16 = (uint16_t)1;
  }
  uint8_t condval_17;
  if (!topk_log_softmax_valid_is_null) {
    condval_17 = (((DLTensor*)valid_handle)[0].dtype.code);
  } else {
    condval_17 = (uint8_t)6;
  }
  uint8_t condval_18;
  if (!topk_log_softmax_valid_is_null) {
    condval_18 = (((DLTensor*)valid_handle)[0].dtype.bits);
  } else {
    condval_18 = (uint8_t)8;
  }
  uint16_t condval_19;
  if (!topk_log_softmax_valid_is_null) {
    condval_19 = (((DLTensor*)valid_handle)[0].dtype.lanes);
  } else {
    condval_19 = (uint16_t)1;
  }
  uint8_t condval_20;
  if (!topk_log_softmax_valid_is_null) {
    condval_20 = (((DLTensor*)valid_handle)[0].dtype.code);
  } else {
    condval_20 = (uint8_t)6;
  }
  uint8_t condval_21;
  if (!topk_log_softmax_valid_is_null) {
    condval_21 = (((DLTensor*)valid_handle)[0].dtype.bits);
  } else {
    condval_21 = (uint8_t)8;
  }
  uint16_t condval_22;
  if (!topk_log_softmax_valid_is_null) {
    condval_22 = (((DLTensor*)valid_handle)[0].dtype.lanes);
  } else {
    condval_22 = (uint16_t)1;
  }
  uint8_t condval_23;
  if (!topk_log_softmax_valid_is_null) {
    condval_23 = (((DLTensor*)valid_handle)[0].dtype.code);
  } else {
    condval_23 = (uint8_t)6;
  }
  uint8_t condval_24;
  if (!topk_log_softmax_valid_is_null) {
    condval_24 = (((DLTensor*)valid_handle)[0].dtype.bits);
  } else {
    condval_24 = (uint8_t)8;
  }
  uint16_t condval_25;
  if (!topk_log_softmax_valid_is_null) {
    condval_25 = (((DLTensor*)valid_handle)[0].dtype.lanes);
  } else {
    condval_25 = (uint16_t)1;
  }
  uint8_t condval_26;
  if (!topk_log_softmax_valid_is_null) {
    condval_26 = (((DLTensor*)valid_handle)[0].dtype.bits);
  } else {
    condval_26 = (uint8_t)8;
  }
  uint16_t condval_27;
  if (!topk_log_softmax_valid_is_null) {
    condval_27 = (((DLTensor*)valid_handle)[0].dtype.lanes);
  } else {
    condval_27 = (uint16_t)1;
  }
  if (!(((((((topk_log_softmax_valid_is_null || (((condval_11 == (uint8_t)6) && (condval_12 == (uint8_t)8)) && (condval_13 == (uint16_t)1))) || (((condval_14 == (uint8_t)0) && (condval_15 == (uint8_t)8)) && (condval_16 == (uint16_t)1))) || (((condval_17 == (uint8_t)1) && (condval_18 == (uint8_t)8)) && (condval_19 == (uint16_t)1))) || (((condval_20 == (uint8_t)6) && (condval_21 == (uint8_t)8)) && (condval_22 == (uint16_t)1))) || (((condval_23 == (uint8_t)6) && (condval_24 == (uint8_t)1)) && (condval_25 == (uint16_t)1))) || ((condval_26 == (uint8_t)1) && (condval_27 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid dtype mismatch, expected bool");
    return -1;
  }
  int32_t condval_28;
  if ((topk_log_softmax_valid_strides == NULL)) {
    condval_28 = 1;
  } else {
    condval_28 = ((int32_t)((int64_t*)topk_log_softmax_valid_strides)[1]);
  }
  if (!(((topk_log_softmax_valid_is_null || (condval_28 == 1)) || (valid_cols == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_29;
  if (!topk_log_softmax_valid_is_null) {
    condval_29 = ((int32_t)((int64_t*)topk_log_softmax_valid_shape)[1]);
  } else {
    condval_29 = 0;
  }
  int32_t condval_30;
  if ((topk_log_softmax_valid_strides == NULL)) {
    condval_30 = 1;
  } else {
    condval_30 = ((int32_t)((int64_t*)topk_log_softmax_valid_strides)[0]);
  }
  int32_t condval_31;
  if (!topk_log_softmax_valid_is_null) {
    condval_31 = ((int32_t)((int64_t*)topk_log_softmax_valid_shape)[1]);
  } else {
    condval_31 = 0;
  }
  if (!((((topk_log_softmax_valid_is_null || (condval_29 == condval_30)) || (condval_31 == 0)) || (valid_rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_32;
  if (!topk_log_softmax_valid_is_null) {
    condval_32 = (((DLTensor*)valid_handle)[0].byte_offset);
  } else {
    condval_32 = (uint64_t)0;
  }
  if (!((topk_log_softmax_valid_is_null || ((uint64_t)0 == condval_32)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_33;
  if (!topk_log_softmax_valid_is_null) {
    condval_33 = (((DLTensor*)valid_handle)[0].device.device_id);
  } else {
    condval_33 = 0;
  }
  if (!((topk_log_softmax_valid_is_null || (condval_33 == (((DLTensor*)output_handle)[0].device.device_id))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_34;
  if (!topk_log_softmax_valid_is_null) {
    condval_34 = (((DLTensor*)valid_handle)[0].device.device_type);
  } else {
    condval_34 = 0;
  }
  if (!((topk_log_softmax_valid_is_null || (condval_34 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid device_type mismatch, expected cuda");
    return -1;
  }
  if (!((((topk_log_softmax_valid_is_null || (valid_rows == 0)) || (valid_cols == 0)) || !(valid == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel topk_log_softmax input valid data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (!(((logits_stride % (int64_t)16) == (int64_t)0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: logits_stride % T.int64(16) == T.int64(0)", (long long)((logits_stride % (int64_t)16)), (long long)((int64_t)0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (logits == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = logits;
  if (output == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = output;
  if (token_ids == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = token_ids;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = logits_stride;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)topk);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)vocab);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)1024);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = (int64_t)0;
  if (topk_log_softmax_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "topk_log_softmax_kernel", &topk_log_softmax_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(topk_log_softmax_kernel_packed, (TVMFFIAny*) stack_ffi_any, 12, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_topk_log_softmax(self, args, num_args, result);
}
