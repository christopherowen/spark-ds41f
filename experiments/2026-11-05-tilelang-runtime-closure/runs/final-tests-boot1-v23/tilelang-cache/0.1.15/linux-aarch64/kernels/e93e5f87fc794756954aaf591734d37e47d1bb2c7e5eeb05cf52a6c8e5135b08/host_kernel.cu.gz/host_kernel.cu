// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* partial_argmax_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_partial_argmax(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_partial_argmax(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[15];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "partial_argmax: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "partial_argmax: args pointer is NULL");
    return -1;
  }
  int32_t base_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((base_handle_type_index == 0) || (base_handle_type_index == 4)) || (base_handle_type_index == 7)) || (64 <= base_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input base expected pointer or tensor handle");
    return -1;
  }
  int32_t bias_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((bias_handle_type_index == 0) || (bias_handle_type_index == 4)) || (bias_handle_type_index == 7)) || (64 <= bias_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input bias expected pointer or tensor handle");
    return -1;
  }
  int32_t values_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((values_handle_type_index == 0) || (values_handle_type_index == 4)) || (values_handle_type_index == 7)) || (64 <= values_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input values expected pointer or tensor handle");
    return -1;
  }
  int32_t indices_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((indices_handle_type_index == 0) || (indices_handle_type_index == 4)) || (indices_handle_type_index == 7)) || (64 <= indices_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input indices expected pointer or tensor handle");
    return -1;
  }
  void* base_handle = ((base_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* bias_handle = ((bias_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* values_handle = ((values_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* indices_handle = ((indices_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool partial_argmax_base_is_null = (base_handle == NULL);
  if (!(!partial_argmax_base_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "partial_argmax.base is expected to have non-NULL pointer");
    return -1;
  }
  bool partial_argmax_bias_is_null = (bias_handle == NULL);
  if (!(!partial_argmax_bias_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "partial_argmax.bias is expected to have non-NULL pointer");
    return -1;
  }
  bool partial_argmax_values_is_null = (values_handle == NULL);
  if (!(!partial_argmax_values_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "partial_argmax.values is expected to have non-NULL pointer");
    return -1;
  }
  bool partial_argmax_indices_is_null = (indices_handle == NULL);
  if (!(!partial_argmax_indices_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "partial_argmax.indices is expected to have non-NULL pointer");
    return -1;
  }
  void* partial_argmax_base_shape = (((DLTensor*)base_handle)[0].shape);
  void* partial_argmax_bias_shape = (((DLTensor*)bias_handle)[0].shape);
  void* partial_argmax_values_shape = (((DLTensor*)values_handle)[0].shape);
  void* partial_argmax_indices_shape = (((DLTensor*)indices_handle)[0].shape);
  if (!(((((DLTensor*)base_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input base ndim mismatch, expected 2", (long long)((((DLTensor*)base_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: partial_argmax.base, partial_argmax.bias");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)partial_argmax_base_shape)[0]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable vocab requires at least one non-null buffer among: partial_argmax.base, partial_argmax.bias");
    return -1;
  }
  int32_t vocab = ((int32_t)((int64_t*)partial_argmax_base_shape)[1]);
  void* partial_argmax_base_strides = (((DLTensor*)base_handle)[0].strides);
  int64_t condval;
  if ((partial_argmax_base_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)partial_argmax_base_strides)[0];
  }
  int64_t base_stride = condval;
  int32_t dev_id = (((DLTensor*)base_handle)[0].device.device_id);
  void* base = (((DLTensor*)base_handle)[0].data);
  if (!(((((DLTensor*)bias_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input bias ndim mismatch, expected 2", (long long)((((DLTensor*)bias_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* partial_argmax_bias_strides = (((DLTensor*)bias_handle)[0].strides);
  int64_t condval_1;
  if ((partial_argmax_bias_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)partial_argmax_bias_strides)[0];
  }
  int64_t bias_stride = condval_1;
  void* bias = (((DLTensor*)bias_handle)[0].data);
  if (!(((((DLTensor*)values_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input values ndim mismatch, expected 1", (long long)((((DLTensor*)values_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t values_len = ((int32_t)((int64_t*)partial_argmax_values_shape)[0]);
  void* partial_argmax_values_strides = (((DLTensor*)values_handle)[0].strides);
  void* values = (((DLTensor*)values_handle)[0].data);
  if (!(((((DLTensor*)indices_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input indices ndim mismatch, expected 1", (long long)((((DLTensor*)indices_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t indices_len = ((int32_t)((int64_t*)partial_argmax_indices_shape)[0]);
  void* partial_argmax_indices_strides = (((DLTensor*)indices_handle)[0].strides);
  void* indices = (((DLTensor*)indices_handle)[0].data);
  if (!(((((((DLTensor*)base_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)base_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)base_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input base dtype mismatch, expected float16");
    return -1;
  }
  int32_t condval_2;
  if ((partial_argmax_base_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)partial_argmax_base_strides)[1]);
  }
  if (!(((condval_2 == 1) || (vocab == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input base strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)base_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input base byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)base_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)base_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input base device_type mismatch, expected cuda", (long long)((((DLTensor*)base_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (vocab == 0)) || !(base == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input base data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)bias_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)bias_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)bias_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input bias dtype mismatch, expected float16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)partial_argmax_base_shape)[0]) == ((int32_t)((int64_t*)partial_argmax_bias_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input bias shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)partial_argmax_base_shape)[0])), (long long)(((int32_t)((int64_t*)partial_argmax_bias_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)partial_argmax_base_shape)[1]) == ((int32_t)((int64_t*)partial_argmax_bias_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input bias shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)partial_argmax_base_shape)[1])), (long long)(((int32_t)((int64_t*)partial_argmax_bias_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((partial_argmax_bias_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)partial_argmax_bias_strides)[1]);
  }
  if (!(((condval_3 == 1) || (vocab == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input bias strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)bias_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input bias byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)bias_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)bias_handle)[0].device.device_id) == (((DLTensor*)base_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input bias device_id violates packed ABI constraint", (long long)((((DLTensor*)bias_handle)[0].device.device_id)), (long long)((((DLTensor*)base_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)bias_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input bias device_type mismatch, expected cuda", (long long)((((DLTensor*)bias_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (vocab == 0)) || !(bias == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input bias data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)values_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)values_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)values_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input values dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_4;
  if ((partial_argmax_values_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)partial_argmax_values_strides)[0]);
  }
  if (!(((condval_4 == 1) || (values_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input values strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)values_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input values byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)values_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)values_handle)[0].device.device_id) == (((DLTensor*)base_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input values device_id violates packed ABI constraint", (long long)((((DLTensor*)values_handle)[0].device.device_id)), (long long)((((DLTensor*)base_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)values_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input values device_type mismatch, expected cuda", (long long)((((DLTensor*)values_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((values_len == 0) || !(values == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input values data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)indices_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)indices_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)indices_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input indices dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_5;
  if ((partial_argmax_indices_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)partial_argmax_indices_strides)[0]);
  }
  if (!(((condval_5 == 1) || (indices_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input indices strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)indices_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input indices byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)indices_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_id) == (((DLTensor*)base_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input indices device_id violates packed ABI constraint", (long long)((((DLTensor*)indices_handle)[0].device.device_id)), (long long)((((DLTensor*)base_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel partial_argmax input indices device_type mismatch, expected cuda", (long long)((((DLTensor*)indices_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((indices_len == 0) || !(indices == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel partial_argmax input indices data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (!(((base_stride % (int64_t)8) == (int64_t)0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: base_stride % T.int64(8) == T.int64(0)", (long long)((base_stride % (int64_t)8)), (long long)((int64_t)0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((bias_stride % (int64_t)8) == (int64_t)0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: bias_stride % T.int64(8) == T.int64(0)", (long long)((bias_stride % (int64_t)8)), (long long)((int64_t)0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((vocab % 8) == 0))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "Assume: vocab % 8 == 0", (long long)((vocab % 8)), (long long)(0));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (base == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = base;
  if (bias == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = bias;
  if (indices == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = indices;
  if (values == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = values;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = base_stride;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = bias_stride;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)vocab);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)((vocab + 2047) >> 11));
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = (int64_t)0;
  if (partial_argmax_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "partial_argmax_kernel", &partial_argmax_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(partial_argmax_kernel_packed, (TVMFFIAny*) stack_ffi_any, 14, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_partial_argmax(self, args, num_args, result);
}
