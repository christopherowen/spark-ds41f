
__device__ __forceinline__ void splitk_fence() { __threadfence(); }
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/atomic.h>
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gemm_bf16_splitk_kernel(const bfloat16_t* A, const bfloat16_t* B, float* C0, float* C1, float* P, int* counters, int M, int tiles);
extern "C" __global__ void __launch_bounds__(128, 1) gemm_bf16_splitk_kernel(const bfloat16_t* A, const bfloat16_t* B, float* C0, float* C1, float* P, int* counters, int M, int tiles) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* last = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 6144));
  float C_local[4];
  float C_block[4];
  float acc = 0x0p+0f/*0.000000e+00*/;
  cudaGridDependencySynchronize();
  cudaTriggerProgrammaticLaunchCompletion();
  float broadcast_var = 0x0p+0f/*0.000000e+00*/;
  *(float4*)(C_local + 0) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[(((((((int)threadIdx.x) >> 3) * 64) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A[((((((int64_t)((int)blockIdx.z)) * (int64_t)81920) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8))])), ((((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M) && (((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M)));
  #pragma unroll
  for (int i = 0; i < 2; ++i) {
    tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[(((((i * 1024) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B[(((((((int)blockIdx.x) * 163840) + (i * 81920)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8))])));
  }
  tl::cp_async_commit();
  tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[((((((((int)threadIdx.x) >> 3) * 64) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 1024)])), (&(A[(((((((int64_t)((int)blockIdx.z)) * (int64_t)81920) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)64)])), ((((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M) && (((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M)));
  #pragma unroll
  for (int i_1 = 0; i_1 < 2; ++i_1) {
    tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[((((((i_1 * 1024) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 2048)])), (&(B[((((((((int)blockIdx.x) * 163840) + (i_1 * 81920)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8)) + 64)])));
  }
  tl::cp_async_commit();
  tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[((((((((int)threadIdx.x) >> 3) * 64) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 2048)])), (&(A[(((((((int64_t)((int)blockIdx.z)) * (int64_t)81920) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)128)])), ((((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M) && (((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M)));
  #pragma unroll
  for (int i_2 = 0; i_2 < 2; ++i_2) {
    tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[((((((i_2 * 1024) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(B[((((((((int)blockIdx.x) * 163840) + (i_2 * 81920)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8)) + 128)])));
  }
  tl::cp_async_commit();
  for (int kb = 0; kb < 13; ++kb) {
    float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_block + 0) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    tl::cp_async_wait<2>();
    __syncthreads();
    {
      bfloat16_t A_local[8];
      bfloat16_t B_local[4];
      for (int ki = 0; ki < 4; ++ki) {
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((kb % 3) * 1024) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[0])));
        tl::ptx_ldmatrix_x2((&(((bfloat16_t*)B_shared)[(((((((kb % 3) * 2048) + ((((((int)threadIdx.x) >> 5) + ((((int)threadIdx.x) & 31) >> 4)) & 3) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[0])));
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + 0), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + 0));
      }
    }
    __syncthreads();
    tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[((((((kb % 3) * 1024) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A[((((((((int64_t)((int)blockIdx.z)) * (int64_t)81920) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + (((int64_t)kb) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)192)])), ((((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M) && (((((int)blockIdx.z) * 16) + (((int)threadIdx.x) >> 3)) < M)));
    #pragma unroll
    for (int i_3 = 0; i_3 < 2; ++i_3) {
      tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[(((((((kb % 3) * 2048) + (i_3 * 1024)) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B[(((((((((int)blockIdx.x) * 163840) + (i_3 * 81920)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + (kb * 64)) + ((((int)threadIdx.x) & 7) * 8)) + 192)])));
    }
    tl::cp_async_commit();
    float4 __1;
      float4 v_ = *(float4*)(C_local + 0);
      float4 v__1 = *(float4*)(C_block + 0);
      *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
      *(float2*)(&(__1.z)) = tl::add2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
    *(float4*)(C_local + 0) = __1;
  }
  float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
  *(float4*)(C_block + 0) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
  tl::cp_async_wait<2>();
  __syncthreads();
  {
    bfloat16_t A_local_1[8];
    bfloat16_t B_local_1[4];
    for (int ki_1 = 0; ki_1 < 4; ++ki_1) {
      tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((int)threadIdx.x) & 15) * 64) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 1024)])), (&(A_local_1[0])));
      tl::ptx_ldmatrix_x2((&(((bfloat16_t*)B_shared)[(((((((((((int)threadIdx.x) >> 5) + ((((int)threadIdx.x) & 31) >> 4)) & 3) * 512) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 2048)])), (&(B_local_1[0])));
      tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + 0), reinterpret_cast<const unsigned*>(A_local_1 + 0), reinterpret_cast<const unsigned*>(B_local_1 + 0));
    }
  }
  float4 __2;
    float4 v__2 = *(float4*)(C_local + 0);
    float4 v__3 = *(float4*)(C_block + 0);
    *(float2*)(&(__2.x)) = tl::add2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
    *(float2*)(&(__2.z)) = tl::add2(*(float2*)(&(v__2.z)), *(float2*)(&(v__3.z)));
  *(float4*)(C_local + 0) = __2;
  float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
  *(float4*)(C_block + 0) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
  tl::cp_async_wait<1>();
  __syncthreads();
  {
    bfloat16_t A_local_2[8];
    bfloat16_t B_local_2[4];
    for (int ki_2 = 0; ki_2 < 4; ++ki_2) {
      tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((int)threadIdx.x) & 15) * 64) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_2 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 2048)])), (&(A_local_2[0])));
      tl::ptx_ldmatrix_x2((&(((bfloat16_t*)B_shared)[(((((((((((int)threadIdx.x) >> 5) + ((((int)threadIdx.x) & 31) >> 4)) & 3) * 512) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_2 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(B_local_2[0])));
      tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + 0), reinterpret_cast<const unsigned*>(A_local_2 + 0), reinterpret_cast<const unsigned*>(B_local_2 + 0));
    }
  }
  float4 __3;
    float4 v__4 = *(float4*)(C_local + 0);
    float4 v__5 = *(float4*)(C_block + 0);
    *(float2*)(&(__3.x)) = tl::add2(*(float2*)(&(v__4.x)), *(float2*)(&(v__5.x)));
    *(float2*)(&(__3.z)) = tl::add2(*(float2*)(&(v__4.z)), *(float2*)(&(v__5.z)));
  *(float4*)(C_local + 0) = __3;
  float broadcast_var_4 = 0x0p+0f/*0.000000e+00*/;
  *(float4*)(C_block + 0) = make_float4(broadcast_var_4, broadcast_var_4, broadcast_var_4, broadcast_var_4);
  tl::cp_async_wait<0>();
  __syncthreads();
  {
    bfloat16_t A_local_3[8];
    bfloat16_t B_local_3[4];
    for (int ki_3 = 0; ki_3 < 4; ++ki_3) {
      tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[(((((((int)threadIdx.x) & 15) * 64) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_3 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_3 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local_3[0])));
      tl::ptx_ldmatrix_x2((&(((bfloat16_t*)B_shared)[((((((((((int)threadIdx.x) >> 5) + ((((int)threadIdx.x) & 31) >> 4)) & 3) * 512) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_3 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_3 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_3[0])));
      tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + 0), reinterpret_cast<const unsigned*>(A_local_3 + 0), reinterpret_cast<const unsigned*>(B_local_3 + 0));
    }
  }
  float4 __4;
    float4 v__6 = *(float4*)(C_local + 0);
    float4 v__7 = *(float4*)(C_block + 0);
    *(float2*)(&(__4.x)) = tl::add2(*(float2*)(&(v__6.x)), *(float2*)(&(v__7.x)));
    *(float2*)(&(__4.z)) = tl::add2(*(float2*)(&(v__6.z)), *(float2*)(&(v__7.z)));
  *(float4*)(C_local + 0) = __4;
  #pragma unroll
  for (int i_4 = 0; i_4 < 2; ++i_4) {
    if ((((((int)blockIdx.z) * 16) + (i_4 * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M) {
      *(float2*)(P + (((((((((int64_t)((int)blockIdx.z)) * (int64_t)4096) + (((int64_t)i_4) * (int64_t)2048)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)256)) + ((((int64_t)((int)blockIdx.y)) * ((int64_t)M)) * (int64_t)256)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2))) = *(float2*)(C_local + (i_4 * 2));
    }
  }
  splitk_fence();
  __syncthreads();
  if (((int)threadIdx.x) == 0) {
    int condval;
    if ((((((int)blockIdx.z) * 8) + ((int)blockIdx.x)) < tiles)) {
      condval = AtomicAddRet((&(counters[((((int64_t)((int)blockIdx.z)) * (int64_t)8) + ((int64_t)((int)blockIdx.x)))])), 1, 4);
    } else {
      condval = 0;
    }
    int arrived = condval;
    int condval_1;
    if ((arrived == 4)) {
      condval_1 = 1;
    } else {
      condval_1 = 0;
    }
    ((int*)last)[0] = condval_1;
  }
  __syncthreads();
  if (((int*)last)[0] == 1) {
    splitk_fence();
  }
  if (((int*)last)[0] == 1) {
    #pragma unroll
    for (int i_5 = 0; i_5 < 4; ++i_5) {
      if ((((((int)blockIdx.z) * 16) + (i_5 * 4)) + (((int)threadIdx.x) >> 5)) < M) {
        acc = P[(((((((int64_t)((int)blockIdx.z)) * (int64_t)4096) + (((int64_t)i_5) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)256)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + (((int64_t)((int)threadIdx.x)) & (int64_t)31))];
        for (int t = 1; t < 5; ++t) {
          acc = (acc + P[((((((((int64_t)((int)blockIdx.z)) * (int64_t)4096) + (((int64_t)i_5) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)256)) + ((((int64_t)t) * ((int64_t)M)) * (int64_t)256)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + (((int64_t)((int)threadIdx.x)) & (int64_t)31))]);
        }
        if (((int)blockIdx.x) < 4) {
          C0[(((((((int64_t)((int)blockIdx.z)) * (int64_t)2048) + (((int64_t)i_5) * (int64_t)512)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + (((int64_t)((int)threadIdx.x)) & (int64_t)31))] = acc;
        } else {
          C1[((((((((int64_t)((int)blockIdx.z)) * (int64_t)2048) + (((int64_t)i_5) * (int64_t)512)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)5) * (int64_t)128)) + (((int64_t)((int)blockIdx.x)) * (int64_t)32)) + (((int64_t)((int)threadIdx.x)) & (int64_t)31)) - (int64_t)128)] = acc;
        }
      }
    }
  }
  if (((int*)last)[0] == 1) {
    if (((int)threadIdx.x) == 0) {
      if (((((int)blockIdx.z) * 8) + ((int)blockIdx.x)) < tiles) {
        counters[((((int64_t)((int)blockIdx.z)) * (int64_t)8) + ((int64_t)((int)blockIdx.x)))] = 0;
      }
    }
  }
}

