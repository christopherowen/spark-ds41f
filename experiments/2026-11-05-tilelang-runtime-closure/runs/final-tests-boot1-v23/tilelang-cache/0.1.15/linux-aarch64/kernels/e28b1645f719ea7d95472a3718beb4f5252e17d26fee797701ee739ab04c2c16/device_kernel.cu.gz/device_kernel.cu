
template <int GROUP>
__device__ __forceinline__ void vllm_packed_bf16_histogram(
    const unsigned short* __restrict__ weight,
    int* __restrict__ histogram,
    int row, int K, int tx,
    int* __restrict__ s_hist) {
  s_hist[tx] = 0;
  s_hist[tx + GROUP] = 0;
  __syncthreads();
  const unsigned short* row_ptr = weight + (long long)row * K;
  for (int col = tx; col < K; col += GROUP) {
    const int exp = ((int)row_ptr[col] >> 7) & 0xFF;
    atomicAdd(&s_hist[exp], 1);
  }
  __syncthreads();
  const int c0 = s_hist[tx];
  const int c1 = s_hist[tx + GROUP];
  if (c0 != 0) atomicAdd(&histogram[tx], c0);
  if (c1 != 0) atomicAdd(&histogram[tx + GROUP], c1);
}

template <int GROUP, int WINDOW>
__device__ __forceinline__ void vllm_packed_bf16_exception_count(
    const unsigned short* __restrict__ weight,
    int* __restrict__ counts,
    int row, int K, int base, int tx,
    int* __restrict__ s_count) {
  if (tx == 0) s_count[0] = 0;
  __syncthreads();
  const unsigned short* row_ptr = weight + (long long)row * K;
  int local_count = 0;
  for (int col = tx; col < K; col += GROUP) {
    const int exp = ((int)row_ptr[col] >> 7) & 0xFF;
    if (exp != 0 && (exp < base || exp >= base + WINDOW)) {
      local_count += 1;
    }
  }
  if (local_count != 0) atomicAdd(&s_count[0], local_count);
  __syncthreads();
  if (tx == 0) counts[row] = s_count[0];
}

template <int GROUP, int WINDOW>
__device__ __forceinline__ void vllm_packed_bf16_pack_row(
    const unsigned short* __restrict__ weight,
    unsigned char* __restrict__ values,
    const int* __restrict__ offsets,
    int* __restrict__ rows,
    int* __restrict__ entries,
    int* __restrict__ mismatches,
    int prog_row, int row_start, int K, int base, int tx,
    int* __restrict__ s_warp_counts) {
  constexpr int HALF = GROUP / 2;
  const int row_index = row_start + prog_row;
  const unsigned short* source = weight + (long long)row_index * K;
  unsigned char* out = values + (long long)prog_row * (K + K / 2);
  int written = offsets[row_index];
  int bad = 0;
  const int warp_id = tx >> 5;
  const int lane = tx & 31;
  const unsigned int lane_mask = (1u << lane) - 1u;
  for (int group = 0; group < K / GROUP; ++group) {
    const int column = group * GROUP;
    const int col_a = column + tx;
    const int bits_a = (int)source[col_a] & 0xFFFF;
    const int exp_a = (bits_a >> 7) & 0xFF;
    const bool out_a = (exp_a != 0) && (exp_a < base || exp_a >= base + WINDOW);
    const int code_a = (exp_a != 0 && !out_a) ? (exp_a - base + 1) : 0;
    const int low_a = out_a ? 0 : (((bits_a >> 8) & 0x80) | (bits_a & 0x7F));
    const int dec_a = ((low_a & 0x80) << 8) |
                      (((code_a == 0) ? 0 : (code_a + base - 1)) << 7) |
                      (low_a & 0x7F);
    if (!out_a && dec_a != bits_a) bad += 1;
    const unsigned int mask_a = __ballot_sync(0xffffffffu, out_a);
    if (lane == 0) s_warp_counts[warp_id] = __popc(mask_a);
    __syncthreads();
    const int pos_a = written + (warp_id ? s_warp_counts[0] : 0) +
                      __popc(mask_a & lane_mask);
    if (out_a) {
      rows[pos_a] = row_index;
      entries[pos_a] = (col_a << 16) | bits_a;
    }
    written += s_warp_counts[0] + s_warp_counts[1];
    __syncthreads();

    const int col_b = column + HALF + tx;
    const int bits_b = (int)source[col_b] & 0xFFFF;
    const int exp_b = (bits_b >> 7) & 0xFF;
    const bool out_b = (exp_b != 0) && (exp_b < base || exp_b >= base + WINDOW);
    const int code_b = (exp_b != 0 && !out_b) ? (exp_b - base + 1) : 0;
    const int low_b = out_b ? 0 : (((bits_b >> 8) & 0x80) | (bits_b & 0x7F));
    const int dec_b = ((low_b & 0x80) << 8) |
                      (((code_b == 0) ? 0 : (code_b + base - 1)) << 7) |
                      (low_b & 0x7F);
    if (!out_b && dec_b != bits_b) bad += 1;
    const unsigned int mask_b = __ballot_sync(0xffffffffu, out_b);
    if (lane == 0) s_warp_counts[warp_id] = __popc(mask_b);
    __syncthreads();
    const int pos_b = written + (warp_id ? s_warp_counts[0] : 0) +
                      __popc(mask_b & lane_mask);
    if (out_b) {
      rows[pos_b] = row_index;
      entries[pos_b] = (col_b << 16) | bits_b;
    }
    written += s_warp_counts[0] + s_warp_counts[1];
    __syncthreads();

    out[col_a] = (unsigned char)low_a;
    out[col_b] = (unsigned char)low_b;
    out[K + group * HALF + tx] = (unsigned char)(code_a | (code_b << 4));
  }
  if (tx == 0 && written != offsets[row_index + 1]) bad += 1;
  if (bad != 0) atomicAdd(mismatches, bad);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vocab_packed_histogram_kernel(int* __restrict__ histogram, ushort* __restrict__ weight, int M);
extern "C" __global__ void __launch_bounds__(128, 1) vocab_packed_histogram_kernel(int* __restrict__ histogram, ushort* __restrict__ weight, int M) {
  extern __shared__ __align__(1024) int s_hist[];
  vllm_packed_bf16_histogram<128>((&(weight[0])), (&(histogram[0])), ((int)blockIdx.x), 5120, ((int)threadIdx.x), (&(s_hist[0])));
}

