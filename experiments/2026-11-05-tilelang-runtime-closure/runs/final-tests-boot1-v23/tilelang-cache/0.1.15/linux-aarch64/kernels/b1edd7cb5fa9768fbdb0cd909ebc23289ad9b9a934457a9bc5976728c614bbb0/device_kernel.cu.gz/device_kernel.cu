#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void vision_attention_kernel(__grid_constant__ const CUtensorMap Out_desc, __grid_constant__ const CUtensorMap QKV_desc, __grid_constant__ const CUtensorMap QKV_desc_1, int M);
extern "C" __global__ void __launch_bounds__(256, 1) vision_attention_kernel(__grid_constant__ const CUtensorMap Out_desc, __grid_constant__ const CUtensorMap QKV_desc, __grid_constant__ const CUtensorMap QKV_desc_1, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* O_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* Q_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* K_shared = ((void*)((char*)buf_dyn_shmem + 16384));
  void* V_shared = ((void*)((char*)buf_dyn_shmem + 32768));
  __shared__ __align__(16) uint64_t mbarrier_mem[9];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float acc[64];
  float denom[4];
  float row_max[4];
  float scores[64];
  float prev_max[4];
  float rescale[4];
  float row_sum[4];
  bfloat16_t probs[64];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(QKV_desc);
    tl::prefetch_tma_descriptor(QKV_desc_1);
    tl::prefetch_tma_descriptor(Out_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(1);
    mbarrier[3].init(1);
    mbarrier[4].init(128);
    mbarrier[5].init(128);
    mbarrier[6].init(128);
    mbarrier[7].init(128);
    mbarrier[8].init(1);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (tl::tl_shuffle_elect<256>()) {
    mbarrier[8].arrive_and_expect_tx(16384);
    tl::tma_load(QKV_desc, mbarrier[8], (&(((bfloat16_t*)Q_shared)[0])), (((int)blockIdx.y) * 64), (((int)blockIdx.x) * 128));
  }
  __syncthreads();
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    for (int kb = 0; kb < ((M + 63) >> 6); ++kb) {
      mbarrier[((kb & 1) + 4)].wait((((kb & 3) >> 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[(kb & 1)].arrive_and_expect_tx(8192);
        tl::tma_load(QKV_desc_1, mbarrier[(kb & 1)], (&(((bfloat16_t*)K_shared)[((kb & 1) * 4096)])), ((((int)blockIdx.y) * 64) + 256), (kb * 64));
      }
      mbarrier[((kb & 1) + 6)].wait((((kb & 3) >> 1) ^ 1));
      if (tl::tl_shuffle_elect<128>()) {
        mbarrier[((kb & 1) + 2)].arrive_and_expect_tx(8192);
        tl::tma_load(QKV_desc_1, mbarrier[((kb & 1) + 2)], (&(((bfloat16_t*)V_shared)[((kb & 1) * 4096)])), ((((int)blockIdx.y) * 64) + 512), (kb * 64));
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i = 0; i < 16; ++i) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(acc + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(denom + 0) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    float broadcast_var_2 = -CUDART_INF_F;
    *(float4*)(row_max + 0) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
    for (int kb_1 = 0; kb_1 < ((M + 63) >> 6); ++kb_1) {
      if (kb_1 == 0) {
        mbarrier[8].wait(0);
      }
      mbarrier[(kb_1 & 1)].wait(((kb_1 & 3) >> 1));
      {
        bfloat16_t A_local[16];
        bfloat16_t B_local[32];
        #pragma unroll
        for (int i_1 = 0; i_1 < 16; ++i_1) {
          float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
          *(float4*)(scores + (i_1 * 4)) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
        }
        for (int ki = 0; ki < 4; ++ki) {
          #pragma unroll
          for (int i_2 = 0; i_2 < 2; ++i_2) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)Q_shared)[((((((((((int)threadIdx.x) & 127) >> 5) * 2048) + (i_2 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_2 * 8)])));
          }
          #pragma unroll
          for (int i_3 = 0; i_3 < 4; ++i_3) {
            tl::ptx_ldmatrix_x4((&(((bfloat16_t*)K_shared)[((((((((kb_1 & 1) * 4096) + (i_3 * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[(i_3 * 8)])));
          }
          for (int i_4 = 0; i_4 < 2; ++i_4) {
            for (int j = 0; j < 4; ++j) {
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(scores + ((i_4 * 32) + (j * 8))), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + (j * 8)));
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(scores + (((i_4 * 32) + (j * 8)) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_4 * 8)), reinterpret_cast<const unsigned*>(B_local + ((j * 8) + 4)));
            }
          }
        }
      }
      mbarrier[((kb_1 & 1) + 4)].arrive();
      #pragma unroll
      for (int i_5 = 0; i_5 < 64; ++i_5) {
        float condval;
        if ((((((kb_1 * 64) + (((i_5 & 31) >> 2) * 8)) + ((((int)threadIdx.x) & 3) * 2)) + (i_5 & 1)) < M)) {
          condval = (scores[i_5] * 0x1.71547652b82fep-3f/*1.803369e-01*/);
        } else {
          condval = -CUDART_INF_F;
        }
        scores[i_5] = condval;
      }
      *(float4*)(prev_max + 0) = *(float4*)(row_max + 0);
      #pragma unroll
      for (int i_6 = 0; i_6 < 4; ++i_6) {
        row_max[i_6] = -CUDART_INF_F;
        #pragma unroll
        for (int rv = 0; rv < 16; ++rv) {
          row_max[i_6] = max(row_max[i_6], scores[(((((i_6 >> 1) * 32) + ((rv & 7) * 4)) + ((i_6 & 1) * 2)) + (rv >> 3))]);
        }
        row_max[i_6] = tl::AllReduce<tl::MaxOp, 4, 1, 128, tl::NamedBarrier<128>>::run(row_max[i_6]);
      }
      float4 __1;
        float4 v_ = *(float4*)(row_max + 0);
        float4 v__1 = *(float4*)(prev_max + 0);
        *(float2*)(&(__1.x)) = tl::max2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
        *(float2*)(&(__1.z)) = tl::max2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
      *(float4*)(row_max + 0) = __1;
      float4 __2;
      float4 __3;
        float4 v__2 = *(float4*)(prev_max + 0);
        float4 v__3 = *(float4*)(row_max + 0);
        *(float2*)(&(__3.x)) = tl::sub2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
        *(float2*)(&(__3.z)) = tl::sub2(*(float2*)(&(v__2.z)), *(float2*)(&(v__3.z)));
      __2.x = exp2f(__3.x);
      __2.y = exp2f(__3.y);
      __2.z = exp2f(__3.z);
      __2.w = exp2f(__3.w);
      *(float4*)(rescale + 0) = __2;
      #pragma unroll
      for (int i_7 = 0; i_7 < 32; ++i_7) {
        float2 __4;
        float2 __5;
          float2 v__4 = *(float2*)(scores + (i_7 * 2));
          float2 v__5 = make_float2(row_max[(((i_7 >> 4) * 2) + (i_7 & 1))], row_max[(((i_7 >> 4) * 2) + (i_7 & 1))]);
          *(float2*)(&(__5.x)) = tl::sub2(*(float2*)(&(v__4.x)), *(float2*)(&(v__5.x)));
        __4.x = exp2f(__5.x);
        __4.y = exp2f(__5.y);
        *(float2*)(scores + (i_7 * 2)) = __4;
      }
      #pragma unroll
      for (int i_8 = 0; i_8 < 4; ++i_8) {
        row_sum[i_8] = 0x0p+0f/*0.000000e+00*/;
        #pragma unroll
        for (int rv_1 = 0; rv_1 < 16; ++rv_1) {
          row_sum[i_8] = (row_sum[i_8] + scores[(((((i_8 >> 1) * 32) + ((rv_1 & 7) * 4)) + ((i_8 & 1) * 2)) + (rv_1 >> 3))]);
        }
        row_sum[i_8] = tl::AllReduce<tl::SumOp, 4, 1, 128, tl::NamedBarrier<128>>::run(row_sum[i_8]);
      }
      float4 __6;
        float4 v__6 = *(float4*)(denom + 0);
        float4 v__7 = *(float4*)(rescale + 0);
        float4 v__8 = *(float4*)(row_sum + 0);
        *(float2*)(&(__6.x)) = tl::fma2(*(float2*)(&(v__6.x)), *(float2*)(&(v__7.x)), *(float2*)(&(v__8.x)));
        *(float2*)(&(__6.z)) = tl::fma2(*(float2*)(&(v__6.z)), *(float2*)(&(v__7.z)), *(float2*)(&(v__8.z)));
      *(float4*)(denom + 0) = __6;
      #pragma unroll
      for (int i_9 = 0; i_9 < 16; ++i_9) {
        uint2 __7;
        float4 v__9 = *(float4*)(scores + (((((i_9 & 3) >> 1) * 32) + ((i_9 >> 2) * 8)) + ((i_9 & 1) * 4)));
        (reinterpret_cast<__nv_bfloat162*>(&__7))[0] = __float22bfloat162_rn(((float2*)(&v__9))[0]);
        (reinterpret_cast<__nv_bfloat162*>(&__7))[1] = __float22bfloat162_rn(((float2*)(&v__9))[1]);
        *(uint2*)(probs + (i_9 * 4)) = __7;
      }
      #pragma unroll
      for (int i_10 = 0; i_10 < 32; ++i_10) {
        float2 __8;
          float2 v__10 = *(float2*)(acc + (i_10 * 2));
          float2 v__11 = make_float2(rescale[(((i_10 >> 4) * 2) + (i_10 & 1))], rescale[(((i_10 >> 4) * 2) + (i_10 & 1))]);
          *(float2*)(&(__8.x)) = tl::mul2(*(float2*)(&(v__10.x)), *(float2*)(&(v__11.x)));
        *(float2*)(acc + (i_10 * 2)) = __8;
      }
      mbarrier[((kb_1 & 1) + 2)].wait(((kb_1 & 3) >> 1));
      {
        bfloat16_t B_local_1[32];
        for (int ki_1 = 0; ki_1 < 4; ++ki_1) {
          #pragma unroll
          for (int i_11 = 0; i_11 < 4; ++i_11) {
            tl::ptx_ldmatrix_x4_trans((&(((bfloat16_t*)V_shared)[(((((((kb_1 & 1) * 4096) + (ki_1 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (i_11 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_11 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_1[(i_11 * 8)])));
          }
          for (int i_12 = 0; i_12 < 2; ++i_12) {
            for (int j_1 = 0; j_1 < 4; ++j_1) {
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc + ((i_12 * 32) + (j_1 * 8))), reinterpret_cast<const unsigned*>(probs + ((ki_1 * 16) + (i_12 * 8))), reinterpret_cast<const unsigned*>(B_local_1 + (j_1 * 8)));
              tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc + (((i_12 * 32) + (j_1 * 8)) + 4)), reinterpret_cast<const unsigned*>(probs + ((ki_1 * 16) + (i_12 * 8))), reinterpret_cast<const unsigned*>(B_local_1 + ((j_1 * 8) + 4)));
            }
          }
        }
      }
      mbarrier[((kb_1 & 1) + 6)].arrive();
    }
    #pragma unroll
    for (int i_13 = 0; i_13 < 32; ++i_13) {
      float2 __9;
        float2 v__12 = *(float2*)(acc + (i_13 * 2));
        float2 v__13 = make_float2(denom[(((i_13 >> 4) * 2) + (i_13 & 1))], denom[(((i_13 >> 4) * 2) + (i_13 & 1))]);
        __9.x = (v__12.x/v__13.x);
        __9.y = (v__12.y/v__13.y);
      *(float2*)(acc + (i_13 * 2)) = __9;
    }
    tl::__sync_thread_partial(3, 128);
    #pragma unroll
    for (int i_14 = 0; i_14 < 8; ++i_14) {
      tl::ptx_stmatrix_m8n8_x4((&(((bfloat16_t*)O_shared)[((((((((((int)threadIdx.x) >> 5) * 2048) + ((i_14 >> 2) * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((i_14 & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (i_14 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) - 8192)])), __pack_half2(((bfloat16_t)acc[(i_14 * 8)]), ((bfloat16_t)acc[((i_14 * 8) + 1)])), __pack_half2(((bfloat16_t)acc[((i_14 * 8) + 2)]), ((bfloat16_t)acc[((i_14 * 8) + 3)])), __pack_half2(((bfloat16_t)acc[((i_14 * 8) + 4)]), ((bfloat16_t)acc[((i_14 * 8) + 5)])), __pack_half2(((bfloat16_t)acc[((i_14 * 8) + 6)]), ((bfloat16_t)acc[((i_14 * 8) + 7)])));
    }
    tl::__sync_thread_partial(3, 128);
    if (tl::tl_shuffle_elect<128>()) {
      tl::fence_proxy_async();
      tl::tma_store(Out_desc, (&(((bfloat16_t*)O_shared)[0])), (((int)blockIdx.y) * 64), (((int)blockIdx.x) * 128));
      tl::tma_store_arrive();
      tl::tma_store_wait<0, true>();
    }
  }
}

