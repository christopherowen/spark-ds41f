// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* gumbel_finish_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gumbel_finish(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gumbel_finish(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[12];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "gumbel_finish: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_finish: args pointer is NULL");
    return -1;
  }
  int32_t local_argmax_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((local_argmax_handle_type_index == 0) || (local_argmax_handle_type_index == 4)) || (local_argmax_handle_type_index == 7)) || (64 <= local_argmax_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_argmax expected pointer or tensor handle");
    return -1;
  }
  int32_t local_max_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((local_max_handle_type_index == 0) || (local_max_handle_type_index == 4)) || (local_max_handle_type_index == 7)) || (64 <= local_max_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_max expected pointer or tensor handle");
    return -1;
  }
  int32_t sampled_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((sampled_handle_type_index == 0) || (sampled_handle_type_index == 4)) || (sampled_handle_type_index == 7)) || (64 <= sampled_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input sampled expected pointer or tensor handle");
    return -1;
  }
  void* local_argmax_handle = ((local_argmax_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* local_max_handle = ((local_max_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* sampled_handle = ((sampled_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  bool gumbel_finish_local_argmax_is_null = (local_argmax_handle == NULL);
  if (!(!gumbel_finish_local_argmax_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_finish.local_argmax is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_finish_local_max_is_null = (local_max_handle == NULL);
  if (!(!gumbel_finish_local_max_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_finish.local_max is expected to have non-NULL pointer");
    return -1;
  }
  bool gumbel_finish_sampled_is_null = (sampled_handle == NULL);
  if (!(!gumbel_finish_sampled_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gumbel_finish.sampled is expected to have non-NULL pointer");
    return -1;
  }
  void* gumbel_finish_local_argmax_shape = (((DLTensor*)local_argmax_handle)[0].shape);
  void* gumbel_finish_local_max_shape = (((DLTensor*)local_max_handle)[0].shape);
  void* gumbel_finish_sampled_shape = (((DLTensor*)sampled_handle)[0].shape);
  if (!(((((DLTensor*)local_argmax_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_argmax ndim mismatch, expected 2", (long long)((((DLTensor*)local_argmax_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable tokens requires at least one non-null buffer among: gumbel_finish.local_argmax, gumbel_finish.local_max, gumbel_finish.sampled");
    return -1;
  }
  int32_t tokens = ((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[0]);
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable blocks requires at least one non-null buffer among: gumbel_finish.local_argmax, gumbel_finish.local_max");
    return -1;
  }
  int32_t blocks = ((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[1]);
  void* gumbel_finish_local_argmax_strides = (((DLTensor*)local_argmax_handle)[0].strides);
  int64_t condval;
  if ((gumbel_finish_local_argmax_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)gumbel_finish_local_argmax_strides)[0];
  }
  int64_t argmax_stride = condval;
  int32_t dev_id = (((DLTensor*)local_argmax_handle)[0].device.device_id);
  void* local_argmax = (((DLTensor*)local_argmax_handle)[0].data);
  if (!(((((DLTensor*)local_max_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_max ndim mismatch, expected 2", (long long)((((DLTensor*)local_max_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gumbel_finish_local_max_strides = (((DLTensor*)local_max_handle)[0].strides);
  int64_t condval_1;
  if ((gumbel_finish_local_max_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)gumbel_finish_local_max_strides)[0];
  }
  int64_t max_stride = condval_1;
  void* local_max = (((DLTensor*)local_max_handle)[0].data);
  if (!(((((DLTensor*)sampled_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input sampled ndim mismatch, expected 1", (long long)((((DLTensor*)sampled_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gumbel_finish_sampled_strides = (((DLTensor*)sampled_handle)[0].strides);
  void* sampled = (((DLTensor*)sampled_handle)[0].data);
  if (!(((((((DLTensor*)local_argmax_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)local_argmax_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)local_argmax_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_argmax dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_2;
  if ((gumbel_finish_local_argmax_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)gumbel_finish_local_argmax_strides)[1]);
  }
  if (!(((condval_2 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_argmax strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_argmax_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_argmax byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_argmax_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_argmax_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_argmax device_type mismatch, expected cuda", (long long)((((DLTensor*)local_argmax_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((tokens == 0) || (blocks == 0)) || !(local_argmax == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_argmax data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)local_max_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)local_max_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)local_max_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_max dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[0]) == ((int32_t)((int64_t*)gumbel_finish_local_max_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_max shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[0])), (long long)(((int32_t)((int64_t*)gumbel_finish_local_max_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[1]) == ((int32_t)((int64_t*)gumbel_finish_local_max_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_max shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[1])), (long long)(((int32_t)((int64_t*)gumbel_finish_local_max_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((gumbel_finish_local_max_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)gumbel_finish_local_max_strides)[1]);
  }
  if (!(((condval_3 == 1) || (blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_max strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)local_max_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_max byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)local_max_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_max device_id violates packed ABI constraint", (long long)((((DLTensor*)local_max_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)local_max_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input local_max device_type mismatch, expected cuda", (long long)((((DLTensor*)local_max_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((tokens == 0) || (blocks == 0)) || !(local_max == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input local_max data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)sampled_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)sampled_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)sampled_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input sampled dtype mismatch, expected int64");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[0]) == ((int32_t)((int64_t*)gumbel_finish_sampled_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input sampled shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gumbel_finish_local_argmax_shape)[0])), (long long)(((int32_t)((int64_t*)gumbel_finish_sampled_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((gumbel_finish_sampled_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)gumbel_finish_sampled_strides)[0]);
  }
  if (!(((condval_4 == 1) || (tokens == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input sampled strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)sampled_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input sampled byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)sampled_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_id) == (((DLTensor*)local_argmax_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input sampled device_id violates packed ABI constraint", (long long)((((DLTensor*)sampled_handle)[0].device.device_id)), (long long)((((DLTensor*)local_argmax_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)sampled_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gumbel_finish input sampled device_type mismatch, expected cuda", (long long)((((DLTensor*)sampled_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((tokens == 0) || !(sampled == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gumbel_finish input sampled data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (local_argmax == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = local_argmax;
  if (local_max == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = local_max;
  if (sampled == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = sampled;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = argmax_stride;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)blocks);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = max_stride;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)tokens);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)tokens);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = (int64_t)0;
  if (gumbel_finish_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "gumbel_finish_kernel", &gumbel_finish_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(gumbel_finish_kernel_packed, (TVMFFIAny*) stack_ffi_any, 11, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_gumbel_finish(self, args, num_args, result);
}
