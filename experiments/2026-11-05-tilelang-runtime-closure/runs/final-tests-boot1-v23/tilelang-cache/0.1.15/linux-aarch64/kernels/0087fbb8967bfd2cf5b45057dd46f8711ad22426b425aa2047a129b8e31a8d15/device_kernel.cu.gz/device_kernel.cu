#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_order_sum_kernel(bfloat16_t* __restrict__ out, const bfloat16_t* __restrict__ s0, const bfloat16_t* __restrict__ src, const bfloat16_t* __restrict__ src_1, const bfloat16_t* __restrict__ src_2, int m);
extern "C" __global__ void __launch_bounds__(256, 1) collectives_rank_order_sum_kernel(bfloat16_t* __restrict__ out, const bfloat16_t* __restrict__ s0, const bfloat16_t* __restrict__ src, const bfloat16_t* __restrict__ src_1, const bfloat16_t* __restrict__ src_2, int m) {
  bfloat16_t xs[8];
  float total[8];
  if (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) < m) {
    *(uint4*)(xs + 0) = *(uint4*)(s0 + ((((int64_t)((int)blockIdx.x)) * (int64_t)2048) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    #pragma unroll
    for (int i = 0; i < 8; ++i) {
      total[i] = ((float)xs[i]);
    }
    *(uint4*)(xs + 0) = *(uint4*)(src + ((((int64_t)((int)blockIdx.x)) * (int64_t)2048) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    #pragma unroll
    for (int i_1 = 0; i_1 < 8; ++i_1) {
      total[i_1] = (total[i_1] + ((float)xs[i_1]));
    }
    *(uint4*)(xs + 0) = *(uint4*)(src_1 + ((((int64_t)((int)blockIdx.x)) * (int64_t)2048) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    #pragma unroll
    for (int i_2 = 0; i_2 < 8; ++i_2) {
      total[i_2] = (total[i_2] + ((float)xs[i_2]));
    }
    *(uint4*)(xs + 0) = *(uint4*)(src_2 + ((((int64_t)((int)blockIdx.x)) * (int64_t)2048) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    #pragma unroll
    for (int i_3 = 0; i_3 < 8; ++i_3) {
      total[i_3] = (total[i_3] + ((float)xs[i_3]));
    }
    #pragma unroll
    for (int i_4 = 0; i_4 < 8; ++i_4) {
      xs[i_4] = ((bfloat16_t)total[i_4]);
    }
    *(uint4*)(out + ((((int64_t)((int)blockIdx.x)) * (int64_t)2048) + (((int64_t)((int)threadIdx.x)) * (int64_t)8))) = *(uint4*)(xs + 0);
  }
}

