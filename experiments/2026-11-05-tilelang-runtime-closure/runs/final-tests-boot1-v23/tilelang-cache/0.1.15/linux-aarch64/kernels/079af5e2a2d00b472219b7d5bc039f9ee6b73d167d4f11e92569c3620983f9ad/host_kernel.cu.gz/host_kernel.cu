// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* select_first_argmax_embed_top2_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_select_first_argmax_embed_top2(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_select_first_argmax_embed_top2(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[24];
  void* stack_ffi_any = stack;
  if (!((num_args == 13))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "select_first_argmax_embed_top2: num_args should be 13", (long long)(num_args), (long long)(13));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2: args pointer is NULL");
    return -1;
  }
  int32_t pairs_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((pairs_handle_type_index == 0) || (pairs_handle_type_index == 4)) || (pairs_handle_type_index == 7)) || (64 <= pairs_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input pairs expected pointer or tensor handle");
    return -1;
  }
  int32_t out_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((out_handle_type_index == 0) || (out_handle_type_index == 4)) || (out_handle_type_index == 7)) || (64 <= out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input out expected pointer or tensor handle");
    return -1;
  }
  int32_t out_stride_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((out_stride_type_index == 1) || (out_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 scalar out_stride expected integer");
    return -1;
  }
  int32_t table_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((table_handle_type_index == 0) || (table_handle_type_index == 4)) || (table_handle_type_index == 7)) || (64 <= table_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input table expected pointer or tensor handle");
    return -1;
  }
  int32_t step_out_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((step_out_handle_type_index == 0) || (step_out_handle_type_index == 4)) || (step_out_handle_type_index == 7)) || (64 <= step_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input step_out expected pointer or tensor handle");
    return -1;
  }
  int32_t confidence_out_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((confidence_out_handle_type_index == 0) || (confidence_out_handle_type_index == 4)) || (confidence_out_handle_type_index == 7)) || (64 <= confidence_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input confidence_out expected pointer or tensor handle");
    return -1;
  }
  int32_t markov_conf_weight_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((markov_conf_weight_handle_type_index == 0) || (markov_conf_weight_handle_type_index == 4)) || (markov_conf_weight_handle_type_index == 7)) || (64 <= markov_conf_weight_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input markov_conf_weight expected pointer or tensor handle");
    return -1;
  }
  int32_t runner_up_out_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((runner_up_out_handle_type_index == 0) || (runner_up_out_handle_type_index == 4)) || (runner_up_out_handle_type_index == 7)) || (64 <= runner_up_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input runner_up_out expected pointer or tensor handle");
    return -1;
  }
  int32_t runner_up_stride_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((runner_up_stride_type_index == 1) || (runner_up_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 scalar runner_up_stride expected integer");
    return -1;
  }
  int32_t margin_out_handle_type_index = (((TVMFFIAny*)args)[9].type_index);
  if (!(((((margin_out_handle_type_index == 0) || (margin_out_handle_type_index == 4)) || (margin_out_handle_type_index == 7)) || (64 <= margin_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input margin_out expected pointer or tensor handle");
    return -1;
  }
  int32_t margin_stride_type_index = (((TVMFFIAny*)args)[10].type_index);
  if (!(((margin_stride_type_index == 1) || (margin_stride_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 scalar margin_stride expected integer");
    return -1;
  }
  int32_t branch_margin_type_index = (((TVMFFIAny*)args)[11].type_index);
  if (!((((branch_margin_type_index == 3) || (branch_margin_type_index == 1)) || (branch_margin_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 scalar branch_margin expected float");
    return -1;
  }
  int32_t branch_weight_type_index = (((TVMFFIAny*)args)[12].type_index);
  if (!((((branch_weight_type_index == 3) || (branch_weight_type_index == 1)) || (branch_weight_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 scalar branch_weight expected float");
    return -1;
  }
  void* pairs_handle = ((pairs_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* out_handle = ((out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  int64_t out_stride = (((TVMFFIAny*)args)[2].v_int64);
  void* table_handle = ((table_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* step_out_handle = ((step_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* confidence_out_handle = ((confidence_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* markov_conf_weight_handle = ((markov_conf_weight_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* runner_up_out_handle = ((runner_up_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  int64_t runner_up_stride = (((TVMFFIAny*)args)[8].v_int64);
  void* margin_out_handle = ((margin_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[9].v_ptr) + 24)) : (((TVMFFIAny*)args)[9].v_ptr));
  int64_t margin_stride = (((TVMFFIAny*)args)[10].v_int64);
  float branch_margin = ((branch_margin_type_index == 3) ? ((float)(((TVMFFIAny*)args)[11].v_float64)) : ((float)(((TVMFFIAny*)args)[11].v_int64)));
  float branch_weight = ((branch_weight_type_index == 3) ? ((float)(((TVMFFIAny*)args)[12].v_float64)) : ((float)(((TVMFFIAny*)args)[12].v_int64)));
  bool select_first_argmax_embed_top2_pairs_is_null = (pairs_handle == NULL);
  if (!(!select_first_argmax_embed_top2_pairs_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.pairs is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_embed_top2_out_is_null = (out_handle == NULL);
  if (!(!select_first_argmax_embed_top2_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.out is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_embed_top2_table_is_null = (table_handle == NULL);
  if (!(!select_first_argmax_embed_top2_table_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.table is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_embed_top2_step_out_is_null = (step_out_handle == NULL);
  if (!(!select_first_argmax_embed_top2_step_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.step_out is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_embed_top2_confidence_out_is_null = (confidence_out_handle == NULL);
  if (!(!select_first_argmax_embed_top2_confidence_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.confidence_out is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_embed_top2_markov_conf_weight_is_null = (markov_conf_weight_handle == NULL);
  if (!(!select_first_argmax_embed_top2_markov_conf_weight_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.markov_conf_weight is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_embed_top2_runner_up_out_is_null = (runner_up_out_handle == NULL);
  if (!(!select_first_argmax_embed_top2_runner_up_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.runner_up_out is expected to have non-NULL pointer");
    return -1;
  }
  bool select_first_argmax_embed_top2_margin_out_is_null = (margin_out_handle == NULL);
  if (!(!select_first_argmax_embed_top2_margin_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "select_first_argmax_embed_top2.margin_out is expected to have non-NULL pointer");
    return -1;
  }
  void* select_first_argmax_embed_top2_pairs_shape = (((DLTensor*)pairs_handle)[0].shape);
  void* select_first_argmax_embed_top2_out_shape = (((DLTensor*)out_handle)[0].shape);
  void* select_first_argmax_embed_top2_table_shape = (((DLTensor*)table_handle)[0].shape);
  void* select_first_argmax_embed_top2_step_out_shape = (((DLTensor*)step_out_handle)[0].shape);
  void* select_first_argmax_embed_top2_confidence_out_shape = (((DLTensor*)confidence_out_handle)[0].shape);
  void* select_first_argmax_embed_top2_markov_conf_weight_shape = (((DLTensor*)markov_conf_weight_handle)[0].shape);
  void* select_first_argmax_embed_top2_runner_up_out_shape = (((DLTensor*)runner_up_out_handle)[0].shape);
  void* select_first_argmax_embed_top2_margin_out_shape = (((DLTensor*)margin_out_handle)[0].shape);
  if (!(((((DLTensor*)pairs_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input pairs ndim mismatch, expected 2", (long long)((((DLTensor*)pairs_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: select_first_argmax_embed_top2.pairs, select_first_argmax_embed_top2.step_out, select_first_argmax_embed_top2.confidence_out");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)select_first_argmax_embed_top2_pairs_shape)[0]);
  int32_t width = ((int32_t)((int64_t*)select_first_argmax_embed_top2_pairs_shape)[1]);
  void* select_first_argmax_embed_top2_pairs_strides = (((DLTensor*)pairs_handle)[0].strides);
  int64_t condval;
  if ((select_first_argmax_embed_top2_pairs_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)select_first_argmax_embed_top2_pairs_strides)[0];
  }
  int64_t pairs_stride = condval;
  int32_t dev_id = (((DLTensor*)pairs_handle)[0].device.device_id);
  void* pairs = (((DLTensor*)pairs_handle)[0].data);
  if (!(((((DLTensor*)out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input out ndim mismatch, expected 1", (long long)((((DLTensor*)out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t out_len = ((int32_t)((int64_t*)select_first_argmax_embed_top2_out_shape)[0]);
  void* select_first_argmax_embed_top2_out_strides = (((DLTensor*)out_handle)[0].strides);
  void* out = (((DLTensor*)out_handle)[0].data);
  if (!(((((DLTensor*)table_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input table ndim mismatch, expected 2", (long long)((((DLTensor*)table_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t table_rows = ((int32_t)((int64_t*)select_first_argmax_embed_top2_table_shape)[0]);
  void* select_first_argmax_embed_top2_table_strides = (((DLTensor*)table_handle)[0].strides);
  void* table = (((DLTensor*)table_handle)[0].data);
  if (!(((((DLTensor*)step_out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input step_out ndim mismatch, expected 2", (long long)((((DLTensor*)step_out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* select_first_argmax_embed_top2_step_out_strides = (((DLTensor*)step_out_handle)[0].strides);
  int64_t condval_1;
  if ((select_first_argmax_embed_top2_step_out_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)select_first_argmax_embed_top2_step_out_strides)[0];
  }
  int64_t step_stride = condval_1;
  void* step_out = (((DLTensor*)step_out_handle)[0].data);
  if (!(((((DLTensor*)confidence_out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input confidence_out ndim mismatch, expected 2", (long long)((((DLTensor*)confidence_out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* select_first_argmax_embed_top2_confidence_out_strides = (((DLTensor*)confidence_out_handle)[0].strides);
  int64_t condval_2;
  if ((select_first_argmax_embed_top2_confidence_out_strides == NULL)) {
    condval_2 = (int64_t)1;
  } else {
    condval_2 = ((int64_t*)select_first_argmax_embed_top2_confidence_out_strides)[0];
  }
  int64_t confidence_stride = condval_2;
  void* confidence_out = (((DLTensor*)confidence_out_handle)[0].data);
  if (!(((((DLTensor*)markov_conf_weight_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input markov_conf_weight ndim mismatch, expected 1", (long long)((((DLTensor*)markov_conf_weight_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* select_first_argmax_embed_top2_markov_conf_weight_strides = (((DLTensor*)markov_conf_weight_handle)[0].strides);
  void* markov_conf_weight = (((DLTensor*)markov_conf_weight_handle)[0].data);
  if (!(((((DLTensor*)runner_up_out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input runner_up_out ndim mismatch, expected 1", (long long)((((DLTensor*)runner_up_out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t runner_up_len = ((int32_t)((int64_t*)select_first_argmax_embed_top2_runner_up_out_shape)[0]);
  void* select_first_argmax_embed_top2_runner_up_out_strides = (((DLTensor*)runner_up_out_handle)[0].strides);
  void* runner_up_out = (((DLTensor*)runner_up_out_handle)[0].data);
  if (!(((((DLTensor*)margin_out_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input margin_out ndim mismatch, expected 1", (long long)((((DLTensor*)margin_out_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t margin_len = ((int32_t)((int64_t*)select_first_argmax_embed_top2_margin_out_shape)[0]);
  void* select_first_argmax_embed_top2_margin_out_strides = (((DLTensor*)margin_out_handle)[0].strides);
  void* margin_out = (((DLTensor*)margin_out_handle)[0].data);
  if (!(((((((DLTensor*)pairs_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)pairs_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)pairs_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input pairs dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_3;
  if ((select_first_argmax_embed_top2_pairs_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_pairs_strides)[1]);
  }
  if (!(((condval_3 == 1) || (width == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input pairs strides[1] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)pairs_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input pairs byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)pairs_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)pairs_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input pairs device_type mismatch, expected cuda", (long long)((((DLTensor*)pairs_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((rows == 0) || (width == 0)) || !(pairs == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input pairs data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)out_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input out dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_4;
  if ((select_first_argmax_embed_top2_out_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_out_strides)[0]);
  }
  if (!(((condval_4 == 1) || (out_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input out device_id violates packed ABI constraint", (long long)((((DLTensor*)out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input out device_type mismatch, expected cuda", (long long)((((DLTensor*)out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((out_len == 0) || !(out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)table_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)table_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)table_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input table dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)select_first_argmax_embed_top2_table_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input table shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_table_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((select_first_argmax_embed_top2_table_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_table_strides)[1]);
  }
  if (!((condval_5 == 1))) {
    int32_t condval_6;
    if ((select_first_argmax_embed_top2_table_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_table_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input table strides[1] violates packed ABI constraint", (long long)(condval_6), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((select_first_argmax_embed_top2_table_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_table_strides)[0]);
  }
  if (!(((condval_7 == 256) || (table_rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input table strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)table_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input table byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)table_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)table_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input table device_id violates packed ABI constraint", (long long)((((DLTensor*)table_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)table_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input table device_type mismatch, expected cuda", (long long)((((DLTensor*)table_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((table_rows == 0) || !(table == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input table data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)step_out_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)step_out_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)step_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input step_out dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)select_first_argmax_embed_top2_pairs_shape)[0]) == ((int32_t)((int64_t*)select_first_argmax_embed_top2_step_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input step_out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_pairs_shape)[0])), (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_step_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)select_first_argmax_embed_top2_step_out_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input step_out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_step_out_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((select_first_argmax_embed_top2_step_out_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_step_out_strides)[1]);
  }
  if (!((condval_8 == 1))) {
    int32_t condval_9;
    if ((select_first_argmax_embed_top2_step_out_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_step_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input step_out strides[1] violates packed ABI constraint", (long long)(condval_9), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)step_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input step_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)step_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)step_out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input step_out device_id violates packed ABI constraint", (long long)((((DLTensor*)step_out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)step_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input step_out device_type mismatch, expected cuda", (long long)((((DLTensor*)step_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(step_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input step_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)confidence_out_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)confidence_out_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)confidence_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input confidence_out dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)select_first_argmax_embed_top2_pairs_shape)[0]) == ((int32_t)((int64_t*)select_first_argmax_embed_top2_confidence_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input confidence_out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_pairs_shape)[0])), (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_confidence_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)select_first_argmax_embed_top2_confidence_out_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input confidence_out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_confidence_out_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((select_first_argmax_embed_top2_confidence_out_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_confidence_out_strides)[1]);
  }
  if (!((condval_10 == 1))) {
    int32_t condval_11;
    if ((select_first_argmax_embed_top2_confidence_out_strides == NULL)) {
      condval_11 = 1;
    } else {
      condval_11 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_confidence_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input confidence_out strides[1] violates packed ABI constraint", (long long)(condval_11), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)confidence_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input confidence_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)confidence_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)confidence_out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input confidence_out device_id violates packed ABI constraint", (long long)((((DLTensor*)confidence_out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)confidence_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input confidence_out device_type mismatch, expected cuda", (long long)((((DLTensor*)confidence_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(confidence_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input confidence_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)markov_conf_weight_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)markov_conf_weight_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)markov_conf_weight_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input markov_conf_weight dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)select_first_argmax_embed_top2_markov_conf_weight_shape)[0]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input markov_conf_weight shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)select_first_argmax_embed_top2_markov_conf_weight_shape)[0])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((select_first_argmax_embed_top2_markov_conf_weight_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_markov_conf_weight_strides)[0]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((select_first_argmax_embed_top2_markov_conf_weight_strides == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_markov_conf_weight_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input markov_conf_weight strides[0] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)markov_conf_weight_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input markov_conf_weight byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)markov_conf_weight_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)markov_conf_weight_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input markov_conf_weight device_id violates packed ABI constraint", (long long)((((DLTensor*)markov_conf_weight_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)markov_conf_weight_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input markov_conf_weight device_type mismatch, expected cuda", (long long)((((DLTensor*)markov_conf_weight_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(markov_conf_weight == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input markov_conf_weight data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)runner_up_out_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)runner_up_out_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)runner_up_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input runner_up_out dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_14;
  if ((select_first_argmax_embed_top2_runner_up_out_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_runner_up_out_strides)[0]);
  }
  if (!(((condval_14 == 1) || (runner_up_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input runner_up_out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)runner_up_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input runner_up_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)runner_up_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)runner_up_out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input runner_up_out device_id violates packed ABI constraint", (long long)((((DLTensor*)runner_up_out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)runner_up_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input runner_up_out device_type mismatch, expected cuda", (long long)((((DLTensor*)runner_up_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((runner_up_len == 0) || !(runner_up_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input runner_up_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)margin_out_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)margin_out_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)margin_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input margin_out dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_15;
  if ((select_first_argmax_embed_top2_margin_out_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)select_first_argmax_embed_top2_margin_out_strides)[0]);
  }
  if (!(((condval_15 == 1) || (margin_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input margin_out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)margin_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input margin_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)margin_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)margin_out_handle)[0].device.device_id) == (((DLTensor*)pairs_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input margin_out device_id violates packed ABI constraint", (long long)((((DLTensor*)margin_out_handle)[0].device.device_id)), (long long)((((DLTensor*)pairs_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)margin_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel select_first_argmax_embed_top2 input margin_out device_type mismatch, expected cuda", (long long)((((DLTensor*)margin_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((margin_len == 0) || !(margin_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel select_first_argmax_embed_top2 input margin_out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (confidence_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = confidence_out;
  if (margin_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = margin_out;
  if (markov_conf_weight == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = markov_conf_weight;
  if (out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = out;
  if (pairs == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = pairs;
  if (runner_up_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = runner_up_out;
  if (step_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = step_out;
  if (table == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = table;
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 3;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_float64) = ((double)branch_margin);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 3;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_float64) = ((double)branch_weight);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = confidence_stride;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = margin_stride;
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = out_stride;
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = pairs_stride;
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = runner_up_stride;
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = step_stride;
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)table_rows);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[19].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[19].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[20].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[20].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[20].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[21].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[21].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[21].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[22].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[22].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[22].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[23].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[23].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[23].v_int64) = (int64_t)0;
  if (select_first_argmax_embed_top2_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "select_first_argmax_embed_top2_kernel", &select_first_argmax_embed_top2_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(select_first_argmax_embed_top2_kernel_packed, (TVMFFIAny*) stack_ffi_any, 23, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_select_first_argmax_embed_top2(self, args, num_args, result);
}
