
__device__ __forceinline__ void splitk_fence() { __threadfence(); }
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/atomic.h>
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gemm_bf16_splitk_kernel(const bfloat16_t* A, const bfloat16_t* B, float* C0, float* C1, float* P, int* counters, int M, int tiles);
extern "C" __global__ void __launch_bounds__(256, 1) gemm_bf16_splitk_kernel(const bfloat16_t* A, const bfloat16_t* B, float* C0, float* C1, float* P, int* counters, int M, int tiles) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* last = ((void*)((char*)buf_dyn_shmem + 0));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 24576));
  float C_local[16];
  float C_block[16];
  float acc = 0x0p+0f/*0.000000e+00*/;
  cudaGridDependencySynchronize();
  cudaTriggerProgrammaticLaunchCompletion();
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    float broadcast_var = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_local + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 2; ++i_1) {
    tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[(((((i_1 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A[(((((((int64_t)((int)blockIdx.z)) * (int64_t)327680) + (((int64_t)i_1) * (int64_t)163840)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8))])), (((((((int)blockIdx.z) * 64) + (i_1 * 32)) + (((int)threadIdx.x) >> 3)) < M) && ((((((int)blockIdx.z) * 64) + (i_1 * 32)) + (((int)threadIdx.x) >> 3)) < M)));
  }
  #pragma unroll
  for (int i_2 = 0; i_2 < 2; ++i_2) {
    tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[(((((i_2 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B[(((((((int)blockIdx.x) * 327680) + (i_2 * 163840)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8))])));
  }
  tl::cp_async_commit();
  #pragma unroll
  for (int i_3 = 0; i_3 < 2; ++i_3) {
    tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[((((((i_3 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(A[((((((((int64_t)((int)blockIdx.z)) * (int64_t)327680) + (((int64_t)i_3) * (int64_t)163840)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)64)])), (((((((int)blockIdx.z) * 64) + (i_3 * 32)) + (((int)threadIdx.x) >> 3)) < M) && ((((((int)blockIdx.z) * 64) + (i_3 * 32)) + (((int)threadIdx.x) >> 3)) < M)));
  }
  #pragma unroll
  for (int i_4 = 0; i_4 < 2; ++i_4) {
    tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[((((((i_4 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(B[((((((((int)blockIdx.x) * 327680) + (i_4 * 163840)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8)) + 64)])));
  }
  tl::cp_async_commit();
  #pragma unroll
  for (int i_5 = 0; i_5 < 2; ++i_5) {
    tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[((((((i_5 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 8192)])), (&(A[((((((((int64_t)((int)blockIdx.z)) * (int64_t)327680) + (((int64_t)i_5) * (int64_t)163840)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)128)])), (((((((int)blockIdx.z) * 64) + (i_5 * 32)) + (((int)threadIdx.x) >> 3)) < M) && ((((((int)blockIdx.z) * 64) + (i_5 * 32)) + (((int)threadIdx.x) >> 3)) < M)));
  }
  #pragma unroll
  for (int i_6 = 0; i_6 < 2; ++i_6) {
    tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[((((((i_6 * 2048) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 8192)])), (&(B[((((((((int)blockIdx.x) * 327680) + (i_6 * 163840)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + ((((int)threadIdx.x) & 7) * 8)) + 128)])));
  }
  tl::cp_async_commit();
  for (int kb = 0; kb < 13; ++kb) {
    #pragma unroll
    for (int i_7 = 0; i_7 < 4; ++i_7) {
      float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(C_block + (i_7 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
    }
    tl::cp_async_wait<2>();
    __syncthreads();
    {
      bfloat16_t A_local[16];
      bfloat16_t B_local[8];
      for (int ki = 0; ki < 4; ++ki) {
        #pragma unroll
        for (int i_8 = 0; i_8 < 2; ++i_8) {
          tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((kb % 3) * 4096) + (((((int)threadIdx.x) & 63) >> 5) * 2048)) + (i_8 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[(i_8 * 8)])));
        }
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)B_shared)[((((((((kb % 3) * 4096) + ((((int)threadIdx.x) >> 6) * 1024)) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[0])));
        for (int i_9 = 0; i_9 < 2; ++i_9) {
          tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (i_9 * 8)), reinterpret_cast<const unsigned*>(A_local + (i_9 * 8)), reinterpret_cast<const unsigned*>(B_local + 0));
          tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + ((i_9 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local + (i_9 * 8)), reinterpret_cast<const unsigned*>(B_local + 4));
        }
      }
    }
    __syncthreads();
    #pragma unroll
    for (int i_10 = 0; i_10 < 2; ++i_10) {
      tl::cp_async_gs_conditional<16>((&(((bfloat16_t*)A_shared)[(((((((kb % 3) * 4096) + (i_10 * 2048)) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A[(((((((((int64_t)((int)blockIdx.z)) * (int64_t)327680) + (((int64_t)i_10) * (int64_t)163840)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)3) * (int64_t)5120)) + (((int64_t)((int)blockIdx.y)) * (int64_t)1024)) + (((int64_t)kb) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)7) * (int64_t)8)) + (int64_t)192)])), (((((((int)blockIdx.z) * 64) + (i_10 * 32)) + (((int)threadIdx.x) >> 3)) < M) && ((((((int)blockIdx.z) * 64) + (i_10 * 32)) + (((int)threadIdx.x) >> 3)) < M)));
    }
    #pragma unroll
    for (int i_11 = 0; i_11 < 2; ++i_11) {
      tl::cp_async_gs<16>((&(((bfloat16_t*)B_shared)[(((((((kb % 3) * 4096) + (i_11 * 2048)) + ((((int)threadIdx.x) >> 3) * 64)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B[(((((((((int)blockIdx.x) * 327680) + (i_11 * 163840)) + ((((int)threadIdx.x) >> 3) * 5120)) + (((int)blockIdx.y) * 1024)) + (kb * 64)) + ((((int)threadIdx.x) & 7) * 8)) + 192)])));
    }
    tl::cp_async_commit();
    #pragma unroll
    for (int i_12 = 0; i_12 < 4; ++i_12) {
      float4 __1;
        float4 v_ = *(float4*)(C_local + (i_12 * 4));
        float4 v__1 = *(float4*)(C_block + (i_12 * 4));
        *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
        *(float2*)(&(__1.z)) = tl::add2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
      *(float4*)(C_local + (i_12 * 4)) = __1;
    }
  }
  #pragma unroll
  for (int i_13 = 0; i_13 < 4; ++i_13) {
    float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_block + (i_13 * 4)) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
  }
  tl::cp_async_wait<2>();
  __syncthreads();
  {
    bfloat16_t A_local_1[16];
    bfloat16_t B_local_1[8];
    for (int ki_1 = 0; ki_1 < 4; ++ki_1) {
      #pragma unroll
      for (int i_14 = 0; i_14 < 2; ++i_14) {
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[(((((((((((int)threadIdx.x) & 63) >> 5) * 2048) + (i_14 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(A_local_1[(i_14 * 8)])));
      }
      tl::ptx_ldmatrix_x4((&(((bfloat16_t*)B_shared)[((((((((((int)threadIdx.x) >> 6) * 1024) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_1 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_1 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 4096)])), (&(B_local_1[0])));
      for (int i_15 = 0; i_15 < 2; ++i_15) {
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (i_15 * 8)), reinterpret_cast<const unsigned*>(A_local_1 + (i_15 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + 0));
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + ((i_15 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local_1 + (i_15 * 8)), reinterpret_cast<const unsigned*>(B_local_1 + 4));
      }
    }
  }
  #pragma unroll
  for (int i_16 = 0; i_16 < 4; ++i_16) {
    float4 __2;
      float4 v__2 = *(float4*)(C_local + (i_16 * 4));
      float4 v__3 = *(float4*)(C_block + (i_16 * 4));
      *(float2*)(&(__2.x)) = tl::add2(*(float2*)(&(v__2.x)), *(float2*)(&(v__3.x)));
      *(float2*)(&(__2.z)) = tl::add2(*(float2*)(&(v__2.z)), *(float2*)(&(v__3.z)));
    *(float4*)(C_local + (i_16 * 4)) = __2;
  }
  #pragma unroll
  for (int i_17 = 0; i_17 < 4; ++i_17) {
    float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_block + (i_17 * 4)) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
  }
  tl::cp_async_wait<1>();
  __syncthreads();
  {
    bfloat16_t A_local_2[16];
    bfloat16_t B_local_2[8];
    for (int ki_2 = 0; ki_2 < 4; ++ki_2) {
      #pragma unroll
      for (int i_18 = 0; i_18 < 2; ++i_18) {
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[(((((((((((int)threadIdx.x) & 63) >> 5) * 2048) + (i_18 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_2 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 8192)])), (&(A_local_2[(i_18 * 8)])));
      }
      tl::ptx_ldmatrix_x4((&(((bfloat16_t*)B_shared)[((((((((((int)threadIdx.x) >> 6) * 1024) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_2 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_2 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8)) + 8192)])), (&(B_local_2[0])));
      for (int i_19 = 0; i_19 < 2; ++i_19) {
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (i_19 * 8)), reinterpret_cast<const unsigned*>(A_local_2 + (i_19 * 8)), reinterpret_cast<const unsigned*>(B_local_2 + 0));
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + ((i_19 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local_2 + (i_19 * 8)), reinterpret_cast<const unsigned*>(B_local_2 + 4));
      }
    }
  }
  #pragma unroll
  for (int i_20 = 0; i_20 < 4; ++i_20) {
    float4 __3;
      float4 v__4 = *(float4*)(C_local + (i_20 * 4));
      float4 v__5 = *(float4*)(C_block + (i_20 * 4));
      *(float2*)(&(__3.x)) = tl::add2(*(float2*)(&(v__4.x)), *(float2*)(&(v__5.x)));
      *(float2*)(&(__3.z)) = tl::add2(*(float2*)(&(v__4.z)), *(float2*)(&(v__5.z)));
    *(float4*)(C_local + (i_20 * 4)) = __3;
  }
  #pragma unroll
  for (int i_21 = 0; i_21 < 4; ++i_21) {
    float broadcast_var_4 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_block + (i_21 * 4)) = make_float4(broadcast_var_4, broadcast_var_4, broadcast_var_4, broadcast_var_4);
  }
  tl::cp_async_wait<0>();
  __syncthreads();
  {
    bfloat16_t A_local_3[16];
    bfloat16_t B_local_3[8];
    for (int ki_3 = 0; ki_3 < 4; ++ki_3) {
      #pragma unroll
      for (int i_22 = 0; i_22 < 2; ++i_22) {
        tl::ptx_ldmatrix_x4((&(((bfloat16_t*)A_shared)[((((((((((int)threadIdx.x) & 63) >> 5) * 2048) + (i_22 * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_3 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_3 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local_3[(i_22 * 8)])));
      }
      tl::ptx_ldmatrix_x4((&(((bfloat16_t*)B_shared)[(((((((((int)threadIdx.x) >> 6) * 1024) + (((((int)threadIdx.x) & 31) >> 4) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (ki_3 >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki_3 & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local_3[0])));
      for (int i_23 = 0; i_23 < 2; ++i_23) {
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + (i_23 * 8)), reinterpret_cast<const unsigned*>(A_local_3 + (i_23 * 8)), reinterpret_cast<const unsigned*>(B_local_3 + 0));
        tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(C_block + ((i_23 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local_3 + (i_23 * 8)), reinterpret_cast<const unsigned*>(B_local_3 + 4));
      }
    }
  }
  #pragma unroll
  for (int i_24 = 0; i_24 < 4; ++i_24) {
    float4 __4;
      float4 v__6 = *(float4*)(C_local + (i_24 * 4));
      float4 v__7 = *(float4*)(C_block + (i_24 * 4));
      *(float2*)(&(__4.x)) = tl::add2(*(float2*)(&(v__6.x)), *(float2*)(&(v__7.x)));
      *(float2*)(&(__4.z)) = tl::add2(*(float2*)(&(v__6.z)), *(float2*)(&(v__7.z)));
    *(float4*)(C_local + (i_24 * 4)) = __4;
  }
  #pragma unroll
  for (int i_25 = 0; i_25 < 8; ++i_25) {
    if ((((((((int)blockIdx.z) * 64) + (((((int)threadIdx.x) & 63) >> 5) * 32)) + ((i_25 >> 2) * 16)) + ((i_25 & 1) * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M) {
      *(float2*)(P + ((((((((((((int64_t)((int)blockIdx.z)) * (int64_t)65536) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)32768)) + ((((int64_t)i_25) >> (int64_t)2) * (int64_t)16384)) + ((((int64_t)i_25) & (int64_t)1) * (int64_t)8192)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)1024)) + ((((int64_t)((int)blockIdx.y)) * ((int64_t)M)) * (int64_t)1024)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)16)) + (((((int64_t)i_25) & (int64_t)3) >> (int64_t)1) * (int64_t)8)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)2))) = *(float2*)(C_local + (i_25 * 2));
    }
  }
  splitk_fence();
  __syncthreads();
  if (((int)threadIdx.x) == 0) {
    int condval;
    if ((((((int)blockIdx.z) * 16) + ((int)blockIdx.x)) < tiles)) {
      condval = AtomicAddRet((&(counters[((((int64_t)((int)blockIdx.z)) * (int64_t)16) + ((int64_t)((int)blockIdx.x)))])), 1, 4);
    } else {
      condval = 0;
    }
    int arrived = condval;
    int condval_1;
    if ((arrived == 4)) {
      condval_1 = 1;
    } else {
      condval_1 = 0;
    }
    ((int*)last)[0] = condval_1;
  }
  __syncthreads();
  if (((int*)last)[0] == 1) {
    splitk_fence();
  }
  if (((int*)last)[0] == 1) {
    #pragma unroll
    for (int i_26 = 0; i_26 < 16; ++i_26) {
      if ((((((int)blockIdx.z) * 64) + (i_26 * 4)) + (((int)threadIdx.x) >> 6)) < M) {
        acc = P[(((((((int64_t)((int)blockIdx.z)) * (int64_t)65536) + (((int64_t)i_26) * (int64_t)4096)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)1024)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + (((int64_t)((int)threadIdx.x)) & (int64_t)63))];
        for (int t = 1; t < 5; ++t) {
          acc = (acc + P[((((((((int64_t)((int)blockIdx.z)) * (int64_t)65536) + (((int64_t)i_26) * (int64_t)4096)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)1024)) + ((((int64_t)t) * ((int64_t)M)) * (int64_t)1024)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + (((int64_t)((int)threadIdx.x)) & (int64_t)63))]);
        }
        if (((int)blockIdx.x) < 8) {
          C0[(((((((int64_t)((int)blockIdx.z)) * (int64_t)32768) + (((int64_t)i_26) * (int64_t)2048)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)512)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + (((int64_t)((int)threadIdx.x)) & (int64_t)63))] = acc;
        } else {
          C1[((((((((int64_t)((int)blockIdx.z)) * (int64_t)32768) + (((int64_t)i_26) * (int64_t)2048)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)6) * (int64_t)512)) + (((int64_t)((int)blockIdx.x)) * (int64_t)64)) + (((int64_t)((int)threadIdx.x)) & (int64_t)63)) - (int64_t)512)] = acc;
        }
      }
    }
  }
  if (((int*)last)[0] == 1) {
    if (((int)threadIdx.x) == 0) {
      if (((((int)blockIdx.z) * 16) + ((int)blockIdx.x)) < tiles) {
        counters[((((int64_t)((int)blockIdx.z)) * (int64_t)16) + ((int64_t)((int)blockIdx.x)))] = 0;
      }
    }
  }
}

