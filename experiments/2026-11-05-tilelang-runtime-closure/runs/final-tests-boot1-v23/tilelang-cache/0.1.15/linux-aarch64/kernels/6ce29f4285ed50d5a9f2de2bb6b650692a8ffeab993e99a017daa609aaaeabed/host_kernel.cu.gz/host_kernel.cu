// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* vision_rope_qkv_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_rope_qkv(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_vision_rope_qkv(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[10];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "vision_rope_qkv: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_rope_qkv: args pointer is NULL");
    return -1;
  }
  int32_t qkv_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((qkv_handle_type_index == 0) || (qkv_handle_type_index == 4)) || (qkv_handle_type_index == 7)) || (64 <= qkv_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv input qkv expected pointer or tensor handle");
    return -1;
  }
  int32_t inv_freq_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((inv_freq_handle_type_index == 0) || (inv_freq_handle_type_index == 4)) || (inv_freq_handle_type_index == 7)) || (64 <= inv_freq_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv input inv_freq expected pointer or tensor handle");
    return -1;
  }
  int32_t image_width_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((image_width_type_index == 1) || (image_width_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv scalar image_width expected integer");
    return -1;
  }
  void* qkv_handle = ((qkv_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* inv_freq_handle = ((inv_freq_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  int32_t image_width = ((int32_t)(((TVMFFIAny*)args)[2].v_int64));
  bool vision_rope_qkv_qkv_is_null = (qkv_handle == NULL);
  if (!(!vision_rope_qkv_qkv_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_rope_qkv.qkv is expected to have non-NULL pointer");
    return -1;
  }
  bool vision_rope_qkv_inv_freq_is_null = (inv_freq_handle == NULL);
  if (!(!vision_rope_qkv_inv_freq_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "vision_rope_qkv.inv_freq is expected to have non-NULL pointer");
    return -1;
  }
  void* vision_rope_qkv_qkv_shape = (((DLTensor*)qkv_handle)[0].shape);
  void* vision_rope_qkv_inv_freq_shape = (((DLTensor*)inv_freq_handle)[0].shape);
  if (!(((((DLTensor*)qkv_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input qkv ndim mismatch, expected 2", (long long)((((DLTensor*)qkv_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t M = ((int32_t)((int64_t*)vision_rope_qkv_qkv_shape)[0]);
  void* vision_rope_qkv_qkv_strides = (((DLTensor*)qkv_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)qkv_handle)[0].device.device_id);
  void* qkv = (((DLTensor*)qkv_handle)[0].data);
  if (!(((((DLTensor*)inv_freq_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input inv_freq ndim mismatch, expected 1", (long long)((((DLTensor*)inv_freq_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* vision_rope_qkv_inv_freq_strides = (((DLTensor*)inv_freq_handle)[0].strides);
  void* inv_freq = (((DLTensor*)inv_freq_handle)[0].data);
  if (!(((((((DLTensor*)qkv_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)qkv_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)qkv_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv input qkv dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_rope_qkv_qkv_shape)[1]) == 3072))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input qkv shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_rope_qkv_qkv_shape)[1])), (long long)(3072));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((vision_rope_qkv_qkv_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)vision_rope_qkv_qkv_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((vision_rope_qkv_qkv_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)vision_rope_qkv_qkv_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input qkv strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((vision_rope_qkv_qkv_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)vision_rope_qkv_qkv_strides)[0]);
  }
  if (!(((condval_2 == 3072) || (M == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv input qkv strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)qkv_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input qkv byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)qkv_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)qkv_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input qkv device_type mismatch, expected cuda", (long long)((((DLTensor*)qkv_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((M == 0) || !(qkv == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv input qkv data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)inv_freq_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)inv_freq_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)inv_freq_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv input inv_freq dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)vision_rope_qkv_inv_freq_shape)[0]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input inv_freq shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)vision_rope_qkv_inv_freq_shape)[0])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((vision_rope_qkv_inv_freq_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)vision_rope_qkv_inv_freq_strides)[0]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((vision_rope_qkv_inv_freq_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)vision_rope_qkv_inv_freq_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input inv_freq strides[0] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)inv_freq_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input inv_freq byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)inv_freq_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)inv_freq_handle)[0].device.device_id) == (((DLTensor*)qkv_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input inv_freq device_id violates packed ABI constraint", (long long)((((DLTensor*)inv_freq_handle)[0].device.device_id)), (long long)((((DLTensor*)qkv_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)inv_freq_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel vision_rope_qkv input inv_freq device_type mismatch, expected cuda", (long long)((((DLTensor*)inv_freq_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(inv_freq == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel vision_rope_qkv input inv_freq data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (inv_freq == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = inv_freq;
  if (qkv == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = qkv;
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)image_width);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)M);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)256);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = (int64_t)0;
  if (vision_rope_qkv_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "vision_rope_qkv_kernel", &vision_rope_qkv_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(vision_rope_qkv_kernel_packed, (TVMFFIAny*) stack_ffi_any, 9, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_vision_rope_qkv(self, args, num_args, result);
}
