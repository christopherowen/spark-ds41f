// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* collectives_rank_rows_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_collectives_rank_rows(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_collectives_rank_rows(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[13];
  void* stack_ffi_any = stack;
  if (!((num_args == 5))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "collectives_rank_rows: num_args should be 5", (long long)(num_args), (long long)(5));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_rows: args pointer is NULL");
    return -1;
  }
  int32_t src_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((src_handle_type_index == 0) || (src_handle_type_index == 4)) || (src_handle_type_index == 7)) || (64 <= src_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input src expected pointer or tensor handle");
    return -1;
  }
  int32_t out_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((out_handle_type_index == 0) || (out_handle_type_index == 4)) || (out_handle_type_index == 7)) || (64 <= out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input out expected pointer or tensor handle");
    return -1;
  }
  int32_t world_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((world_type_index == 1) || (world_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows scalar world expected integer");
    return -1;
  }
  int32_t rows_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((rows_type_index == 1) || (rows_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows scalar rows expected integer");
    return -1;
  }
  int32_t packs_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((packs_type_index == 1) || (packs_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows scalar packs expected integer");
    return -1;
  }
  void* src_handle = ((src_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* out_handle = ((out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  int32_t world = ((int32_t)(((TVMFFIAny*)args)[2].v_int64));
  int32_t rows = ((int32_t)(((TVMFFIAny*)args)[3].v_int64));
  int32_t packs = ((int32_t)(((TVMFFIAny*)args)[4].v_int64));
  bool collectives_rank_rows_src_is_null = (src_handle == NULL);
  if (!(!collectives_rank_rows_src_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_rows.src is expected to have non-NULL pointer");
    return -1;
  }
  bool collectives_rank_rows_out_is_null = (out_handle == NULL);
  if (!(!collectives_rank_rows_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "collectives_rank_rows.out is expected to have non-NULL pointer");
    return -1;
  }
  void* collectives_rank_rows_src_shape = (((DLTensor*)src_handle)[0].shape);
  void* collectives_rank_rows_out_shape = (((DLTensor*)out_handle)[0].shape);
  if (!(((((DLTensor*)src_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_rows input src ndim mismatch, expected 2", (long long)((((DLTensor*)src_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t src_rows = ((int32_t)((int64_t*)collectives_rank_rows_src_shape)[0]);
  int32_t src_words = ((int32_t)((int64_t*)collectives_rank_rows_src_shape)[1]);
  void* collectives_rank_rows_src_strides = (((DLTensor*)src_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)src_handle)[0].device.device_id);
  void* src = (((DLTensor*)src_handle)[0].data);
  if (!(((((DLTensor*)out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_rows input out ndim mismatch, expected 2", (long long)((((DLTensor*)out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t out_rows = ((int32_t)((int64_t*)collectives_rank_rows_out_shape)[0]);
  int32_t out_words = ((int32_t)((int64_t*)collectives_rank_rows_out_shape)[1]);
  void* collectives_rank_rows_out_strides = (((DLTensor*)out_handle)[0].strides);
  void* out = (((DLTensor*)out_handle)[0].data);
  if (!(((((((DLTensor*)src_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)src_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)src_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input src dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval;
  if ((collectives_rank_rows_src_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)collectives_rank_rows_src_strides)[1]);
  }
  if (!(((condval == 1) || (src_words == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input src strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_1;
  if ((collectives_rank_rows_src_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)collectives_rank_rows_src_strides)[0]);
  }
  if (!((((((int32_t)((int64_t*)collectives_rank_rows_src_shape)[1]) == condval_1) || (((int32_t)((int64_t*)collectives_rank_rows_src_shape)[1]) == 0)) || (src_rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input src strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)src_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_rows input src byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)src_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)src_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_rows input src device_type mismatch, expected cuda", (long long)((((DLTensor*)src_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((src_rows == 0) || (src_words == 0)) || !(src == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input src data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)out_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)out_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input out dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_2;
  if ((collectives_rank_rows_out_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)collectives_rank_rows_out_strides)[1]);
  }
  if (!(((condval_2 == 1) || (out_words == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input out strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_3;
  if ((collectives_rank_rows_out_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)collectives_rank_rows_out_strides)[0]);
  }
  if (!((((((int32_t)((int64_t*)collectives_rank_rows_out_shape)[1]) == condval_3) || (((int32_t)((int64_t*)collectives_rank_rows_out_shape)[1]) == 0)) || (out_rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_rows input out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_id) == (((DLTensor*)src_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_rows input out device_id violates packed ABI constraint", (long long)((((DLTensor*)out_handle)[0].device.device_id)), (long long)((((DLTensor*)src_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel collectives_rank_rows input out device_type mismatch, expected cuda", (long long)((((DLTensor*)out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((out_rows == 0) || (out_words == 0)) || !(out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel collectives_rank_rows input out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = out;
  if (src == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = src;
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)out_words);
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)packs);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)src_words);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)world);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)(((world * packs) + 127) >> 7));
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = (int64_t)0;
  if (collectives_rank_rows_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "collectives_rank_rows_kernel", &collectives_rank_rows_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(collectives_rank_rows_kernel_packed, (TVMFFIAny*) stack_ffi_any, 12, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_collectives_rank_rows(self, args, num_args, result);
}
