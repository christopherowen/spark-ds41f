
// Triton's bundled libdevice __nv_logf, as used by the sampling family.
// CUDA's logf and lg2.approx * ln(2) can move a min-p threshold by one ULP.
__device__ __forceinline__ float vllm_control_log(float x) {
  float result;
  asm("{\n"
      ".reg .pred tiny, fin, zero;\n"
      ".reg .b32 z, o, e, m, f, r, p, q, l, w;\n"
      "setp.lt.f32 tiny, %1, 0f00800000;\n"
      "mul.rn.f32 z, %1, 0f4B000000;\n"
      "selp.f32 z, z, %1, tiny;\n"
      "selp.f32 o, 0fC1B80000, 0f00000000, tiny;\n"
      "add.s32 e, z, -1059760811;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, z, e;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "fma.rn.ftz.f32 f, f, 0f34000000, o;\n"
      "add.rn.f32 r, m, 0fBF800000;\n"
      "fma.rn.ftz.f32 p, 0fBE055027, r, 0f3E1039F6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBDF8CDCC;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E0F2955;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2AD8B9;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CED0B;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE7FFF22;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAA78;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Preserve the bundled libdevice exceptional-value handling.
      "setp.lt.u32 fin, z, 2139095040;\n"
      "fma.rn.ftz.f32 w, z, 0f7F800000, 0f7F800000;\n"
      "selp.f32 l, l, w, fin;\n"
      "setp.eq.f32 zero, z, 0f00000000;\n"
      "selp.f32 %0, 0fFF800000, l, zero;\n"
      "}"
      : "=f"(result) : "f"(x));
  return result;
}
// Triton's masked loads and stores: a masked lane keeps ``other`` and never waits on
// memory, and nothing branches, so a tile's loads issue together.
__device__ __forceinline__ int vllm_control_load_if_b32(const void* p, int other,
                                                       bool ok) {
  int v = other;
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q ld.global.b32 %0, [%1];\n}"
               : "+r"(v) : "l"(p), "r"((int)ok));
  return v;
}
__device__ __forceinline__ float vllm_control_load_if_f32(const void* p, float other,
                                                         bool ok) {
  float v = other;
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q ld.global.f32 %0, [%1];\n}"
               : "+f"(v) : "l"(p), "r"((int)ok));
  return v;
}
__device__ __forceinline__ void vllm_control_store_if_b64(void* p, long long v,
                                                          bool ok) {
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q st.global.b64 [%0], %1;\n}"
               :: "l"(p), "l"(v), "r"((int)ok) : "memory");
}
__device__ __forceinline__ void vllm_control_store_if(void* p, float v, bool ok) {
  asm volatile("{\n .reg .pred q;\n setp.ne.b32 q, %2, 0;\n"
               " @q st.global.f32 [%0], %1;\n}"
               :: "l"(p), "f"(v), "r"((int)ok) : "memory");
}
__device__ __forceinline__ float vllm_control_reciprocal(float x) {
  float y;
  asm("rcp.approx.ftz.f32 %0, %1;" : "=f"(y) : "f"(x));
  return y;
}
__device__ __forceinline__ float vllm_control_penalty(float x, float scale,
    float freq, int count, float presence) {
  x = __fmul_rn(x, scale);
  x = __fmaf_rn(-freq, (float)count, x);
  return __fmaf_rn(-presence, (float)(count > 0), x);
}

// tl.exp of an FP32 value: the product with log2(e), then ex2.approx.f32 without
// flush-to-zero.
__device__ __forceinline__ float vllm_topk_exp(float x) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "mul.rn.f32 t, %1, 0f3FB8AA3B;\n"
      "ex2.approx.f32 %0, t;\n"
      "}"
      : "=f"(y)
      : "f"(x));
  return y;
}

// Triton's FP32 `/`: div.full.f32.
__device__ __forceinline__ float vllm_topk_div(float x, float y) {
  float q;
  asm("div.full.f32 %0, %1, %2;" : "=f"(q) : "f"(x), "f"(y));
  return q;
}

// tl.sqrt: sqrt.approx.ftz.f32.
__device__ __forceinline__ float vllm_topk_sqrt(float x) {
  float y;
  asm("sqrt.approx.ftz.f32 %0, %1;" : "=f"(y) : "f"(x));
  return y;
}

// FP32 arithmetic rounded to nearest, out of nvcc's contraction and the TileLang
// simplifier's reach.
__device__ __forceinline__ float vllm_topk_add(float a, float b) {
  float c;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_sub(float a, float b) {
  float c;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_mul(float a, float b) {
  float c;
  asm("mul.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_fma(float a, float b, float c) {
  float d;
  asm("fma.rn.f32 %0, %1, %2, %3;" : "=f"(d) : "f"(a), "f"(b), "f"(c));
  return d;
}

// max.f32 and min.f32: a NaN gives way to the other operand.
__device__ __forceinline__ float vllm_topk_max(float a, float b) {
  float c;
  asm("max.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_topk_min(float a, float b) {
  float c;
  asm("min.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}

// Ordered comparisons: false when either side is NaN.
__device__ __forceinline__ int vllm_topk_lt(float a, float b) { return a < b; }
__device__ __forceinline__ int vllm_topk_le(float a, float b) { return a <= b; }
__device__ __forceinline__ int vllm_topk_gt(float a, float b) { return a > b; }
__device__ __forceinline__ int vllm_topk_ge(float a, float b) { return a >= b; }
__device__ __forceinline__ int vllm_topk_eq(float a, float b) { return a == b; }

// tl.abs(a - b) < 1e-9, the tolerance of the pivot searches.
__device__ __forceinline__ int vllm_topk_near(float a, float b) {
  float d;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(d) : "f"(a), "f"(b));
  return fabsf(d) < __int_as_float(0x3089705F);
}

// tl.cast to uint32 and to int32: cvt.rzi, saturating, NaN to 0.
__device__ __forceinline__ unsigned int vllm_topk_u32(float x) {
  unsigned int y;
  asm("cvt.rzi.u32.f32 %0, %1;" : "=r"(y) : "f"(x));
  return y;
}
__device__ __forceinline__ int vllm_topk_i32(float x) {
  int y;
  asm("cvt.rzi.s32.f32 %0, %1;" : "=r"(y) : "f"(x));
  return y;
}

// The warp's ballot of a flag, a ballot's flags, and its flags below this lane.
__device__ __forceinline__ unsigned int vllm_topk_ballot(int flag) {
  return __ballot_sync(0xffffffffu, flag);
}
__device__ __forceinline__ int vllm_topk_popc(unsigned int mask) {
  return __popc(mask);
}
__device__ __forceinline__ int vllm_topk_below(unsigned int mask) {
  unsigned int lower;
  asm("mov.u32 %0, %%lanemask_lt;" : "=r"(lower));
  return __popc(mask & lower);
}

// The warp's sum of an integer, its inclusive prefix sums over the lanes, and the
// value of a lane.
__device__ __forceinline__ int vllm_topk_warp_count(int v) {
  return __reduce_add_sync(0xffffffffu, v);
}
__device__ __forceinline__ int vllm_topk_warp_scan(int v) {
  const int lane = threadIdx.x & 31;
#pragma unroll
  for (int d = 1; d < 32; d <<= 1) {
    const int u = __shfl_up_sync(0xffffffffu, v, d);
    if (lane >= d) v += u;
  }
  return v;
}
__device__ __forceinline__ int vllm_topk_lane(int v, int lane) {
  return __shfl_sync(0xffffffffu, v, lane);
}

// Whether any thread of the block passes a nonzero flag (a barrier).
__device__ __forceinline__ int vllm_topk_any(int flag) {
  return __syncthreads_or(flag);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void topp_stats_kernel(const float* __restrict__ logits, const float* __restrict__ p, float* __restrict__ stats, int64_t logits_stride, int rows);
extern "C" __global__ void __launch_bounds__(256, 1) topp_stats_kernel(const float* __restrict__ logits, const float* __restrict__ p, float* __restrict__ stats, int64_t logits_stride, int rows) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* red = ((void*)((char*)buf_dyn_shmem + 0));
  void* red_i = ((void*)((char*)buf_dyn_shmem + 64));
  float maximum[1];
  float exp_sum[1];
  float minimum[1];
  float finite[1];
  float values[32];
  float part[2];
  float top = 0x0p+0f/*0.000000e+00*/;
  float rescale = 0x0p+0f/*0.000000e+00*/;
  int count[1];
  float terms[32];
  bool if_condition = (vllm_topk_ge(p[(((int64_t)((int)blockIdx.x)) >> (int64_t)5)], 0x1p+0f/*1.000000e+00*/) == 0);
  if (if_condition) {
    maximum[0] = -CUDART_INF_F;
    exp_sum[0] = 0x0p+0f/*0.000000e+00*/;
    minimum[0] = CUDART_INF_F;
    finite[0] = 0x0p+0f/*0.000000e+00*/;
    #pragma unroll
    for (int r = 0; r < 8; ++r) {
      if ((((r * 1024) + (((int)threadIdx.x) * 4)) + ((((int)blockIdx.x) & 31) * 4)) == ((((int)blockIdx.x) & 31) * 4)) {
        *(float4*)(values + (r * 4)) = *(float4*)(logits + ((((((int64_t)r) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride)));
      } else {
        #pragma unroll
        for (int v = 0; v < 4; ++v) {
          values[((r * 4) + v)] = -CUDART_INF_F;
          if (((r * 256) + ((int)threadIdx.x)) < 1) {
            values[((r * 4) + v)] = logits[(((((((int64_t)r) * (int64_t)1024) + (((int64_t)((int)threadIdx.x)) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) & (int64_t)31) * (int64_t)4)) + ((((int64_t)((int)blockIdx.x)) >> (int64_t)5) * logits_stride)) + ((int64_t)v))];
          }
        }
      }
    }
    part[0] = values[0];
    #pragma unroll
    for (int e = 1; e < 32; ++e) {
      part[0] = vllm_topk_max(part[0], values[e]);
    }
    part[0] = vllm_topk_max(part[0], __shfl_xor_sync((uint)4294967295, part[0], 16, 32));
    part[0] = vllm_topk_max(part[0], __shfl_xor_sync((uint)4294967295, part[0], 8, 32));
    part[0] = vllm_topk_max(part[0], __shfl_xor_sync((uint)4294967295, part[0], 4, 32));
    part[0] = vllm_topk_max(part[0], __shfl_xor_sync((uint)4294967295, part[0], 2, 32));
    part[0] = vllm_topk_max(part[0], __shfl_xor_sync((uint)4294967295, part[0], 1, 32));
    __syncthreads();
    if ((((int)threadIdx.x) % 32) == 0) {
      ((float*)red)[(((int)threadIdx.x) >> 5)] = part[0];
    }
    __syncthreads();
    top = vllm_topk_max(maximum[0], vllm_topk_max(vllm_topk_max(vllm_topk_max(vllm_topk_max(vllm_topk_max(vllm_topk_max(vllm_topk_max(((float*)red)[0], ((float*)red)[1]), ((float*)red)[2]), ((float*)red)[3]), ((float*)red)[4]), ((float*)red)[5]), ((float*)red)[6]), ((float*)red)[7]));
    float condval;
    if ((vllm_topk_eq(maximum[0], -CUDART_INF_F) != 0)) {
      condval = 0x0p+0f/*0.000000e+00*/;
    } else {
      condval = vllm_topk_exp(vllm_topk_sub(maximum[0], top));
    }
    rescale = condval;
    part[1] = CUDART_INF_F;
    count[0] = 0;
    #pragma unroll
    for (int e_1 = 0; e_1 < 32; ++e_1) {
      bool live = (vllm_topk_gt(values[e_1], -CUDART_INF_F) != 0);
      float condval_1;
      if (live) {
        condval_1 = vllm_topk_exp(vllm_topk_sub(values[e_1], top));
      } else {
        condval_1 = 0x0p+0f/*0.000000e+00*/;
      }
      terms[e_1] = condval_1;
      float condval_2;
      if (live) {
        condval_2 = values[e_1];
      } else {
        condval_2 = CUDART_INF_F;
      }
      part[1] = vllm_topk_min(part[1], condval_2);
      count[0] = (count[0] + ((int)live));
    }
    part[0] = vllm_topk_add(terms[0], terms[1]);
    #pragma unroll
    for (int e_2 = 2; e_2 < 32; ++e_2) {
      part[0] = vllm_topk_add(part[0], terms[e_2]);
    }
    part[0] = vllm_topk_add(part[0], __shfl_xor_sync((uint)4294967295, part[0], 16, 32));
    part[0] = vllm_topk_add(part[0], __shfl_xor_sync((uint)4294967295, part[0], 8, 32));
    part[0] = vllm_topk_add(part[0], __shfl_xor_sync((uint)4294967295, part[0], 4, 32));
    part[0] = vllm_topk_add(part[0], __shfl_xor_sync((uint)4294967295, part[0], 2, 32));
    part[0] = vllm_topk_add(part[0], __shfl_xor_sync((uint)4294967295, part[0], 1, 32));
    part[1] = vllm_topk_min(part[1], __shfl_xor_sync((uint)4294967295, part[1], 16, 32));
    part[1] = vllm_topk_min(part[1], __shfl_xor_sync((uint)4294967295, part[1], 8, 32));
    part[1] = vllm_topk_min(part[1], __shfl_xor_sync((uint)4294967295, part[1], 4, 32));
    part[1] = vllm_topk_min(part[1], __shfl_xor_sync((uint)4294967295, part[1], 2, 32));
    part[1] = vllm_topk_min(part[1], __shfl_xor_sync((uint)4294967295, part[1], 1, 32));
    count[0] = vllm_topk_warp_count(count[0]);
    __syncthreads();
    if ((((int)threadIdx.x) % 32) == 0) {
      ((float*)red)[(((int)threadIdx.x) >> 5)] = part[0];
      ((float*)red)[((((int)threadIdx.x) >> 5) + 8)] = part[1];
      ((int*)red_i)[(((int)threadIdx.x) >> 5)] = count[0];
    }
    __syncthreads();
    exp_sum[0] = vllm_topk_fma(exp_sum[0], rescale, vllm_topk_add(vllm_topk_add(vllm_topk_add(((float*)red)[0], ((float*)red)[4]), vllm_topk_add(((float*)red)[2], ((float*)red)[6])), vllm_topk_add(vllm_topk_add(((float*)red)[1], ((float*)red)[5]), vllm_topk_add(((float*)red)[3], ((float*)red)[7]))));
    maximum[0] = top;
    minimum[0] = vllm_topk_min(minimum[0], vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(vllm_topk_min(((float*)red)[8], ((float*)red)[9]), ((float*)red)[10]), ((float*)red)[11]), ((float*)red)[12]), ((float*)red)[13]), ((float*)red)[14]), ((float*)red)[15]));
    finite[0] = vllm_topk_add(finite[0], ((float)(((((((((int*)red_i)[0] + ((int*)red_i)[1]) + ((int*)red_i)[2]) + ((int*)red_i)[3]) + ((int*)red_i)[4]) + ((int*)red_i)[5]) + ((int*)red_i)[6]) + ((int*)red_i)[7])));
    if (((int)threadIdx.x) == 0) {
      stats[(((int64_t)((int)blockIdx.x)) * (int64_t)4)] = maximum[0];
      stats[((((int64_t)((int)blockIdx.x)) * (int64_t)4) + (int64_t)1)] = exp_sum[0];
      stats[((((int64_t)((int)blockIdx.x)) * (int64_t)4) + (int64_t)2)] = minimum[0];
      stats[((((int64_t)((int)blockIdx.x)) * (int64_t)4) + (int64_t)3)] = finite[0];
    }
  }
}

