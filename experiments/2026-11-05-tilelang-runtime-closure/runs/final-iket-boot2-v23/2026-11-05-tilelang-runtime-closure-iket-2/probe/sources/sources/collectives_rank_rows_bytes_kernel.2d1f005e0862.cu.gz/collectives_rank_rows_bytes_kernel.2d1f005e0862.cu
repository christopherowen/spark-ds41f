__device__ __forceinline__ int __tl_iket_count(bool c) {
  int n;
  asm volatile("mov.b32 %0, %1;" : "=r"(n) : "r"((int)c));
  return n;
}
#define TL_IKET_WHEN(C) _Pragma("unroll 1") for (int __tl_iket_n = __tl_iket_count(C); __tl_iket_n > 0; --__tl_iket_n)

__device__ __forceinline__ unsigned vllm_tail_div(
    unsigned n, unsigned d, unsigned magic) {
  if (d == 1) return n;
  unsigned q = __umulhi(n, magic);
  return q - (static_cast<unsigned long long>(q) * d > n);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
// __tilelang_iket_tool__
// Experimental IKET metadata emitted by tilelang.tools.cuda.iket.
extern "C" {
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_load_global_1_attrs[60] = {60, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 169, 185, 89, 200, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_store_global_2_attrs[60] = {60, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 138, 198, 13, 198, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_load_global_3361323433_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 169, 185, 89, 200, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_store_global_3322791562_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 138, 198, 13, 198, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_meta_info[48] = {48, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 31, 0, 0, 0, 32, 0, 0, 0, 60, 0, 0, 0, 157, 241, 190, 186, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}

#define TL_IKET_EVENT(ID, ...) \
  asm volatile("{\n\t" \
               ".reg .b32 r, t;\n\t" \
               "mov.b32 r, %cluster_ctarank;\n\t" \
               "mov.u32 t, %globaltimer_lo;\n\t" \
               "or.b32 t, t, " #ID ";\n\t" \
               "mad.lo.u32 r, r, 0x1000000, 0x20;\n\t" \
               "st.weak.shared.u32 [r], t;\n\t" \
               "pmevent.mask " #ID ";\n\t" \
               "}" ::: "memory")

#define TL_IKET_EVENT_PAYLOAD_U32(ID, VALUE, ...) TL_IKET_EVENT(ID)
#define TL_IKET_EVENT_PAYLOAD_F32(ID, VALUE, ...) TL_IKET_EVENT(ID)

#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_rows_bytes_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int output_units, uint row_magic, int row_units, int rows, int source_units, uint span_magic, int world);
extern "C" __global__ void __launch_bounds__(256, 1) collectives_rank_rows_bytes_kernel(ushort* __restrict__ dst, const ushort* __restrict__ src, int output_units, uint row_magic, int row_units, int rows, int source_units, uint span_magic, int world) {
  const bool __tl_iket_cta = (((blockIdx.z * gridDim.y + blockIdx.y) * gridDim.x + blockIdx.x) % max(1u, gridDim.x * gridDim.y * gridDim.z / 1u)) == 0u;
  const bool __tl_iket_warp = ((((threadIdx.z * blockDim.y + threadIdx.y) * blockDim.x + threadIdx.x) >> 5) % max(1u, ((blockDim.x * blockDim.y * blockDim.z + 31u) >> 5) / 1u)) == 0u;
  if (((((int)blockIdx.x) * 256) + ((int)threadIdx.x)) < output_units) {
    uint row = vllm_tail_div(((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))), (((uint)world) * ((uint)row_units)), span_magic);
    uint rank = vllm_tail_div((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))), ((uint)row_units), row_magic);
    ushort condval;
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(1, "__tl_iket_v1_eyJldmVudF9pZCI6MSwia2luZCI6InJhbmdlIiwibmFtZSI6ImxvYWQuZ2xvYmFsIiwicGF5bG9hZF9pa2V0X2lkIjowLCJwYXlsb2FkX3R5cGUiOiJOb1BheWxvYWQiLCJyYW5nZV9pZCI6MzM2MTMyMzQzMywidmVyc2lvbiI6MX0");
    if (((((((rank * ((uint)rows)) + row) * ((uint)row_units)) + ((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))) - (rank * ((uint)row_units)))) < ((uint)source_units)) && ((uint)0 <= ((((rank * ((uint)rows)) + row) * ((uint)row_units)) + ((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))) - (rank * ((uint)row_units))))))) {
      condval = src[((((rank * ((uint)rows)) + row) * ((uint)row_units)) + ((((uint)((((int)blockIdx.x) * 256) + ((int)threadIdx.x))) - (row * (((uint)world) * ((uint)row_units)))) - (rank * ((uint)row_units))))];
    } else {
      condval = (ushort)0;
    }
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(2, "__tl_iket_v1_eyJldmVudF9pZCI6Miwia2luZCI6InJhbmdlIiwibmFtZSI6InN0b3JlLmdsb2JhbCIsInBheWxvYWRfaWtldF9pZCI6MCwicGF5bG9hZF90eXBlIjoiTm9QYXlsb2FkIiwicmFuZ2VfaWQiOjMzMjI3OTE1NjIsInZlcnNpb24iOjF9");
    dst[((((int64_t)((int)blockIdx.x)) * (int64_t)256) + ((int64_t)((int)threadIdx.x)))] = condval;
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  }
}

