__device__ __forceinline__ int __tl_iket_count(bool c) {
  int n;
  asm volatile("mov.b32 %0, %1;" : "=r"(n) : "r"((int)c));
  return n;
}
#define TL_IKET_WHEN(C) _Pragma("unroll 1") for (int __tl_iket_n = __tl_iket_count(C); __tl_iket_n > 0; --__tl_iket_n)

__device__ __forceinline__ void vllm_gather_b128(const void* d, const void* s) {
  *reinterpret_cast<uint4*>(const_cast<void*>(d)) = *reinterpret_cast<const uint4*>(s);
}
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
// __tilelang_iket_tool__
// Experimental IKET metadata emitted by tilelang.tools.cuda.iket.
extern "C" {
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_load_global_1_attrs[60] = {60, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 169, 185, 89, 200, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_load_global_3361323433_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 169, 185, 89, 200, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_meta_info[48] = {48, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 31, 0, 0, 0, 32, 0, 0, 0, 60, 0, 0, 0, 157, 241, 190, 186, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}

#define TL_IKET_EVENT(ID, ...) \
  asm volatile("{\n\t" \
               ".reg .b32 r, t;\n\t" \
               "mov.b32 r, %cluster_ctarank;\n\t" \
               "mov.u32 t, %globaltimer_lo;\n\t" \
               "or.b32 t, t, " #ID ";\n\t" \
               "mad.lo.u32 r, r, 0x1000000, 0x20;\n\t" \
               "st.weak.shared.u32 [r], t;\n\t" \
               "pmevent.mask " #ID ";\n\t" \
               "}" ::: "memory")

#define TL_IKET_EVENT_PAYLOAD_U32(ID, VALUE, ...) TL_IKET_EVENT(ID)
#define TL_IKET_EVENT_PAYLOAD_F32(ID, VALUE, ...) TL_IKET_EVENT(ID)

#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void gather_columns_into_kernel(float* __restrict__ out0, float* __restrict__ out1, float* __restrict__ src, int rows, int stride0, int stride1);
extern "C" __global__ void __launch_bounds__(128, 1) gather_columns_into_kernel(float* __restrict__ out0, float* __restrict__ out1, float* __restrict__ src, int rows, int stride0, int stride1) {
  const bool __tl_iket_cta = (((blockIdx.z * gridDim.y + blockIdx.y) * gridDim.x + blockIdx.x) % max(1u, gridDim.x * gridDim.y * gridDim.z / 1u)) == 0u;
  const bool __tl_iket_warp = ((((threadIdx.z * blockDim.y + threadIdx.y) * blockDim.x + threadIdx.x) >> 5) % max(1u, ((blockDim.x * blockDim.y * blockDim.z + 31u) >> 5) / 1u)) == 0u;
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(1, "__tl_iket_v1_eyJldmVudF9pZCI6MSwia2luZCI6InJhbmdlIiwibmFtZSI6ImxvYWQuZ2xvYmFsIiwicGF5bG9hZF9pa2V0X2lkIjowLCJwYXlsb2FkX3R5cGUiOiJOb1BheWxvYWQiLCJyYW5nZV9pZCI6MzM2MTMyMzQzMywidmVyc2lvbiI6MX0");
  if (((int)threadIdx.x) < 16) {
    vllm_gather_b128((&(out0[((((int64_t)((int)threadIdx.x)) * (int64_t)4) + (((int64_t)((int)blockIdx.x)) * ((int64_t)stride0)))])), (&(src[(((((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * ((int64_t)rows)) * (int64_t)32) + (((int64_t)((int)blockIdx.x)) * (int64_t)16)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)4))])));
    vllm_gather_b128((&(out1[((((int64_t)((int)threadIdx.x)) * (int64_t)4) + (((int64_t)((int)blockIdx.x)) * ((int64_t)stride1)))])), (&(src[(((((((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)2) + (int64_t)1) * ((int64_t)rows)) * (int64_t)16) + (((int64_t)((int)blockIdx.x)) * (int64_t)16)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)4))])));
  }
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
}

