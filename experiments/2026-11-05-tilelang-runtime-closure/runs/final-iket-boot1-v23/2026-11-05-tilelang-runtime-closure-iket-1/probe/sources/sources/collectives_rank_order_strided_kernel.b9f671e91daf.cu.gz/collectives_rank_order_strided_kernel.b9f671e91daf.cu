__device__ __forceinline__ int __tl_iket_count(bool c) {
  int n;
  asm volatile("mov.b32 %0, %1;" : "=r"(n) : "r"((int)c));
  return n;
}
#define TL_IKET_WHEN(C) _Pragma("unroll 1") for (int __tl_iket_n = __tl_iket_count(C); __tl_iket_n > 0; --__tl_iket_n)
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
// __tilelang_iket_tool__
// Experimental IKET metadata emitted by tilelang.tools.cuda.iket.
extern "C" {
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_load_global_1_attrs[60] = {60, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 169, 185, 89, 200, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_store_global_2_attrs[60] = {60, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 138, 198, 13, 198, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_load_global_3361323433_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 169, 185, 89, 200, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_store_global_3322791562_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 138, 198, 13, 198, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_meta_info[48] = {48, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 31, 0, 0, 0, 32, 0, 0, 0, 60, 0, 0, 0, 157, 241, 190, 186, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}

#define TL_IKET_EVENT(ID, ...) \
  asm volatile("{\n\t" \
               ".reg .b32 r, t;\n\t" \
               "mov.b32 r, %cluster_ctarank;\n\t" \
               "mov.u32 t, %globaltimer_lo;\n\t" \
               "or.b32 t, t, " #ID ";\n\t" \
               "mad.lo.u32 r, r, 0x1000000, 0x20;\n\t" \
               "st.weak.shared.u32 [r], t;\n\t" \
               "pmevent.mask " #ID ";\n\t" \
               "}" ::: "memory")

#define TL_IKET_EVENT_PAYLOAD_U32(ID, VALUE, ...) TL_IKET_EVENT(ID)
#define TL_IKET_EVENT_PAYLOAD_F32(ID, VALUE, ...) TL_IKET_EVENT(ID)

#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void collectives_rank_order_strided_kernel(float* __restrict__ output, const float* __restrict__ s0, const float* __restrict__ source, const float* __restrict__ source_1, int dim0, int dim1, int dim2, int dim3, int dim4, int dim5, int dim6, int dim7, int stride0_0, int stride0_1, int stride0_2, int stride0_3, int stride0_4, int stride0_5, int stride0_6, int stride0_7, int stride1_0, int stride1_1, int stride1_2, int stride1_3, int stride1_4, int stride1_5, int stride1_6, int stride1_7, int stride2_0, int stride2_1, int stride2_2, int stride2_3, int stride2_4, int stride2_5, int stride2_6, int stride2_7, int stride3_0, int stride3_1, int stride3_2, int stride3_3, int stride3_4, int stride3_5, int stride3_6, int stride3_7);
extern "C" __global__ void __launch_bounds__(256, 1) collectives_rank_order_strided_kernel(float* __restrict__ output, const float* __restrict__ s0, const float* __restrict__ source, const float* __restrict__ source_1, int dim0, int dim1, int dim2, int dim3, int dim4, int dim5, int dim6, int dim7, int stride0_0, int stride0_1, int stride0_2, int stride0_3, int stride0_4, int stride0_5, int stride0_6, int stride0_7, int stride1_0, int stride1_1, int stride1_2, int stride1_3, int stride1_4, int stride1_5, int stride1_6, int stride1_7, int stride2_0, int stride2_1, int stride2_2, int stride2_3, int stride2_4, int stride2_5, int stride2_6, int stride2_7, int stride3_0, int stride3_1, int stride3_2, int stride3_3, int stride3_4, int stride3_5, int stride3_6, int stride3_7) {
  const bool __tl_iket_cta = (((blockIdx.z * gridDim.y + blockIdx.y) * gridDim.x + blockIdx.x) % max(1u, gridDim.x * gridDim.y * gridDim.z / 1u)) == 0u;
  const bool __tl_iket_warp = ((((threadIdx.z * blockDim.y + threadIdx.y) * blockDim.x + threadIdx.x) >> 5) % max(1u, ((blockDim.x * blockDim.y * blockDim.z + 31u) >> 5) / 1u)) == 0u;
  int64_t remaining = (int64_t)0;
  int indices[8];
  float total = 0x0p+0f/*0.000000e+00*/;
  if (((((int64_t)blockIdx.x) * (int64_t)256) + ((int64_t)((int)threadIdx.x))) < (((((((((int64_t)dim0) * ((int64_t)dim1)) * ((int64_t)dim2)) * ((int64_t)dim3)) * ((int64_t)dim4)) * ((int64_t)dim5)) * ((int64_t)dim6)) * ((int64_t)dim7))) {
    remaining = ((((int64_t)blockIdx.x) * (int64_t)256) + ((int64_t)((int)threadIdx.x)));
    int64_t rmod = (remaining % ((int64_t)dim7));
    indices[7] = ((int)(((((int64_t)0 <= ((int64_t)dim7)) && ((int64_t)0 <= rmod)) || ((((int64_t)dim7) < (int64_t)0) && (rmod <= (int64_t)0))) ? rmod : (rmod + ((int64_t)dim7))));
    int64_t rmod_1 = (remaining % ((int64_t)dim7));
    int64_t rdiv = (remaining / ((int64_t)dim7));
    remaining = (((((int64_t)0 <= ((int64_t)dim7)) && ((int64_t)0 <= rmod_1)) || ((((int64_t)dim7) < (int64_t)0) && (rmod_1 <= (int64_t)0))) ? rdiv : (rdiv - (int64_t)1));
    int64_t rmod_2 = (remaining % ((int64_t)dim6));
    indices[6] = ((int)(((((int64_t)0 <= ((int64_t)dim6)) && ((int64_t)0 <= rmod_2)) || ((((int64_t)dim6) < (int64_t)0) && (rmod_2 <= (int64_t)0))) ? rmod_2 : (rmod_2 + ((int64_t)dim6))));
    int64_t rmod_3 = (remaining % ((int64_t)dim6));
    int64_t rdiv_1 = (remaining / ((int64_t)dim6));
    remaining = (((((int64_t)0 <= ((int64_t)dim6)) && ((int64_t)0 <= rmod_3)) || ((((int64_t)dim6) < (int64_t)0) && (rmod_3 <= (int64_t)0))) ? rdiv_1 : (rdiv_1 - (int64_t)1));
    int64_t rmod_4 = (remaining % ((int64_t)dim5));
    indices[5] = ((int)(((((int64_t)0 <= ((int64_t)dim5)) && ((int64_t)0 <= rmod_4)) || ((((int64_t)dim5) < (int64_t)0) && (rmod_4 <= (int64_t)0))) ? rmod_4 : (rmod_4 + ((int64_t)dim5))));
    int64_t rmod_5 = (remaining % ((int64_t)dim5));
    int64_t rdiv_2 = (remaining / ((int64_t)dim5));
    remaining = (((((int64_t)0 <= ((int64_t)dim5)) && ((int64_t)0 <= rmod_5)) || ((((int64_t)dim5) < (int64_t)0) && (rmod_5 <= (int64_t)0))) ? rdiv_2 : (rdiv_2 - (int64_t)1));
    int64_t rmod_6 = (remaining % ((int64_t)dim4));
    indices[4] = ((int)(((((int64_t)0 <= ((int64_t)dim4)) && ((int64_t)0 <= rmod_6)) || ((((int64_t)dim4) < (int64_t)0) && (rmod_6 <= (int64_t)0))) ? rmod_6 : (rmod_6 + ((int64_t)dim4))));
    int64_t rmod_7 = (remaining % ((int64_t)dim4));
    int64_t rdiv_3 = (remaining / ((int64_t)dim4));
    remaining = (((((int64_t)0 <= ((int64_t)dim4)) && ((int64_t)0 <= rmod_7)) || ((((int64_t)dim4) < (int64_t)0) && (rmod_7 <= (int64_t)0))) ? rdiv_3 : (rdiv_3 - (int64_t)1));
    int64_t rmod_8 = (remaining % ((int64_t)dim3));
    indices[3] = ((int)(((((int64_t)0 <= ((int64_t)dim3)) && ((int64_t)0 <= rmod_8)) || ((((int64_t)dim3) < (int64_t)0) && (rmod_8 <= (int64_t)0))) ? rmod_8 : (rmod_8 + ((int64_t)dim3))));
    int64_t rmod_9 = (remaining % ((int64_t)dim3));
    int64_t rdiv_4 = (remaining / ((int64_t)dim3));
    remaining = (((((int64_t)0 <= ((int64_t)dim3)) && ((int64_t)0 <= rmod_9)) || ((((int64_t)dim3) < (int64_t)0) && (rmod_9 <= (int64_t)0))) ? rdiv_4 : (rdiv_4 - (int64_t)1));
    int64_t rmod_10 = (remaining % ((int64_t)dim2));
    indices[2] = ((int)(((((int64_t)0 <= ((int64_t)dim2)) && ((int64_t)0 <= rmod_10)) || ((((int64_t)dim2) < (int64_t)0) && (rmod_10 <= (int64_t)0))) ? rmod_10 : (rmod_10 + ((int64_t)dim2))));
    int64_t rmod_11 = (remaining % ((int64_t)dim2));
    int64_t rdiv_5 = (remaining / ((int64_t)dim2));
    remaining = (((((int64_t)0 <= ((int64_t)dim2)) && ((int64_t)0 <= rmod_11)) || ((((int64_t)dim2) < (int64_t)0) && (rmod_11 <= (int64_t)0))) ? rdiv_5 : (rdiv_5 - (int64_t)1));
    int64_t rmod_12 = (remaining % ((int64_t)dim1));
    indices[1] = ((int)(((((int64_t)0 <= ((int64_t)dim1)) && ((int64_t)0 <= rmod_12)) || ((((int64_t)dim1) < (int64_t)0) && (rmod_12 <= (int64_t)0))) ? rmod_12 : (rmod_12 + ((int64_t)dim1))));
    int64_t rmod_13 = (remaining % ((int64_t)dim1));
    int64_t rdiv_6 = (remaining / ((int64_t)dim1));
    remaining = (((((int64_t)0 <= ((int64_t)dim1)) && ((int64_t)0 <= rmod_13)) || ((((int64_t)dim1) < (int64_t)0) && (rmod_13 <= (int64_t)0))) ? rdiv_6 : (rdiv_6 - (int64_t)1));
    int64_t rmod_14 = (remaining % ((int64_t)dim0));
    indices[0] = ((int)(((((int64_t)0 <= ((int64_t)dim0)) && ((int64_t)0 <= rmod_14)) || ((((int64_t)dim0) < (int64_t)0) && (rmod_14 <= (int64_t)0))) ? rmod_14 : (rmod_14 + ((int64_t)dim0))));
    int64_t rmod_15 = (remaining % ((int64_t)dim0));
    int64_t rdiv_7 = (remaining / ((int64_t)dim0));
    remaining = (((((int64_t)0 <= ((int64_t)dim0)) && ((int64_t)0 <= rmod_15)) || ((((int64_t)dim0) < (int64_t)0) && (rmod_15 <= (int64_t)0))) ? rdiv_7 : (rdiv_7 - (int64_t)1));
    float condval;
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(1, "__tl_iket_v1_eyJldmVudF9pZCI6MSwia2luZCI6InJhbmdlIiwibmFtZSI6ImxvYWQuZ2xvYmFsIiwicGF5bG9hZF9pa2V0X2lkIjowLCJwYXlsb2FkX3R5cGUiOiJOb1BheWxvYWQiLCJyYW5nZV9pZCI6MzM2MTMyMzQzMywidmVyc2lvbiI6MX0");
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval = s0[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride0_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride0_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride0_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride0_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride0_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride0_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride0_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride0_7)))];
    } else {
      condval = 0x0p+0f/*0.000000e+00*/;
    }
    total = condval;
    float condval_1;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_1 = source_1[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride1_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride1_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride1_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride1_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride1_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride1_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride1_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride1_7)))];
    } else {
      condval_1 = 0x0p+0f/*0.000000e+00*/;
    }
    total = (total + condval_1);
    float condval_2;
    if (((((((((((((((((0 <= indices[7]) && (indices[7] < dim7)) && (0 <= indices[6])) && (indices[6] < dim6)) && (0 <= indices[5])) && (indices[5] < dim5)) && (0 <= indices[4])) && (indices[4] < dim4)) && (0 <= indices[3])) && (indices[3] < dim3)) && (0 <= indices[2])) && (indices[2] < dim2)) && (0 <= indices[1])) && (indices[1] < dim1)) && (0 <= indices[0])) && (indices[0] < dim0))) {
      condval_2 = source[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride2_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride2_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride2_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride2_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride2_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride2_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride2_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride2_7)))];
    } else {
      condval_2 = 0x0p+0f/*0.000000e+00*/;
    }
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
    total = (total + condval_2);
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(2, "__tl_iket_v1_eyJldmVudF9pZCI6Miwia2luZCI6InJhbmdlIiwibmFtZSI6InN0b3JlLmdsb2JhbCIsInBheWxvYWRfaWtldF9pZCI6MCwicGF5bG9hZF90eXBlIjoiTm9QYXlsb2FkIiwicmFuZ2VfaWQiOjMzMjI3OTE1NjIsInZlcnNpb24iOjF9");
    if (0 <= indices[7]) {
      if (indices[7] < dim7) {
        if (0 <= indices[6]) {
          if (indices[6] < dim6) {
            if (0 <= indices[5]) {
              if (indices[5] < dim5) {
                if (0 <= indices[4]) {
                  if (indices[4] < dim4) {
                    if (0 <= indices[3]) {
                      if (indices[3] < dim3) {
                        if (0 <= indices[2]) {
                          if (indices[2] < dim2) {
                            if (0 <= indices[1]) {
                              if (indices[1] < dim1) {
                                if (0 <= indices[0]) {
                                  if (indices[0] < dim0) {
                                    output[((((((((((int64_t)indices[(int64_t)0]) * ((int64_t)stride3_0)) + (((int64_t)indices[(int64_t)1]) * ((int64_t)stride3_1))) + (((int64_t)indices[(int64_t)2]) * ((int64_t)stride3_2))) + (((int64_t)indices[(int64_t)3]) * ((int64_t)stride3_3))) + (((int64_t)indices[(int64_t)4]) * ((int64_t)stride3_4))) + (((int64_t)indices[(int64_t)5]) * ((int64_t)stride3_5))) + (((int64_t)indices[(int64_t)6]) * ((int64_t)stride3_6))) + (((int64_t)indices[(int64_t)7]) * ((int64_t)stride3_7)))] = total;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  }
}

