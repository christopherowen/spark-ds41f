#define TL_IKET_SETTLE() asm volatile("{\n\t.reg .b32 a, s;\n\tmov.u32 a, 0x20;\n\tld.volatile.shared.u32 s, [a];\n\t}" ::: "memory")
__device__ __forceinline__ int __tl_iket_count(bool c) {
  int n;
  asm volatile("mov.b32 %0, %1;" : "=r"(n) : "r"((int)c));
  return n;
}
#define TL_IKET_WHEN(C) _Pragma("unroll 1") for (int __tl_iket_n = __tl_iket_count(C); __tl_iket_n > 0; --__tl_iket_n)

// Triton 3.5 philox_impl (triton/language/random.py) on 32-bit words, ten
// rounds; the first word.
__device__ __forceinline__ unsigned int vllm_philox(unsigned int c0, unsigned int c1,
                                                   unsigned int c2, unsigned int c3,
                                                   unsigned int k0, unsigned int k1) {
#pragma unroll
  for (int round = 0; round < 10; ++round) {
    const unsigned int a = c0;
    const unsigned int b = c2;
    c0 = __umulhi(0xCD9E8D57u, b) ^ c1 ^ k0;
    c2 = __umulhi(0xD2511F53u, a) ^ c3 ^ k1;
    c1 = 0xCD9E8D57u * b;
    c3 = 0xD2511F53u * a;
    k0 += 0x9E3779B9u;
    k1 += 0xBB67AE85u;
  }
  return c0;
}

// tl.randint(seed, offset) for an int64 seed and an int64 offset: the offset's
// low word, then its arithmetic high word.
__device__ __forceinline__ unsigned int vllm_randint64(long long seed,
                                                      long long offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox((unsigned int)offset, (unsigned int)(offset >> 32), 0u, 0u,
                     (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for an int64 seed and an int32 offset: Triton gives a
// 32-bit offset no high word.
__device__ __forceinline__ unsigned int vllm_randint64_offset32(long long seed,
                                                               unsigned int offset) {
  const unsigned long long key = (unsigned long long)seed;
  return vllm_philox(offset, 0u, 0u, 0u, (unsigned int)key, (unsigned int)(key >> 32));
}

// tl.randint(seed, offset) for a uint32 seed (tl.randint's own result, widened
// with zeros) and an int32 offset (no high word).
__device__ __forceinline__ unsigned int vllm_randint32(unsigned int seed, int offset) {
  return vllm_philox((unsigned int)offset, 0u, 0u, 0u, seed, 0u);
}

// gumbel.py's FP32 noise of one Philox word, as Triton 3.5 compiles
// tl_rand32(includes_zero=False) and -tl.log(-tldevice.log1p(-u)) for sm_121a:
// uint_to_uniform_float, the clamp to _TL_RAND_MIN (0f2FFFFFFF), then libdevice's
// __nv_log1pf of 0 - u and __nv_logf of 0 - that, negated.
__device__ __forceinline__ float vllm_gumbel_noise(unsigned int word) {
  float noise;
  asm("{\n"
      ".reg .pred fin, inside, zero, tiny;\n"
      ".reg .b32 x, s, u, v, t, e, m, k, a, r, f, p, q, l, w, y, z, o;\n"
      // uint_to_uniform_float: where(x < 0, -x - 1, x) * 4.6566127342e-10
      "shr.s32 s, %1, 31;\n"
      "xor.b32 x, s, %1;\n"
      "cvt.rn.f32.s32 u, x;\n"
      "mul.rn.f32 u, u, 0f2FFFFFFF;\n"
      "max.f32 u, u, 0f2FFFFFFF;\n"
      // __nv_log1pf(v), v = 0 - u
      "sub.rn.f32 v, 0f00000000, u;\n"
      "add.rz.ftz.f32 t, v, 0f3F800000;\n"
      "add.s32 e, t, -1061158912;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, v, e;\n"
      "sub.s32 k, 1082130432, e;\n"
      "fma.rn.ftz.f32 a, 0f3E800000, k, 0fBF800000;\n"
      "add.rn.f32 r, a, m;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "mul.rn.f32 f, f, 0f34000000;\n"
      "fma.rn.ftz.f32 p, 0fBD39BF78, r, 0f3DD80012;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE0778E0;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E146475;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2A68DD;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CAF9E;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE800042;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAAE6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not a finite non-negative v: inside [-1, -0] keep, else fma(v, inf, inf);
      // then a zero v gives -0.
      "setp.lt.u32 fin, v, 2139095040;\n"
      "setp.lt.s32 inside, v, -1082130431;\n"
      "fma.rn.ftz.f32 w, v, 0f7F800000, 0f7F800000;\n"
      "selp.f32 w, l, w, inside;\n"
      "setp.eq.f32 zero, v, 0f00000000;\n"
      "selp.f32 w, 0f80000000, w, zero;\n"
      "selp.f32 l, l, w, fin;\n"
      // __nv_logf(y), y = 0 - log1p(v): subnormal y scaled by 2^23
      "sub.rn.f32 y, 0f00000000, l;\n"
      "setp.lt.f32 tiny, y, 0f00800000;\n"
      "mul.rn.f32 z, y, 0f4B000000;\n"
      "selp.f32 z, z, y, tiny;\n"
      "selp.f32 o, 0fC1B80000, 0f00000000, tiny;\n"
      "add.s32 e, z, -1059760811;\n"
      "and.b32 e, e, -8388608;\n"
      "sub.s32 m, z, e;\n"
      "cvt.rn.f32.s32 f, e;\n"
      "fma.rn.ftz.f32 f, f, 0f34000000, o;\n"
      "add.rn.f32 r, m, 0fBF800000;\n"
      "fma.rn.ftz.f32 p, 0fBE055027, r, 0f3E1039F6;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBDF8CDCC;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E0F2955;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE2AD8B9;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3E4CED0B;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBE7FFF22;\n"
      "fma.rn.ftz.f32 p, p, r, 0f3EAAAA78;\n"
      "fma.rn.ftz.f32 p, p, r, 0fBF000000;\n"
      "mul.rn.f32 q, r, p;\n"
      "fma.rn.ftz.f32 q, q, r, r;\n"
      "fma.rn.ftz.f32 l, f, 0f3F317218, q;\n"
      // Not finite non-negative: fma(z, inf, inf). The noise is 0 - logf(y), or
      // +inf where z is zero.
      "setp.lt.u32 fin, z, 2139095040;\n"
      "fma.rn.ftz.f32 w, z, 0f7F800000, 0f7F800000;\n"
      "selp.f32 l, l, w, fin;\n"
      "sub.rn.f32 l, 0f00000000, l;\n"
      "setp.eq.f32 zero, z, 0f00000000;\n"
      "selp.f32 %0, 0f7F800000, l, zero;\n"
      "}"
      : "=f"(noise)
      : "r"(word));
  return noise;
}

// A logit plus the noise of its word: Triton's FP32 add.
__device__ __forceinline__ float vllm_gumbel_score(float logit, unsigned int word) {
  const float noise = vllm_gumbel_noise(word);
  float score;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(score) : "f"(logit), "f"(noise));
  return score;
}

// Triton's FP32 `/`: div.full.f32.
__device__ __forceinline__ float vllm_div_full(float x, float y) {
  float q;
  asm("div.full.f32 %0, %1, %2;" : "=f"(q) : "f"(x), "f"(y));
  return q;
}

// dspark.greedy._first_argmax: keep (av, ai) over (bv, bi) when av is NaN and bv
// is not or has a higher index, or neither is NaN and av > bv, or av == bv with
// ai < bi: torch.argmax's first maximum, NaN above everything. Bitwise, not
// short-circuit, operators: every comparison is evaluated and combined in
// predicates, as Triton's tl.where combine is, instead of a branch for each.
__device__ __forceinline__ int vllm_first_argmax_keep(float av, int ai, float bv,
                                                      int bi) {
  const bool a_nan = av != av;
  const bool b_nan = bv != bv;
  return (a_nan & (!b_nan | (ai < bi))) |
         (!a_nan & !b_nan & ((av > bv) | ((av == bv) & (ai < bi))));
}

// tl.max(..., return_indices=True)'s combine (tie break to the left): keep
// (v, i) over (w, j) when v > w, or v == w and i < j. Comparisons with NaN are
// false. Compiled here, out of the TileLang simplifier's reach; bitwise
// operators, as above.
__device__ __forceinline__ int vllm_argmax_keep(float v, int i, float w, int j) {
  return (v > w) | ((v == w) & (i < j));
}

// tl.exp of an FP32 value: the product with log2(e), then ex2.approx.f32 without
// flush-to-zero (ptxas keeps subnormal results).
__device__ __forceinline__ float vllm_exp(float x) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "mul.rn.f32 t, %1, 0f3FB8AA3B;\n"
      "ex2.approx.f32 %0, t;\n"
      "}"
      : "=f"(y)
      : "f"(x));
  return y;
}

// FP32 arithmetic rounded to nearest, out of nvcc's contraction and the TileLang
// simplifier's reach.
__device__ __forceinline__ float vllm_add(float a, float b) {
  float c;
  asm("add.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_sub(float a, float b) {
  float c;
  asm("sub.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
__device__ __forceinline__ float vllm_mul(float a, float b) {
  float c;
  asm("mul.rn.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}
// max.f32: a NaN gives way to the other operand.
__device__ __forceinline__ float vllm_max(float a, float b) {
  float c;
  asm("max.f32 %0, %1, %2;" : "=f"(c) : "f"(a), "f"(b));
  return c;
}

// tl.exp(x - m).
__device__ __forceinline__ float vllm_exp_from(float x, float m) {
  return vllm_exp(vllm_sub(x, m));
}

// expm1 within an ULP: CUDA's (libdevice), compiled without fast math.
__device__ __forceinline__ float vllm_expm1(float x) { return expm1f(x); }

// Barron, Gnanapragasam and Tschannen's log-softmax ("A Fix for Softmax and
// Cross-Entropy", Eq. 5), from a row's maximum m. These compute every value and
// select, in PTX: a C conditional lets nvcc predicate the exponential instead,
// which costs a column several instructions.
//
// A logit's shift x - m, exactly 0 where x is the maximum (an infinite one
// included).
__device__ __forceinline__ float vllm_shifted(float x, float m) {
  float y;
  asm("{\n"
      ".reg .pred tie;\n"
      ".reg .b32 d;\n"
      "sub.rn.f32 d, %1, %2;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.f32 %0, 0f00000000, d, tie;\n"
      "}"
      : "=f"(y)
      : "f"(x), "f"(m));
  return y;
}

// tl.exp(x - m) of a column that is not the maximum (NaN is not), 0 for one that is.
__device__ __forceinline__ float vllm_other_exp(float x, float m) {
  float y;
  asm("{\n"
      ".reg .pred tie;\n"
      ".reg .b32 t, e;\n"
      "sub.rn.f32 t, %1, %2;\n"
      "mul.rn.f32 t, t, 0f3FB8AA3B;\n"
      "ex2.approx.f32 e, t;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.f32 %0, 0f00000000, e, tie;\n"
      "}"
      : "=f"(y)
      : "f"(x), "f"(m));
  return y;
}

// 1 for a column holding the maximum, else 0: its ties, counted exactly in FP32.
__device__ __forceinline__ float vllm_tie(float x, float m) {
  float y;
  asm("set.eq.f32.f32 %0, %1, %2;" : "=f"(y) : "f"(x), "f"(m));
  return y;
}

// int: x is the maximum m.
__device__ __forceinline__ int vllm_is_max(float x, float m) {
  int y;
  asm("{\n"
      ".reg .pred tie;\n"
      "setp.eq.f32 tie, %1, %2;\n"
      "selp.s32 %0, 1, 0, tie;\n"
      "}"
      : "=r"(y)
      : "f"(x), "f"(m));
  return y;
}

// S, the others' sum: the columns that are not the maximum (sum), and of the
// maximum's ``ties`` all but one, exp(m - m) each (1; NaN for an infinite maximum,
// as the paper's z - z_max).
__device__ __forceinline__ float vllm_others(float sum, float ties, float m) {
  return ties > 1.0f
             ? vllm_add(sum, vllm_mul(vllm_sub(ties, 1.0f), vllm_exp_from(m, m)))
             : sum;
}

// A row's S from its block sums: NaN where its two or more columns are all -inf
// (the paper's z - z_max is -inf - -inf there, as in ``vllm_others``), which the
// block sums cannot tell, since a block whose maximum is -inf sums to 0.
__device__ __forceinline__ float vllm_row_others(float others, float m, int columns) {
  return (m == __uint_as_float(0xff800000u) && columns > 1)
             ? __uint_as_float(0x7fffffffu)
             : others;
}

// The log-sum-exp past the maximum, softplus(-margin) = log1p(S): CUDA's log1pf
// (libdevice, within an ULP).
__device__ __forceinline__ float vllm_softplus(float others) { return log1pf(others); }

// A sampled row's block sum of exponentials, kept while the block's maximum is
// above -inf (a NaN maximum is not), else 0.
__device__ __forceinline__ float vllm_live_sum(float m, float s) {
  float y;
  asm("{\n"
      ".reg .pred live;\n"
      "setp.gt.f32 live, %1, 0fFF800000;\n"
      "selp.f32 %0, %2, 0f00000000, live;\n"
      "}"
      : "=f"(y)
      : "f"(m), "f"(s));
  return y;
}

// A step of the cumulative log ratio: min(log_p + log_prob, 0), min.f32 (a NaN sum
// gives 0).
__device__ __forceinline__ float vllm_log_ratio(float log_p, float log_prob) {
  float y;
  asm("{\n"
      ".reg .b32 t;\n"
      "add.rn.f32 t, %1, %2;\n"
      "min.f32 %0, t, 0f00000000;\n"
      "}"
      : "=f"(y)
      : "f"(log_p), "f"(log_prob));
  return y;
}

// tl_rand32(includes_zero=False) of a Philox word: uint_to_uniform_float, then the
// clamp to _TL_RAND_MIN (0f2FFFFFFF).
__device__ __forceinline__ float vllm_uniform(unsigned int word) {
  float u;
  asm("{\n"
      ".reg .b32 s, x, v;\n"
      "shr.s32 s, %1, 31;\n"
      "xor.b32 x, s, %1;\n"
      "cvt.rn.f32.s32 v, x;\n"
      "mul.rn.f32 v, v, 0f2FFFFFFF;\n"
      "max.f32 %0, v, 0f2FFFFFFF;\n"
      "}"
      : "=f"(u)
      : "r"(word));
  return u;
}

// Block verification's acceptance threshold for a one-hot draft followed by a valid
// one, from the logs of the prefix's joint ratio p and of the next draft's target
// probability m: the residual mass p (1 - m) over residual + 1 - p, which is
// 1 - p m. Both complements are -expm1 of a log, never 1 - x of a probability near
// 1, where it cancels (1 - m was 0 once m rounded to 1); the quotient is IEEE's,
// and the threshold 1 where the denominator is not positive (p = m = 1, or NaN).
__device__ __forceinline__ float vllm_block_threshold(float log_p, float log_m) {
  const float residual = vllm_mul(vllm_exp(log_p), -vllm_expm1(log_m));
  const float denom = -vllm_expm1(vllm_add(log_p, log_m));
  float ratio;
  asm("div.rn.f32 %0, %1, %2;" : "=f"(ratio) : "f"(residual), "f"(denom));
  return denom > 0.0f ? ratio : 1.0f;
}

// u <= h, ordered: a NaN threshold accepts nothing.
__device__ __forceinline__ int vllm_at_most(float u, float h) { return u <= h; }
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <math_constants.h>
// __tilelang_iket_tool__
// Experimental IKET metadata emitted by tilelang.tools.cuda.iket.
extern "C" {
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_load_global_1_attrs[60] = {60, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 169, 185, 89, 200, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_compute_reduce_2_attrs[60] = {60, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 251, 224, 179, 120, 14, 0, 0, 0, 99, 111, 109, 112, 117, 116, 101, 46, 114, 101, 100, 117, 99, 101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_wait_sync_3_attrs[60] = {60, 0, 0, 0, 3, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 117, 231, 137, 147, 9, 0, 0, 0, 119, 97, 105, 116, 46, 115, 121, 110, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_load_global_2_4_attrs[60] = {60, 0, 0, 0, 4, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 207, 240, 223, 250, 13, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_compute_reduce_2_5_attrs[60] = {60, 0, 0, 0, 5, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 163, 150, 229, 96, 16, 0, 0, 0, 99, 111, 109, 112, 117, 116, 101, 46, 114, 101, 100, 117, 99, 101, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_wait_sync_2_6_attrs[60] = {60, 0, 0, 0, 6, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 255, 93, 129, 91, 11, 0, 0, 0, 119, 97, 105, 116, 46, 115, 121, 110, 99, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_store_global_7_attrs[60] = {60, 0, 0, 0, 7, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 138, 198, 13, 198, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_load_global_3_8_attrs[60] = {60, 0, 0, 0, 8, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 89, 192, 216, 141, 13, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 35, 51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_store_global_2_9_attrs[60] = {60, 0, 0, 0, 9, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 87, 229, 204, 132, 14, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_load_global_3361323433_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 169, 185, 89, 200, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_compute_reduce_2025054459_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 251, 224, 179, 120, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 99, 111, 109, 112, 117, 116, 101, 46, 114, 101, 100, 117, 99, 101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_wait_sync_2475288437_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 117, 231, 137, 147, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 119, 97, 105, 116, 46, 115, 121, 110, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_load_global_2_4208980175_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 207, 240, 223, 250, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_compute_reduce_2_1625659043_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 163, 150, 229, 96, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 99, 111, 109, 112, 117, 116, 101, 46, 114, 101, 100, 117, 99, 101, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_wait_sync_2_1535204863_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 255, 93, 129, 91, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 119, 97, 105, 116, 46, 115, 121, 110, 99, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_store_global_3322791562_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 138, 198, 13, 198, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_load_global_3_2379792473_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 89, 192, 216, 141, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 108, 111, 97, 100, 46, 103, 108, 111, 98, 97, 108, 35, 51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_store_global_2_2228020567_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 87, 229, 204, 132, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 35, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_meta_info[48] = {48, 0, 0, 0, 0, 0, 0, 0, 18, 0, 0, 0, 31, 0, 0, 0, 32, 0, 0, 0, 60, 0, 0, 0, 157, 241, 190, 186, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}

#define TL_IKET_EVENT(ID, ...) \
  asm volatile("{\n\t" \
               ".reg .b32 r, t;\n\t" \
               "mov.b32 r, %cluster_ctarank;\n\t" \
               "mov.u32 t, %globaltimer_lo;\n\t" \
               "or.b32 t, t, " #ID ";\n\t" \
               "mad.lo.u32 r, r, 0x1000000, 0x20;\n\t" \
               "st.weak.shared.u32 [r], t;\n\t" \
               "pmevent.mask " #ID ";\n\t" \
               "}" ::: "memory")

#define TL_IKET_EVENT_PAYLOAD_U32(ID, VALUE, ...) TL_IKET_EVENT(ID)
#define TL_IKET_EVENT_PAYLOAD_F32(ID, VALUE, ...) TL_IKET_EVENT(ID)

#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void topk_log_softmax_ranks_kernel(const float* __restrict__ logits, float* __restrict__ output, int64_t* __restrict__ ranks, const int64_t* __restrict__ token_ids, int64_t logits_stride, int rows, int topk, int vocab);
extern "C" __global__ void __launch_bounds__(1024, 1) topk_log_softmax_ranks_kernel(const float* __restrict__ logits, float* __restrict__ output, int64_t* __restrict__ ranks, const int64_t* __restrict__ token_ids, int64_t logits_stride, int rows, int topk, int vocab) {
  const bool __tl_iket_cta = (((blockIdx.z * gridDim.y + blockIdx.y) * gridDim.x + blockIdx.x) % max(1u, gridDim.x * gridDim.y * gridDim.z / 1u)) == 0u;
  const bool __tl_iket_warp = ((((threadIdx.z * blockDim.y + threadIdx.y) * blockDim.x + threadIdx.x) >> 5) % max(1u, ((blockDim.x * blockDim.y * blockDim.z + 31u) >> 5) / 1u)) == 0u;
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* max_partial = ((void*)((char*)buf_dyn_shmem + 0));
  void* rank_partial = ((void*)((char*)buf_dyn_shmem + 0));
  void* sum_partial = ((void*)((char*)buf_dyn_shmem + 0));
  void* tie_partial = ((void*)((char*)buf_dyn_shmem + 0));
  int rank_count[1];
  float selected_rank[1];
  float peak[2];
  float raw[2];
  float best[1];
  float maximum = 0x0p+0f/*0.000000e+00*/;
  float total[2];
  float tally[2];
  float se[1];
  float ties[1];
  float lse = 0x0p+0f/*0.000000e+00*/;
  int count = 0;
  rank_count[0] = 0;
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(1, "__tl_iket_v1_eyJldmVudF9pZCI6MSwia2luZCI6InJhbmdlIiwibmFtZSI6ImxvYWQuZ2xvYmFsIiwicGF5bG9hZF9pa2V0X2lkIjowLCJwYXlsb2FkX3R5cGUiOiJOb1BheWxvYWQiLCJyYW5nZV9pZCI6MzM2MTMyMzQzMywidmVyc2lvbiI6MX0");
  selected_rank[0] = logits[((((int64_t)((int)blockIdx.x)) * logits_stride) + token_ids[(((int64_t)((int)blockIdx.x)) * ((int64_t)topk))])];
  peak[0] = -CUDART_INF_F;
  peak[1] = -CUDART_INF_F;
  if (0 < (vocab & 2047)) {
    raw[0] = logits[((((int64_t)((int)blockIdx.x)) * logits_stride) + ((int64_t)min((((vocab >> 11) * 2048) + ((int)threadIdx.x)), (vocab - 1))))];
    raw[1] = logits[((((int64_t)((int)blockIdx.x)) * logits_stride) + ((int64_t)min(((((vocab >> 11) * 2048) + ((int)threadIdx.x)) + 1024), (vocab - 1))))];
    float condval;
    if (((((vocab >> 11) * 2048) + ((int)threadIdx.x)) < vocab)) {
      condval = raw[0];
    } else {
      condval = -CUDART_INF_F;
    }
    float value = condval;
    peak[0] = vllm_max(peak[0], value);
    rank_count[0] = (rank_count[0] + ((int)(((((vocab >> 11) * 2048) + ((int)threadIdx.x)) < vocab) & (selected_rank[0] <= value))));
    float condval_1;
    if ((((((vocab >> 11) * 2048) + ((int)threadIdx.x)) + 1024) < vocab)) {
      condval_1 = raw[1];
    } else {
      condval_1 = -CUDART_INF_F;
    }
    float value_1 = condval_1;
    peak[1] = vllm_max(peak[1], value_1);
    rank_count[0] = (rank_count[0] + ((int)((((((vocab >> 11) * 2048) + ((int)threadIdx.x)) + 1024) < vocab) & (selected_rank[0] <= value_1))));
  }
  for (int step = 0; step < (vocab >> 11); ++step) {
    raw[0] = logits[((((((((int64_t)vocab) >> (int64_t)11) * (int64_t)2048) + (((int64_t)((int)blockIdx.x)) * logits_stride)) + ((int64_t)((int)threadIdx.x))) - (((int64_t)step) * (int64_t)2048)) - (int64_t)2048)];
    raw[1] = logits[((((((((int64_t)vocab) >> (int64_t)11) * (int64_t)2048) + (((int64_t)((int)blockIdx.x)) * logits_stride)) + ((int64_t)((int)threadIdx.x))) - (((int64_t)step) * (int64_t)2048)) - (int64_t)1024)];
    float value_2 = raw[0];
    peak[0] = vllm_max(peak[0], value_2);
    rank_count[0] = (rank_count[0] + ((int)((((((vocab >> 11) * 2048) + ((int)threadIdx.x)) - (step * 2048)) < (vocab + 2048)) & (selected_rank[0] <= value_2))));
    float value_3 = raw[1];
    peak[1] = vllm_max(peak[1], value_3);
    rank_count[0] = (rank_count[0] + ((int)((((((vocab >> 11) * 2048) + ((int)threadIdx.x)) - (step * 2048)) < (vocab + 1024)) & (selected_rank[0] <= value_3))));
  }
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  best[0] = peak[0];
  best[0] = vllm_max(best[0], peak[1]);
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(2, "__tl_iket_v1_eyJldmVudF9pZCI6Miwia2luZCI6InJhbmdlIiwibmFtZSI6ImNvbXB1dGUucmVkdWNlIiwicGF5bG9hZF9pa2V0X2lkIjowLCJwYXlsb2FkX3R5cGUiOiJOb1BheWxvYWQiLCJyYW5nZV9pZCI6MjAyNTA1NDQ1OSwidmVyc2lvbiI6MX0");
  best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 16, 32));
  best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 8, 32));
  best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 4, 32));
  best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 2, 32));
  best[0] = vllm_max(best[0], __shfl_xor_sync((uint)4294967295, best[0], 1, 32));
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  if ((((int)threadIdx.x) % 32) == 0) {
    ((float*)max_partial)[(((int)threadIdx.x) >> 5)] = best[0];
  }
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(3, "__tl_iket_v1_eyJldmVudF9pZCI6Mywia2luZCI6InJhbmdlIiwibmFtZSI6IndhaXQuc3luYyIsInBheWxvYWRfaWtldF9pZCI6MCwicGF5bG9hZF90eXBlIjoiTm9QYXlsb2FkIiwicmFuZ2VfaWQiOjI0NzUyODg0MzcsInZlcnNpb24iOjF9");
  __syncthreads();
  if (__tl_iket_cta && __tl_iket_warp) TL_IKET_SETTLE();
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  best[0] = ((float*)max_partial)[0];
  best[0] = vllm_max(best[0], ((float*)max_partial)[1]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[2]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[3]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[4]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[5]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[6]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[7]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[8]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[9]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[10]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[11]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[12]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[13]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[14]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[15]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[16]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[17]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[18]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[19]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[20]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[21]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[22]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[23]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[24]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[25]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[26]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[27]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[28]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[29]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[30]);
  best[0] = vllm_max(best[0], ((float*)max_partial)[31]);
  maximum = best[0];
  total[0] = 0x0p+0f/*0.000000e+00*/;
  tally[0] = 0x0p+0f/*0.000000e+00*/;
  total[1] = 0x0p+0f/*0.000000e+00*/;
  tally[1] = 0x0p+0f/*0.000000e+00*/;
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(4, "__tl_iket_v1_eyJldmVudF9pZCI6NCwia2luZCI6InJhbmdlIiwibmFtZSI6ImxvYWQuZ2xvYmFsIzIiLCJwYXlsb2FkX2lrZXRfaWQiOjAsInBheWxvYWRfdHlwZSI6Ik5vUGF5bG9hZCIsInJhbmdlX2lkIjo0MjA4OTgwMTc1LCJ2ZXJzaW9uIjoxfQ");
  for (int step_1 = 0; step_1 < (vocab >> 11); ++step_1) {
    raw[0] = logits[(((((int64_t)step_1) * (int64_t)2048) + (((int64_t)((int)blockIdx.x)) * logits_stride)) + ((int64_t)((int)threadIdx.x)))];
    raw[1] = logits[((((((int64_t)step_1) * (int64_t)2048) + (((int64_t)((int)blockIdx.x)) * logits_stride)) + ((int64_t)((int)threadIdx.x))) + (int64_t)1024)];
    float maximum_1 = maximum;
    float value_4 = raw[0];
    float term = vllm_other_exp(value_4, maximum_1);
    float tie = vllm_tie(value_4, maximum_1);
    total[0] = vllm_add(total[0], term);
    tally[0] = vllm_add(tally[0], tie);
    float value_5 = raw[1];
    float term_1 = vllm_other_exp(value_5, maximum_1);
    float tie_1 = vllm_tie(value_5, maximum_1);
    total[1] = vllm_add(total[1], term_1);
    tally[1] = vllm_add(tally[1], tie_1);
  }
  if (0 < (vocab & 2047)) {
    raw[0] = logits[((((int64_t)((int)blockIdx.x)) * logits_stride) + ((int64_t)min((((vocab >> 11) * 2048) + ((int)threadIdx.x)), (vocab - 1))))];
    raw[1] = logits[((((int64_t)((int)blockIdx.x)) * logits_stride) + ((int64_t)min(((((vocab >> 11) * 2048) + ((int)threadIdx.x)) + 1024), (vocab - 1))))];
    float value_6 = raw[0];
    float condval_2;
    if (((((vocab >> 11) * 2048) + ((int)threadIdx.x)) < vocab)) {
      condval_2 = vllm_other_exp(value_6, maximum);
    } else {
      condval_2 = 0x0p+0f/*0.000000e+00*/;
    }
    float term_2 = condval_2;
    float condval_3;
    if (((((vocab >> 11) * 2048) + ((int)threadIdx.x)) < vocab)) {
      condval_3 = vllm_tie(value_6, maximum);
    } else {
      condval_3 = 0x0p+0f/*0.000000e+00*/;
    }
    float tie_2 = condval_3;
    total[0] = vllm_add(total[0], term_2);
    tally[0] = vllm_add(tally[0], tie_2);
    float value_7 = raw[1];
    float condval_4;
    if ((((((vocab >> 11) * 2048) + ((int)threadIdx.x)) + 1024) < vocab)) {
      condval_4 = vllm_other_exp(value_7, maximum);
    } else {
      condval_4 = 0x0p+0f/*0.000000e+00*/;
    }
    float term_3 = condval_4;
    float condval_5;
    if ((((((vocab >> 11) * 2048) + ((int)threadIdx.x)) + 1024) < vocab)) {
      condval_5 = vllm_tie(value_7, maximum);
    } else {
      condval_5 = 0x0p+0f/*0.000000e+00*/;
    }
    float tie_3 = condval_5;
    total[1] = vllm_add(total[1], term_3);
    tally[1] = vllm_add(tally[1], tie_3);
  }
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  se[0] = total[0];
  ties[0] = tally[0];
  se[0] = vllm_add(se[0], total[1]);
  ties[0] = vllm_add(ties[0], tally[1]);
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(5, "__tl_iket_v1_eyJldmVudF9pZCI6NSwia2luZCI6InJhbmdlIiwibmFtZSI6ImNvbXB1dGUucmVkdWNlIzIiLCJwYXlsb2FkX2lrZXRfaWQiOjAsInBheWxvYWRfdHlwZSI6Ik5vUGF5bG9hZCIsInJhbmdlX2lkIjoxNjI1NjU5MDQzLCJ2ZXJzaW9uIjoxfQ");
  se[0] = vllm_add(se[0], __shfl_xor_sync((uint)4294967295, se[0], 16, 32));
  se[0] = vllm_add(se[0], __shfl_xor_sync((uint)4294967295, se[0], 8, 32));
  se[0] = vllm_add(se[0], __shfl_xor_sync((uint)4294967295, se[0], 4, 32));
  se[0] = vllm_add(se[0], __shfl_xor_sync((uint)4294967295, se[0], 2, 32));
  se[0] = vllm_add(se[0], __shfl_xor_sync((uint)4294967295, se[0], 1, 32));
  __syncthreads();
  if ((((int)threadIdx.x) % 32) == 0) {
    ((float*)sum_partial)[(((int)threadIdx.x) >> 5)] = se[0];
  }
  __syncthreads();
  se[0] = ((float*)sum_partial)[0];
  se[0] = vllm_add(se[0], ((float*)sum_partial)[1]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[2]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[3]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[4]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[5]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[6]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[7]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[8]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[9]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[10]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[11]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[12]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[13]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[14]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[15]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[16]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[17]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[18]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[19]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[20]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[21]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[22]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[23]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[24]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[25]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[26]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[27]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[28]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[29]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[30]);
  se[0] = vllm_add(se[0], ((float*)sum_partial)[31]);
  ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 16, 32));
  ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 8, 32));
  ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 4, 32));
  ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 2, 32));
  ties[0] = vllm_add(ties[0], __shfl_xor_sync((uint)4294967295, ties[0], 1, 32));
  __syncthreads();
  if ((((int)threadIdx.x) % 32) == 0) {
    ((float*)tie_partial)[(((int)threadIdx.x) >> 5)] = ties[0];
  }
  __syncthreads();
  ties[0] = ((float*)tie_partial)[0];
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[1]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[2]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[3]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[4]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[5]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[6]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[7]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[8]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[9]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[10]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[11]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[12]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[13]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[14]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[15]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[16]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[17]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[18]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[19]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[20]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[21]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[22]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[23]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[24]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[25]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[26]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[27]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[28]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[29]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[30]);
  ties[0] = vllm_add(ties[0], ((float*)tie_partial)[31]);
  lse = vllm_softplus(vllm_others(se[0], ties[0], maximum));
  rank_count[0] = (rank_count[0] + __shfl_xor_sync((uint)4294967295, rank_count[0], 16));
  rank_count[0] = (rank_count[0] + __shfl_xor_sync((uint)4294967295, rank_count[0], 8));
  rank_count[0] = (rank_count[0] + __shfl_xor_sync((uint)4294967295, rank_count[0], 4));
  rank_count[0] = (rank_count[0] + __shfl_xor_sync((uint)4294967295, rank_count[0], 2));
  rank_count[0] = (rank_count[0] + __shfl_xor_sync((uint)4294967295, rank_count[0], 1));
  if (__tl_iket_cta && __tl_iket_warp) TL_IKET_SETTLE();
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(6, "__tl_iket_v1_eyJldmVudF9pZCI6Niwia2luZCI6InJhbmdlIiwibmFtZSI6IndhaXQuc3luYyMyIiwicGF5bG9hZF9pa2V0X2lkIjowLCJwYXlsb2FkX3R5cGUiOiJOb1BheWxvYWQiLCJyYW5nZV9pZCI6MTUzNTIwNDg2MywidmVyc2lvbiI6MX0");
  __syncthreads();
  if ((((int)threadIdx.x) % 32) == 0) {
    ((int*)rank_partial)[(((int)threadIdx.x) >> 5)] = rank_count[0];
  }
  __syncthreads();
  if (__tl_iket_cta && __tl_iket_warp) TL_IKET_SETTLE();
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(7, "__tl_iket_v1_eyJldmVudF9pZCI6Nywia2luZCI6InJhbmdlIiwibmFtZSI6InN0b3JlLmdsb2JhbCIsInBheWxvYWRfaWtldF9pZCI6MCwicGF5bG9hZF90eXBlIjoiTm9QYXlsb2FkIiwicmFuZ2VfaWQiOjMzMjI3OTE1NjIsInZlcnNpb24iOjF9");
  if (((int)threadIdx.x) == 0) {
    count = 0;
    #pragma unroll
    for (int warp = 0; warp < 32; ++warp) {
      count = (count + ((int*)rank_partial)[warp]);
    }
    ranks[((int64_t)((int)blockIdx.x))] = ((int64_t)count);
  }
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
  for (int c = 0; c < ((topk + 1023) >> 10); ++c) {
    if (((c * 1024) + ((int)threadIdx.x)) < topk) {
      TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp && ((int)((c) - (0)) % max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) == max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) / 2)) TL_IKET_EVENT(8, "__tl_iket_v1_eyJldmVudF9pZCI6OCwia2luZCI6InJhbmdlIiwibmFtZSI6ImxvYWQuZ2xvYmFsIzMiLCJwYXlsb2FkX2lrZXRfaWQiOjAsInBheWxvYWRfdHlwZSI6Ik5vUGF5bG9hZCIsInJhbmdlX2lkIjoyMzc5NzkyNDczLCJ2ZXJzaW9uIjoxfQ");
      float value_8 = vllm_sub(vllm_shifted(logits[((((int64_t)((int)blockIdx.x)) * logits_stride) + token_ids[(((((int64_t)c) * (int64_t)1024) + (((int64_t)((int)blockIdx.x)) * ((int64_t)topk))) + ((int64_t)((int)threadIdx.x)))])], maximum), lse);
      TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp && ((int)((c) - (0)) % max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) == max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) / 2)) TL_IKET_EVENT(31);
      TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp && ((int)((c) - (0)) % max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) == max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) / 2)) TL_IKET_EVENT(9, "__tl_iket_v1_eyJldmVudF9pZCI6OSwia2luZCI6InJhbmdlIiwibmFtZSI6InN0b3JlLmdsb2JhbCMyIiwicGF5bG9hZF9pa2V0X2lkIjowLCJwYXlsb2FkX3R5cGUiOiJOb1BheWxvYWQiLCJyYW5nZV9pZCI6MjIyODAyMDU2NywidmVyc2lvbiI6MX0");
      output[(((((int64_t)c) * (int64_t)1024) + (((int64_t)((int)blockIdx.x)) * ((int64_t)topk))) + ((int64_t)((int)threadIdx.x)))] = value_8;
      TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp && ((int)((c) - (0)) % max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) == max(1, (int)(((((topk + 1023) >> 10)) - (0) + 0) / 1)) / 2)) TL_IKET_EVENT(31);
    }
  }
}

