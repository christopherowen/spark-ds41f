// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* markov_anchor_embed_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_markov_anchor_embed(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_markov_anchor_embed(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[14];
  void* stack_ffi_any = stack;
  if (!((num_args == 5))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "markov_anchor_embed: num_args should be 5", (long long)(num_args), (long long)(5));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "markov_anchor_embed: args pointer is NULL");
    return -1;
  }
  int32_t ids_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((ids_handle_type_index == 0) || (ids_handle_type_index == 4)) || (ids_handle_type_index == 7)) || (64 <= ids_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input ids expected pointer or tensor handle");
    return -1;
  }
  int32_t index_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((index_handle_type_index == 0) || (index_handle_type_index == 4)) || (index_handle_type_index == 7)) || (64 <= index_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input index expected pointer or tensor handle");
    return -1;
  }
  int32_t table_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((table_handle_type_index == 0) || (table_handle_type_index == 4)) || (table_handle_type_index == 7)) || (64 <= table_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input table expected pointer or tensor handle");
    return -1;
  }
  int32_t step_out_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((step_out_handle_type_index == 0) || (step_out_handle_type_index == 4)) || (step_out_handle_type_index == 7)) || (64 <= step_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input step_out expected pointer or tensor handle");
    return -1;
  }
  int32_t confidence_out_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((confidence_out_handle_type_index == 0) || (confidence_out_handle_type_index == 4)) || (confidence_out_handle_type_index == 7)) || (64 <= confidence_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input confidence_out expected pointer or tensor handle");
    return -1;
  }
  void* ids_handle = ((ids_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* index_handle = ((index_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* table_handle = ((table_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* step_out_handle = ((step_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* confidence_out_handle = ((confidence_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  bool markov_anchor_embed_ids_is_null = (ids_handle == NULL);
  if (!(!markov_anchor_embed_ids_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "markov_anchor_embed.ids is expected to have non-NULL pointer");
    return -1;
  }
  bool markov_anchor_embed_index_is_null = (index_handle == NULL);
  if (!(!markov_anchor_embed_index_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "markov_anchor_embed.index is expected to have non-NULL pointer");
    return -1;
  }
  bool markov_anchor_embed_table_is_null = (table_handle == NULL);
  if (!(!markov_anchor_embed_table_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "markov_anchor_embed.table is expected to have non-NULL pointer");
    return -1;
  }
  bool markov_anchor_embed_step_out_is_null = (step_out_handle == NULL);
  if (!(!markov_anchor_embed_step_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "markov_anchor_embed.step_out is expected to have non-NULL pointer");
    return -1;
  }
  bool markov_anchor_embed_confidence_out_is_null = (confidence_out_handle == NULL);
  if (!(!markov_anchor_embed_confidence_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "markov_anchor_embed.confidence_out is expected to have non-NULL pointer");
    return -1;
  }
  void* markov_anchor_embed_ids_shape = (((DLTensor*)ids_handle)[0].shape);
  void* markov_anchor_embed_index_shape = (((DLTensor*)index_handle)[0].shape);
  void* markov_anchor_embed_table_shape = (((DLTensor*)table_handle)[0].shape);
  void* markov_anchor_embed_step_out_shape = (((DLTensor*)step_out_handle)[0].shape);
  void* markov_anchor_embed_confidence_out_shape = (((DLTensor*)confidence_out_handle)[0].shape);
  if (!(((((DLTensor*)ids_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input ids ndim mismatch, expected 1", (long long)((((DLTensor*)ids_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t ids_len = ((int32_t)((int64_t*)markov_anchor_embed_ids_shape)[0]);
  void* markov_anchor_embed_ids_strides = (((DLTensor*)ids_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)ids_handle)[0].device.device_id);
  void* ids = (((DLTensor*)ids_handle)[0].data);
  if (!(((((DLTensor*)index_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input index ndim mismatch, expected 1", (long long)((((DLTensor*)index_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: markov_anchor_embed.index, markov_anchor_embed.step_out, markov_anchor_embed.confidence_out");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)markov_anchor_embed_index_shape)[0]);
  void* markov_anchor_embed_index_strides = (((DLTensor*)index_handle)[0].strides);
  void* index = (((DLTensor*)index_handle)[0].data);
  if (!(((((DLTensor*)table_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input table ndim mismatch, expected 2", (long long)((((DLTensor*)table_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t table_rows = ((int32_t)((int64_t*)markov_anchor_embed_table_shape)[0]);
  void* markov_anchor_embed_table_strides = (((DLTensor*)table_handle)[0].strides);
  void* table = (((DLTensor*)table_handle)[0].data);
  if (!(((((DLTensor*)step_out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input step_out ndim mismatch, expected 2", (long long)((((DLTensor*)step_out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* markov_anchor_embed_step_out_strides = (((DLTensor*)step_out_handle)[0].strides);
  int64_t condval;
  if ((markov_anchor_embed_step_out_strides == NULL)) {
    condval = (int64_t)1;
  } else {
    condval = ((int64_t*)markov_anchor_embed_step_out_strides)[0];
  }
  int64_t step_stride = condval;
  void* step_out = (((DLTensor*)step_out_handle)[0].data);
  if (!(((((DLTensor*)confidence_out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input confidence_out ndim mismatch, expected 2", (long long)((((DLTensor*)confidence_out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* markov_anchor_embed_confidence_out_strides = (((DLTensor*)confidence_out_handle)[0].strides);
  int64_t condval_1;
  if ((markov_anchor_embed_confidence_out_strides == NULL)) {
    condval_1 = (int64_t)1;
  } else {
    condval_1 = ((int64_t*)markov_anchor_embed_confidence_out_strides)[0];
  }
  int64_t confidence_stride = condval_1;
  void* confidence_out = (((DLTensor*)confidence_out_handle)[0].data);
  if (!(((((((DLTensor*)ids_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)ids_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)ids_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input ids dtype mismatch, expected int32");
    return -1;
  }
  int32_t condval_2;
  if ((markov_anchor_embed_ids_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)markov_anchor_embed_ids_strides)[0]);
  }
  if (!(((condval_2 == 1) || (ids_len == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input ids strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)ids_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input ids byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)ids_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)ids_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input ids device_type mismatch, expected cuda", (long long)((((DLTensor*)ids_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((ids_len == 0) || !(ids == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input ids data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)index_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)index_handle)[0].dtype.bits) == (uint8_t)64)) && ((((DLTensor*)index_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input index dtype mismatch, expected int64");
    return -1;
  }
  int32_t condval_3;
  if ((markov_anchor_embed_index_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)markov_anchor_embed_index_strides)[0]);
  }
  if (!(((condval_3 == 1) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input index strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)index_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input index byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)index_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)index_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input index device_id violates packed ABI constraint", (long long)((((DLTensor*)index_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)index_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input index device_type mismatch, expected cuda", (long long)((((DLTensor*)index_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(index == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input index data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)table_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)table_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)table_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input table dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)markov_anchor_embed_table_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input table shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)markov_anchor_embed_table_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((markov_anchor_embed_table_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)markov_anchor_embed_table_strides)[1]);
  }
  if (!((condval_4 == 1))) {
    int32_t condval_5;
    if ((markov_anchor_embed_table_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)markov_anchor_embed_table_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input table strides[1] violates packed ABI constraint", (long long)(condval_5), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((markov_anchor_embed_table_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)markov_anchor_embed_table_strides)[0]);
  }
  if (!(((condval_6 == 256) || (table_rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input table strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)table_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input table byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)table_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)table_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input table device_id violates packed ABI constraint", (long long)((((DLTensor*)table_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)table_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input table device_type mismatch, expected cuda", (long long)((((DLTensor*)table_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((table_rows == 0) || !(table == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input table data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)step_out_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)step_out_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)step_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input step_out dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)markov_anchor_embed_index_shape)[0]) == ((int32_t)((int64_t*)markov_anchor_embed_step_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input step_out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)markov_anchor_embed_index_shape)[0])), (long long)(((int32_t)((int64_t*)markov_anchor_embed_step_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)markov_anchor_embed_step_out_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input step_out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)markov_anchor_embed_step_out_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((markov_anchor_embed_step_out_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)markov_anchor_embed_step_out_strides)[1]);
  }
  if (!((condval_7 == 1))) {
    int32_t condval_8;
    if ((markov_anchor_embed_step_out_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)markov_anchor_embed_step_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input step_out strides[1] violates packed ABI constraint", (long long)(condval_8), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)step_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input step_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)step_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)step_out_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input step_out device_id violates packed ABI constraint", (long long)((((DLTensor*)step_out_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)step_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input step_out device_type mismatch, expected cuda", (long long)((((DLTensor*)step_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(step_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input step_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)confidence_out_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)confidence_out_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)confidence_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input confidence_out dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)markov_anchor_embed_index_shape)[0]) == ((int32_t)((int64_t*)markov_anchor_embed_confidence_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input confidence_out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)markov_anchor_embed_index_shape)[0])), (long long)(((int32_t)((int64_t*)markov_anchor_embed_confidence_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)markov_anchor_embed_confidence_out_shape)[1]) == 256))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input confidence_out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)markov_anchor_embed_confidence_out_shape)[1])), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((markov_anchor_embed_confidence_out_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)markov_anchor_embed_confidence_out_strides)[1]);
  }
  if (!((condval_9 == 1))) {
    int32_t condval_10;
    if ((markov_anchor_embed_confidence_out_strides == NULL)) {
      condval_10 = 1;
    } else {
      condval_10 = ((int32_t)((int64_t*)markov_anchor_embed_confidence_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input confidence_out strides[1] violates packed ABI constraint", (long long)(condval_10), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)confidence_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input confidence_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)confidence_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)confidence_out_handle)[0].device.device_id) == (((DLTensor*)ids_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input confidence_out device_id violates packed ABI constraint", (long long)((((DLTensor*)confidence_out_handle)[0].device.device_id)), (long long)((((DLTensor*)ids_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)confidence_out_handle)[0].device.device_type) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel markov_anchor_embed input confidence_out device_type mismatch, expected cuda", (long long)((((DLTensor*)confidence_out_handle)[0].device.device_type)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(confidence_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel markov_anchor_embed input confidence_out data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (confidence_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = confidence_out;
  if (ids == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = ids;
  if (index == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = index;
  if (step_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = step_out;
  if (table == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = table;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = confidence_stride;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = step_stride;
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)table_rows);
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)32);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = (int64_t)0;
  if (markov_anchor_embed_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "markov_anchor_embed_kernel", &markov_anchor_embed_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(markov_anchor_embed_kernel_packed, (TVMFFIAny*) stack_ffi_any, 13, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_markov_anchor_embed(self, args, num_args, result);
}
