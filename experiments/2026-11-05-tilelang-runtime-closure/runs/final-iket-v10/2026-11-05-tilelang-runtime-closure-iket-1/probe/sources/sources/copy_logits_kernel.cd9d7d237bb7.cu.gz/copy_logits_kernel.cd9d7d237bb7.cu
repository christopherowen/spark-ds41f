__device__ __forceinline__ int __tl_iket_count(bool c) {
  int n;
  asm volatile("mov.b32 %0, %1;" : "=r"(n) : "r"((int)c));
  return n;
}
#define TL_IKET_WHEN(C) _Pragma("unroll 1") for (int __tl_iket_n = __tl_iket_count(C); __tl_iket_n > 0; --__tl_iket_n)
#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
// __tilelang_iket_tool__
// Experimental IKET metadata emitted by tilelang.tools.cuda.iket.
extern "C" {
__device__ __attribute__((used, aligned(1))) unsigned char __iket_evt_decl_store_global_1_attrs[60] = {60, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 138, 198, 13, 198, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_range_decl_store_global_3322791562_attrs[72] = {72, 0, 0, 0, 0, 0, 0, 0, 138, 198, 13, 198, 255, 255, 255, 255, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 115, 116, 111, 114, 101, 46, 103, 108, 111, 98, 97, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
__device__ __attribute__((used, aligned(1))) unsigned char __iket_meta_info[48] = {48, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 31, 0, 0, 0, 32, 0, 0, 0, 60, 0, 0, 0, 157, 241, 190, 186, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}

#define TL_IKET_EVENT(ID, ...) \
  asm volatile("{\n\t" \
               ".reg .b32 r, t;\n\t" \
               "mov.b32 r, %cluster_ctarank;\n\t" \
               "mov.u32 t, %globaltimer_lo;\n\t" \
               "or.b32 t, t, " #ID ";\n\t" \
               "mad.lo.u32 r, r, 0x1000000, 0x20;\n\t" \
               "st.weak.shared.u32 [r], t;\n\t" \
               "pmevent.mask " #ID ";\n\t" \
               "}" ::: "memory")

#define TL_IKET_EVENT_PAYLOAD_U32(ID, VALUE, ...) TL_IKET_EVENT(ID)
#define TL_IKET_EVENT_PAYLOAD_F32(ID, VALUE, ...) TL_IKET_EVENT(ID)

#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void copy_logits_kernel(float* __restrict__ dst, const half_t* __restrict__ src, int col_stride, int cols, int row_stride, int rows);
extern "C" __global__ void __launch_bounds__(256, 1) copy_logits_kernel(float* __restrict__ dst, const half_t* __restrict__ src, int col_stride, int cols, int row_stride, int rows) {
  const bool __tl_iket_cta = (((blockIdx.z * gridDim.y + blockIdx.y) * gridDim.x + blockIdx.x) % max(1u, gridDim.x * gridDim.y * gridDim.z / 1u)) == 0u;
  const bool __tl_iket_warp = ((((threadIdx.z * blockDim.y + threadIdx.y) * blockDim.x + threadIdx.x) >> 5) % max(1u, ((blockDim.x * blockDim.y * blockDim.z + 31u) >> 5) / 1u)) == 0u;
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(1, "__tl_iket_v1_eyJldmVudF9pZCI6MSwia2luZCI6InJhbmdlIiwibmFtZSI6InN0b3JlLmdsb2JhbCIsInBheWxvYWRfaWtldF9pZCI6MCwicGF5bG9hZF90eXBlIjoiTm9QYXlsb2FkIiwicmFuZ2VfaWQiOjMzMjI3OTE1NjIsInZlcnNpb24iOjF9");
  #pragma unroll
  for (int j = 0; j < 4; ++j) {
    if ((((((int)blockIdx.y) * 1024) + (j * 256)) + ((int)threadIdx.x)) < cols) {
      dst[((((((int64_t)((int)blockIdx.y)) * (int64_t)1024) + (((int64_t)j) * (int64_t)256)) + (((int64_t)((int)blockIdx.x)) * ((int64_t)cols))) + ((int64_t)((int)threadIdx.x)))] = ((float)src[((((int64_t)((int)blockIdx.x)) * ((int64_t)row_stride)) + ((((((int64_t)((int)blockIdx.y)) * (int64_t)1024) + (((int64_t)j) * (int64_t)256)) + ((int64_t)((int)threadIdx.x))) * ((int64_t)col_stride)))]);
    }
  }
  TL_IKET_WHEN(__tl_iket_cta && __tl_iket_warp) TL_IKET_EVENT(31);
}

