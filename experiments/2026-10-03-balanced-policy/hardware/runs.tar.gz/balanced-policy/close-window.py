"""Record the agreed idle return and release this task's owned hold."""
import concurrent.futures,datetime,json,pathlib,shlex,subprocess
out=pathlib.Path('.work/balanced-policy/restoration');out.mkdir(exist_ok=False)
code=r'''
import json,pathlib,subprocess
P=pathlib.Path
def run(*args):return subprocess.check_output(args,text=True).strip()
home=P.home();q=home/'projects/spark3-ring4-qualification';p=home/'projects/spark3-vllm-ds41f'
d={'containers':run('docker','ps','--format','{{.Names}}').splitlines(),'compute_processes':run('nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'),'fan_service':run('systemctl','is-active','dgx-fan-control'),'qualification_commit':run('git','-C',str(q),'rev-parse','HEAD'),'qualification_tracked_status':run('git','-C',str(q),'status','--porcelain','--untracked-files=no'),'shared_commit':run('git','-C',str(p),'rev-parse','HEAD'),'shared_tracked_status':run('git','-C',str(p),'status','--porcelain','--untracked-files=no'),'memory':P('/proc/meminfo').read_text()}
print(json.dumps(d))
'''
def collect(n):
 r=subprocess.run(['ssh','-o','BatchMode=yes','swank@dgx'+str(n),shlex.join(['python3','-c',code])],capture_output=True,text=True,check=True,timeout=30)
 d=json.loads(r.stdout);(out/f'dgx{n}.json').write_text(json.dumps(d,indent=2)+'\n')
 assert not any(x in d['containers'] for x in ('dsv41-karmic-kraken','spark3-collective-probe'))
 assert not d['compute_processes'],d
 assert d['fan_service']=='active'
 assert d['qualification_commit']=='6b6861b66b3c2f10da56fadbcf452b705fc31c3c'
 assert not d['qualification_tracked_status']
 return d
with concurrent.futures.ThreadPoolExecutor(4) as p:ds=list(p.map(collect,range(1,5)))
assert all(d['shared_commit']=='cfa6e5cd4f2f3af057e2fec550ced0d988fb1170' for d in ds)
release="import pathlib,json;p=pathlib.Path.home()/'spark3-hold.json';d=json.loads(p.read_text());assert d['holder']=='balanced-policy';print(json.dumps(d));p.unlink()"
hold=json.loads(subprocess.check_output(['ssh','swank@dgx1',shlex.join(['python3','-c',release])],text=True))
(out/'release.json').write_text(json.dumps({'released_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hold':hold,'return_state':'idle; no compute processes; fan service active on every node'},indent=2)+'\n')
print('All four nodes idle; fan services active; shared checkouts unchanged; owned hold released.')
