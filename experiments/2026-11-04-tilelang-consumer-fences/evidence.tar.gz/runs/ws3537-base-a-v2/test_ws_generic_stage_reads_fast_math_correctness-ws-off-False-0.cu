#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void exp_sum_kernel(const float* __restrict__ M, float* __restrict__ P, const bfloat16_t* __restrict__ R, const float* __restrict__ X);
extern "C" __global__ void __launch_bounds__(256, 1) exp_sum_kernel(const float* __restrict__ M, float* __restrict__ P, const bfloat16_t* __restrict__ R, const float* __restrict__ X) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* M_s = ((void*)((char*)buf_dyn_shmem + 0));
  void* workspace = ((void*)((char*)buf_dyn_shmem + 128));
  void* X_s = ((void*)((char*)buf_dyn_shmem + 1024));
  void* R_s = ((void*)((char*)buf_dyn_shmem + 25600));
  __shared__ __align__(16) uint64_t mbarrier_mem[7];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float acc[16];
  float e[16];
  float part[16];
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(1);
    mbarrier[1].init(1);
    mbarrier[2].init(1);
    mbarrier[3].init(128);
    mbarrier[4].init(128);
    mbarrier[5].init(128);
    mbarrier[6].init(1);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (tl::tl_shuffle_elect<256>()) {
    mbarrier[6].arrive_and_expect_tx(128);
    tl::tma_load((&(((float*)M_s)[0])), (&(M[0])), mbarrier[6], 128);
  }
  if (((int)threadIdx.x) < 128) {
    tl::warpgroup_reg_dealloc<24>();
    if (((int)threadIdx.x) < 32) {
      for (int kk = 0; kk < 4; ++kk) {
        mbarrier[((kk % 3) + 3)].wait(((kk / 3) ^ 1));
        if (tl::tl_shuffle_elect<32>()) {
          mbarrier[(kk % 3)].expect_transaction(8192);
          tl::tma_load((&(((float*)X_s)[((kk % 3) * 2048)])), (&(X[((((int)blockIdx.y) * 8192) + (kk * 2048))])), mbarrier[(kk % 3)], 8192);
          mbarrier[(kk % 3)].arrive_and_expect_tx(4096);
          tl::tma_load((&(((bfloat16_t*)R_s)[((kk % 3) * 2048)])), (&(R[((((int)blockIdx.y) * 8192) + (kk * 2048))])), mbarrier[(kk % 3)], 4096);
        }
      }
    }
  } else {
    tl::warpgroup_reg_alloc<240>();
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(acc + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    }
    for (int kk_1 = 0; kk_1 < 4; ++kk_1) {
      if (kk_1 == 0) {
        mbarrier[6].wait(0);
      }
      mbarrier[(kk_1 % 3)].wait((kk_1 / 3));
      tl::__sync_thread_partial(3, 128);
      #pragma unroll
      for (int i_1 = 0; i_1 < 16; ++i_1) {
        e[i_1] = expf((((((float*)X_s)[((((((kk_1 % 3) * 2048) + ((((int)threadIdx.x) & 63) * 32)) + (i_1 * 2)) + (((int)threadIdx.x) >> 6)) - 2)] * ((float)((bfloat16_t*)R_s)[((((((kk_1 % 3) * 2048) + ((((int)threadIdx.x) & 63) * 32)) + (i_1 * 2)) + (((int)threadIdx.x) >> 6)) - 2)])) / 0x1.6a09e667f3bcdp+3f/*1.131371e+01*/) - ((float*)M_s)[(((i_1 * 2) + (((int)threadIdx.x) >> 6)) - 2)]));
      }
      mbarrier[((kk_1 % 3) + 3)].arrive();
      #pragma unroll
      for (int i_2 = 0; i_2 < 16; ++i_2) {
        part[i_2] = 0x0p+0f/*0.000000e+00*/;
        part[i_2] = (part[i_2] + e[i_2]);
        tl::__sync_thread_partial(3, 128);
        part[i_2] = tl::AllReduce<tl::SumOp, 64, 1, 128, tl::NamedBarrier<128>>::run(part[i_2], (&(((float*)workspace)[0])));
      }
      #pragma unroll
      for (int i_3 = 0; i_3 < 4; ++i_3) {
        float4 __1;
          float4 v_ = *(float4*)(acc + (i_3 * 4));
          float4 v__1 = *(float4*)(part + (i_3 * 4));
          *(float2*)(&(__1.x)) = tl::add2(*(float2*)(&(v_.x)), *(float2*)(&(v__1.x)));
          *(float2*)(&(__1.z)) = tl::add2(*(float2*)(&(v_.z)), *(float2*)(&(v__1.z)));
        *(float4*)(acc + (i_3 * 4)) = __1;
      }
    }
    if ((((int)threadIdx.x) % 64) == 0) {
      #pragma unroll
      for (int i_4 = 0; i_4 < 16; ++i_4) {
        P[((((((int)blockIdx.y) * 32) + (i_4 * 2)) + (((int)threadIdx.x) >> 6)) - 2)] = acc[i_4];
      }
    }
  }
}

