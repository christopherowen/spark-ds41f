# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Adaptive verification for DSpark speculative decoding."""

import hashlib
import json
import os
from collections import defaultdict
from collections.abc import Callable, Iterable, Iterator, Mapping
from contextlib import AbstractContextManager
from typing import TYPE_CHECKING

import numpy as np
import torch

import vllm.envs as envs
from vllm.config.compilation import CUDAGraphMode
from vllm.distributed.parallel_state import get_tp_group
from vllm.logger import init_logger
from vllm.utils.gpu_sync_debug import gpu_sync_allowed
from vllm.utils.torch_utils import async_tensor_h2d
from vllm.v1.attention.backend import AttentionCGSupport
from vllm.v1.utils import CpuGpuBuffer
from vllm.v1.worker.gpu.async_utils import StepTimingCollector, StepTimingSample, stream
from vllm.v1.worker.gpu.attn_utils import (
    get_attn_cg_support,
    get_query_lens_mismatch_unsupported_backend,
)
from vllm.v1.worker.gpu.input_batch import DeadRows

logger = init_logger(__name__)
_PROFILE_REPLAYS = int(os.environ.get("SPARK3_DSPARK_PROFILE_REPLAYS", "5"))
# Directory of pinned cost curves: rank 0 saves the first profile of a shape
# set and every later boot with the same shapes reuses it, so the draft
# budget no longer depends on one boot's startup timing noise.
_COST_DIR = os.environ.get("SPARK3_DSPARK_COST_DIR") or None
# "ratio" maximizes each step's expected tokens per millisecond. "marginal"
# maximizes expected tokens minus the achieved rate times cost, the rule that
# maximizes long-run tokens per millisecond when step confidence varies.
_VERIFY_RULE = os.environ.get("SPARK3_DSPARK_VERIFY_RULE", "ratio")
# Dead rows: verification rows past the first draft whose survival (running
# product of this step's confidences) falls below this threshold are marked
# as padding, so routed MoE skips them, and the request commits at most one
# token past its last live row. Decided on device, inside the draft combine,
# from the current drafts' confidences; the batch shape is unchanged. 0 = off.
_DEAD_ROWS_TAU = float(os.environ.get("SPARK3_DSPARK_DEAD_ROWS_TAU", "0"))
# SPARK3_DSPARK_DEAD_ROWS=ratio decides dead rows by cost instead: of the rows
# the host budget scheduled, the device keeps live the drafts most likely to
# survive, as many as maximize this step's expected tokens per millisecond.
# A live row is priced by a second startup profile on real (routed) rows, a
# dead row by the padded-row profile the host budget uses.
_DEAD_ROWS_RULE = os.environ.get("SPARK3_DSPARK_DEAD_ROWS", "")
_RATE_ALPHA = float(os.environ.get("SPARK3_DSPARK_RATE_ALPHA", "0.1"))

if TYPE_CHECKING:
    from vllm.config import VllmConfig
    from vllm.v1.worker.gpu.attn_utils import AttentionCGSupportInfo
    from vllm.v1.worker.gpu.input_batch import InputBatch
    from vllm.v1.worker.gpu.states import RequestState
    from vllm.v1.worker.utils import AttentionGroup


# Consecutive steps that may schedule drafts yet verify none before one step
# verifies a draft per request anyway (see ``get_num_tokens``).
EXPLORE_AFTER_IDLE_STEPS = 32


def resolve_adaptive_cudagraph_mode(
    mode: CUDAGraphMode, *, piecewise_capture_available: bool
) -> CUDAGraphMode:
    """Select a separate decode route for variable-length verification."""
    assert mode.has_full_cudagraphs()
    if mode == CUDAGraphMode.FULL_DECODE_ONLY or not piecewise_capture_available:
        return CUDAGraphMode.FULL_DECODE_ONLY
    return CUDAGraphMode.FULL_AND_PIECEWISE


def _assign_draft_token_budget(
    confidence_probs: torch.Tensor,
    idx_mapping: torch.Tensor,
    capacities: torch.Tensor,
    draft_budget: int,
    num_steps: int,
) -> None:
    """Admit the globally best `draft_budget` draft slots, in place.

    Every (request, step) slot is scored by its survival probability, the running
    product of that request's per-position confidences, and the highest scores win.
    Survival only decreases along a request, so a global top-k always admits
    continuously along steps with a request.

    `capacities` enters holding each request's scheduled draft count (which bounds its
    eligible slots) and leaves holding the admitted count. The caller only calls this
    when `draft_budget < capacities.sum()`, so every winner is a real draft slot.
    """
    survival = confidence_probs[idx_mapping].cumprod(dim=1)
    steps = torch.arange(num_steps, device=survival.device)
    # Out-of-range slots score -inf so they never outrank a real draft.
    out_of_range = steps[None, :] >= capacities[:, None]
    survival = survival.masked_fill(out_of_range, -float("inf"))
    flat = survival.flatten()
    winners = flat.topk(draft_budget).indices
    admitted = torch.zeros_like(flat, dtype=torch.bool).index_fill_(0, winners, True)
    torch.sum(admitted.view_as(survival), dim=1, dtype=capacities.dtype, out=capacities)


_assign_draft_token_budget_compiled = torch.compile(
    _assign_draft_token_budget, dynamic=True
)


def median_curve(points: Iterable[tuple[int, float]]) -> list[tuple[int, float]]:
    grouped: defaultdict[int, list[float]] = defaultdict(list)
    for key, value in points:
        grouped[key].append(value)
    return [(k, float(np.median(v))) for k, v in sorted(grouped.items())]


def verify_curves_by_num_reqs_from(
    samples: Iterable[StepTimingSample],
) -> dict[int, list[tuple[int, float]]]:
    samples = [s for s in samples if s.full_cudagraph]
    return {
        num_reqs: median_curve(
            (s.num_target_tokens, s.forward_ms)
            for s in samples
            if s.num_reqs == num_reqs
        )
        for num_reqs in sorted({s.num_reqs for s in samples})
    }


def build_tables_by_num_reqs(
    verify_curves_by_num_reqs: Mapping[int, list[tuple[int, float]]],
    max_num_reqs: int,
    max_batch_tokens: int,
    beyond: np.ndarray,
) -> dict[int, np.ndarray]:
    """Per-request-count verify tables from FULL graph shape curves.

    FULL replay pads both tokens and requests. A request count may have only
    one exact shape; extending that point prices all larger graphs as free
    verification, so each count follows the smallest compatible padded shape.
    Token counts beyond the captured shapes take ``beyond``.
    """
    full_shapes = sorted(
        (num_tokens, padded_reqs, cost)
        for padded_reqs, curve in verify_curves_by_num_reqs.items()
        for num_tokens, cost in curve
    )
    tables = {}
    for num_reqs in range(1, max_num_reqs + 1):
        curve: dict[int, float] = {}
        for num_tokens, padded_reqs, cost in full_shapes:
            if padded_reqs >= num_reqs:
                curve.setdefault(num_tokens, cost)
        if not curve:
            continue
        xs = np.asarray(list(curve))
        ys = np.maximum.accumulate(list(curve.values()))
        limit = min(int(xs[-1]), max_batch_tokens)
        table = beyond.copy()
        table[: limit + 1] = np.maximum(
            ys[np.searchsorted(xs, np.arange(limit + 1), side="left")], 1e-6
        )
        tables[num_reqs] = table
    return tables


def build_cost_tables_from_curves(
    draft_curve: list[tuple[int, float]],
    verify_curve: list[tuple[int, float]],
    max_num_reqs: int,
    max_batch_tokens: int,
    cudagraph_limit: int = 0,
) -> tuple[np.ndarray, np.ndarray]:
    """Build cost tables: graph-padded below the capture limit, smooth above.

    Args:
        cudagraph_limit: Largest cudagraph-captured size. At or below it,
            execution pads up to the next captured size, so cost is a step
            function. Above it there is no padding, so cost is continuous.
    """

    def build_table(limit: int, curve: list[tuple[int, float]]) -> np.ndarray:
        xs, ys = np.asarray(curve, dtype=np.float64).T
        ys = np.maximum.accumulate(ys)
        values = np.arange(limit + 1)
        # Execution pads to the next captured size, so cost is a step
        # function of the padded size: smooth interpolation would invent
        # marginal per-token costs that don't exist within a pad bucket.
        idx = np.searchsorted(xs, values, side="left")
        result = ys[np.minimum(idx, len(xs) - 1)]
        # Past the capture limit nothing pads, so cost really is continuous in
        # size; snapping to the next profiled point overestimates badly when
        # the profiled points are far apart. Interpolate only between points
        # that are themselves past the limit: crossing the limit loses
        # cudagraphs entirely, which is a genuine discontinuity, so the first
        # point above it must not be blended with the last one below.
        if cudagraph_limit:
            smooth = values > cudagraph_limit
            above = xs > cudagraph_limit
            if smooth.any() and above.any():
                result[smooth] = np.interp(values[smooth], xs[above], ys[above])
        if len(xs) > 1:
            after = values > xs[-1]
            slope = (ys[-1] - ys[-2]) / (xs[-1] - xs[-2])
            result[after] = ys[-1] + slope * (values[after] - xs[-1])
        return result

    draft_table = np.maximum(build_table(max_num_reqs, draft_curve), 0.0)
    verify_table = np.maximum(build_table(max_batch_tokens, verify_curve), 1e-6)
    return draft_table, verify_table


def preparation_tail_sizes(
    capture_sizes: Iterable[int], max_num_tokens: int
) -> tuple[int, ...]:
    """Exact eager token counts used to initialize adaptive verification costs."""
    capture_sizes = tuple(capture_sizes)
    size = capture_sizes[-1] if capture_sizes else 0
    tail_sizes = set()
    if size:
        tail_sizes.add(min(size + size // 2, max_num_tokens))
        while size < max_num_tokens:
            size = min(size * 2, max_num_tokens)
            tail_sizes.add(size)
        tail_sizes -= set(capture_sizes)
    return tuple(sorted(tail_sizes))


class AdaptiveVerificationManager:
    _verify_rule = "ratio"
    dead_rows_ratio = False
    _live_costs_np: np.ndarray | None = None

    def __init__(
        self,
        req_states: "RequestState",
        query_start_loc: torch.Tensor,
        num_bonus_tokens: int,
        max_total_logits: int,
        cost_scale: float = 1.0,
    ):
        self.req_states = req_states
        self.num_speculative_steps = req_states.num_speculative_steps
        device = req_states.device
        self._copy_stream = torch.cuda.Stream(device)

        self.num_bonus_tokens = num_bonus_tokens
        # Rejection sampling verifies logits in one contiguous chunk; the
        # chunked path indexes by scheduled (untrimmed) offsets and cannot
        # address the compacted layout, so the budget must fit one chunk.
        self._max_total_logits = max_total_logits
        self.cost_scale = cost_scale
        if _VERIFY_RULE not in ("ratio", "marginal", "all"):
            raise ValueError(
                "SPARK3_DSPARK_VERIFY_RULE must be ratio, marginal or all, got "
                f"{_VERIFY_RULE!r}"
            )
        self._verify_rule = _VERIFY_RULE
        self.dead_rows_tau = _DEAD_ROWS_TAU
        if _DEAD_ROWS_RULE not in ("", "ratio"):
            raise ValueError(
                "SPARK3_DSPARK_DEAD_ROWS must be ratio or unset, got "
                f"{_DEAD_ROWS_RULE!r}"
            )
        self.dead_rows_ratio = _DEAD_ROWS_RULE == "ratio"
        if self.dead_rows_ratio and self.dead_rows_tau > 0:
            raise ValueError(
                "Set SPARK3_DSPARK_DEAD_ROWS=ratio or SPARK3_DSPARK_DEAD_ROWS_TAU, "
                "not both"
            )
        if self.dead_rows_ratio and (
            os.environ.get("SPARK3_DSPARK_PROFILE_TOKENS", "zeros") != "zeros"
        ):
            raise ValueError(
                "SPARK3_DSPARK_DEAD_ROWS=ratio prices scheduled rows on the padded-"
                "row profile and profiles real rows itself; unset "
                "SPARK3_DSPARK_PROFILE_TOKENS"
            )
        if self.dead_rows_ratio and req_states.max_num_reqs > 64:
            raise ValueError(
                "SPARK3_DSPARK_DEAD_ROWS=ratio ranks the whole batch in one program "
                f"and supports up to 64 requests, not {req_states.max_num_reqs}"
            )
        self._dead_row_cut = torch.empty(
            req_states.max_num_reqs, dtype=torch.int32, device=device
        )
        # Per-step live-row costs (see DeadRows.live_costs), staged by
        # get_num_tokens and copied by reallocate_drafts.
        self._live_costs = torch.empty(
            req_states.max_num_reqs * self.num_speculative_steps + 2,
            dtype=torch.float32,
            device=device,
        )
        self._live_costs_np: np.ndarray | None = None
        # Real-row verification costs per request count; NaN where unprofiled.
        self.live_verify_tables_by_num_reqs: dict[int, np.ndarray] = {}
        if self.dead_rows_tau > 0:
            logger.info(
                "DSpark dead verification rows below survival %.3g", self.dead_rows_tau
            )
        if self.dead_rows_ratio:
            logger.info("DSpark dead verification rows by expected tokens per ms")
        # Achieved expected tokens per millisecond, per request count. Every
        # rank derives it from the same broadcast confidences and cost tables.
        self._rates: dict[int, float] = {}
        self.query_start_loc = query_start_loc
        self.cost_tables: tuple[np.ndarray, np.ndarray] | None = None
        # Largest cudagraph-captured token count; above it nothing pads.
        self._cudagraph_limit = 0
        self._batch_budget: tuple[dict[str, int], dict[str, int], int] | None = None
        max_num_reqs = req_states.max_num_reqs
        # Current per-slot confidences
        self._confidence_probs = torch.empty(
            (max_num_reqs, self.num_speculative_steps),
            dtype=torch.float32,
            device=device,
        )
        self._batch_draft_capacity = torch.empty(
            max_num_reqs, dtype=torch.int32, device=device
        )
        self._num_non_draft_tokens = torch.empty_like(query_start_loc[:-1])
        self._cu_num_logits = torch.empty_like(query_start_loc)

        # Two D2H slots preserve stale inputs for budget selection.
        self._stale_confidences = [
            CpuGpuBuffer(
                max_num_reqs,
                self.num_speculative_steps,
                dtype=torch.float32,
                device=device,
            )
            for _ in range(2)
        ]
        self._copy_events = [torch.cuda.Event(blocking=True) for _ in range(2)]
        self._pending_resets: list[int] = []
        self._stale_idx = 0
        for slot in self._stale_confidences:
            slot.np.fill(1.0)

    def add_request(self, req_idx: int) -> None:
        self._stale_confidences[self._stale_idx].np[req_idx].fill(1.0)
        self._pending_resets.append(req_idx)
        self._confidence_probs[req_idx].fill_(1.0)

    def batches_to_profile(
        self,
        capture_sizes: list[int],
        full_batch_shapes: list[tuple[int, int]] | None = None,
        *,
        replays: int = _PROFILE_REPLAYS,
        tail: bool = True,
    ) -> Iterator[dict[str, int]]:
        """Dummy-run kwargs whose step timings seed the cost tables.

        Run these inside StepTimingCollector.collect(), then hand the block's
        timings to set_initial_cost_curves. FULL graph shapes retain request
        count because adaptive verification costs differ materially across the
        dense low-concurrency specializations.
        """
        max_num_tokens = self.req_states.max_num_batched_tokens
        self._cudagraph_limit = capture_sizes[-1] if capture_sizes else 0
        profile_shapes: list[tuple[int, int | None]]
        if full_batch_shapes is None:
            profile_shapes = [(num_tokens, None) for num_tokens in capture_sizes]
        else:
            profile_shapes = list(full_batch_shapes)

        # Also profile beyond the capture limit: real steps run there
        # (piecewise/eager) and linear extrapolation badly underestimates
        # them. These runs double as JIT warmup for the piecewise shapes.
        if tail:
            profile_shapes.extend(
                (num_tokens, None)
                for num_tokens in preparation_tail_sizes(capture_sizes, max_num_tokens)
            )
        for replay in range(replays):
            shapes = profile_shapes if replay % 2 == 0 else reversed(profile_shapes)
            for num_tokens, num_reqs in shapes:
                batch = {
                    "num_tokens": num_tokens,
                    "context_len": envs.VLLM_ADAPTIVE_VERIFICATION_PROFILE_CONTEXT_LEN,
                }
                if num_reqs is not None:
                    batch["profile_num_reqs"] = num_reqs
                yield batch

    def profile_costs(
        self,
        run_dummy: Callable[..., object],
        step_timing: StepTimingCollector,
        capture_sizes: list[int],
        full_batch_shapes: list[tuple[int, int]],
        live_rows: Callable[[], AbstractContextManager] | None = None,
    ) -> None:
        """Warm every shape, then sample rounds to limit startup/order bias.

        With dead rows by ratio, ``live_rows`` makes dummy rows real (routed)
        rows, and the full graph shapes are profiled again under it to price
        live verification rows.
        """
        for batch in self.batches_to_profile(
            capture_sizes, full_batch_shapes, replays=1
        ):
            run_dummy(**batch)
        with step_timing.collect() as timings:
            for batch in self.batches_to_profile(capture_sizes, full_batch_shapes):
                run_dummy(**batch)
        self.set_initial_cost_curves(timings)
        if not self.dead_rows_ratio:
            return
        assert live_rows is not None
        with live_rows():
            for batch in self.batches_to_profile(
                capture_sizes, full_batch_shapes, replays=1, tail=False
            ):
                run_dummy(**batch)
            with step_timing.collect() as timings:
                for batch in self.batches_to_profile(
                    capture_sizes, full_batch_shapes, tail=False
                ):
                    run_dummy(**batch)
        self.set_live_cost_curves(timings)

    def set_initial_cost_curves(self, samples: list[StepTimingSample]) -> None:
        # Draft curve: eager-target steps inflate drafter timings (the CPU is
        # still launching kernels, opening gaps between the drafter's events),
        # and request counts — unlike token counts — collide across execution
        # modes, so only graph-replay samples may price the draft curve.
        draft_curve = median_curve(
            (s.num_reqs, s.drafter_ms) for s in samples if s.full_cudagraph
        )
        verify_curve = median_curve(
            (s.num_target_tokens, s.forward_ms) for s in samples
        )
        verify_curves_by_num_reqs = verify_curves_by_num_reqs_from(samples)
        draft_curve, verify_curve, verify_curves_by_num_reqs = self._pin_cost_curves(
            draft_curve, verify_curve, verify_curves_by_num_reqs
        )
        self.set_cost_curves(
            draft_curve,
            verify_curve,
            verify_curves_by_num_reqs=verify_curves_by_num_reqs,
        )

    def set_live_cost_curves(self, samples: list[StepTimingSample]) -> None:
        """Real-row verification costs of the FULL graph shapes, for dead rows."""
        curves = verify_curves_by_num_reqs_from(samples)
        _, _, curves = self._pin_cost_curves([], [], curves, rows="live")
        curves = get_tp_group().broadcast_object(curves, src=0)
        if not curves:
            raise RuntimeError("Could not profile real-row verification costs")
        assert self.cost_tables is not None
        self.live_verify_tables_by_num_reqs = build_tables_by_num_reqs(
            curves,
            self.req_states.max_num_reqs,
            self.req_states.max_num_batched_tokens,
            np.full_like(self.cost_tables[1], np.nan),
        )
        logger.debug(
            "DSpark live-row verify tables: %s", self.live_verify_tables_by_num_reqs
        )

    def _pin_cost_curves(
        self,
        draft_curve: list[tuple[int, float]],
        verify_curve: list[tuple[int, float]],
        verify_curves_by_num_reqs: dict[int, list[tuple[int, float]]],
        rows: str = "padded",
    ) -> tuple[
        list[tuple[int, float]],
        list[tuple[int, float]],
        dict[int, list[tuple[int, float]]],
    ]:
        """Reuse (or save) rank 0's curves for this shape set.

        Only rank 0's curves matter: set_cost_curves broadcasts them. Other
        ranks still profile, so every rank issues the same collectives.
        """
        if _COST_DIR is None:
            return draft_curve, verify_curve, verify_curves_by_num_reqs
        tp_group = get_tp_group()
        if tp_group.rank_in_group != 0:
            return draft_curve, verify_curve, verify_curves_by_num_reqs

        def plain(curve: list[tuple[int, float]]) -> list[list[int | float]]:
            return [[int(x), float(y)] for x, y in curve]

        draft_curve = plain(draft_curve)
        verify_curve = plain(verify_curve)
        verify_curves_by_num_reqs = {
            int(n): plain(curve) for n, curve in verify_curves_by_num_reqs.items()
        }
        key = {
            "tp": tp_group.world_size,
            "num_speculative_steps": self.num_speculative_steps,
            "max_num_reqs": self.req_states.max_num_reqs,
            "max_num_batched_tokens": self.req_states.max_num_batched_tokens,
            "cudagraph_limit": self._cudagraph_limit,
            "profile_context_len": envs.VLLM_ADAPTIVE_VERIFICATION_PROFILE_CONTEXT_LEN,
            "draft_sizes": [x for x, _ in draft_curve],
            "verify_sizes": [x for x, _ in verify_curve],
            "full_shapes": {
                str(n): [x for x, _ in curve]
                for n, curve in sorted(verify_curves_by_num_reqs.items())
            },
        }
        if rows != "padded":
            key["rows"] = rows
        digest = hashlib.sha256(
            json.dumps(key, sort_keys=True).encode()
        ).hexdigest()[:16]
        path = os.path.join(_COST_DIR, f"dspark-costs-{digest}.json")
        if os.path.exists(path):
            with open(path) as f:
                pinned = json.load(f)
            if pinned.get("key") == key:
                logger.info("Using pinned DSpark cost curves from %s", path)
                return (
                    [tuple(p) for p in pinned["draft_curve"]],
                    [tuple(p) for p in pinned["verify_curve"]],
                    {
                        int(n): [tuple(p) for p in curve]
                        for n, curve in pinned["verify_curves_by_num_reqs"].items()
                    },
                )
            logger.warning("Ignoring pinned DSpark cost curves with another key: %s", path)
            return draft_curve, verify_curve, verify_curves_by_num_reqs
        os.makedirs(_COST_DIR, exist_ok=True)
        tmp = f"{path}.{os.getpid()}.tmp"
        with open(tmp, "w") as f:
            json.dump(
                {
                    "key": key,
                    "profile_replays": _PROFILE_REPLAYS,
                    "draft_curve": draft_curve,
                    "verify_curve": verify_curve,
                    "verify_curves_by_num_reqs": {
                        str(n): curve for n, curve in verify_curves_by_num_reqs.items()
                    },
                },
                f,
                indent=1,
            )
        os.replace(tmp, path)
        logger.info("Pinned DSpark cost curves to %s", path)
        return (
            [tuple(p) for p in draft_curve],
            [tuple(p) for p in verify_curve],
            {n: [tuple(p) for p in curve] for n, curve in verify_curves_by_num_reqs.items()},
        )

    def set_cost_curves(
        self,
        draft_curve: list[tuple[int, float]],
        verify_curve: list[tuple[int, float]],
        *,
        verify_curves_by_num_reqs: Mapping[int, list[tuple[int, float]]] | None = None,
    ) -> None:
        draft_curve, verify_curve, verify_curves_by_num_reqs = (
            get_tp_group().broadcast_object(
                (draft_curve, verify_curve, verify_curves_by_num_reqs), src=0
            )
        )
        if not draft_curve or not verify_curve:
            raise RuntimeError(
                "Adaptive verification could not profile step costs. Pass "
                "`enable_adaptive_verification=false` in the speculative config to "
                "verify a fixed number of drafts instead."
            )
        max_num_reqs = self.req_states.max_num_reqs
        max_batch_tokens = self.req_states.max_num_batched_tokens
        self.cost_tables = build_cost_tables_from_curves(
            draft_curve,
            verify_curve,
            max_num_reqs,
            max_batch_tokens,
            self._cudagraph_limit,
        )
        # Beyond the captured shapes, retain the measured eager costs.
        self.verify_cost_tables_by_num_reqs = build_tables_by_num_reqs(
            verify_curves_by_num_reqs or {},
            max_num_reqs,
            max_batch_tokens,
            self.cost_tables[1],
        )
        logger.debug(
            "DSpark cost tables: %s; per-request verify tables: %s",
            self.cost_tables,
            self.verify_cost_tables_by_num_reqs,
        )

    def record_confidences(
        self,
        confidence_probs: torch.Tensor,
        input_batch: "InputBatch",
    ) -> None:
        """Publish this step's raw confidences for the ranking kernel and start
        copying them to the CPU, where a later step's budget reads them."""
        num_reqs = input_batch.num_reqs
        ready_idx = self._stale_idx ^ 1
        with gpu_sync_allowed():
            self._copy_events[ready_idx].synchronize()
        if self._pending_resets:
            self._stale_confidences[ready_idx].np[self._pending_resets] = 1.0
            self._pending_resets.clear()
        # Last step's copy has landed: budgets read it, this step overwrites the
        # slot they were reading before.
        self._stale_idx, write_idx = ready_idx, self._stale_idx

        self._confidence_probs[input_batch.idx_mapping] = confidence_probs[:num_reqs]
        # Replicated projections may differ through unordered floating-point
        # reductions. Both CPU graph selection and GPU request compaction must
        # consume one TP-wide confidence snapshot to issue matching collectives.
        tp_group = get_tp_group()
        if tp_group.world_size > 1:
            tp_group.broadcast(self._confidence_probs, src=0)
        write_slot = self._stale_confidences[write_idx]
        write_slot.gpu.copy_(self._confidence_probs)

        current_stream = torch.cuda.current_stream(self.req_states.device)
        self._copy_stream.wait_stream(current_stream)
        with stream(self._copy_stream, current_stream):
            write_slot.copy_to_cpu()
            self._copy_events[write_idx].record()

    def get_num_tokens(
        self,
        num_tokens_per_req: dict[str, int],
        draft_tokens: dict[str, list[int]],
    ) -> int:
        """Token count once the draft budget is trimmed to fit.

        Stashes the chosen budget in ``_batch_budget`` for the compaction and
        reallocation that follow in the same step.
        """
        assert self.cost_tables is not None
        req_ids = list(num_tokens_per_req)
        num_reqs = len(req_ids)
        scheduled_tokens = np.fromiter(
            num_tokens_per_req.values(), dtype=np.int32, count=num_reqs
        )
        scheduled_drafts = np.fromiter(
            (len(draft_tokens.get(req_id, ())) for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        num_non_draft_tokens = scheduled_tokens - scheduled_drafts
        slots = np.fromiter(
            (self.req_states.req_id_to_index[req_id] for req_id in req_ids),
            dtype=np.int32,
            count=len(req_ids),
        )
        stale_confidences = self._stale_confidences[self._stale_idx].np[slots]
        survival_probability = np.cumprod(stale_confidences.astype(np.float64), axis=1)
        steps = np.arange(self.num_speculative_steps)
        valid = steps[None, :] < scheduled_drafts[:, None]
        scores = np.sort(survival_probability[valid])[::-1]
        num_non_draft_tokens_total = int(num_non_draft_tokens.sum())
        max_draft_budget = min(
            int(scheduled_drafts.sum()),
            max(0, self._max_total_logits - num_reqs * self.num_bonus_tokens),
        )
        scores = scores[:max_draft_budget]
        draft_cost_ms, verify_cost_ms = self.cost_tables
        verify_cost_ms = getattr(self, "verify_cost_tables_by_num_reqs", {}).get(
            num_reqs, verify_cost_ms
        )
        num_sampling_requests = np.count_nonzero(
            self.req_states.num_computed_tokens_np[slots] + num_non_draft_tokens
            >= self.req_states.prefill_len.np[slots]
        )
        num_tokens_to_estimated_accepted_tokens = np.concatenate(
            ([num_sampling_requests], num_sampling_requests + np.cumsum(scores))
        )
        verify_costs = verify_cost_ms[
            num_non_draft_tokens_total : num_non_draft_tokens_total
            + max_draft_budget
            + 1
        ]
        base_verify_cost = verify_costs[0]
        costs = (
            draft_cost_ms[len(req_ids)]
            + base_verify_cost
            + self.cost_scale * (verify_costs - base_verify_cost)
        )
        num_drafts_per_req = {
            req_id: int(num_drafts)
            for req_id, num_drafts in zip(req_ids, scheduled_drafts, strict=True)
        }
        num_non_draft_tokens_per_req = {
            req_id: int(num_tokens)
            for req_id, num_tokens in zip(req_ids, num_non_draft_tokens, strict=True)
        }
        if self._verify_rule == "all":
            # Schedule every draft; dead rows (if enabled) prune on device.
            utilities = num_tokens_to_estimated_accepted_tokens / costs
            draft_budget = max_draft_budget
        elif self._verify_rule == "marginal":
            # Maximize tokens - rate * cost with rate the achieved expected
            # tokens per ms (Dinkelbach's fixed point for tokens / time). A
            # confident step then verifies every draft that beats the average
            # rate, not only those that raise its own ratio. The rate never
            # falls below this batch's no-draft rate.
            plain_rate = num_tokens_to_estimated_accepted_tokens[0] / costs[0]
            rate = max(self._rates.get(num_reqs, plain_rate), plain_rate)
            utilities = num_tokens_to_estimated_accepted_tokens - rate * costs
            draft_budget = int(np.argmax(utilities))
            chosen_rate = (
                num_tokens_to_estimated_accepted_tokens[draft_budget]
                / costs[draft_budget]
            )
            self._rates[num_reqs] = (1.0 - _RATE_ALPHA) * rate + _RATE_ALPHA * chosen_rate
        else:
            utilities = num_tokens_to_estimated_accepted_tokens / costs
            draft_budget = int(np.argmax(utilities))
        # The confidences come from an estimator that learns only from admitted
        # drafts, so a long run of empty budgets would leave it without the
        # evidence to ever admit one again. Periodically verify one draft per
        # request to keep it grounded.
        idle = getattr(self, "_steps_without_drafts", 0)
        if draft_budget == 0 and max_draft_budget > 0:
            idle += 1
            if idle >= EXPLORE_AFTER_IDLE_STEPS:
                draft_budget = min(num_reqs, max_draft_budget)
                idle = 0
        else:
            idle = 0
        self._steps_without_drafts = idle
        logger.debug(
            "DSpark adaptive verification selected %d/%d draft rows for %d "
            "requests at cost scale %.3g (selected utility %.4g, full utility "
            "%.4g)",
            draft_budget,
            int(scheduled_drafts.sum()),
            num_reqs,
            self.cost_scale,
            utilities[draft_budget],
            utilities[-1],
        )
        self._batch_budget = (
            num_drafts_per_req,
            num_non_draft_tokens_per_req,
            draft_budget,
        )
        if self.dead_rows_ratio:
            self._live_costs_np = self.live_costs(
                num_reqs,
                num_sampling_requests,
                num_non_draft_tokens_total,
                draft_budget,
                draft_cost_ms[num_reqs],
                verify_cost_ms,
            )
        return sum(num_non_draft_tokens_per_req.values()) + draft_budget

    def live_costs(
        self,
        num_reqs: int,
        num_sampling_requests: int,
        num_non_draft_tokens: int,
        draft_budget: int,
        draft_ms: float,
        padded_verify_ms: np.ndarray,
    ) -> np.ndarray:
        """DeadRows.live_costs for this step: live drafts cost their real-row
        increment over the padded rows, and the step always pays for every
        scheduled row as padding. Without a real-row price (beyond the captured
        shapes) every cost is equal, so every scheduled draft stays live."""
        costs = np.empty(draft_budget + 2, dtype=np.float32)
        costs[0] = num_sampling_requests
        live_verify_ms = self.live_verify_tables_by_num_reqs.get(num_reqs)
        rows = np.arange(num_non_draft_tokens, num_non_draft_tokens + draft_budget + 1)
        if live_verify_ms is None or np.isnan(live_verify_ms[rows[-1]]):
            costs[1:] = 1.0
            return costs
        routed_ms = np.maximum(live_verify_ms[rows] - padded_verify_ms[rows], 0.0)
        costs[1:] = draft_ms + padded_verify_ms[rows[-1]] + routed_ms
        return costs

    def compact_batch(
        self,
        num_draft_tokens_per_req: np.ndarray,
        num_scheduled_tokens: np.ndarray,
        cu_num_logits_np: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Compact the CPU batch to the chosen draft budget.

        Returns the compacted per-request token counts and the CPU cu_num_logits_np.
        If the draft budget is 0, we can know cu_num_logits_np exactly, otherwise
        its unchanged/an-upper-bound.
        """
        batch_budget = self._batch_budget
        assert batch_budget is not None
        _, _, draft_budget = batch_budget
        num_drafts = int(num_draft_tokens_per_req.sum())
        if draft_budget == num_drafts:
            return num_scheduled_tokens, cu_num_logits_np

        num_non_draft_tokens = num_scheduled_tokens - num_draft_tokens_per_req
        if draft_budget == 0:
            # The draft budget is 0, so we can know cu_num_logits_np exactly. This helps
            # when we would exceed the sampler logit chunk size.
            num_reqs = num_scheduled_tokens.shape[0]
            cu_num_logits_np = (
                np.arange(num_reqs + 1, dtype=cu_num_logits_np.dtype)
                * self.num_bonus_tokens
            )
            return num_non_draft_tokens, cu_num_logits_np

        is_verification_request = num_draft_tokens_per_req > 0
        num_verification_reqs = int(is_verification_request.sum())
        # sort_batch_req_ids keeps verification requests at the front.
        assert np.all(is_verification_request[:num_verification_reqs])
        # for the CPU side buffer we distribute draft tokens evenly
        draft_lens_cpu = np.zeros_like(num_non_draft_tokens)
        draft_lens_cpu[:num_verification_reqs] = draft_budget // num_verification_reqs
        draft_lens_cpu[: draft_budget % num_verification_reqs] += 1
        return num_non_draft_tokens + draft_lens_cpu, cu_num_logits_np

    def dead_row_args(self, is_padding: torch.Tensor, num_reqs: int) -> DeadRows | None:
        """Arguments for the fused dead-row marking, or None when disabled.

        The confidences are the current drafts', broadcast from rank 0, and
        the live costs derive from rank 0's cost tables, so every rank marks
        the same rows.
        """
        if self.dead_rows_ratio:
            return DeadRows(
                self._confidence_probs,
                is_padding,
                self._dead_row_cut[:num_reqs],
                live_costs=self._live_costs,
            )
        if self.dead_rows_tau <= 0:
            return None
        return DeadRows(
            self._confidence_probs,
            is_padding,
            self._dead_row_cut[:num_reqs],
            log_tau=float(np.log(self.dead_rows_tau)),
        )

    def get_verified_draft_counts(self, num_reqs: int) -> torch.Tensor:
        """Return the device-selected draft count for each request."""
        return self._batch_draft_capacity[:num_reqs]

    def reallocate_drafts(
        self, req_ids: list[str], idx_mapping: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, int]:
        batch_budget, self._batch_budget = self._batch_budget, None
        assert batch_budget is not None
        num_drafts_per_req, num_non_draft_tokens_per_req, draft_budget = batch_budget
        num_reqs = idx_mapping.shape[0]
        scheduled_drafts = np.fromiter(
            (num_drafts_per_req[req_id] for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        num_non_draft_tokens = np.fromiter(
            (num_non_draft_tokens_per_req[req_id] for req_id in req_ids),
            dtype=np.int32,
            count=num_reqs,
        )
        num_tokens = int(num_non_draft_tokens.sum()) + draft_budget

        # Rank draft slots by survival probability and admit the best prefix.
        # capacities enters holding each request's valid draft count (the kernel
        # uses it to bound eligible slots) and leaves holding the admitted count.
        capacities = self._batch_draft_capacity[:num_reqs]
        if draft_budget == 0:
            capacities.zero_()
        else:
            async_tensor_h2d(scheduled_drafts, out=capacities)
            if draft_budget < int(scheduled_drafts.sum()):
                _assign_draft_token_budget_compiled(
                    self._confidence_probs,
                    idx_mapping,
                    capacities,
                    draft_budget,
                    self.num_speculative_steps,
                )

        if self._live_costs_np is not None:
            live_costs, self._live_costs_np = self._live_costs_np, None
            async_tensor_h2d(live_costs, out=self._live_costs[: live_costs.shape[0]])
        num_non_draft_tokens_gpu = self._num_non_draft_tokens[:num_reqs]
        async_tensor_h2d(num_non_draft_tokens, out=num_non_draft_tokens_gpu)
        self._cu_num_logits[:1].zero_()
        torch.cumsum(
            capacities + self.num_bonus_tokens,
            dim=0,
            out=self._cu_num_logits[1 : num_reqs + 1],
        )
        self.query_start_loc[:1].zero_()
        torch.cumsum(
            capacities + num_non_draft_tokens_gpu,
            dim=0,
            out=self.query_start_loc[1 : num_reqs + 1],
        )
        self.query_start_loc[num_reqs + 1 :].fill_(num_tokens)
        return (
            self._cu_num_logits[: num_reqs + 1],
            self.query_start_loc,
            draft_budget,
        )


def maybe_create_adaptive_verification_manager(
    *,
    enable_adaptive_verification: bool,
    attn_groups: list[list["AttentionGroup"]],
    attn_cg_support: "AttentionCGSupportInfo",
    req_states: "RequestState",
    query_start_loc: torch.Tensor,
    num_bonus_tokens: int,
    max_total_logits: int,
    vllm_config: "VllmConfig",
    adaptive_verification_cost_scale: float = 1.0,
    target_layer_names: set[str] | None = None,
    additional_attn_cg_support: tuple[AttentionCGSupport, str | None] | None = None,
) -> AdaptiveVerificationManager | None:
    if not enable_adaptive_verification:
        return None

    # The selector rejects unsupported backends, but models that
    # hard-wire theirs (e.g. DeepSeek-V4) never go through it.
    backend = get_query_lens_mismatch_unsupported_backend(
        attn_groups,
        checked_layer_names=target_layer_names,
    )
    if backend is not None:
        raise ValueError(
            "Adaptive verification trims verification requests on device, which"
            f" the {backend} attention backend does not support. Pass "
            "enable_adaptive_verification=false in the speculative config, or "
            "use a backend that does."
        )

    target_attn_cg_support = attn_cg_support
    if target_layer_names is not None:
        target_attn_cg_support = get_attn_cg_support(
            attn_groups,
            vllm_config,
            checked_layer_names=target_layer_names,
        )
        if additional_attn_cg_support is not None:
            target_attn_cg_support = target_attn_cg_support.narrow(
                *additional_attn_cg_support
            )
    varlen_unsupported = []
    groups_to_check = (
        attn_groups
        if target_attn_cg_support.min_cg_support != AttentionCGSupport.ALWAYS
        else []
    )
    for groups in groups_to_check:
        for group in groups:
            if target_layer_names is not None and target_layer_names.isdisjoint(
                group.layer_names
            ):
                continue
            builder = group.get_metadata_builder(0)
            support = builder.get_cudagraph_support(vllm_config, group.kv_cache_spec)
            if support != AttentionCGSupport.ALWAYS and not (
                support == AttentionCGSupport.UNIFORM_BATCH
                and getattr(builder, "supports_varlen_decode_cudagraph", False)
            ):
                varlen_unsupported.append(group.backend.__name__)
    if (
        additional_attn_cg_support is not None
        and additional_attn_cg_support[0] != AttentionCGSupport.ALWAYS
    ):
        varlen_unsupported.append(str(additional_attn_cg_support[1]))
    if varlen_unsupported:
        raise ValueError(
            "Adaptive verification requires variable-length decode CUDA graphs; "
            f"unsupported target backends: {', '.join(varlen_unsupported)}. Pass "
            "enable_adaptive_verification=false in the speculative config, or "
            "use a backend that does."
        )

    return AdaptiveVerificationManager(
        req_states,
        query_start_loc,
        num_bonus_tokens,
        max_total_logits=max_total_logits,
        cost_scale=adaptive_verification_cost_scale,
    )
