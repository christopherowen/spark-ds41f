import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types
from unittest.mock import patch
sys.path.insert(0,str(Path.cwd()))
from servebench import client, load, prompts

root=Path.cwd(); commit='19efdd6fe1f11a159c5f1989aaa3433682325ab2'
def historical(path):
 return subprocess.check_output(['git','show',commit+':'+path])
raw=historical('servebench/client.py'); old=types.ModuleType('recorded_stream_client');exec(compile(raw,'recorded-client.py','exec'),old.__dict__)
cases=[
 ('continuous-empty-deltas',True,[
  {'choices':[{'delta':{'role':'assistant','content':''}}],'usage':{'prompt_tokens':5,'completion_tokens':0}},
  {'choices':[{'delta':{},'token_ids':[1]}],'usage':{'prompt_tokens':5,'completion_tokens':1}},
  {'choices':[{'delta':{'content':'Hi'},'token_ids':[2]}],'usage':{'prompt_tokens':5,'completion_tokens':2}},
  {'choices':[{'delta':{},'token_ids':[3]}],'usage':{'prompt_tokens':5,'completion_tokens':3}},
  {'choices':[{'delta':{'content':'!'},'token_ids':[4],'finish_reason':'length'}],'usage':{'prompt_tokens':5,'completion_tokens':4}},
  {'choices':[],'usage':{'prompt_tokens':5,'completion_tokens':4}}]),
 ('without-continuous-counts',False,[{'choices':[{'delta':{'content':'Hi'}}]}, {'choices':[{'delta':{},'token_ids':[2]}]}, {'choices':[{'delta':{'content':'!'},'finish_reason':'length'}]}, {'choices':[],'usage':{'prompt_tokens':5,'completion_tokens':3}}]),
 ('invalid-usage',True,[{'choices':[{'delta':{'content':'Hi'},'finish_reason':'length'}],'usage':'invalid'}]),
 ('server-error',True,[{'choices':[{'delta':{'content':'Hi'}}],'usage':{'prompt_tokens':5,'completion_tokens':1}},{'error':{'message':'recorded fixture failure'}}]),
]
class Response:
 def __init__(self,events):self.events=events
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def __iter__(self):return iter([('data: '+json.dumps(e)+'\n\n').encode() for e in self.events]+[b'data: [DONE]\n\n'])
rows=[]
for name,continuous,events in cases:
 wire=[]
 def open_request(request,**kwargs):wire.append({'url':request.full_url,'method':request.method,'body':json.loads(request.data)});return Response(events)
 ticks=iter(float(i) for i in range(100))
 with patch.object(old.urllib.request,'urlopen',open_request):
  try:record=old.stream_chat('http://fixture',{'model':'fixture','messages':[],'max_tokens':4},continuous_usage=continuous,clock=lambda:next(ticks))
  except Exception as error:record={'raised':f'{type(error).__name__}: {error}'}
 rows.append({'name':name,'continuous_usage':continuous,'events':events,'payload':{'model':'fixture','messages':[],'max_tokens':4},'expected_record':record,'expected_wire':wire})
p=root/'experiments/2026-11-04-lossless-memory/collector'
(p/'recorded-events.json').write_text(json.dumps({'reference_client_commit':commit,'reference_client_sha256':hashlib.sha256(raw).hexdigest(),'inference_requests':0,'scope':'synthetic streams processed by the unmodified historical collector; no model or network','cases':rows},indent=2)+'\n')
# All real suite payloads retain the same explicit seed and parameters.
legacy=types.ModuleType('servebench.recorded_load');legacy.__package__='servebench';sys.modules[legacy.__name__]=legacy;exec(compile(historical('servebench/load.py'),'recorded-load.py','exec'),legacy.__dict__)
wire=[]
for name,extra in [('greedy',{'chat_template_kwargs':{'thinking':False}}),('sampled',{'temperature':1.0,'top_p':1.0,'seed':0,'chat_template_kwargs':{'thinking':False}})]:
 for concurrency in (1,4,8,16):
  args=dict(model='fixture',prompt={'id':'p0','text':'hello'},vllm=True,extra_body=extra,salt='fixed-independent-request')
  a=legacy.payload(load=legacy.Load(concurrency=concurrency),**args);b=load.payload(load=load.Load(concurrency=concurrency),**args);assert a==b
  wire.append({'mode':name,'concurrency':concurrency,'body_identical':True})
unchanged={f:historical(f)==(root/f).read_bytes() for f in ['servebench/behaviour.py','servebench/engine.py','servebench/prefill.py','servebench/prompts.py','servebench/prom.py','servebench/stats.py']};assert all(unchanged.values())
old_ast=ast.parse(historical('servebench/stall.py'));now_ast=ast.parse((root/'servebench/stall.py').read_text());builders={}
for name in ('stream_body','probe_body'):
 a=next(n for n in old_ast.body if isinstance(n,ast.FunctionDef) and n.name==name);b=next(n for n in now_ast.body if isinstance(n,ast.FunctionDef) and n.name==name);builders[name]=ast.dump(a)==ast.dump(b);assert builders[name]
audit={'schema_version':1,'reference_client_commit':commit,'execution_client_before_handoff':'e5031394ff9d3f1798c958cf153d307966f56521','default_prompt_count':len(prompts.load('default')),'default_prompt_sha256':prompts.digest(prompts.load('default')),'unchanged_sources':unchanged,'stall_request_builders_identical':builders,'payload_checks':wire,'collector_change':'Current collection includes token-ID-only chunks and continuous-usage progress without decoded text. Recorded 1030 collection accepts only nonempty decoded content/reasoning chunks. This changes first-event timing, stream-gap metrics and window token accounting.','decision_before_candidate_performance_review':'Preserve the current primary suite as an unmatched-collector observation. Complete its atomic job, restore C36, then use a separately named two-boot cohort with the historical event policy. No released build is remeasured.','runtime_source_or_image_changed':False}
(p/'compatibility-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
