import datetime,json,os,pathlib,subprocess
root=pathlib.Path('/home/swank/projects/spark-ds41f')
setup=pathlib.Path('/home/swank/tl-logs/lossless-memory/scales-round3-setup')
argv=['/usr/bin/python3', '-u', 'experiments/2026-11-04-lossless-memory/run_component.py', '--component', 'expert-scales', '--window', 'dgx1-1793877834', '--reuse-kernel-from', 'results/private/lossless-memory-scales-round2/receipt.json', '--through', 'release', '--out', 'results/private/lossless-memory-scales-round3', '--apply']
with (root/results/private/lossless-memory-scales-round3-controller.log).open(x) as log:
 child=subprocess.Popen(argv,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 with (setup/launch.json).open(x) as out:json.dump({controller_pid:child.pid,supervisor_pid:os.getpid(),argv:argv,started:datetime.datetime.now(datetime.timezone.utc).isoformat()},out,indent=2)
 code=child.wait()
 with (setup/exit.json).open(x) as out:json.dump({actual_exit:code,controller_pid:child.pid,supervisor_pid:os.getpid(),ended:datetime.datetime.now(datetime.timezone.utc).isoformat()},out,indent=2)
