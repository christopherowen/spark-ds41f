import datetime,fcntl,json,pathlib,subprocess,sys,traceback
r=pathlib.Path("/home/swank/projects/spark-ds41f")
d=pathlib.Path("/home/swank/tl-logs/lossless-memory/engram-window-setup-20261106")
argv=[sys.executable,"experiments/2026-11-04-lossless-memory/run_component.py","--component","engram","--window","dgx1-1793930544","--through","release","--out","results/private/lossless-memory-engram-round1","--restore-revision","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--apply"]
lock=(d/"qualification-launch.lock").open("a")
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
code=1
record={"argv":argv,"started":datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 assert json.loads((d/"image-build-exit.json").read_text())["exit"]==0,"original image build has not passed"
 assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=r,text=True).strip()=="0fa053bb104538135daf59a9715b02684597b54f"
 assert not subprocess.check_output(["git","status","--porcelain"],cwd=r).strip(),"dirty deployment checkout"
 h=json.loads((pathlib.Path.home()/"spark-hold.json").read_text())
 assert h["holder"]=="spark-lab: owner-authorized lossless memory qualification" and h["window"]=="dgx1-1793930544"
 assert not (d/"qualification-started.json").exists(),"launch already recorded"
 with (d/"qualification-started.json").open("x") as f: json.dump(record,f,indent=2);f.write("\n")
 with (d/"qualification-controller.log").open("x") as f:
  p=subprocess.run(argv,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 code=p.returncode
 record["exit"]=code
except BaseException as e:
 record.update(exit=1,error=repr(e),traceback=traceback.format_exc())
finally:
 record["ended"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (d/"qualification-exit.json").open("x") as f: json.dump(record,f,indent=2);f.write("\n")
raise SystemExit(code)
