import json,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
sys.path.insert(0,str(r));from spark_ds41f import lab
h=lab.read_hold()
assert h["window"]=="dgx1-1793930544" and h["holder"]=="spark-lab: owner-authorized lossless memory qualification" and set(h["nodes"])=={"dgx1","dgx2","dgx3"}
h["rule"]="Only the exact holder/token may run GPU, synchronization or lifecycle work on dgx1,dgx2,dgx3. Explicitly leased disjoint pools remain independent."
lab.write_json_atomic(lab.HOLD,h)
argv=[sys.executable,str(d/"scoped_window.py"),"exec","--source-commit","0fa053bb104538135daf59a9715b02684597b54f",
      "--restore-commit","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--window","dgx1-1793930544",
      "--out","results/private/lossless-memory-engram-setup-20261106a","--apply","--",
      sys.executable,"experiments/2026-11-04-lossless-memory/engram/observer_control.py","--window","dgx1-1793930544",
      "--out","results/private/lossless-memory-engram-observer-controls-20261106a","--apply"]
with (d/"observer-control.dispatch.log").open("x") as log:
 p=subprocess.run(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT)
(d/"observer-control-exit.json").write_text(json.dumps({"argv":argv,"exit":p.returncode},indent=2)+"\n")

