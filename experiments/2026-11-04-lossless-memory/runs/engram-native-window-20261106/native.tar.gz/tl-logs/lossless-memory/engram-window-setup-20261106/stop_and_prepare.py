import json,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
control=json.loads((r/"results/private/lossless-memory-engram-observer-controls-20261106a/receipt.json").read_text())
assert control["passed"] and control["commit"]=="0fa053bb104538135daf59a9715b02684597b54f" and control["window"]=="dgx1-1793930544"
assert {n["node"] for n in control["nodes"]}=={"dgx1","dgx2","dgx3"} and all(n["passed"] for n in control["nodes"])
base=[sys.executable,str(d/"scoped_window.py"),"exec","--source-commit","0fa053bb104538135daf59a9715b02684597b54f",
      "--restore-commit","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--window","dgx1-1793930544",
      "--out","results/private/lossless-memory-engram-setup-20261106a","--apply","--"]
commands=[("stop-for-build",[sys.executable,"bin/spark","--cluster-config","experiments/2026-10-26-spark-ds41f-candidate/candidate-36/tp3-dev.json","cluster","stop","--parallel","--apply"])]
objects=[]
cache=r/".work/upstreams/vllm/.git/objects"
if cache.is_dir():objects.append(str(cache))
previous=r/".work/build/vllm-19f2c20ed4d6-b12x-236ddff04a5f-edba9f62/src/vllm"
if (previous/".git").exists():
 p=subprocess.run(["git","-C",str(previous),"rev-parse","--path-format=absolute","--git-common-dir"],capture_output=True,text=True)
 if p.returncode==0:
  object_path=pathlib.Path(p.stdout.strip())/"objects"
  if object_path.is_dir() and str(object_path) not in objects:objects.append(str(object_path))
limited=["systemd-run","--user","--scope","--quiet","--unit=spark-lossless-engram-prepare-20261106",
         "--property=CPUQuota=200%","--property=MemoryMax=8G","--property=TasksMax=128","ionice","-c","3","nice","-n","10"]
prepare=[sys.executable,"bin/spark","--cluster-config","experiments/2026-11-04-lossless-memory/engram/tp3.json","build","prepare"]
if objects:prepare=["env","GIT_ALTERNATE_OBJECT_DIRECTORIES="+":".join(objects),*prepare]
commands.append(("build-prepare",[*limited,*prepare]))
results=[]
for name,command in commands:
 with (d/(name+".dispatch.log")).open("x") as log:
  p=subprocess.run([*base,*command],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 results.append({"name":name,"exit":p.returncode,"argv":command})
 (d/"stop-and-prepare-exit.json").write_text(json.dumps(results,indent=2)+"\n")
 if p.returncode:break

