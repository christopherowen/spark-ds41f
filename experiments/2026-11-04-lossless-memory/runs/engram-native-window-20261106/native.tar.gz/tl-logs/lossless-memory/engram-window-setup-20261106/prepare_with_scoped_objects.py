import json,os,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
source=r/".work/build/vllm-19f2c20ed4d6-b12x-236ddff04a5f-5012ef72/src/vllm"
targets=[r/".work/upstreams/vllm/.git/objects",r/".work/build/vllm-19f2c20ed4d6-b12x-236ddff04a5f-edba9f62/src/vllm/.git/objects"]
targets=[p for p in targets if p.is_dir()];assert targets
alt=source/".git/objects/info/alternates";assert not alt.exists()
alt.parent.mkdir(parents=True,exist_ok=True);alt.write_text("".join(str(p)+"\n" for p in targets))
env=dict(os.environ,GIT_NO_LAZY_FETCH="1");env.pop("GIT_ALTERNATE_OBJECT_DIRECTORIES",None)
def git(*args):return subprocess.check_output(["git","-C",str(source),*args],env=env,text=True).strip()
assert git("rev-parse","HEAD")=="8bcfc031f1c4c4f40fdebe3ea1099c8cc8076aea"
assert git("rev-parse","HEAD^{tree}")=="05a895a269246adf3c8a573562dd9eda8b1372b9"
deleted=git("diff","--name-only","--diff-filter=D","af1c01499b289be555c475669ba50a88e96d846e","HEAD","--","vllm")
(d/"vllm-scoped-object-cache.json").write_text(json.dumps({"source":str(source),"alternates_file":str(alt),
    "targets":[str(p) for p in targets],"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),
    "base_image_deletion_diff_verified":True,"deleted_paths":deleted.splitlines(),"global_alternates_removed":True},indent=2)+"\n")
raise SystemExit(subprocess.run([sys.executable,"bin/spark","--cluster-config","experiments/2026-11-04-lossless-memory/engram/tp3.json","build","prepare"],cwd=r,env=env).returncode)

