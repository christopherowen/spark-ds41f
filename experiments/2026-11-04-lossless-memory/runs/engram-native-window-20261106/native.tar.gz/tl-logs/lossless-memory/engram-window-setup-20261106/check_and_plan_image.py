import json,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
base=[sys.executable,str(d/"scoped_window.py"),"exec","--source-commit","0fa053bb104538135daf59a9715b02684597b54f",
      "--restore-commit","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--window","dgx1-1793930544",
      "--out","results/private/lossless-memory-engram-setup-20261106a","--apply","--"]
profile="experiments/2026-11-04-lossless-memory/engram/tp3.json"
commands=[("build-check",[sys.executable,"bin/spark","--cluster-config",profile,"build","check"]),
          ("image-plan",["taskset","-c","0-11",sys.executable,"bin/spark","--cluster-config",profile,"build","image"])]
rows=[]
for name,command in commands:
 with (d/(name+".dispatch.log")).open("x") as log:
  p=subprocess.run([*base,*command],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 rows.append({"name":name,"exit":p.returncode,"argv":command})
 (d/"build-check-plan-exit.json").write_text(json.dumps(rows,indent=2)+"\n")
 if p.returncode:break

