import argparse,json,pathlib,subprocess,sys,os
r=pathlib.Path("/home/swank/projects/spark-ds41f");os.chdir(r);sys.path.insert(0,str(r));import spark_ds41f as s
c,n,_=s.configuration(argparse.Namespace(cluster_config="experiments/2026-10-26-spark-ds41f-candidate/candidate-36/tp3-dev.json"))
print(json.dumps({"restore_profile_branch":c["deployment"].get("branch"),"nodes":[x["name"] for x in n["nodes"]]}))
p=subprocess.run(["git","diff","--stat","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","0fa053bb104538135daf59a9715b02684597b54f","--","experiments/2026-10-26-spark-ds41f-candidate/candidate-36","experiments/2026-10-26-spark-ds41f-candidate/rc14","releases/spark-ds41f-1030"],capture_output=True,text=True);print(p.stdout)
d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
argv=[sys.executable,str(d/"scoped_window.py"),"exec","--source-commit","0fa053bb104538135daf59a9715b02684597b54f","--restore-commit","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--window","dgx1-1793930544","--out","results/private/lossless-memory-engram-setup-20261106a","--apply","--",sys.executable,"bin/spark","--cluster-config","experiments/2026-10-26-spark-ds41f-candidate/candidate-36/tp3-dev.json","cluster","sync","--revision","0fa053bb104538135daf59a9715b02684597b54f"]
with (d/"sync-c36-plan.dispatch.log").open("x") as log:
 code=subprocess.run(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
print(json.dumps({"sync_plan_exit":code}))

