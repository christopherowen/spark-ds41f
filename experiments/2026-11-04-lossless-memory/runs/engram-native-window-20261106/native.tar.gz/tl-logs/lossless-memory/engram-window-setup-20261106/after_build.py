import fcntl,json,pathlib,subprocess,sys,time,datetime
d=pathlib.Path("/home/swank/tl-logs/lossless-memory/engram-window-setup-20261106")
lock=(d/"after-build.lock").open("a")
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
deadline=time.monotonic()+7200
while not (d/"image-build-exit.json").exists():
 h=json.loads((pathlib.Path.home()/"spark-hold.json").read_text())
 if h.get("window")!="dgx1-1793930544" or h.get("holder")!="spark-lab: owner-authorized lossless memory qualification":
  raise SystemExit("reservation changed while waiting; qualification not launched")
 if time.monotonic()>deadline: raise SystemExit("image wait exceeded two hours")
 time.sleep(5)
if json.loads((d/"image-build-exit.json").read_text())["exit"]!=0:
 raise SystemExit("image build failed; qualification not launched")
p=subprocess.run([sys.executable,str(d/"qualify.py")],cwd="/home/swank/projects/spark-ds41f")
print(json.dumps({"qualification_supervisor_exit":p.returncode,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
raise SystemExit(p.returncode)
