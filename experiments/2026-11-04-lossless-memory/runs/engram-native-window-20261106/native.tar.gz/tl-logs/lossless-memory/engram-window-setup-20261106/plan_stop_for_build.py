import json,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
argv=[sys.executable,str(d/"scoped_window.py"),"exec","--source-commit","0fa053bb104538135daf59a9715b02684597b54f",
      "--restore-commit","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--window","dgx1-1793930544",
      "--out","results/private/lossless-memory-engram-setup-20261106a","--apply","--",
      sys.executable,"bin/spark","--cluster-config","experiments/2026-10-26-spark-ds41f-candidate/candidate-36/tp3-dev.json",
      "cluster","stop","--parallel"]
with (d/"pre-build-stop-plan.dispatch.log").open("x") as log:
 p=subprocess.run(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT)
(d/"pre-build-stop-plan-exit.json").write_text(json.dumps({"argv":argv,"exit":p.returncode},indent=2)+"\n")

