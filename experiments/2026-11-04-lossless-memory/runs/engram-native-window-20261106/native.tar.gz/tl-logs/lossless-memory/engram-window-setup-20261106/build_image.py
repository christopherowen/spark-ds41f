import json,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
checks=json.loads((d/"build-check-plan-exit.json").read_text())
assert len(checks)==2 and all(row["exit"]==0 for row in checks)
control=json.loads((r/"results/private/lossless-memory-engram-observer-controls-20261106a/receipt.json").read_text())
assert control["passed"] and len(control["nodes"])==3 and all(row["passed"] for row in control["nodes"])
argv=[sys.executable,str(d/"scoped_window.py"),"exec","--source-commit","0fa053bb104538135daf59a9715b02684597b54f",
      "--restore-commit","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--window","dgx1-1793930544",
      "--out","results/private/lossless-memory-engram-setup-20261106a","--apply","--",
      "taskset","-c","0-11",sys.executable,"bin/spark","--cluster-config",
      "experiments/2026-11-04-lossless-memory/engram/tp3.json","build","image","--apply"]
with (d/"image-build.dispatch.log").open("x") as log:
 p=subprocess.run(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT)
(d/"image-build-exit.json").write_text(json.dumps({"argv":argv,"exit":p.returncode},indent=2)+"\n")

