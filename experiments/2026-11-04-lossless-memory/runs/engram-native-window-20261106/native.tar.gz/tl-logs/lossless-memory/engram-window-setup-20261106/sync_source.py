import json,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
command=["systemd-run","--user","--scope","--quiet","--unit=spark-lossless-engram-source-sync-20261106",
         "--property=CPUQuota=200%","--property=MemoryMax=4G","--property=TasksMax=128",
         sys.executable,"bin/spark","--cluster-config","experiments/2026-11-04-lossless-memory/engram/tp3.json",
         "cluster","sync","--revision","0fa053bb104538135daf59a9715b02684597b54f","--apply"]
argv=[sys.executable,str(d/"scoped_window.py"),"exec","--source-commit","0fa053bb104538135daf59a9715b02684597b54f",
      "--restore-commit","2c4b23afcd834ba2adf6a15ca434e59fa4f49f74","--window","dgx1-1793930544",
      "--out","results/private/lossless-memory-engram-setup-20261106a","--apply","--",*command]
with (d/"source-sync.dispatch.log").open("x") as log:
 p=subprocess.run(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT)
(d/"source-sync-exit.json").write_text(json.dumps({"argv":argv,"exit":p.returncode},indent=2)+"\n")

