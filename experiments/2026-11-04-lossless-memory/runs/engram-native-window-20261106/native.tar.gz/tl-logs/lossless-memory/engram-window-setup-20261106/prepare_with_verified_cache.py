import json,os,pathlib,subprocess,sys
r=pathlib.Path("/home/swank/projects/spark-ds41f");d=pathlib.Path.home()/"tl-logs/lossless-memory/engram-window-setup-20261106"
old=r/".work/build/vllm-19f2c20ed4d6-b12x-236ddff04a5f-edba9f62/src/cutlass"
new=r/".work/build/vllm-19f2c20ed4d6-b12x-236ddff04a5f-5012ef72/src/cutlass"
env=dict(os.environ,GIT_NO_LAZY_FETCH="1");env.pop("GIT_ALTERNATE_OBJECT_DIRECTORIES",None)
def git(*args):return subprocess.check_output(["git","-C",str(old),*args],env=env,text=True).strip()
assert git("rev-parse","HEAD")=="cb4247394dd82148787aed73e5dc7cef33cbf862"
assert git("rev-parse","HEAD^{tree}")=="80bf7bcb14301ae22e83a256c961a6b67ecf7893"
assert not git("status","--porcelain")
assert not new.exists() and not new.is_symlink()
new.symlink_to(os.path.relpath(old,new.parent),target_is_directory=True)
(d/"cutlass-cache-reuse.json").write_text(json.dumps({"source":str(old),"alias":str(new),"revision":git("rev-parse","HEAD"),
    "tree":git("rev-parse","HEAD^{tree}"),"tracked_and_untracked_clean":True,
    "source_unchanged":True,"global_vllm_alternates_removed_for_auxiliary_fetches":True},indent=2)+"\n")
command=[sys.executable,"bin/spark","--cluster-config","experiments/2026-11-04-lossless-memory/engram/tp3.json","build","prepare"]
raise SystemExit(subprocess.run(command,cwd=r,env=env).returncode)

