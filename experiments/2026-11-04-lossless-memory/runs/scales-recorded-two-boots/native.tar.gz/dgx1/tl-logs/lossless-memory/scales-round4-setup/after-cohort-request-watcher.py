import datetime,hashlib,json,os,pathlib,sys,tempfile,time
setup=pathlib.Path(sys.argv[1]);root=pathlib.Path(sys.argv[2]);home=pathlib.Path.home()
intent=json.loads((setup/"after-cohort-request-intent.json").read_text())
canonical=home/"spark-request.json";parked=setup/"deferred-after-cohort-request.json"
def save(name,value):
 with (setup/name).open("x") as f:json.dump(value,f,indent=2)
save("request-watcher-ready.json",{"pid":os.getpid(),"utc":datetime.datetime.now(datetime.timezone.utc).isoformat()})
deadline=time.monotonic()+300
while not (setup/"request-parked.json").exists():
 if time.monotonic()>deadline:raise SystemExit("parent did not park request; canonical remains unchanged")
 time.sleep(.2)
while True:
 receipt_path=root/"results/private/lossless-memory-scales-round4/receipt.json"
 receipt=json.loads(receipt_path.read_text())
 hold_path=home/"spark-hold.json";hold=json.loads(hold_path.read_text()) if hold_path.exists() else None
 pidpath=pathlib.Path("/proc")/str(intent["controller_pid"])/"cmdline"
 live=pidpath.exists() and "lossless-memory-scales-round4" in pidpath.read_bytes().decode()
 reason=None
 if canonical.exists():reason="canonical request appeared; preserve it without overwrite"
 elif not hold or hold.get("window")!=intent["window"] or hold.get("holder")!="spark-lab: owner-authorized lossless memory qualification":reason="window changed"
 elif not live:reason="controller exited"
 elif receipt.get("error") or receipt.get("restore_error"):reason="controller error"
 elif receipt.get("completed") or receipt.get("phase")=="ordinary-agent-workload":reason="final cohort job started; no later measurement guard remains"
 if reason:
  data=parked.read_bytes();assert hashlib.sha256(data).hexdigest()==intent["request_sha256"]
  if not canonical.exists():
   fd,temp=tempfile.mkstemp(prefix=".spark-cohort-handoff-",dir=home)
   try:
    with os.fdopen(fd,"wb") as f:f.write(data);f.flush();os.fsync(f.fileno())
    try:os.link(temp,canonical)
    except FileExistsError:pass
   finally:os.unlink(temp)
  same=canonical.exists() and hashlib.sha256(canonical.read_bytes()).hexdigest()==intent["request_sha256"]
  save("request-restored.json",{"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"reason":reason,"canonical_matches_original":same,"deferred_original_retained":str(parked),"phase":receipt.get("phase")})
  print(json.dumps({"request_restored":same,"reason":reason}),flush=True)
  raise SystemExit(0 if same else 2)
 time.sleep(2)
