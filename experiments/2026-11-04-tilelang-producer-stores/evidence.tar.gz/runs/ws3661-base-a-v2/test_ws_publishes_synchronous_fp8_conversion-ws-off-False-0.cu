#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/intrin.h>
#include <tl_templates/cuda/barrier.h>
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/copy_sm90.h>
#include <tl_templates/cuda/cuda_fp8.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void main_kernel(__grid_constant__ const CUtensorMap A_desc, bfloat16_t* __restrict__ C, const fp8_e4_t* __restrict__ W);
extern "C" __global__ void __launch_bounds__(128, 1) main_kernel(__grid_constant__ const CUtensorMap A_desc, bfloat16_t* __restrict__ C, const fp8_e4_t* __restrict__ W) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* a = ((void*)((char*)buf_dyn_shmem + 0));
  void* w = ((void*)((char*)buf_dyn_shmem + 8192));
  __shared__ __align__(16) uint64_t mbarrier_mem[4];
  auto mbarrier = reinterpret_cast<Barrier*>(mbarrier_mem);
  float acc[4];
  if (tl::tl_shuffle_elect<0>()) {
    tl::prefetch_tma_descriptor(A_desc);
  }
  if (tl::tl_shuffle_elect<0>()) {
    mbarrier[0].init(64);
    mbarrier[1].init(64);
    mbarrier[2].init(64);
    mbarrier[3].init(64);
  }
  tl::fence_barrier_init();
  __syncthreads();
  if (((int)threadIdx.x) < 64) {
    tl::__sync_thread_partial(3, 64);
    for (int bk = 0; bk < 24; ++bk) {
      mbarrier[((bk & 1) + 2)].wait((((bk & 3) >> 1) ^ 1));
      #pragma unroll
      for (int i = 0; i < 4; ++i) {
        fp8_e4_t W_local_cast_1[8];
        bfloat16_t w_local_cast[8];
        *(fp8_e4_8_t*)(W_local_cast_1 + 0) = *(fp8_e4_8_t*)(W + (((((((int)blockIdx.x) * 49152) + (i * 12288)) + ((((int)threadIdx.x) >> 4) * 3072)) + (bk * 128)) + ((((int)threadIdx.x) & 15) * 8)));
        uint4 __1;
        fp8_e4_8_t v_ = *(fp8_e4_8_t*)(W_local_cast_1 + 0);
        ((__nv_bfloat162*)(&__1))[0] = __tl_cvt_e4m3x2_to_bfloat162((reinterpret_cast<__nv_fp8x2_storage_t*>(&v_))[0]);
        ((__nv_bfloat162*)(&__1))[1] = __tl_cvt_e4m3x2_to_bfloat162((reinterpret_cast<__nv_fp8x2_storage_t*>(&v_))[1]);
        ((__nv_bfloat162*)(&__1))[2] = __tl_cvt_e4m3x2_to_bfloat162((reinterpret_cast<__nv_fp8x2_storage_t*>(&v_))[2]);
        ((__nv_bfloat162*)(&__1))[3] = __tl_cvt_e4m3x2_to_bfloat162((reinterpret_cast<__nv_fp8x2_storage_t*>(&v_))[3]);
        *(uint4*)(w_local_cast + 0) = __1;
        *(uint4*)(((bfloat16_t*)w) + ((((((((bk & 1) * 2048) + (((((int)threadIdx.x) & 15) >> 3) * 1024)) + (i * 256)) + ((((int)threadIdx.x) >> 4) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + (i & 1)) & 1) * 32)) + ((((((int)threadIdx.x) >> 5) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))) = *(uint4*)(w_local_cast + 0);
      }
      tl::cp_async_commit();
      tl::__sync_thread_partial(3, 64);
      if (tl::tl_shuffle_elect<64>()) {
        mbarrier[(bk & 1)].expect_transaction(4096);
        tl::fence_proxy_async();
        #pragma unroll
        for (int i_1 = 0; i_1 < 2; ++i_1) {
          tl::tma_load(A_desc, mbarrier[(bk & 1)], (&(((bfloat16_t*)a)[(((bk & 1) * 2048) + (i_1 * 1024))])), ((bk * 128) + (i_1 * 64)), (((int)blockIdx.y) * 16));
        }
      }
      tl::mbarrier_cp_async_arrive_noinc(mbarrier[(bk & 1)]);
    }
  } else {
    float broadcast_var = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(acc + 0) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
    for (int bk_1 = 0; bk_1 < 24; ++bk_1) {
      mbarrier[(bk_1 & 1)].wait(((bk_1 & 3) >> 1));
      {
        bfloat16_t A_local[8];
        bfloat16_t B_local[4];
        for (int ki = 0; ki < 8; ++ki) {
          tl::ptx_ldmatrix_x4((&(((bfloat16_t*)a)[(((((((bk_1 & 1) * 2048) + ((ki >> 2) * 1024)) + ((((int)threadIdx.x) & 15) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 31) >> 4) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(A_local[0])));
          tl::ptx_ldmatrix_x2((&(((bfloat16_t*)w)[((((((((bk_1 & 1) * 2048) + ((ki >> 2) * 1024)) + (((((((int)threadIdx.x) & 63) >> 5) + ((((int)threadIdx.x) & 31) >> 4)) & 1) * 512)) + ((((int)threadIdx.x) & 7) * 64)) + (((((((int)threadIdx.x) & 7) >> 2) + ((ki & 3) >> 1)) & 1) * 32)) + (((((((int)threadIdx.x) & 3) >> 1) + (ki & 1)) & 1) * 16)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 8))])), (&(B_local[0])));
          tl::mma_sync<tl::DataType::kBFloat16, tl::DataType::kBFloat16, tl::DataType::kFloat32, 16, 8, 16, false, true>(reinterpret_cast<float*>(acc + 0), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + 0));
        }
      }
      mbarrier[((bk_1 & 1) + 2)].arrive();
    }
    #pragma unroll
    for (int i_2 = 0; i_2 < 2; ++i_2) {
      bfloat16_t C_local_cast_2[2];
      uint1 __2;
      float2 v__1 = *(float2*)(acc + (i_2 * 2));
      (reinterpret_cast<__nv_bfloat162*>(&__2))[0] = __float22bfloat162_rn(((float2*)(&v__1))[0]);
      *(uint1*)(C_local_cast_2 + 0) = __2;
      *(uint1*)(C + (((((((((int)blockIdx.y) * 16384) + (i_2 * 8192)) + (((((int)threadIdx.x) & 31) >> 2) * 1024)) + (((int)blockIdx.x) * 16)) + ((((int)threadIdx.x) >> 5) * 8)) + ((((int)threadIdx.x) & 3) * 2)) - 16)) = *(uint1*)(C_local_cast_2 + 0);
    }
  }
}

