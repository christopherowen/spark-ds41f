import concurrent.futures,json,pathlib,shlex,subprocess,sys
label=sys.argv[1];root=pathlib.Path('.work/tp3-tp4-comparison');out=root/label;out.mkdir(exist_ok=False)
remote=r'''
import pathlib,subprocess,json
commands={
 'containers':['docker','ps','--format','{{.Names}} {{.Status}}'],
 'all_containers':['docker','ps','-a','--format','{{.Names}} {{.Status}}'],
 'gpu':['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],
 'fan':['systemctl','is-active','dgx-fan-control.service'],
 'shared_revision':['git','-C','/home/swank/projects/spark3-vllm-ds41f','rev-parse','HEAD'],
 'shared_status':['git','-C','/home/swank/projects/spark3-vllm-ds41f','status','--porcelain'],
 'qualification_revision':['git','-C','/home/swank/projects/spark3-ring4-qualification','rev-parse','HEAD'],
 'qualification_status':['git','-C','/home/swank/projects/spark3-ring4-qualification','status','--porcelain'],
 'addresses':['ip','-j','address','show'],
 'routes':['ip','-j','route','show'],
 'devlink':['sudo','devlink','-j','dev','param','show'],
}
r={k:subprocess.check_output(cmd,text=True).strip() for k,cmd in commands.items()}
r['memory']=pathlib.Path('/proc/meminfo').read_text()
r['network']={p.name:{f.name:int(f.read_text()) for f in (p/'ports/1/hw_counters').glob('*')} for p in pathlib.Path('/sys/class/infiniband').iterdir()}
print(json.dumps(r))
'''
def capture(n):
 result=json.loads(subprocess.check_output(['ssh',f'swank@dgx{n}',shlex.join(['python3','-c',remote])],text=True));(out/f'dgx{n}.json').write_text(json.dumps(result,indent=2)+'\n')
 entry=json.loads((root/f'entry-dgx{n}.json').read_text())
 assert not result['containers'] and not result['gpu'],(n,'not idle')
 assert result['all_containers']==entry['all_containers'],(n,'container mismatch')
 assert result['shared_revision']==entry['shared_revision'] and result['shared_status']==entry['shared_status'],(n,'shared checkout changed')
 assert result['fan']=='active', (n,'fan not active')
 print('dgx'+str(n),'idle, original containers and shared checkout preserved, fans active',flush=True)
with concurrent.futures.ThreadPoolExecutor(4) as p:list(p.map(capture,range(1,5)))
