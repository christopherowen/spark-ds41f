import concurrent.futures,json,pathlib,subprocess,sys
label='tp4'
out=pathlib.Path('.work/tp3-tp4-comparison')/'runtime-final';out.mkdir(exist_ok=False)
start=json.loads((out.parent/'boot.txt.json').read_text())['started_utc']
def collect(n):
 for suffix,cmd in [('', 'docker logs dsv41-karmic-kraken 2>&1'),('-kernel',f"sudo journalctl -k --since '{start}' --no-pager")]:
  r=subprocess.run(['ssh',f'swank@dgx{n}',cmd],capture_output=True,text=True,check=True)
  (out/f'dgx{n}{suffix}.txt').write_text(r.stdout+r.stderr)
with concurrent.futures.ThreadPoolExecutor(4) as p:list(p.map(collect,range(1,5)))
logs=[p.read_text() for p in out.glob('dgx?.txt')]
assert 'Using pinned DSpark cost curves' in (out/'dgx1.txt').read_text()
for p in out.glob('*-kernel.txt'):
 errors=[l for l in p.read_text().splitlines() if any(w in l.lower() for w in ('xid','out of memory','oom-kill','allocation failed'))]
 assert not errors,(p,errors)
r=subprocess.check_output(['ssh','swank@dgx1','sha256sum /home/swank/projects/spark3-vllm-ds41f/cache/kkref/dspark-costs/ring4-collective-20261003/dspark-costs-8b0313ede293a6de.json'],text=True)
(out/'pinned-cost-sha256.txt').write_text(r)
assert r.split()[0]=='1c66058404523da5323fe46c0a467b1448a39a2eaa5d7cfb1f39e5dffa8d3a0e'
print(label,'rank 0 reused pinned costs; no kernel allocation/OOM/Xid errors')
