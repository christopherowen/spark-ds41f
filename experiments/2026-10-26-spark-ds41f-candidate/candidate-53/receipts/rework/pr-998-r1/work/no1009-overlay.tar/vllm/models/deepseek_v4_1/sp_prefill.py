# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Prefill sequence parallelism (SP) for DeepSeek V4.1 tensor parallelism.

## Mode

At tensor parallel size N every rank repeats the row-wise work of a decoder
layer (mHC mixes, norms, the Engram gate, the residual carry) on every token.
For a long prefill forward, SP turns the per-layer all-reduces into dim-0
reduce-scatters so that each rank owns 1/N of the rows for that work, and
all-gathers the rows back before the ops that need all of them. Weights stay
exactly as in ordinary TP, except that the CED boundary retains one full
ratio-one BF16 compressor weight for its local-row projection. The static
``_use_sequence_parallel`` construction flag stays off: this mode changes no
module.

SP trades two all-gathers per layer for reduce-scatters that split the
row-wise work across the ranks, so a forward runs sequence-parallel exactly
when that trade can pay; there is no setting. It must be prompt processing:
decode forwards (at most the largest CUDA graph capture size, and at most
``max_num_seqs * (1 + num_speculative_tokens)`` tokens) replay captured
graphs and keep full rows. And its reduce-scatter must really scatter: a
conservative hidden-state byte threshold comes from the TP group's
registered one-shot RoCE capacity. This preserves the qualified SP boundary
when transport dispatch is tuned independently below that capacity. It is
a performance policy, not a claim that every smaller message uses RoCE.
``DeepseekV4Model.forward`` decides per forward from the token count T,
which every rank shares, so no agreement between ranks is needed. SP is off
only where it cannot apply: tensor parallel size 1, pipeline parallelism,
static sequence parallelism and request boundary checkpoints. With CED
compaction, only the encoder layers before ``ced_decoder_start`` run on
every row: SP covers those and the boundary's row-wise normalization. The
boundary projects local global-KV rows and gathers their 512-column values,
plus the selected replay rows of its normalized input and residual carry.
Selections keep the full carry gather when compact slots plus the narrow
projection gather would cost at least as many bytes.

## Rows

- Collectives see ``Tp = N * ceil(T / N)`` rows; each rank owns ``L = Tp / N``
  rows, rank r the padded rows ``[r * L, (r + 1) * L)``.
- Kernels never see more than T rows: gathered tensors are used as ``[:T]``.
- Reduce-scatter inputs and unreduced parts are Tp-row buffers whose pad rows
  are zero (TileLang's zero fill).
- The last rank's local rows can include pad rows. They stay finite and are
  never read back into real outputs: every op on local rows is row-wise and every
  gather keeps the first T rows. Zeros keep their values, and the routing and
  expert work they cause, the same in every run.

## Where each op runs

- Local rows (L): the residual carry, mHC pre / post / post_pre / collapse,
  attn_norm, ffn_norm, the Engram gate (``run_engram_mix``), the MoE gate and
  top-k routing, and the final norm.
- Gathered rows (T): the Engram table lookup (for disk column shards, each rank
  exchanges its gathered hash columns all-to-all so it interleaves and projects
  only its own L rows locally through ``wkv``'s column blocks; resident row
  shards slice ``wkv`` and exchange the blocks all-to-all), attention
  (``wq_b``, indexer, compressor, KV cache writes, sparse MLA, WO), and the
  MoE routed and shared experts.
- In attention layers without a compressor, the row-wise front
  (``fused_wqa_wkv``, the q/kv norms and the index weights) runs on local
  rows and its narrower product is gathered instead of the hidden state.
- In encoder attention layers, ``WO-A`` projects all ``T`` rows into its
  native MXFP8 ``o_lora`` activations, exchanges those narrower rows across
  ranks while projecting this rank's own ``WO-B`` shard on local rows, and
  projects the peer ``WO-B`` shards on local rows into the rank-order parts.
- In MoE layers, ``mhc.post_pre`` already writes the local rows' MXFP8 cast and
  the router routes the local BF16 rows; one grouped all-gather exchanges the
  MXFP8 values, scales and local top-k routes instead of gathering the BF16
  hidden state and casting every row again on every rank.

Per decoder layer: all-gather before attention (inside
``DeepseekV4Attention._forward``, behind the opaque attention op, which reads
the rows from ``current()``), reduce-scatter after WO instead of the
all-reduce, all-gather before the MoE, and reduce-scatter of the MoE output
(shared + routed) instead of the runner's final all-reduce. The embedding
reduce-scatters its masked partial rows (each token has one owning
vocabulary shard, so the sum is exact); ``inputs_embeds`` are sliced. After
the final collapse and norm, and for every aux hidden state a drafter
consumes, the rows are gathered back to T. DSpark drafts from the aux hidden
states only, so its pre-collapse MTP buffer is not filled under SP; other
drafters gather it.

## Unreduced results

With ``UNREDUCED`` and the TP group's rank-order reduce-scatter (DS4.1's TileLang
family on the RoCE fabric), the attention's WO output and the MoE output skip the
sum: every rank's partial of this rank's rows is exchanged into one
``(N, L, hidden)`` buffer, this rank's own written in place, and the decoder layer
hands it on as ``RankOrderParts``. TileLang mHC's ``post_pre`` adds the parts in
rank order as it loads them, the same arithmetic and the same bits as the
rank-order reduce-scatter; any other consumer calls ``sum()``. Only real rows are
projected into the buffers; the pad rows of the last rank's block are zeroed.
The MoE combine (shared expert folded in) is that projection: it writes each
rank's block straight into its slot, the other ranks' first, and the exchange of
each slice runs under the combine of this rank's block and of the next slice.
"""

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass

import torch

from vllm.distributed import (
    get_tp_group,
    model_parallel_is_initialized,
    tensor_model_parallel_all_gather,
    tensor_model_parallel_all_to_all_rows,
    tensor_model_parallel_reduce_scatter,
)
from vllm.logger import init_logger

logger = init_logger(__name__)


def _prefill_sp_capacity_bytes() -> int:
    """Registered RoCE capacity used as the conservative SP floor; 0 if none."""
    if not model_parallel_is_initialized():
        return 0
    dev_comm = get_tp_group().device_communicator
    capacity = getattr(dev_comm, "all_reduce_capacity_bytes", None)
    if capacity is not None:
        return int(capacity)
    comm = getattr(dev_comm, "roce_ar_comm", None) or getattr(
        dev_comm, "b12x_ar_comm", None
    )
    return int(getattr(comm, "all_reduce_capacity_bytes", 0)) if comm is not None else 0


def rows_above_bytes(limit: int, row_bytes: int, world_size: int) -> int:
    """The fewest tokens T whose ``Tp``-row message exceeds ``limit`` bytes."""
    padded = -(-(limit // row_bytes + 1) // world_size) * world_size
    return padded - world_size + 1


def resolve_min_rows(vllm_config, *, static_sequence_parallel: bool = False) -> int:
    """The smallest forward, in tokens, that runs sequence-parallel; 0 is never.

    The larger of: one token more than any decode forward (the largest CUDA
    graph capture size, ``max_num_seqs * (1 + num_speculative_tokens)``), and
    the fewest tokens whose padded hidden-state message exceeds the
    registered RoCE capacity. Dispatch tuning must not also retune SP.
    """
    parallel = vllm_config.parallel_config
    reason = None
    if parallel.tensor_parallel_size <= 1:
        reason = "tensor parallel size is 1"
    elif parallel.pipeline_parallel_size != 1:
        reason = "pipeline parallelism keeps full-row intermediate tensors"
    elif static_sequence_parallel:
        reason = "static sequence parallelism is enabled"
    elif vllm_config.use_request_boundary_checkpoints:
        reason = "request boundary checkpoints are enabled"
    if reason is not None:
        logger.info("DeepSeek V4.1 prefill sequence parallelism off: %s", reason)
        return 0
    decode_rows = max(
        vllm_config.compilation_config.max_cudagraph_capture_size or 0,
        # Every decode row the scheduler lays out, copy drafts' included.
        vllm_config.max_decode_rows,
        parallel.tensor_parallel_size,
    )
    rows = decode_rows + 1
    limit = _prefill_sp_capacity_bytes()
    if limit > 0:
        model = vllm_config.model_config
        row_bytes = model.get_hidden_size() * model.dtype.itemsize
        tp = parallel.tensor_parallel_size
        rows = max(rows, rows_above_bytes(limit, row_bytes, tp))
    logger.info(
        "DeepSeek V4.1 prefill sequence parallelism from %d tokens "
        "(capacity floor=%d bytes; independent of all-reduce dispatch)",
        rows,
        limit,
    )
    return rows


@dataclass(frozen=True)
class SPRows:
    """Row layout of one sequence-parallel forward on one TP rank."""

    num_tokens: int
    world_size: int
    rank: int
    # Results stay unreduced (see "Unreduced results").
    unreduced: bool = False

    @property
    def padded_rows(self) -> int:
        """Tp: rows seen by collectives, T rounded up to a multiple of N."""
        return -(-self.num_tokens // self.world_size) * self.world_size

    @property
    def local_rows(self) -> int:
        """L: rows this rank owns between collectives."""
        return self.padded_rows // self.world_size

    @property
    def start(self) -> int:
        """First padded row owned by this rank."""
        return self.rank * self.local_rows

    @property
    def real_rows(self) -> int:
        """Leading local rows that are real tokens; the rest are padding."""
        return max(0, min(self.local_rows, self.num_tokens - self.start))

    def gather(self, x: torch.Tensor) -> torch.Tensor:
        """All-gather this rank's L rows into the first T rows."""
        x = materialize(x)
        if x.shape[0] != self.local_rows:
            raise ValueError(f"SP gather expects {self.local_rows} rows, got {x.shape}")
        return tensor_model_parallel_all_gather(x, dim=0)[: self.num_tokens]

    def gather_many(
        self, *tensors: torch.Tensor, padded_rows: tuple[int, ...] = ()
    ) -> tuple[torch.Tensor, ...]:
        """All-gather several L-row tensors into their first T rows (or ``padded_rows``
        when given for a tensor) in one grouped PyNCCL collective when available."""
        inputs = []
        for x in tensors:
            x = materialize(x)
            if x.shape[0] != self.local_rows:
                raise ValueError(
                    f"SP gather expects {self.local_rows} rows, got {x.shape}"
                )
            inputs.append(x)
        limits = padded_rows + (self.num_tokens,) * (len(inputs) - len(padded_rows))
        comm = (
            getattr(get_tp_group().device_communicator, "pynccl_comm", None)
            if model_parallel_is_initialized()
            else None
        )
        if comm is None or comm.disabled:
            outs = []
            for x, rows in zip(inputs, limits):
                gathered = tensor_model_parallel_all_gather(x, dim=0)
                if rows > gathered.shape[0]:
                    padded = x.new_empty((rows, *x.shape[1:]))
                    padded[: gathered.shape[0]].copy_(gathered)
                    outs.append(padded)
                else:
                    outs.append(gathered[:rows])
            return tuple(outs)
        outs = []
        pairs = []
        for x, rows in zip(inputs, limits):
            inp = x.contiguous()
            alloc_rows = max(self.padded_rows, rows)
            out = torch.empty(
                (alloc_rows, *inp.shape[1:]), dtype=inp.dtype, device=inp.device
            )
            outs.append(out[:rows])
            pairs.append((out[: self.padded_rows], inp))
        comm.group_start()
        for dst, src in pairs:
            comm.all_gather(dst, src)
        comm.group_end()
        return tuple(outs)

    def gather_mxfp8(self, x_q, *extra: torch.Tensor):
        """All-gather this rank's L-row ``MXFP8Rows`` (and any ``extra`` L-row
        tensors, such as local top-k routes) in one grouped collective, returning
        ``(MXFP8Rows, *extra_gathered)``."""
        from vllm.models.deepseek_v4_1.tilelang.linear import MXFP8Rows, mxfp8_rows

        local = self.local_rows
        if x_q.rows.shape[0] != local:
            raise ValueError(
                f"SP MXFP8 gather expects {local} rows, got {x_q.rows.shape}"
            )
        rows_q = mxfp8_rows(self.num_tokens)
        values, scales, *rest = self.gather_many(
            x_q.values[:local],
            x_q.scales[:local],
            *extra,
            padded_rows=(rows_q, rows_q),
        )
        rows = torch.empty(
            (self.num_tokens, *x_q.rows.shape[1:]),
            dtype=x_q.rows.dtype,
            device=x_q.rows.device,
        )
        return (MXFP8Rows(rows, values, scales), *rest)

    def reduce_scatter(self, padded: torch.Tensor) -> torch.Tensor:
        """Sum a zero-padded Tp-row buffer over the ranks into this rank's rows."""
        if padded.shape[0] != self.padded_rows:
            raise ValueError(
                f"SP reduce-scatter expects {self.padded_rows} rows, got {padded.shape}"
            )
        return tensor_model_parallel_reduce_scatter(padded, dim=0)

    def exchange_rows(self, local: torch.Tensor) -> torch.Tensor:
        """Every rank's column block of this rank's rows of a column-parallel product
        of all T rows, ``local`` being this rank's block of every row: ``[N, L, C]``,
        [s] from rank s, so the blocks side by side in rank order are the columns an
        all-gather gives. An all-to-all of each rank's real rows: 1/N of the
        all-gather's bytes, no copy. Rows past this rank's real rows are not written."""
        if local.shape[0] != self.num_tokens:
            raise ValueError(
                f"SP row exchange expects {self.num_tokens} rows, got {local.shape}"
            )
        return tensor_model_parallel_all_to_all_rows(local, self.local_rows)

    def project_exchange_rows(
        self,
        project,
        row_shape: tuple[int, ...],
        dtype: torch.dtype,
        device: torch.device,
        slices: int = 1,
        then=None,
    ) -> torch.Tensor:
        """Every rank's column block of this rank's rows of a column-parallel product
        of all T rows, ``[N, L, *row_shape]``, [s] from rank s.

        ``project(start, stop, out)`` writes this rank's column block of rows
        ``start:stop`` into ``out``. Each slice's peer blocks are projected into a send
        buffer and exchanged into ``out[:, lo:hi]`` on a side stream (``copy_self=False``)
        while this rank's own block of the slice is projected straight into
        ``out[rank, lo : lo + real]`` without allocating a full-row intermediate or
        copying the self-block. ``then()`` runs on the current stream after the last
        projection, before the last exchange is awaited. Rows past this rank's real
        rows are not written.

        Under the one-shot RoCE policy, one slice is one full-row projection,
        ``then()`` and the TP group's row exchange (``exchange_rows``, one-shot RoCE
        when the rows fit, else PyNCCL); two or more slices take the PyNCCL
        pipeline above."""
        local, world, tokens = self.local_rows, self.world_size, self.num_tokens
        comm = _tp_pynccl_comm()
        slices = max(slices, 1)
        roce_rows = (
            getattr(_tp_roce_comm(), "should_all_to_all_rows", None) is not None
        )
        if comm is None or (roce_rows and slices == 1):
            local_kv = torch.empty((tokens, *row_shape), dtype=dtype, device=device)
            if tokens:
                project(0, tokens, local_kv)
            if then is not None:
                then()
            return self.exchange_rows(local_kv)
        out = torch.empty((world, local, *row_shape), dtype=dtype, device=device)
        send = torch.empty((world * local, *row_shape), dtype=dtype, device=device)
        bounds = [local * i // slices for i in range(slices + 1)]
        use_cuda_streams = device.type == "cuda" and torch.cuda.is_available()
        main = torch.cuda.current_stream(device) if use_cuda_streams else None
        side = _side_stream(device) if use_cuda_streams else None
        for lo, hi in zip(bounds, bounds[1:]):
            slice_rows = hi - lo
            if slice_rows == 0:
                continue
            send_slice = send[world * lo : world * hi].view(
                world, slice_rows, *row_shape
            )
            slice_total = 0
            for owner in range(world):
                real = max(0, min(hi, tokens - owner * local) - lo)
                slice_total += real
                if owner != self.rank and real:
                    start = owner * local + lo
                    project(start, start + real, send_slice[owner, :real])
            if slice_total:
                flat_send = send_slice.view(world * slice_rows, *row_shape)[
                    :slice_total
                ]
                if use_cuda_streams:
                    side.wait_stream(main)
                    with torch.cuda.stream(side):
                        comm.all_to_all_rows(
                            out[:, lo:hi],
                            flat_send,
                            slice_rows,
                            stream=side,
                            copy_self=False,
                        )
                else:
                    comm.all_to_all_rows(
                        out[:, lo:hi],
                        flat_send,
                        slice_rows,
                        stream=None,
                        copy_self=False,
                    )
            real_me = max(0, min(hi, tokens - self.rank * local) - lo)
            if real_me:
                start = self.rank * local + lo
                project(start, start + real_me, out[self.rank, lo : lo + real_me])
        if then is not None:
            then()
        if use_cuda_streams:
            # send and out are freed only after this wait, on this stream.
            main.wait_stream(side)
        return out

    def empty_padded(
        self, row_shape: tuple[int, ...], dtype: torch.dtype, device: torch.device
    ) -> torch.Tensor:
        """A Tp-row buffer whose pad rows (T and beyond) are zero."""
        padded = torch.empty((self.padded_rows, *row_shape), dtype=dtype, device=device)
        padded[self.num_tokens :].zero_()
        return padded

    def local_slice(self, x: torch.Tensor) -> torch.Tensor:
        """This rank's L rows of a T-row tensor; pad rows are zero."""
        if x.shape[0] != self.num_tokens:
            raise ValueError(f"SP slice expects {self.num_tokens} rows, got {x.shape}")
        real = self.real_rows
        rows = x[self.start : self.start + real]
        if real == self.local_rows:
            return rows
        local = x.new_zeros((self.local_rows, *x.shape[1:]))
        local[:real].copy_(rows)
        return local

    def project_reduce_scatter(
        self,
        project,
        row_shape: tuple[int, ...],
        dtype: torch.dtype,
        device: torch.device,
        slices: int = 1,
        then=None,
        per_block: bool = False,
    ) -> torch.Tensor:
        """This rank's L rows of the sum over ranks of a T-row projection.

        ``project(start, stop, out)`` writes rows ``start:stop`` of the projection
        into ``out``. With ``slices`` > 1 each rank's block is projected in that many
        pieces, every piece of every block into one contiguous buffer, and each
        piece is reduce-scattered on a side stream while the next is projected.
        A projection whose rows do not depend on one another reduces to the same
        bits as one projection and one reduce-scatter. ``then()`` runs on the
        current stream after the last projection, before the last reduce-scatter
        is awaited.

        With ``unreduced`` rows the result is every rank's unreduced partial of
        this rank's rows instead, ``(N, L, *row_shape)``; see "Unreduced results".
        Block by block (``per_block``, or ``slices`` > 1), each rank's block is
        written with its own call, this rank's straight into its slot, and each
        slice's exchange starts on the side stream once the other ranks' blocks
        are written, under this rank's own and the next slice (for writers that
        cost nothing per call, such as the MoE combine). Otherwise one call
        writes every row and this rank's block is copied into its slot (a
        projection reads its weights once).
        """
        if self.unreduced:
            return self._project_exchange(
                project, row_shape, dtype, device, slices, then, per_block
            )
        if slices <= 1:
            padded = self.empty_padded(row_shape, dtype, device)
            project(0, self.num_tokens, padded[: self.num_tokens])
            if then is not None:
                then()
            return self.reduce_scatter(padded)
        local, world, tokens = self.local_rows, self.world_size, self.num_tokens
        out = torch.empty((local, *row_shape), dtype=dtype, device=device)
        bounds = [local * i // slices for i in range(slices + 1)]
        main = torch.cuda.current_stream(device)
        side = _side_stream(device)
        for lo, hi in zip(bounds, bounds[1:]):
            if hi == lo:
                continue
            piece = torch.empty(
                (world, hi - lo, *row_shape), dtype=dtype, device=device
            )
            for owner in range(world):
                start, stop = owner * local + lo, owner * local + hi
                real = max(0, min(stop, tokens) - start)
                if real:
                    project(start, start + real, piece[owner, :real])
                if real < hi - lo:
                    piece[owner, real:].zero_()
            side.wait_stream(main)
            with torch.cuda.stream(side):
                reduced = tensor_model_parallel_reduce_scatter(
                    piece.view(world * (hi - lo), *row_shape), dim=0
                )
                out[lo:hi].copy_(reduced)
            piece.record_stream(side)
        if then is not None:
            then()
        main.wait_stream(side)
        return out

    def _project_exchange(
        self, project, row_shape, dtype, device, slices, then, per_block=False
    ):
        """``project_reduce_scatter`` without the sum: each rank's block goes into
        its slot of one send buffer, this rank's own straight into its slot of
        the parts, and the chunks are exchanged into the parts. Block by block,
        each slice is exchanged on the side stream once the other ranks' blocks
        of it are projected, while this rank's own block and the next slice
        are."""
        from vllm.models.deepseek_v4_1.tilelang import columns
        from vllm.models.deepseek_v4_1.tilelang.collectives import exchange_into

        local, world, tokens = self.local_rows, self.world_size, self.num_tokens
        send = torch.empty((world, local, *row_shape), dtype=dtype, device=device)
        parts = torch.empty_like(send)
        slices = max(slices, 1)
        if slices == 1 and not per_block:
            flat = send.view(world * local, *row_shape)
            project(0, tokens, flat[:tokens])
            columns.zero_(flat[tokens:])
            parts[self.rank].copy_(send[self.rank])
            if then is not None:
                then()
            self.exchange_into(send, parts)
            return parts

        def write(owner, lo, hi):
            dest = parts if owner == self.rank else send
            start, stop = owner * local + lo, owner * local + hi
            real = max(0, min(stop, tokens) - start)
            if real:
                project(start, start + real, dest[owner, lo : lo + real])
            columns.zero_(dest[owner, lo + real : hi])

        bounds = [local * i // slices for i in range(slices + 1)]
        main = torch.cuda.current_stream(device)
        side = _side_stream(device)
        for lo, hi in zip(bounds, bounds[1:]):
            if hi == lo:
                continue
            for owner in range(world):
                if owner != self.rank:
                    write(owner, lo, hi)
            side.wait_stream(main)
            with torch.cuda.stream(side):
                self.exchange_into(send[:, lo:hi], parts[:, lo:hi])
            write(self.rank, lo, hi)
        if then is not None:
            then()
        # send and parts are freed only after this wait, on this stream.
        main.wait_stream(side)
        return parts

    def exchange_into(self, send: torch.Tensor, recv) -> None:
        """Exchange ``send[peer]`` into ``recv[peer]`` for every peer ``!= rank``."""
        from vllm.models.deepseek_v4_1.tilelang.collectives import exchange_into

        dev_comm = get_tp_group().device_communicator
        comm = dev_comm.pynccl_comm
        roce_comm = _tp_roce_comm()
        if (
            isinstance(recv, torch.Tensor)
            and roce_comm is not None
            and _roce_should_exchange(roce_comm, send, recv)
        ):
            roce_comm.exchange_into(send, recv)
            return
        exchange_into(comm, send, recv, self.rank, self.world_size)


# The attention's WO projection is reduce-scattered in two slices from this many
# tokens, so half its reduce-scatter runs under the other half's projection.
WO_SLICE_TOKENS = 2048


def wo_slices(num_tokens: int) -> int:
    """Slices of a sequence-parallel WO projection of ``num_tokens`` tokens."""
    return 2 if num_tokens >= WO_SLICE_TOKENS else 1


# The Engram projection's row exchange runs in two slices from this many tokens,
# so each slice's peer exchange runs under this rank's own block and the next slice
# once the per-slice projection GEMM is large enough to amortize weight streaming.
ENGRAM_SLICE_TOKENS = 6144


def engram_slices(num_tokens: int) -> int:
    """Slices of a sequence-parallel Engram projection of ``num_tokens`` tokens."""
    return 2 if num_tokens >= ENGRAM_SLICE_TOKENS else 1


# The MoE output is exchanged in one slice per this many tokens: each slice's
# exchange runs under the combine of the next. A slice's message to a peer is at
# least 1,024 rows at TP4, so an exchange's fixed cost stays small beside it.
MOE_SLICE_TOKENS = 4096


def moe_slices(num_tokens: int) -> int:
    """Slices of a sequence-parallel MoE output exchange of ``num_tokens`` tokens."""
    return max(1, num_tokens // MOE_SLICE_TOKENS)


# Results of sequence-parallel steps stay unreduced where the TP group's
# reduce-scatter is the rank-order one (see "Unreduced results"): the TileLang
# family on the RoCE policy.
UNREDUCED = True


def unreduced_enabled() -> bool:
    """Whether this process's SP steps keep their results unreduced."""
    if not UNREDUCED or not model_parallel_is_initialized():
        return False
    comm = get_tp_group().device_communicator
    return bool(getattr(comm, "rank_order_reduce_scatter", False))


def materialize(x):
    """``x``, or the rank-order sum of its parts."""
    from vllm.models.deepseek_v4_1.tilelang.collectives import RankOrderParts

    return x.sum() if isinstance(x, RankOrderParts) else x


def unreduced_parts(x: torch.Tensor):
    """A packed ``(N, L, ...)`` result of an unreduced step as ``RankOrderParts``."""
    from vllm.models.deepseek_v4_1.tilelang.collectives import RankOrderParts

    return RankOrderParts(x)


def project_reduce_scatter_current(
    project, rows, padded_rows, row_shape, dtype, device, then=None
) -> torch.Tensor:
    """The MoE runner's reduce-scatter hook: ``project_reduce_scatter`` over the
    rows of the active SP forward (``activate``). ``project`` is the experts'
    combine, so each block is combined straight into its exchange slot, and the
    exchange runs in ``moe_slices`` slices under the rest of the combine."""
    sp = current()
    if sp is None or sp.num_tokens != rows or sp.padded_rows != padded_rows:
        raise RuntimeError(
            f"SP reduce-scatter of {rows} rows ({padded_rows} padded) outside its "
            f"forward ({sp})"
        )
    return sp.project_reduce_scatter(
        project,
        row_shape,
        dtype,
        device,
        slices=moe_slices(rows),
        then=then,
        per_block=True,
    )


_SIDE_STREAMS: dict = {}


def _tp_roce_comm():
    """The TP group's one-shot RoCE communicator when active, else None."""
    try:
        dev_comm = get_tp_group().device_communicator
    except Exception:
        return None
    roce_comm = getattr(dev_comm, "b12x_ar_comm", None)
    if roce_comm is None or getattr(roce_comm, "disabled", False):
        return None
    return roce_comm


def _tp_pynccl_comm():
    """The TP group's PyNCCL communicator when active, else None."""
    try:
        dev_comm = get_tp_group().device_communicator
    except Exception:
        return None
    comm = getattr(dev_comm, "pynccl_comm", None)
    if comm is None or getattr(comm, "disabled", False):
        return None
    return comm


def _roce_should_exchange(
    roce_comm, send: torch.Tensor, recv: torch.Tensor
) -> bool:
    should_ex = getattr(roce_comm, "should_exchange", None)
    if should_ex is None or getattr(roce_comm, "exchange_into", None) is None:
        return False
    try:
        return bool(should_ex(send, recv))
    except TypeError:
        return bool(should_ex(send))


def _side_stream(device: torch.device) -> torch.cuda.Stream:
    """One stream per device for the reduce-scatters of sliced projections."""
    if device not in _SIDE_STREAMS:
        _SIDE_STREAMS[device] = torch.cuda.Stream(device)
    return _SIDE_STREAMS[device]


def plan_rows(
    num_tokens: int,
    min_rows: int,
    world_size: int,
    rank: int,
    unreduced: bool = False,
) -> SPRows | None:
    """The SP row layout for a forward of ``num_tokens`` tokens, or None."""
    if min_rows <= 0 or world_size <= 1 or num_tokens < min_rows:
        return None
    if not 0 <= rank < world_size:
        raise ValueError(f"TP rank {rank} is outside world size {world_size}")
    return SPRows(num_tokens, world_size, rank, unreduced)


_ROWS: ContextVar[SPRows | None] = ContextVar("ds41_prefill_sp_rows", default=None)


def current() -> SPRows | None:
    """The SP rows of the attention call in progress, if any."""
    return _ROWS.get()


@contextmanager
def activate(rows: SPRows) -> Iterator[None]:
    """Expose ``rows`` across the opaque attention op and MoE runner boundaries."""
    token = _ROWS.set(rows)
    try:
        yield
    finally:
        _ROWS.reset(token)
