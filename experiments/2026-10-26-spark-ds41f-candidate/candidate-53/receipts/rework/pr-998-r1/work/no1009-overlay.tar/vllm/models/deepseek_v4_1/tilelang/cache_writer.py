# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""TileLang writers of DeepSeek-V4.1's paged KV-cache records.

A token's 512 latent values become one record at its slot (``slot // page_size``
selects the page, ``slot % page_size`` the record; negative or out-of-range slots
are skipped):

- ``swa`` (528 bytes): 16 groups of 32 values as E4M3, then 16 UE8M0 scales.
  A group's scale is ``max(amax, 1e-4) * fp32(1/448)`` rounded up to a power of
  two (the exponent is bumped when the mantissa is nonzero).
- ``indexed`` (288 bytes): 32 groups of 16 values as packed E2M1 (low nibble
  first), then 32 E4M3 scales. A group's scale is ``max(amax, 6 * 2^-9) / 6``
  (IEEE division) rounded to E4M3, saturating; the values are divided by its
  decoded value (a rounded reciprocal would move exact E2M1 midpoints off their
  ties-to-even) and converted by ``cvt.rn.satfinite.e2m1x2.f32`` (nearest even,
  saturating), B12X's instruction.

The arithmetic is B12X's ``write_cache`` for ``cache_format="deepseek_v41"``,
step for step, so the records are the same bytes.
"""

# No `from __future__ import annotations`: TileLang reads the prim_func
# annotations eagerly, and the symbolic shape must resolve.
import tilelang
import tilelang.language as T
import torch

from . import pdl, prepare

DIM = 512
RECORD_BYTES = {"swa": 528, "indexed": 288}
_GROUP = {"swa": 32, "indexed": 16}
_E4M3_MAX = 448.0


# Payload bytes, TileLang and torch types of one thread's word: four values each.
_WORD = {"swa": (4, T.uint32, torch.uint32), "indexed": (2, T.uint16, torch.uint16)}
_PER_THREAD = 4

# Four FP32 values to four E4M3 bytes or E2M1 codes, first value lowest: B12X's
# paired conversions in its operand order (the second source fills the low half).
_CVT_HEADER = r"""
__device__ __forceinline__ unsigned int dsv41_e4m3x4(float v0, float v1,
                                                    float v2, float v3) {
  unsigned int packed;
  asm("{\n"
      ".reg .b16 lo, hi;\n"
      "cvt.rn.satfinite.e4m3x2.f32 lo, %2, %1;\n"
      "cvt.rn.satfinite.e4m3x2.f32 hi, %4, %3;\n"
      "mov.b32 %0, {lo, hi};\n"
      "}"
      : "=r"(packed)
      : "f"(v0), "f"(v1), "f"(v2), "f"(v3));
  return packed;
}

__device__ __forceinline__ unsigned short dsv41_e2m1x4(float v0, float v1,
                                                      float v2, float v3) {
  unsigned short packed;
  asm("{\n"
      ".reg .b8 lo, hi;\n"
      "cvt.rn.satfinite.e2m1x2.f32 lo, %2, %1;\n"
      "cvt.rn.satfinite.e2m1x2.f32 hi, %4, %3;\n"
      "mov.b16 %0, {lo, hi};\n"
      "}"
      : "=h"(packed)
      : "f"(v0), "f"(v1), "f"(v2), "f"(v3));
  return packed;
}
"""


@tilelang.jit(pass_configs={tilelang.PassConfigKey.TL_DISABLE_WARP_SPECIALIZED: True})
def cache_writer_kernel(
    cache_kind: str,
    page_size: int,
    slot_dtype: str = "int64",
    rope_dim: int = 0,
    ratio: int = 1,
):
    """One record per token, 128 threads, four values per thread, payload stored in
    whole words through a word view of the pages (scales through the byte view),
    the group's amax shuffled across its lanes. ``swa``: eight lanes per 32-value
    group, one 32-bit word of E4M3 each. ``indexed``: four lanes per 16-value
    group, one 16-bit word of packed E2M1 each. With ``rope_dim > 0``, rotates the
    trailing ``rope_dim`` columns in registers at ``positions`` before quantizing."""
    threads = 128
    group_size = _GROUP[cache_kind]
    groups = DIM // group_size
    word_bytes, word_dtype, _ = _WORD[cache_kind]
    per_thread = _PER_THREAD  # values per thread
    lanes = group_size // per_thread  # threads per group: 8 or 4
    per_token = groups * lanes  # 128 either way
    tokens_per_block = threads // per_token
    record = RECORD_BYTES[cache_kind]
    payload = DIM if cache_kind == "swa" else DIM // 2  # scale bytes follow
    tokens, kv_stride = T.dynamic("tokens, kv_stride")
    positions_max = T.dynamic("positions_max")
    pages, page_bytes, page_stride = T.dynamic("pages, page_bytes, page_stride")
    page_words, word_stride = T.dynamic("page_words, word_stride")
    rope_start = DIM - rope_dim
    rope_half = rope_dim // 2

    @T.macro
    def body(kv, positions, cos_sin, cache, words, slots):
        with T.Kernel(T.ceildiv(tokens, tokens_per_block), threads=threads) as bx:
            T.import_source(_CVT_HEADER)
            pdl.chain()
            tx = T.get_thread_binding()
            token = bx * tokens_per_block + tx // per_token
            item = tx % per_token
            group, lane = item // lanes, item % lanes
            col = group * group_size + lane * per_thread
            values = T.alloc_local((per_thread,), T.float32)
            amax = T.alloc_var(T.float32)
            word = T.alloc_var(word_dtype)
            amax = 0.0
            if token < tokens:
                for i in T.unroll(per_thread):
                    values[i] = T.cast(kv[token, col + i], T.float32)
                if rope_dim > 0:
                    if col >= rope_start:
                        pos = (
                            positions[token] // ratio * ratio
                            if ratio > 1
                            else positions[token]
                        )
                        pair_base = (col - rope_start) // 2
                        for p in T.unroll(per_thread // 2):
                            first = values[2 * p]
                            second = values[2 * p + 1]
                            cosine = cos_sin[pos, pair_base + p]
                            sine = cos_sin[pos, rope_half + pair_base + p]
                            values[2 * p] = T.cast(
                                T.cast(
                                    T.ieee_fmaf(first, cosine, -(second * sine)),
                                    T.bfloat16,
                                ),
                                T.float32,
                            )
                            values[2 * p + 1] = T.cast(
                                T.cast(
                                    T.ieee_fmaf(first, sine, second * cosine),
                                    T.bfloat16,
                                ),
                                T.float32,
                            )
                for i in T.unroll(per_thread):
                    amax = T.max(amax, T.abs(values[i]))
            amax = T.max(amax, T.shfl_xor(amax, 1))
            amax = T.max(amax, T.shfl_xor(amax, 2))
            if lanes == 8:
                amax = T.max(amax, T.shfl_xor(amax, 4))
            if token < tokens:
                slot = T.cast(slots[token], T.int64)
                page = slot // page_size
                if (slot >= 0) & (page < pages):
                    base = (slot % page_size) * record
                    word = T.cast(0, word_dtype)
                    if cache_kind == "swa":
                        bits = T.reinterpret(
                            T.fmul(T.max(amax, 1e-4), T.float32(1.0 / _E4M3_MAX)),
                            T.uint32,
                        )
                        bumped = T.if_then_else(
                            (bits & 0x7FFFFF) != 0, (bits + 0x800000) & 0x7F800000, bits
                        )
                        exponent = T.cast(T.shift_right(bumped, 23) & 0xFF, T.int32)
                        # The exact reciprocal of the power-of-two scale.
                        inverse = T.reinterpret(
                            T.cast(T.shift_left(254 - exponent, 23), T.uint32),
                            T.float32,
                        )
                        word = T.call_extern(
                            "uint32",
                            "dsv41_e4m3x4",
                            T.fmul(values[0], inverse),
                            T.fmul(values[1], inverse),
                            T.fmul(values[2], inverse),
                            T.fmul(values[3], inverse),
                        )
                        words[page, (base + col) // word_bytes] = word
                        if lane == 0:
                            cache[page, base + payload + group] = T.cast(
                                exponent, T.uint8
                            )
                    else:
                        scale = T.max(amax, 6.0 * 2.0**-9) / 6.0
                        scale_code = T.cast(T.min(scale, _E4M3_MAX), T.float8_e4m3fn)
                        decoded = T.cast(scale_code, T.float32)
                        word = T.call_extern(
                            "uint16",
                            "dsv41_e2m1x4",
                            values[0] / decoded,
                            values[1] / decoded,
                            values[2] / decoded,
                            values[3] / decoded,
                        )
                        words[page, (base + col // 2) // word_bytes] = word
                        if lane == 0:
                            cache[page, base + payload + group] = T.reinterpret(
                                scale_code, T.uint8
                            )

    if rope_dim > 0:

        @T.prim_func
        def cache_writer(
            kv: T.StridedTensor((tokens, DIM), (kv_stride, 1), T.bfloat16),
            positions: T.Tensor((tokens,), T.int64),
            cos_sin: T.Tensor((positions_max, rope_dim), T.float32),
            cache: T.StridedTensor((pages, page_bytes), (page_stride, 1), T.uint8),
            words: T.StridedTensor((pages, page_words), (word_stride, 1), word_dtype),
            slots: T.Tensor((tokens,), slot_dtype),
        ):
            body(kv, positions, cos_sin, cache, words, slots)

        return cache_writer

    @T.prim_func
    def cache_writer(
        kv: T.StridedTensor((tokens, DIM), (kv_stride, 1), T.bfloat16),
        cache: T.StridedTensor((pages, page_bytes), (page_stride, 1), T.uint8),
        words: T.StridedTensor((pages, page_words), (word_stride, 1), word_dtype),
        slots: T.Tensor((tokens,), slot_dtype),
    ):
        body(kv, None, None, cache, words, slots)

    return cache_writer


def write_cache(
    kv: torch.Tensor,
    cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    *,
    page_size: int,
    cache_kind: str,
    positions: torch.Tensor | None = None,
    cos_sin: torch.Tensor | None = None,
    ratio: int = 1,
) -> None:
    """Write ``kv`` ([T, 512] BF16, unit column stride) into ``cache`` (``[pages,
    page bytes]`` or ``[pages, records, record bytes]`` bytes, any page stride) at
    ``slot_mapping`` ([T] int32 or int64). With ``positions`` and ``cos_sin``,
    rotates the trailing ``cos_sin.shape[1]`` columns in registers first."""
    if kv.shape[0] == 0:
        return
    if kv.dtype != torch.bfloat16 or kv.shape[1] != DIM or kv.stride(1) != 1:
        raise ValueError("V4.1 cache records come from [T, 512] BF16 rows")
    pages = cache.view(torch.uint8)
    if pages.dim() > 2:  # [pages, records, record bytes]
        pages = pages.flatten(1)
    if pages.shape[1] < page_size * RECORD_BYTES[cache_kind]:
        raise ValueError(
            f"cache pages hold fewer than {page_size} {cache_kind} records"
        )
    word_bytes, _, word_torch = _WORD[cache_kind]
    if pages.stride(0) % word_bytes or pages.shape[1] % word_bytes:
        raise ValueError(f"cache pages are not whole {word_bytes}-byte words")
    if positions is not None and cos_sin is not None:
        function, args, kwargs = writer_call(
            cache_kind,
            page_size,
            slot_mapping.dtype,
            rope_dim=cos_sin.shape[1],
            ratio=ratio,
        )
        kernel = function(*args, **kwargs)
        kernel(kv, positions, cos_sin, pages, pages.view(word_torch), slot_mapping)
        return
    function, args, kwargs = writer_call(cache_kind, page_size, slot_mapping.dtype)
    kernel = function(*args, **kwargs)
    kernel(kv, pages, pages.view(word_torch), slot_mapping)


def writer_call(
    cache_kind: str,
    page_size: int,
    slot_dtype: torch.dtype,
    *,
    rope_dim: int = 0,
    ratio: int = 1,
):
    """The kernel ``write_cache`` launches for ``slot_dtype`` slots, as a
    ``prepare.call``."""
    kwargs = {}
    if rope_dim > 0:
        kwargs = dict(rope_dim=rope_dim, ratio=ratio)
    return prepare.call(
        cache_writer_kernel,
        cache_kind,
        page_size,
        str(slot_dtype).removeprefix("torch."),
        **kwargs,
    )


__all__ = ["RECORD_BYTES", "cache_writer_kernel", "write_cache", "writer_call"]
