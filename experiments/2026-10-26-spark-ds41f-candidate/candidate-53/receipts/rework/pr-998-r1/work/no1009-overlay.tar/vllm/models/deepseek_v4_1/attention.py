# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""V4.1 Full/Reindex/Reuse topology: caches, metadata and ownership. The TileLang
layer (``tilelang/attention.py``) runs the indexer and sparse MLA kernels."""

import os
from typing import cast

import regex as re
import torch
from torch import nn

from vllm.compilation.breakable_cudagraph import (
    eager_break_during_capture,
    is_breakable_cudagraph_enabled,
)
from vllm.config import CacheConfig
from vllm.distributed import (
    get_tensor_model_parallel_rank,
    get_tensor_model_parallel_world_size,
    get_tp_group,
)
from vllm.forward_context import get_forward_context
from vllm.logger import init_logger
from vllm.model_executor.layers import linear as linear_layers
from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase
from vllm.model_executor.layers.linear import (
    ColumnParallelLinear,
    LinearMethodBase,
    ReplicatedLinear,
    RowParallelLinear,
    UnquantizedLinearMethod,
)
from vllm.model_executor.parameter import BlockQuantScaleParameter
from vllm.model_executor.utils import set_weight_attrs
from vllm.model_executor.weight_transfer import copy_weight
from vllm.models.deepseek_v4_1 import kernels, l2_prefetch, sp_prefill
from vllm.models.deepseek_v4_1.ced import ced_decoder_start
from vllm.models.deepseek_v4_1.compressor import DeepseekCompressor
from vllm.models.deepseek_v4_1.quant_config import Block32FP8LinearMethod
from vllm.models.deepseek_v4_1.sparse_mla import (
    SLOT_DTYPE,
    DeepseekV41B12xBackend,
    DeepseekV41B12xMetadata,
    tilelang_builder_kernels,
)
from vllm.models.deepseek_v4_1.tilelang import prepare
from vllm.models.deepseek_v4_1.tilelang.gemm import DECODE_ROWS
from vllm.models.deepseek_v4_1.tilelang.indexer import CANDIDATE_BLOCKS
from vllm.models.deepseek_v41.common.rope import build_deepseek_v4_rope
from vllm.utils.math_utils import cdiv
from vllm.utils.torch_utils import aux_stream
from vllm.v1.kv_cache_interface import MLAAttentionSpec, SlidingWindowMLASpec
from vllm.v1.worker.workspace import (
    current_workspace_manager,
    retain_cuda_graph_capture_resource,
    use_preallocated_workspace,
)

logger = init_logger(__name__)

# Validation only: under a sequence-parallel indexer split, every rank also runs
# the full-row indexer twice and compares its own rows with the split result.
_INDEX_SPLIT_CHECK = os.environ.get("SPARK_DS41F_INDEXER_SPLIT_CHECK") == "1"


def _source(prefix, layer):
    return re.sub(r"(layers\.)\d+", rf"\g<1>{layer}", prefix)


def _native_linear(layer):
    method = layer.quant_method
    if kernels.is_native_linear_method(method):
        return
    if type(method) is UnquantizedLinearMethod:
        layer.quant_method = kernels.linear_method()
        return
    raise ValueError("V4.1 attention only supports native linear methods")


class _Cache(nn.Module, AttentionLayerBase):
    def __init__(self, config, prefix, *, kind, ratio=1, window=0, draft=False):
        super().__init__()
        self.prefix, self.kind, self.ratio, self.window = prefix, kind, ratio, window
        self.draft = draft
        self.block_size = (
            config.cache_config.swa_block_size
            or CacheConfig.DEFAULT_DS41_SWA_BLOCK_SIZE
            if kind == "swa"
            else config.cache_config.block_size
        )
        self.kv_cache = torch.tensor([])
        context = config.compilation_config.static_forward_context
        if prefix in context:
            raise ValueError(f"Duplicate V4.1 cache {prefix}")
        context[prefix] = self

    def bind_kv_cache(self, cache):
        # Keep allocator page stride: padding belongs to the allocator, not the ABI.
        self.kv_cache = cache.view(cache.shape[0], -1)

    def get_kv_cache_spec(self, config):
        # No V4.1 kernel uses a slot its block's owner has not written, as in
        # DeepSeek's reference: windows start at the request's replay start, the
        # sparse MLA never loads a masked entry, the indexer reads no key past the
        # visible positions, and the compressor reads only a slot it wrote.
        # Reused blocks need no zeros.
        common = dict(
            block_size=self.block_size,
            num_kv_heads=1,
            head_size=512 if self.kind == "swa" else 68,
            # Optional BF16 block-mean shortlist storage is admitted only when enabled.
            state_content_bytes=(
                528
                if self.kind == "swa"
                else (100 if os.environ.get("VLLM_DS41_LSA") == "1" else 68)
            ),
            dtype=torch.uint8,
            tokens_per_state=self.ratio,
            cache_dtype_str="b12x_dsv41",
            alignment=None,
            uses_only_written_slots=True,
        )
        if self.kind == "swa":
            boundary = ced_decoder_start(config.model_config.hf_config)
            layer_id = int(re.search(r"layers\.(\d+)", self.prefix).group(1))
            bounded_replay = self.draft or (
                boundary is not None and layer_id >= boundary
            )
            return SlidingWindowMLASpec(
                **common,
                sliding_window=self.window,
                extra_retained_tokens=int(self.draft),
                prefix_cache_enabled=not bounded_replay,
                prefill_replay_window=128 if bounded_replay else 0,
            )
        return MLAAttentionSpec(**common)

    def get_attn_backend(self):
        return DeepseekV41B12xBackend

    def forward(self):
        raise RuntimeError("V4.1 caches are consumed by their owning attention layer")


class _WOProjectionWeightMethod(LinearMethodBase):
    """Keep checkpoint FP8 tensors unmodified for the fused WO projection."""

    def __init__(self, original):
        if not isinstance(original, Block32FP8LinearMethod):
            raise ValueError("V4.1 output projection requires block32 FP8 weights")
        self.original = original

    def create_weights(self, *args, **kwargs):
        return self.original.create_weights(*args, **kwargs)

    def process_weights_after_loading(self, layer):
        if layer.weight.dtype != torch.float8_e4m3fn:
            raise ValueError("V4.1 output projection requires FP8 checkpoint weights")
        if not hasattr(layer, "weight_scale_inv"):
            raise ValueError("V4.1 output projection requires checkpoint scales")
        if layer.weight_scale_inv.dtype != torch.float8_e8m0fnu:
            raise ValueError("V4.1 output projection requires UE8M0 checkpoint scales")

    def apply(self, layer, x, bias=None):
        raise RuntimeError("V4.1 WO weights are consumed only by the fused projection")


class _PaddedMergedColumnParallelLinear(ColumnParallelLinear):
    """Hybrid merged projection: TP-sharded at decode, replicated at prefill/SP.

    Stacks ``output_sizes`` into one logical ``sum(output_sizes)``-row weight padded
    to a multiple of ``tp_size * 32`` (with zero weights and unit scales in any
    trailing pad rows). Because the weight is row-major, both the full logical
    ``[:logical_output_size]`` view and this rank's contiguous TP decode shard
    ``[r * part : (r + 1) * part]`` are zero-copy views of ``self.weight``:
    - Decode (``rows <= DECODE_ROWS`` outside SP prefill) projects this rank's
      ``part_output_size`` shard and ``all_gather(dim=-1)``s back to
      ``logical_output_size`` columns (prefetching only the TP shard into L2).
    - Prefill, wide decode (``rows > DECODE_ROWS``) and SP prefill project the
      full ``logical_output_size`` view locally without any TP all-gather.
    """

    replicated_sp_prefill = True

    def __init__(
        self,
        input_size: int,
        output_sizes: list[int],
        bias: bool = False,
        gather_output: bool = True,
        skip_bias_add: bool = False,
        params_dtype: torch.dtype | None = None,
        quant_config=None,
        prefix: str = "",
        *,
        return_bias: bool = True,
        disable_tp: bool = False,
        tp_rank: int | None = None,
        tp_size: int | None = None,
    ):
        if bias:
            raise ValueError("_PaddedMergedColumnParallelLinear does not support bias")
        if any(size % 32 != 0 for size in output_sizes):
            raise ValueError(
                f"merged output_sizes {output_sizes} must be multiples of 32"
            )
        self.logical_output_sizes = list(output_sizes)
        self.logical_output_size = sum(output_sizes)
        world_size = (
            1
            if disable_tp
            else (
                tp_size
                if tp_size is not None
                else get_tensor_model_parallel_world_size()
            )
        )
        rank = (
            0
            if disable_tp
            else (
                tp_rank
                if tp_rank is not None
                else get_tensor_model_parallel_rank()
            )
        )
        block = world_size * 32
        padded_output_size = cdiv(self.logical_output_size, block) * block
        self.part_output_size = padded_output_size // world_size
        super().__init__(
            input_size=input_size,
            output_size=padded_output_size,
            bias=False,
            gather_output=False,
            skip_bias_add=skip_bias_add,
            params_dtype=params_dtype,
            quant_config=quant_config,
            prefix=prefix,
            return_bias=return_bias,
            disable_tp=True,
        )
        self.tp_rank = rank
        self.tp_size = world_size
        self.gather_output = gather_output
        self.output_size_per_partition = self.part_output_size
        self._init_pad_rows()
        self._refresh_views()

    def _refresh_views(self) -> None:
        r0 = self.tp_rank * self.part_output_size
        r1 = r0 + self.part_output_size
        w = getattr(self, "weight", None)
        if w is not None:
            self.full_weight = w[: self.logical_output_size]
            self.shard_weight = w[r0:r1]
        s = getattr(self, "weight_scale_inv", None)
        if s is not None:
            block_n = getattr(self, "weight_block_size", [32, 32])[0]
            self.full_weight_scale_inv = s[: self.logical_output_size // block_n]
            self.shard_weight_scale_inv = s[r0 // block_n : r1 // block_n]

    def _init_pad_rows(self, param: nn.Parameter | None = None) -> None:
        if self.output_size <= self.logical_output_size:
            return
        pad_start = self.logical_output_size
        targets = (
            (param,)
            if param is not None
            else tuple(
                p
                for p in (
                    getattr(self, "weight", None),
                    getattr(self, "weight_scale_inv", None),
                )
                if p is not None
            )
        )
        for p in targets:
            if p.data.device.type == "meta":
                continue
            if isinstance(p, BlockQuantScaleParameter) or p is getattr(
                self, "weight_scale_inv", None
            ):
                block_n = getattr(self, "weight_block_size", [32, 32])[0]
                row0 = pad_start // block_n
                if p.dtype == torch.float8_e8m0fnu:
                    p.data.view(torch.uint8)[row0:].fill_(0x7F)
                else:
                    p.data[row0:].fill_(1.0)
            else:
                p.data[pad_start:].zero_()

    def weight_loader(
        self,
        param: nn.Parameter,
        loaded_weight: torch.Tensor,
        loaded_shard_id: int | None = None,
    ) -> None:
        if loaded_shard_id is None:
            logical_start = 0
            logical_size = self.logical_output_size
        else:
            if not (
                isinstance(loaded_shard_id, int)
                and 0 <= loaded_shard_id < len(self.logical_output_sizes)
            ):
                raise ValueError(
                    f"Shard id should be between 0 and {len(self.logical_output_sizes) - 1}. "
                    f"Got shard id {loaded_shard_id}."
                )
            logical_start = sum(self.logical_output_sizes[:loaded_shard_id])
            logical_size = self.logical_output_sizes[loaded_shard_id]
        logical_end = logical_start + logical_size
        output_dim = getattr(param, "output_dim", 0)
        is_scale = isinstance(param, BlockQuantScaleParameter) or param is getattr(
            self, "weight_scale_inv", None
        )
        block_n = getattr(self, "weight_block_size", [32, 32])[0] if is_scale else 1
        shard_start = logical_start // block_n
        shard_end = logical_end // block_n
        if loaded_weight.shape[output_dim] != shard_end - shard_start:
            raise ValueError(
                f"Expected shard {loaded_shard_id} output size "
                f"{shard_end - shard_start}, got {loaded_weight.shape[output_dim]}"
            )
        dst = param.data.narrow(output_dim, shard_start, shard_end - shard_start)
        copy_weight(dst, loaded_weight)
        if self.output_size > self.logical_output_size:
            self._init_pad_rows(param)
        self._refresh_views()

    weight_loader_v2 = weight_loader

    def forward(self, input_):
        from vllm.models.deepseek_v4_1.tilelang.linear import (
            TileLangFP8LinearMethod,
            _apply_block32,
        )

        rows = (
            input_.shape[0]
            if input_.ndim == 2
            else input_.numel() // self.input_size
        )
        use_shard = (
            self.tp_size > 1
            and self.gather_output
            and rows <= DECODE_ROWS
            and sp_prefill.current() is None
        )
        if use_shard:
            if isinstance(self.quant_method, TileLangFP8LinearMethod):
                local_out = _apply_block32(
                    self, input_, out_cols=self.part_output_size
                )
            else:
                local_out = self.quant_method.apply(self, input_)
            output = linear_layers.tensor_model_parallel_all_gather(local_out)[
                ..., : self.logical_output_size
            ]
        else:
            if isinstance(self.quant_method, TileLangFP8LinearMethod):
                output = _apply_block32(
                    self, input_, out_cols=self.logical_output_size
                )
            else:
                output = self.quant_method.apply(self, input_)[
                    ..., : self.logical_output_size
                ]
        return (output, None) if self.return_bias else output


class DeepseekV4Indexer(nn.Module):
    def __init__(self, config, prefix, *, owns_k, k_cache, ratio):
        super().__init__()
        hf = config.model_config.hf_config
        self.prefix, self.owns_k, self.k_cache = prefix, owns_k, k_cache
        # Replicating the small indexer avoids reducing a rows-by-context score
        # matrix across TP ranks. Every rank selects from all index heads.
        self.heads = hf.index_n_heads
        self.wq_b = ReplicatedLinear(
            hf.q_lora_rank,
            hf.index_n_heads * 128,
            bias=False,
            return_bias=False,
            quant_config=config.quant_config,
            prefix=f"{prefix}.wq_b",
        )
        _native_linear(self.wq_b)
        # Indexer Q-B reads the normalized q latent's MXFP8 cast alongside attention Q-B.
        self.wq_b.tilelang_mxfp8_input = True
        self.wq_b.tilelang_rope_mxfp4 = (128, hf.qk_rope_head_dim)
        self.weights_proj = ReplicatedLinear(
            hf.hidden_size,
            hf.index_n_heads,
            bias=False,
            return_bias=False,
            quant_config=None,
            prefix=f"{prefix}.weights_proj",
        )
        from vllm.models.deepseek_v4_1.tilelang.linear import (
            TileLangScaledLinearMethod,
        )

        # DeepSeek scales the head weights by (heads * head_dim) ** -0.5, a
        # power of two folded exactly into the projection.
        self.weights_proj.quant_method = TileLangScaledLinearMethod(
            (hf.index_n_heads * 128) ** -0.5
        )
        if owns_k:
            self.wk = ReplicatedLinear(
                512,
                128,
                bias=False,
                return_bias=False,
                quant_config=None,
                prefix=f"{prefix}.wk",
            )
            self.wk.quant_method = kernels.linear_method()
            self.k_norm = kernels.rms_norm(128, hf.rms_norm_eps)
            # _write_index_keys fuses k_norm with RoPE and MXFP4 quantization.
            self.k_norm.declare_kernels = lambda: None
        self.ratio = ratio


class DeepseekV4Attention(nn.Module, AttentionLayerBase):
    """The V4.1 attention layer: caches, metadata, projections and ownership. Its
    kernels are the TileLang layer's (``DeepseekV41TileLangAttention``), which
    defines ``_check_attention_rows``, ``_attention_scratch_specs``,
    ``_quantize_index_query``, ``_write_index_keys``, ``_index_chunk`` and
    ``_attend``."""

    backend_cls = DeepseekV41B12xBackend
    # Index scores need bounded row scratch; attention handles the whole batch.
    INDEX_CHUNK = 256
    DECODE_CHUNK = 64
    _l2pf_wo = None
    _l2pf_comp = None

    @classmethod
    def get_padded_num_q_heads(cls, num_heads):
        return num_heads

    def __init__(
        self,
        vllm_config,
        prefix,
        topk_indices_buffer=None,
        aux_stream_list=None,
    ):
        super().__init__()
        self.config = vllm_config
        hf = vllm_config.model_config.hf_config
        self.prefix = prefix
        layer_match = re.search(r"layers\.(\d+)", prefix)
        if layer_match is None:
            raise ValueError("V4.1 attention prefix must contain a layer index")
        self.layer_id = int(layer_match.group(1))
        self.hidden_size, self.head_dim = hf.hidden_size, hf.head_dim
        self.rope_head_dim = hf.qk_rope_head_dim
        tp = get_tensor_model_parallel_world_size()
        self.n_local_heads = hf.num_attention_heads // tp
        self.n_local_groups = hf.o_groups // tp
        self.n_groups, self.o_lora_rank = hf.o_groups, hf.o_lora_rank
        self.q_lora_rank, self.window_size = hf.q_lora_rank, hf.sliding_window
        spec = vllm_config.speculative_config
        self.is_draft = (
            self.layer_id >= hf.num_hidden_layers
            and spec is not None
            and spec.use_dspark()
        )
        boundary = ced_decoder_start(hf)
        self.is_ced_decoder = (
            not self.is_draft and boundary is not None and self.layer_id >= boundary
        )
        # With a CED decoder the drafter's context rows are its kept rows, so a
        # draft window starts at CED's replay start (bind_draft_replay_start).
        self._draft_replays = self.is_draft and boundary is not None
        self._draft_replay_start: torch.Tensor | None = None
        self.swa_width = self.window_size
        if self.is_draft:
            from vllm.v1.attention.backends.mla.compressor_utils import (
                get_dspark_swa_index_width,
            )

            self.swa_width = get_dspark_swa_index_width(
                self.window_size, spec.num_speculative_tokens
            )
        self.capacity = vllm_config.scheduler_config.max_num_batched_tokens
        self.max_model_len = vllm_config.model_config.max_model_len
        self.compress_ratio = (
            hf.compress_ratios[self.layer_id]
            if self.layer_id < len(hf.compress_ratios)
            else 0
        )
        self._main_page = vllm_config.cache_config.block_size // max(
            self.compress_ratio, 1
        )
        self._main_width = (
            self.max_model_len + vllm_config.cache_config.block_size - 1
        ) // vllm_config.cache_config.block_size
        self._index_page, self._index_width = self._main_page, self._main_width
        self.is_kv_source = self.layer_id in hf.kv_source_layer_ids
        self.is_index_source = self.layer_id in hf.index_source_layer_ids
        self.kv_source_layer_id = (
            max(s for s in hf.kv_source_layer_ids if s <= self.layer_id)
            if self.compress_ratio
            else None
        )
        self.index_source_layer_id = (
            max(s for s in hf.index_source_layer_ids if s <= self.layer_id)
            if self.compress_ratio
            else None
        )
        self.candidate_source_layer = hf.candidate_source_layer_id
        if (
            self.head_dim != 512
            or self.rope_head_dim != 64
            or self.compress_ratio not in (0, 1, 2)
        ):
            raise ValueError("unsupported V4.1 native attention geometry")
        if (
            vllm_config.parallel_config.decode_context_parallel_size != 1
            or vllm_config.parallel_config.prefill_context_parallel_size != 1
        ):
            raise ValueError(
                "V4.1 TP shards heads, not context; context parallel is unsupported"
            )
        self._context = vllm_config.compilation_config.static_forward_context
        if prefix in self._context:
            raise ValueError(f"Duplicate attention layer {prefix}")
        self._context[prefix] = self
        self.kv_cache = torch.tensor([])
        self.attn_sink = nn.Parameter(
            torch.full((self.n_local_heads,), -float("inf"), dtype=torch.float32),
            requires_grad=False,
        )
        self.fused_wqa_wkv = _PaddedMergedColumnParallelLinear(
            hf.hidden_size,
            [hf.q_lora_rank, 512],
            bias=False,
            gather_output=True,
            quant_config=vllm_config.quant_config,
            disable_tp=self.is_draft,
            prefix=f"{prefix}.fused_wqa_wkv",
        )
        self.q_norm = kernels.rms_norm(hf.q_lora_rank, hf.rms_norm_eps)
        self.kv_norm = kernels.rms_norm(512, hf.rms_norm_eps)
        self.wq_b = ColumnParallelLinear(
            hf.q_lora_rank,
            hf.num_attention_heads * 512,
            bias=False,
            return_bias=False,
            quant_config=vllm_config.quant_config,
            prefix=f"{prefix}.wq_b",
        )
        self.wo_a = ColumnParallelLinear(
            hf.num_attention_heads * 512 // hf.o_groups,
            hf.o_groups * hf.o_lora_rank,
            bias=False,
            return_bias=False,
            quant_config=vllm_config.quant_config,
            prefix=f"{prefix}.wo_a",
        )
        self.wo_a.is_bmm, self.wo_a.bmm_batch_size = True, self.n_local_groups
        self.wo_a.quant_method = _WOProjectionWeightMethod(self.wo_a.quant_method)
        self.wo_b = RowParallelLinear(
            hf.o_groups * hf.o_lora_rank,
            hf.hidden_size,
            bias=False,
            return_bias=False,
            quant_config=vllm_config.quant_config,
            prefix=f"{prefix}.wo_b",
            reduce_results=False,
        )
        self.wo_b.quant_method = _WOProjectionWeightMethod(self.wo_b.quant_method)
        if getattr(hf, "original_num_attention_heads", hf.num_attention_heads) != (
            hf.num_attention_heads
        ):
            for linear in (self.wq_b, self.wo_a, self.wo_b):
                for param in linear.parameters():
                    set_weight_attrs(param, {"allow_tp_padding": True})
        self._wo_projection_weights = None
        self._l2pf_wo = None
        self._l2pf_ffn = None
        self._l2pf_comp = None
        for linear in (self.fused_wqa_wkv, self.wq_b):
            _native_linear(linear)
        # Q-B reads its input's MXFP8 cast from the input's producer: the front's one
        # kernel at decode sizes (``_front``), TileKernels' cast otherwise.
        self.wq_b.tilelang_mxfp8_input = True
        self.rotary_emb = build_deepseek_v4_rope(
            hf,
            head_dim=512,
            rope_head_dim=64,
            max_position_embeddings=hf.max_position_embeddings,
            compress_ratio=self.compress_ratio,
        )
        self.swa_cache_layer = _Cache(
            vllm_config,
            f"{prefix}.swa_cache",
            kind="swa",
            window=self.window_size,
            draft=self.is_draft,
        )
        self.compressor = (
            DeepseekCompressor(
                vllm_config,
                self.compress_ratio,
                hf.hidden_size,
                512,
                prefix=f"{prefix}.compressor",
            )
            if self.is_kv_source
            else None
        )
        self.indexer = None
        if self.is_index_source:
            if self.is_kv_source:
                k_cache = _Cache(
                    vllm_config,
                    f"{prefix}.indexer.k_cache",
                    kind="index",
                    ratio=self.compress_ratio,
                )
            else:
                k_cache = self._context[
                    f"{_source(prefix, self.kv_source_layer_id)}.indexer.k_cache"
                ]
            self.indexer = DeepseekV4Indexer(
                vllm_config,
                f"{prefix}.indexer",
                owns_k=self.is_kv_source,
                k_cache=k_cache,
                ratio=self.compress_ratio,
            )
        self.topk_indices_buffer = topk_indices_buffer
        self._ready = False

    def get_attn_backend(self):
        return self.backend_cls

    def get_kv_cache_spec(self, config):
        if not self.is_kv_source:
            return None
        return MLAAttentionSpec(
            block_size=config.cache_config.block_size,
            num_kv_heads=1,
            head_size=512,
            state_content_bytes=288,
            dtype=torch.uint8,
            tokens_per_state=self.compress_ratio,
            cache_dtype_str="b12x_dsv41",
            alignment=None,
            uses_only_written_slots=True,
        )

    def bind_kv_cache(self, cache):
        self.kv_cache = cache.view(cache.shape[0], -1)

    def _owner(self):
        return self._context[_source(self.prefix, self.kv_source_layer_id)]

    def _attention_geometry(self) -> None:
        """The metadata arena of each attention mode and the staging this layer
        owns, from configuration alone."""
        # Page geometry stays as computed at construction, from the block size
        # the caches were allocated with. The engine later lowers
        # cache_config.block_size to its smallest prefix-cacheable group (the
        # SWA block); re-reading it here would plan half-size main pages
        # whenever the worker shares the engine's config (the uniproc executor).
        spec = self.config.speculative_config
        # Every request at or below the backend's reorder threshold is a decode
        # row, short prefills included, so the decode arena holds max_num_seqs of
        # the widest: two draft spans (parallel drafting's verifier profiling) or
        # a copying request's verification (copy drafts).
        query_width = (
            max(
                1 + (2 if spec.parallel_drafting else 1) * spec.num_speculative_tokens,
                1 + spec.num_verification_tokens,
            )
            if spec is not None
            else 1
        )
        decode_rows = self.config.scheduler_config.max_num_seqs * query_width
        # Graph buffers include padding beyond the live decode-token bound.
        decode_rows = max(
            decode_rows,
            self.config.compilation_config.max_cudagraph_capture_size or 0,
        )
        self._attention_workspace_specs = {}
        self._decode_capacity = min(self.capacity, decode_rows)
        for mode, capacity in (
            ("decode", self._decode_capacity),
            ("extend", self.capacity),
        ):
            metadata_specs: tuple[tuple[tuple[int, ...], torch.dtype], ...] = (
                ((capacity, self.swa_width), torch.int32),
                ((capacity,), torch.int32),
                ((capacity,), torch.int32),
            )
            if self.compress_ratio:
                metadata_specs += (((capacity, self._main_width), torch.int32),)
            self._attention_workspace_specs[mode] = metadata_specs
        if not hasattr(self, "_owns_topk_indices"):
            self._owns_topk_indices = (
                self.topk_indices_buffer is None and self.is_index_source
            )
        specs: list[tuple[str, tuple[int, ...], torch.dtype]] = []
        if self._owns_topk_indices:
            specs.append(("topk_indices_buffer", (self.capacity, 512), torch.int32))
        if self.indexer is not None:
            specs.extend(
                (
                    (
                        "_index_pages",
                        (self.INDEX_CHUNK, self._index_width),
                        torch.int32,
                    ),
                    ("_active", (1,), torch.int32),
                )
            )
            if self.layer_id == self.candidate_source_layer:
                specs.extend(
                    (
                        # The block ids the candidate source publishes, a row.
                        ("_candidates", (self.capacity, CANDIDATE_BLOCKS), torch.int32),
                        ("_candidate_lens", (self.capacity,), torch.int32),
                    )
                )
        self._short_index_shape = None
        if (
            self.indexer is not None
            and not self.is_ced_decoder
            and self.capacity > self.INDEX_CHUNK
            and self.layer_id < self.candidate_source_layer
        ):
            short_rows = min(1024, self.capacity)
            short_width = min(self._index_width, cdiv(16384, self._index_page))
            self._short_index_shape = (short_rows, short_width)
            specs.append(("_short_index_pages", self._short_index_shape, torch.int32))
        self._staging_specs = tuple(specs)

    def declare_kernels(self) -> None:
        """Declare every TileLang kernel this layer can launch, its WO projection's
        included (the worker calls this after loading, before any distributed
        work)."""
        from vllm.models.deepseek_v4_1.tilelang.linear import _warm_casts

        self._attention_geometry()
        calls = self._tilelang_calls()
        q_lora_rank = self.q_lora_rank
        # Q-B's input cast where the front's one kernel does not write it.
        prepare.declare(lambda: calls, warm=lambda: _warm_casts(q_lora_rank))
        declare_wo = getattr(self._wo_projection_weights, "declare_kernels", None)
        if declare_wo is not None:
            declare_wo()

    def _owned_caches(self) -> list:
        """The cache layers this layer allocates: one per KV-cache group it joins."""
        caches = [self.swa_cache_layer]
        if self.is_kv_source:
            caches.append(self)
        if self.indexer is not None and self.indexer.owns_k:
            caches.append(self.indexer.k_cache)
        if self.compressor is not None and self.compressor.state_cache is not None:
            caches.append(self.compressor.state_cache)
        return caches

    def _tilelang_calls(self) -> list:
        """The TileLang kernels of the shared layer paths, as ``prepare.call``s:
        window metadata and index page tables, the metadata builders of the cache
        groups this layer joins, the RoPE of every role and the cache writers, each
        in its call site's call form."""
        from vllm.models.deepseek_v4_1.tilelang import metadata as tl_metadata
        from vllm.models.deepseek_v4_1.tilelang.cache_writer import writer_call
        from vllm.models.deepseek_v4_1.tilelang.front import (
            context_kv_front_call,
            front_call,
        )
        from vllm.models.deepseek_v4_1.tilelang.rope import rope_call

        calls = []
        # _write_decode_metadata: the window metadata, with the main page table in
        # the same launch on compressed layers. A CED decoder's rows start no
        # earlier than their request's replay start when the step has one; a
        # drafter's beside a CED decoder always do.
        replays = (
            (True,)
            if self._draft_replays
            else (False, True)
            if self.is_ced_decoder
            else (False,)
        )
        for replay in replays:
            args = (
                self.swa_cache_layer.block_size,
                self.window_size,
                self.swa_width,
                self.is_draft,
                replay,
            )
            if self.compress_ratio:
                calls.append(
                    prepare.call(
                        tl_metadata.decode_metadata_kernel,
                        *args,
                        self._main_width,
                        self._main_page,
                    )
                )
            else:
                calls.append(prepare.call(tl_metadata.chunk_kernel, *args))
        # forward_mqa: the page tables of the index chunks, full or short.
        if self.indexer is not None:
            widths = {self._index_width}
            if self._short_index_shape is not None:
                widths.add(self._short_index_shape[1])
            calls.extend(
                prepare.call(tl_metadata.pages_kernel, width, self._index_page)
                for width in widths
            )
        # Each group's metadata builder: its spec as the KV-cache spec code makes
        # it, for the scheduler's requests.
        requests = self.config.scheduler_config.max_num_seqs
        for cache in self._owned_caches():
            calls.extend(
                tilelang_builder_kernels(cache.get_kv_cache_spec(self.config), requests)
            )
        # _rope (heads, columns, ratio) by role (WO's input is rotated back in the
        # attention kernels' output store).
        table_width = self.rotary_emb.cos_sin_cache.shape[1]
        roles = [(1, 512, 1, False)]  # kv
        if self.n_local_heads > 0:
            roles.insert(0, (self.n_local_heads, self.head_dim, 1, False))  # q
        calls.extend(
            rope_call(heads, dim, table_width, ratio, inverse)
            for heads, dim, ratio, inverse in roles
        )
        # _write_v41_cache: SWA records of every layer, indexed records of the
        # compressor's latents (rotated in registers), at the builders' (and
        # compressor's) slot dtype.
        calls.append(writer_call("swa", self.swa_cache_layer.block_size, SLOT_DTYPE))
        # _front: the decode front's one kernel.
        calls.append(
            front_call(
                self.q_norm.variance_epsilon,
                self.swa_cache_layer.block_size,
                SLOT_DTYPE,
            )
        )
        if self.is_draft:
            calls.append(
                context_kv_front_call(
                    self.kv_norm.variance_epsilon,
                    self.swa_cache_layer.block_size,
                    SLOT_DTYPE,
                )
            )
        if self.compressor is not None:
            calls.append(
                writer_call(
                    "indexed",
                    self._main_page,
                    SLOT_DTYPE,
                    rope_dim=table_width,
                    ratio=self.compress_ratio,
                )
            )
        else:
            # _gather_front: prefill SP's BF16 front, the index head weights beside
            # the normalized halves.
            from vllm.models.deepseek_v4_1.tilelang import columns

            widths = (self.q_lora_rank, 512)
            if self.indexer is not None:
                widths += (self.indexer.heads,)
                key = columns.copy_columns_key(self.indexer.heads, torch.bfloat16)
                calls.append(prepare.call(columns.copy_columns_kernel, *key))
            key = columns.split_columns_key(widths, torch.bfloat16)
            calls.append(prepare.call(columns.split_columns_kernel, *key))
        return calls

    def _prepare(self, device):
        """Materialize admitted integration-owned metadata, never launch choices."""
        if torch.cuda.is_current_stream_capturing():
            raise RuntimeError("V4.1 metadata must be prepared before graph capture")
        if not hasattr(self, "_staging_specs"):
            self._attention_geometry()
        for name, shape, dtype in self._staging_specs:
            tensor = getattr(self, name, None)
            if tensor is None or tuple(tensor.shape) != shape or tensor.dtype != dtype:
                setattr(self, name, torch.empty(shape, dtype=dtype, device=device))
        if self.indexer is not None:
            self._active.fill_(self._index_width * self._index_page)
        if torch.device(device).type == "cuda":
            aux_stream()
        self._ready = True

    def _rope(self, x, positions, role: str):
        """``x`` rotated at ``positions``, in place."""
        from vllm.models.deepseek_v4_1.tilelang.rope import rope_

        table = self.rotary_emb.cos_sin_cache
        compressed = role in ("index_key", "latent")
        rope_(x, positions, table, self.compress_ratio if compressed else 1, False)
        return x

    def _write_v41_cache(
        self, x, cache, slots, *, page_size, cache_kind, positions=None
    ):
        """Write ``x``'s V4.1 records (``cache_kind`` swa or indexed) at ``slots``."""
        from .tilelang.cache_writer import write_cache

        if positions is None:
            write_cache(x, cache, slots, page_size=page_size, cache_kind=cache_kind)
            return
        write_cache(
            x,
            cache,
            slots,
            page_size=page_size,
            cache_kind=cache_kind,
            positions=positions,
            cos_sin=self.rotary_emb.cos_sin_cache,
            ratio=self.compress_ratio if cache_kind == "indexed" else 1,
        )

    def insert_context_kv(self, kv, positions, slot_mapping):
        if not self._ready:
            raise RuntimeError("V4.1 attention metadata is not prepared")
        rotated = self._rope(kv, positions, "kv")
        self._write_v41_cache(
            rotated,
            self.swa_cache_layer.kv_cache,
            slot_mapping,
            page_size=self.swa_cache_layer.block_size,
            cache_kind="swa",
        )

    def insert_raw_context_kv(self, kv_raw, positions, slot_mapping):
        if not self._ready:
            raise RuntimeError("V4.1 attention metadata is not prepared")
        from vllm.models.deepseek_v4_1.tilelang.front import context_kv_front

        context_kv_front(
            kv_raw,
            self.kv_norm.weight,
            self.kv_norm.variance_epsilon,
            positions,
            self.rotary_emb.cos_sin_cache,
            self.swa_cache_layer.kv_cache,
            slot_mapping,
            self.swa_cache_layer.block_size,
        )

    def _query_metadata(self, metadata):
        if self.is_ced_decoder and metadata.decoder is not None:
            return metadata.decoder
        return metadata

    @eager_break_during_capture
    def _cache_context_kv(self, kv, positions):
        # Resolve live request metadata inside the eager segment. A captured
        # slot-mapping argument could refer to a previous request's cache pages.
        metadata = get_forward_context().attn_metadata
        swa = self._query_metadata(metadata[self.swa_cache_layer.prefix])
        self.insert_context_kv(kv, positions, swa.slot_mapping[: kv.shape[0]])

    def ced_sp_saves_bytes(self, sp_rows, replay_rows, hc_mult):
        """Keep the compact boundary only when its gathered payload is smaller.

        TP3's compressor already holds the full weight, so a new row gather must
        also earn back its cost. Aligned TP replaces an existing column gather.
        Include SP padding and every replicated compact slot in both estimates.
        """
        compressor = self.compressor
        if type(compressor) is not DeepseekCompressor or compressor.compress_ratio != 1:
            return False
        # Native carries: BF16 hidden/residual, FP32 pre/post/residual mixes.
        carry_bytes = 2 * self.hidden_size * (hc_mult + 1)
        carry_bytes += 4 * (hc_mult * hc_mult + 2 * hc_mult)
        latent_bytes = 512 * 2
        before = sp_rows.padded_rows * carry_bytes
        if compressor.fused_wkv_wgate.tp_size > 1:
            before += sp_rows.num_tokens * latent_bytes
        after = replay_rows * sp_rows.world_size * carry_bytes
        after += sp_rows.padded_rows * latent_bytes
        return after < before

    def prepare_global_kv(self, positions, hidden_states, *, sp_rows=None):
        """Build full-row global KV before the CED boundary gathers decoder rows."""
        if self.compressor is None or hidden_states.shape[0] == 0:
            return
        self._prepare_global_kv(positions, hidden_states, sp_rows=sp_rows)

    @eager_break_during_capture
    def _prepare_global_kv(self, positions, hidden_states, *, sp_rows=None):
        if not self._ready:
            raise RuntimeError("V4.1 attention metadata is not prepared")
        metadata = get_forward_context().attn_metadata
        if not isinstance(metadata, dict) or self.compressor is None:
            return
        indexer = self.indexer
        if indexer is None:
            raise RuntimeError("V4.1 global KV source requires an indexer")
        if sp_rows is not None and (
            type(self.compressor) is not DeepseekCompressor
            or self.compressor.compress_ratio != 1
        ):
            hidden_states = sp_rows.gather(hidden_states)
            sp_rows = None
        rows = hidden_states.shape[0] if sp_rows is None else sp_rows.num_tokens
        sp_kwargs = {} if sp_rows is None else {"sp_rows": sp_rows}
        # These are deliberately original metadata, never the decoder views.
        main = metadata[self._owner().prefix]
        state = (
            metadata[self.compressor.state_cache.prefix]
            if self.compressor.state_cache is not None
            else None
        )
        fuse_kv_write = DeepseekV4Attention._fuse_compressor_kv_write(self)
        if fuse_kv_write:
            latent, slots = self.compressor(
                hidden_states,
                main,
                state,
                kv_cache=self.kv_cache,
                token_positions=positions,
                cos_sin=self.rotary_emb.cos_sin_cache,
                kv_page_size=self._main_page,
                **sp_kwargs,
            )
        else:
            latent, slots = self.compressor(hidden_states, main, state, **sp_kwargs)
        DeepseekV4Attention._write_compressed_index_keys(
            self, positions, rows, metadata, latent, slots, fuse_kv_write
        )

    def _fuse_compressor_kv_write(self) -> bool:
        return (
            type(self.compressor) is DeepseekCompressor
            and "_write_v41_cache" not in self.__dict__
            and self.kv_cache.ndim == 2
            and self.kv_cache.dtype == torch.uint8
            and self.kv_cache.shape[1] >= self._main_page * 288
        )

    def _write_compressed_index_keys(
        self,
        positions,
        rows: int,
        metadata,
        latent: torch.Tensor,
        slots: torch.Tensor,
        fuse_kv_write: bool,
    ) -> None:
        indexer = self.indexer
        assert indexer is not None
        self._issue_wo_prefetch(rows, after="compressor")
        # Index K consumes the ordinary-normalized PRE-RoPE latent; norm, RoPE
        # and the paged MXFP4 write run in one kernel. At decode sizes, wk's
        # split-K FP32 partials are reduced in registers inside _write_index_keys.
        if (
            hasattr(indexer.wk, "tilelang_partials")
            and "_write_index_keys" not in self.__dict__
        ):
            from vllm.models.deepseek_v4_1.tilelang.linear import (
                project_bf16_partials,
            )

            key = project_bf16_partials(indexer.wk, latent)
        else:
            key = indexer.wk(latent)
        index_meta = cast(DeepseekV41B12xMetadata, metadata[indexer.k_cache.prefix])
        self._write_index_keys(key, index_meta.slot_mapping[:rows], positions=positions)
        if not fuse_kv_write:
            self._write_v41_cache(
                latent,
                self.kv_cache,
                slots,
                page_size=self._main_page,
                cache_kind="indexed",
                positions=positions,
            )

    @staticmethod
    def _layer_workspace_bytes(layer: nn.Module | None, rows: int) -> int:
        method = getattr(layer, "quant_method", None)
        fn = getattr(method, "get_workspace_size", None)
        return int(fn(layer, rows)) if callable(fn) else 0

    def _decode_overlap_workspace_specs(self, rows: int):
        if self.indexer is None:
            return ()
        main_bytes = (
            self._layer_workspace_bytes(self.indexer.wk, rows)
            if self.compressor is not None
            else self._layer_workspace_bytes(self.indexer.wq_b, rows)
        )
        aux_bytes = max(
            self._layer_workspace_bytes(self.indexer.weights_proj, rows),
            self._layer_workspace_bytes(self.indexer.wq_b, rows)
            if self.compressor is not None
            else 0,
        )
        return (
            ((max(256, main_bytes),), torch.uint8),
            ((max(256, aux_bytes),), torch.uint8),
        )

    def _can_overlap_decode(
        self, swa, sp_rows, front_wrote_kv: bool, rows: int
    ) -> bool:
        if (
            not getattr(swa, "is_decode", False)
            or sp_rows is not None
            or not front_wrote_kv
            or self.indexer is None
            or rows == 0
            or rows > self.DECODE_CHUNK
            or is_breakable_cudagraph_enabled()
            or not self.rotary_emb.cos_sin_cache.is_cuda
        ):
            return False
        if any(
            name in self.__dict__
            for name in (
                "_prepare_global_kv",
                "_index_query",
                "forward_mqa",
                "_rope",
                "_write_v41_cache",
                "_write_index_keys",
                "_quantize_index_query",
            )
        ):
            return False
        if self.compressor is not None and (
            type(self.compressor) is not DeepseekCompressor
            or "_forward_tilelang" in self.compressor.__dict__
            or "_project" in self.compressor.__dict__
        ):
            return False
        return aux_stream() is not None

    def _forward_decode_overlapped(
        self,
        q: torch.Tensor,
        qr: torch.Tensor,
        positions: torch.Tensor,
        hidden_states: torch.Tensor | None,
        index_weights: torch.Tensor | None,
        rows: int,
        metadata: dict[str, DeepseekV41B12xMetadata],
        swa: DeepseekV41B12xMetadata,
        original_swa: DeepseekV41B12xMetadata,
        q_cast,
    ):
        stream = aux_stream()
        assert stream is not None and self.indexer is not None
        main_stream = torch.cuda.current_stream(q.device)
        main_scratch, aux_scratch = current_workspace_manager().get_simultaneous(
            *self._decode_overlap_workspace_specs(rows)
        )
        retain_cuda_graph_capture_resource(main_scratch)
        for tensor in (
            qr,
            hidden_states,
            index_weights,
            getattr(q_cast, "values", None),
            getattr(q_cast, "scales", None),
        ):
            if isinstance(tensor, torch.Tensor):
                tensor.record_stream(stream)
        if (
            self.compressor is not None
            and swa is original_swa
            and hidden_states is not None
        ):
            if self.compressor._values is None:
                raise RuntimeError(
                    "compressor kernels must be bound before forwarding"
                )
            gathered = self.compressor._project_local(hidden_states)
            stream.wait_stream(main_stream)
            with (
                torch.cuda.stream(stream),
                use_preallocated_workspace(aux_scratch),
            ):
                query = self._index_query(
                    qr,
                    positions,
                    hidden_states,
                    index_weights,
                    0,
                    rows,
                    swa,
                    q_cast,
                )
            for tensor in query:
                tensor.record_stream(main_stream)
            main = metadata[self._owner().prefix]
            state = (
                metadata[self.compressor.state_cache.prefix]
                if self.compressor.state_cache is not None
                else None
            )
            fuse_kv_write = DeepseekV4Attention._fuse_compressor_kv_write(self)
            with use_preallocated_workspace(main_scratch):
                self.compressor._finish_project(gathered, rows)
                self.compressor._forward_tilelang(
                    rows,
                    main,
                    state,
                    kv_cache=self.kv_cache if fuse_kv_write else None,
                    token_positions=positions if fuse_kv_write else None,
                    cos_sin=self.rotary_emb.cos_sin_cache if fuse_kv_write else None,
                    kv_page_size=self._main_page if fuse_kv_write else None,
                )
                latent = self.compressor._latent[:rows]
                slots = self.compressor._slots[:rows]
                self._write_compressed_index_keys(
                    positions, rows, metadata, latent, slots, fuse_kv_write
                )
            del q_cast
            self._pending_decode_aux = stream
            return (*query, None, None)

        q.record_stream(stream)
        stream.wait_stream(main_stream)
        with (
            torch.cuda.stream(stream),
            use_preallocated_workspace(aux_scratch),
        ):
            if self.n_local_heads > 0:
                self._rope(q, positions, "q")
            weights = (
                index_weights[:rows]
                if index_weights is not None
                else self.indexer.weights_proj(hidden_states)[:rows]
            )
        weights.record_stream(main_stream)
        with use_preallocated_workspace(main_scratch):
            iq_data, iq_scale, _ = self._index_query(
                qr,
                positions,
                hidden_states,
                weights,
                0,
                rows,
                swa,
                q_cast,
            )
        del q_cast
        main_stream.wait_stream(stream)
        return (iq_data, iq_scale, weights, None, None)

    def forward(self, positions, hidden_states, llama_4_scaling=None):
        if hidden_states.shape[0] == 0:
            return torch.empty_like(hidden_states)
        return self._forward(positions, hidden_states)

    def _gather_front(self, sp_rows, hidden_states, qr, kv):
        """Sequence-parallel prefill's row-wise front of every row, as contiguous
        parts (normalized Q, normalized KV, the indexer's head weights, all BF16):
        one all-gather of this rank's rows side by side. The norms write their
        halves into the gather's buffer in place and the head weights are copied
        beside them."""
        from vllm.models.deepseek_v4_1.tilelang import columns

        q = self.q_lora_rank
        widths = (q, 512) + (() if self.indexer is None else (self.indexer.heads,))
        front = qr.new_empty(qr.shape[0], sum(widths))
        self.q_norm(qr, out=front[:, :q])
        self.kv_norm(kv, out=front[:, q : q + 512])
        if self.indexer is not None:
            weights = self.indexer.weights_proj(hidden_states)
            columns.copy_columns(weights, front[:, q + 512 :])
        return columns.split_columns(sp_rows.gather(front), widths)

    def _front(self, qr_kv, positions, sp_rows=None):
        """The front after the fused projection in one launch (``tilelang.front``):
        the normalized q latent and its MXFP8 cast, and the normalized kv latent
        rotated, with its SWA record written. None where the separate kernels run:
        memory profiling (no cache pages) and breakable graphs, which write the
        record from live metadata in an eager segment (``_cache_context_kv``)."""
        from vllm.models.deepseek_v4_1.tilelang.front import attention_front
        from vllm.models.deepseek_v4_1.tilelang.linear import empty_mxfp8

        rows = qr_kv.shape[0]
        if rows == 0 or is_breakable_cudagraph_enabled():
            return None
        metadata = get_forward_context().attn_metadata
        if not isinstance(metadata, dict):
            return None
        swa = self._query_metadata(metadata[self.swa_cache_layer.prefix])
        qr = torch.empty(
            (rows, self.q_lora_rank), dtype=qr_kv.dtype, device=qr_kv.device
        )
        kv = torch.empty((rows, 512), dtype=qr_kv.dtype, device=qr_kv.device)
        q_cast = empty_mxfp8(qr)
        attention_front(
            qr_kv,
            self.q_norm.weight,
            self.kv_norm.weight,
            self.q_norm.variance_epsilon,
            positions,
            self.rotary_emb.cos_sin_cache,
            self.swa_cache_layer.kv_cache,
            swa.slot_mapping[:rows],
            self.swa_cache_layer.block_size,
            qr,
            q_cast.values,
            q_cast.scales,
            kv,
        )
        return qr, kv, q_cast

    def _forward(self, positions, hidden_states):
        if not self._ready:
            raise RuntimeError("V4.1 attention metadata is not prepared")
        sp_rows = sp_prefill.current()
        index_weights = None
        front = None
        if sp_rows is not None and self.compressor is None:
            if getattr(self.fused_wqa_wkv, "tp_size", 1) == 1 or getattr(
                self.fused_wqa_wkv, "replicated_sp_prefill", False
            ):
                # Sequence-parallel prefill without a compressor when fused_wqa_wkv
                # is replicated: the row-wise front (projection, norms, index weights)
                # runs on this rank's rows, and its product is gathered.
                qr_kv, _ = self.fused_wqa_wkv(hidden_states)
                qr, kv = qr_kv.split((self.q_lora_rank, 512), dim=-1)
                del qr_kv
                parts = self._gather_front(sp_rows, hidden_states, qr, kv)
                qr, kv = parts[0], parts[1]
                if self.indexer is not None:
                    index_weights = parts[2]
                del parts
                hidden_states = None
                rows = sp_rows.num_tokens
            else:
                # Column-sharded fused_wqa_wkv: gather the local MXFP8 rows (and
                # local index head weights) in one grouped collective, run the
                # sharded projection across TP, and release the hidden state.
                local_q = kernels.try_provided_mxfp8(hidden_states)
                extra = (
                    (self.indexer.weights_proj(hidden_states),)
                    if self.indexer is not None
                    else ()
                )
                if local_q is not None:
                    gathered, *rest = sp_rows.gather_mxfp8(local_q, *extra)
                    hidden_states = gathered.rows
                elif extra:
                    hidden_states, *rest = sp_rows.gather_many(hidden_states, *extra)
                    gathered = kernels.cast_mxfp8(hidden_states)
                else:
                    hidden_states = sp_rows.gather(hidden_states)
                    gathered = kernels.cast_mxfp8(hidden_states)
                    rest = []
                if rest:
                    (index_weights,) = rest
                rows = hidden_states.shape[0]
                with kernels.mxfp8_inputs(gathered):
                    qr_kv, _ = self.fused_wqa_wkv(hidden_states)
                del gathered
                hidden_states = None
                qr, kv = qr_kv.split((self.q_lora_rank, 512), dim=-1)
                del qr_kv
                qr, kv = self.q_norm(qr), self.kv_norm(kv)
        else:
            gathered = None
            if sp_rows is not None:
                # Sequence-parallel prefill: attention runs on every row, and the
                # projection reads the gathered rows' MXFP8 cast.
                hidden_states = sp_rows.gather(hidden_states)
                gathered = kernels.cast_mxfp8(hidden_states)
            rows = hidden_states.shape[0]
            with kernels.mxfp8_inputs(gathered):
                qr_kv, _ = self.fused_wqa_wkv(hidden_states)
            del gathered
            front = self._front(qr_kv, positions)
            if front is None:
                qr, kv = qr_kv.split((self.q_lora_rank, 512), dim=-1)
                del qr_kv
                qr, kv = self.q_norm(qr), self.kv_norm(kv)
            else:
                del qr_kv
        if front is None:
            q_cast = (
                kernels.cast_mxfp8(qr)
                if self.n_local_heads > 0 or self.indexer is not None
                else None
            )
            front_wrote_kv = False
        else:
            qr, kv, q_cast = front
            front = None
            front_wrote_kv = True
        if self.n_local_heads > 0:
            with kernels.mxfp8_inputs(q_cast):
                q = self.wq_b(qr).view(rows, self.n_local_heads, 512)
        else:
            q = torch.empty((rows, 0, 512), dtype=qr.dtype, device=qr.device)
        if self.indexer is None:
            del q_cast
        self._issue_wo_prefetch(rows, after="q-b")
        metadata = cast(
            dict[str, DeepseekV41B12xMetadata] | None,
            get_forward_context().attn_metadata,
        )
        if not isinstance(metadata, dict):
            # Memory profiling has no cache pages; serving does not use this branch.
            if self.n_local_heads > 0:
                q = self._rope(q, positions, "q")
            q_cast = None
            del qr, kv, hidden_states, index_weights, q_cast
            output = torch.zeros_like(q)
            del q
        else:
            original_swa = metadata[self.swa_cache_layer.prefix]
            swa = self._query_metadata(original_swa)
            overlap_decode = self._can_overlap_decode(
                swa, sp_rows, front_wrote_kv, rows
            )
            if not overlap_decode and self.n_local_heads > 0:
                q = self._rope(q, positions, "q")
            if not front_wrote_kv:  # the front's kernel wrote the record
                self._cache_context_kv(kv, positions)
            if overlap_decode:
                index_query = self._forward_decode_overlapped(
                    q,
                    qr,
                    positions,
                    hidden_states,
                    index_weights,
                    rows,
                    metadata,
                    swa,
                    original_swa,
                    q_cast,
                )
                del q_cast, qr, hidden_states, index_weights
                output = torch.empty_like(q)
                self.forward_mqa(q, kv, positions, output, index_query=index_query)
                del q, kv, index_query
            else:
                if swa is original_swa and hidden_states is not None:
                    self._prepare_global_kv(positions, hidden_states)
                index_query = None
                if self.indexer is not None:
                    # Sequence-parallel prefill: the indexer is replicated, so each
                    # rank scores and selects only its own rows, and forward_mqa
                    # gathers the selected positions. Every row is independent.
                    split = (
                        sp_rows if sp_rows is not None and not swa.is_decode else None
                    )
                    first = split.start if split is not None else 0
                    last = first + split.real_rows if split is not None else rows
                    query = self._index_query(
                        qr,
                        positions,
                        hidden_states,
                        index_weights,
                        first,
                        last,
                        swa,
                        q_cast,
                    )
                    reference = None
                    if split is not None and _INDEX_SPLIT_CHECK:
                        reference = self._index_query(
                            qr,
                            positions,
                            hidden_states,
                            index_weights,
                            0,
                            rows,
                            swa,
                            q_cast,
                        )
                    del q_cast
                    index_query = (*query, split, reference)
                del qr, hidden_states, index_weights
                output = torch.empty_like(q)
                self.forward_mqa(q, kv, positions, output, index_query=index_query)
                del q, kv, index_query
        return self._o_proj(output, sp_rows=sp_rows)

    def _issue_wo_prefetch(self, rows, *, after):
        """Issue the WO window's L2 prefetch at its point in this layer's forward
        (``l2_prefetch``): after Q-B, or right after the compressor in a layer that
        owns one. There the compressor's projection between Q-B and WO-A would evict
        WO's lines; the COMP window, the compressor's own weight, takes WO's place
        after Q-B, and WO's fill queues behind it."""
        if after == ("q-b" if self.compressor is None else "compressor"):
            l2_prefetch.issue(self._l2pf_wo, rows)
        if after == "q-b":
            l2_prefetch.issue(self._l2pf_comp, rows)

    def _index_query(
        self,
        qr,
        positions,
        hidden_states,
        index_weights,
        first,
        last,
        swa,
        q_cast=None,
    ):
        """MXFP4 index queries and scaled head weights for rows [first, last)."""
        rows = last - first
        h = self.indexer.heads
        qr_rows = qr if (first == 0 and last == qr.shape[0]) else qr[first:last]
        cast_rows = (
            kernels.cast_mxfp8(qr_rows)
            if q_cast is None
            else kernels.slice_mxfp8(q_cast, first, last)
        )
        iq_data = torch.empty((rows, h, 64), dtype=torch.uint8, device=qr.device)
        iq_scale = torch.empty((rows, h, 4), dtype=torch.uint8, device=qr.device)
        pos_rows = positions[first:last]
        if (
            rows <= getattr(self.indexer.wq_b, "tilelang_decode_rows", 0)
            and hasattr(self.indexer.wq_b, "tilelang_decode_rope_mxfp4")
            and "_quantize_index_query" not in self.__dict__
        ):
            from vllm.models.deepseek_v4_1.tilelang.linear import (
                project_block32_rope_mxfp4_decode,
            )

            with kernels.mxfp8_inputs(cast_rows):
                project_block32_rope_mxfp4_decode(
                    self.indexer.wq_b,
                    qr_rows,
                    pos_rows,
                    self.rotary_emb.cos_sin_cache,
                    iq_data,
                    iq_scale,
                )
            del cast_rows, q_cast
        else:
            with kernels.mxfp8_inputs(cast_rows):
                iq = self.indexer.wq_b(qr_rows).view(rows, h, 128)
            del cast_rows, q_cast
            self._quantize_index_query(
                "decode" if swa.is_decode else "prefill",
                iq,
                iq_data,
                iq_scale,
                positions=pos_rows,
            )
            del iq
        # The BF16 head-weight projection runs on every row: its GEMV rounds
        # differently at another row count, which would move top-k selections.
        # The FP8 wq_b quantizes per row and does not depend on the row count.
        weights = (
            index_weights[first:last]
            if index_weights is not None
            else self.indexer.weights_proj(hidden_states)[first:last]
        )
        return iq_data, iq_scale, weights  # the projection applied the scale

    @staticmethod
    def _selection_spread(actual, expected):
        """Rows whose selected positions differ, and positions absent from `expected`.

        Unused slots (-1) are ignored; only real positions count.
        """
        actual = actual.sort(dim=-1).values
        expected = expected.sort(dim=-1).values
        where = torch.searchsorted(expected, actual).clamp_max(expected.shape[-1] - 1)
        missing = ((expected.gather(-1, where) != actual) & (actual >= 0)).sum(dim=-1)
        return (
            int((missing > 0).sum()),
            int(missing.sum()),
            int(missing.max()) if missing.numel() else 0,
        )

    def _check_index_split(
        self, split, selected, expected, repeat, expected_candidates
    ):
        """Compare this rank's split selection with the full-row indexer.

        The radix top-k keeps an arbitrary subset of the positions tied at its
        threshold, so two full-row runs can differ; `repeat` is a second run
        and measures that spread. The split passes when it differs from the
        first run no more than that, writes every row, and leaves the
        candidate lists unchanged.
        """
        real = split.real_rows
        rows = slice(split.start, split.start + real)
        actual = selected[:real]
        unwritten = int((actual == -2).any(dim=-1).sum())
        split_rows, split_positions, split_max = self._selection_spread(
            actual, expected
        )
        repeat_rows, repeat_positions, repeat_max = self._selection_spread(
            repeat, expected
        )
        bad_candidates = 0
        if expected_candidates is not None:
            candidates, lengths = expected_candidates
            bad_candidates = int(
                (
                    (self._candidates[rows] != candidates).any(dim=-1)
                    | (self._candidate_lens[rows] != lengths)
                ).sum()
            )
        log = logger.warning if unwritten or bad_candidates else logger.info
        log(
            "DeepSeek V4.1 indexer split check: layer %d rank %d rows %d-%d of %d: "
            "split vs full %d rows, %d positions (max %d); full vs full %d rows, "
            "%d positions (max %d); %d unwritten rows; %d candidate rows differ",
            self.layer_id,
            split.rank,
            rows.start,
            rows.stop,
            split.num_tokens,
            split_rows,
            split_positions,
            split_max,
            repeat_rows,
            repeat_positions,
            repeat_max,
            unwritten,
            bad_candidates,
        )

    @eager_break_during_capture
    def forward_mqa(self, q, kv, positions, output, *, index_query=None):
        pending_aux = self.__dict__.pop("_pending_decode_aux", None)
        metadata = get_forward_context().attn_metadata
        swa = self._query_metadata(metadata[self.swa_cache_layer.prefix])
        mode = "decode" if swa.is_decode else "extend"
        rows = q.shape[0]
        self._check_attention_rows(mode, rows)
        # A mixed step's decode requests, its leading rows (the batch is reordered
        # decode-first), keep the decode plan and the decode index mode: a row's
        # arithmetic must not depend on whether a prefill shares its step.
        decode_rows = 0
        if mode == "extend":
            decode_rows = min(getattr(swa, "num_decode_tokens", 0), rows)
            if decode_rows:
                self._check_attention_rows("decode", decode_rows)

        # Only the score matrix needs row chunking. All selected positions
        # survive in the source-owned buffer until their reuse interval ends.
        if self.indexer is not None:
            index_mode = "decode" if mode == "decode" else "prefill"
            *query, split, reference = index_query
            im = self._query_metadata(metadata[self.indexer.k_cache.prefix])
            lsa_enabled = os.environ.get("VLLM_DS41_LSA") == "1"
            score_width = None
            if (
                (mode == "extend" or lsa_enabled)
                and self.layer_id <= self.candidate_source_layer
                and not torch.cuda.is_current_stream_capturing()
            ):
                score_width = min(
                    self._index_width * self._index_page,
                    max(1, cdiv(im.max_seq_len, self.compress_ratio or 1)),
                )
            chunk_rows = self.DECODE_CHUNK if mode == "decode" else self.INDEX_CHUNK
            index_pages = self._index_pages
            decode_mode = "decode"
            decode_pages = self._index_pages
            if (
                score_width is not None
                and score_width <= 16384
                and self._short_index_shape is not None
            ):
                if mode == "extend" or (lsa_enabled and rows >= 2):
                    index_mode = "prefill_short"
                    chunk_rows = (
                        self.DECODE_CHUNK
                        if mode == "decode"
                        else self._short_index_shape[0]
                    )
                    index_pages = self._short_index_pages
                if lsa_enabled and decode_rows >= 2:
                    decode_mode = "prefill_short"
                    decode_pages = self._short_index_pages
            rest = (index_mode, chunk_rows, index_pages, score_width)
            decode = (
                decode_mode,
                self.DECODE_CHUNK,
                decode_pages,
                score_width if lsa_enabled else None,
            )

            def select(query, first, selected):
                # Decode requests' rows (global rows below decode_rows) take the
                # decode index mode, as in a step of decode requests alone.
                count = query[0].shape[0]
                cut = min(max(decode_rows - first, 0), count)
                if cut:
                    keep = (
                        cut == count
                        or rest[2] is not decode[2]
                        or first + count <= decode[2].shape[0]
                    )
                    select_rows(
                        [t[:cut] for t in query],
                        first,
                        selected[:cut],
                        decode,
                        keep=keep,
                    )
                if cut < count:
                    select_rows(
                        [t[cut:] for t in query],
                        first + cut,
                        selected[cut:],
                        rest,
                    )

            def select_rows(query, first, selected, params, keep=True):
                # Query rows start at global row `first`; metadata and
                # candidates are indexed by global row, `selected` by query row.
                index_mode, chunk_rows, index_pages, score_width = params
                index_width = index_pages.shape[1]
                iq_data, iq_scale, iw = query
                index_rows = iq_data.shape[0]
                buf = (
                    index_pages[first:]
                    if first and first + index_rows <= index_pages.shape[0]
                    else index_pages
                )
                for offset in range(0, index_rows, chunk_rows):
                    end = min(offset + chunk_rows, index_rows)
                    count = end - offset
                    row, row_end = first + offset, first + end
                    from vllm.models.deepseek_v4_1.tilelang import (
                        metadata as tl_metadata,
                    )

                    page_table = None
                    cacheable = split is None and index_rows <= chunk_rows
                    if cacheable:
                        key = (id(im), row, count, index_width, self._index_page)
                        shared = get_forward_context().__dict__.setdefault(
                            "_ds41_index_pages", {}
                        )
                        entry = shared.get(key)
                        if entry is not None and entry[0] is im:
                            page_table = entry[1]
                    if page_table is None:
                        tl_metadata.pages(
                            im.req_id_per_token,
                            im.cache_lengths,
                            im.block_table,
                            buf,
                            row,
                            count,
                            min(im.block_table.shape[1], index_width),
                            page=self._index_page,
                        )
                        page_table = buf[:count]
                        if cacheable and keep:
                            shared[key] = (im, page_table)
                    candidate_args = {}
                    if self.layer_id == self.candidate_source_layer:
                        candidate_args = dict(
                            candidate_output=self._candidates[row:row_end],
                            candidate_output_lengths=self._candidate_lens[row:row_end],
                        )
                    elif self.layer_id > self.candidate_source_layer:
                        source = self._context[
                            _source(self.prefix, self.candidate_source_layer)
                        ]
                        candidate_args = dict(
                            candidate_indices=source._candidates[row:row_end],
                            candidate_lengths=source._candidate_lens[row:row_end],
                        )
                    if pending_aux is not None:
                        main_stream = torch.cuda.current_stream(q.device)
                        main_stream.wait_stream(pending_aux)
                        main_meta = (
                            self._query_metadata(
                                metadata[self._owner().prefix]
                            )
                            if self.compress_ratio
                            else None
                        )
                        decode_specs = self._attention_workspace_specs["decode"]
                        q.record_stream(pending_aux)
                        with torch.cuda.stream(pending_aux):
                            if self.n_local_heads > 0:
                                self._rope(q, positions, "q")
                            if self.n_local_heads > 0 and not decode_rows:
                                meta_bufs = self._shared_decode_metadata(
                                    swa,
                                    main_meta,
                                    rows,
                                    decode_specs,
                                    q.device,
                                )
                            else:
                                meta_bufs = ()
                        for buf in meta_bufs:
                            buf.record_stream(main_stream)
                    self._index_chunk(
                        index_mode,
                        count,
                        q_mxfp4=iq_data[offset:end],
                        q_scales=iq_scale[offset:end],
                        query_weights=iw[offset:end],
                        page_table=page_table,
                        cache_lengths=im.cache_lengths[row:row_end],
                        score_width=score_width,
                        output_indices=selected[offset:end],
                        **candidate_args,
                    )

            if split is None:
                select(query, 0, self.topk_indices_buffer)
                if pending_aux is not None:
                    torch.cuda.current_stream(q.device).wait_stream(pending_aux)
                    pending_aux = None
            else:
                real = split.real_rows
                local = slice(split.start, split.start + real)
                selected = torch.empty(
                    (split.local_rows, 512), dtype=torch.int32, device=q.device
                )
                owns_candidates = self.layer_id == self.candidate_source_layer
                expected = repeat = expected_candidates = None
                if reference is not None:
                    # Sentinels make unwritten rows visible to the comparison.
                    self.topk_indices_buffer[:rows].fill_(-2)
                    if owns_candidates:
                        self._candidates[:rows].fill_(-2)
                        self._candidate_lens[:rows].fill_(-2)
                    select(reference, 0, self.topk_indices_buffer)
                    expected = self.topk_indices_buffer[local].clone()
                    if owns_candidates:
                        expected_candidates = (
                            self._candidates[local].clone(),
                            self._candidate_lens[local].clone(),
                        )
                    # A second full-row run measures the top-k's own spread.
                    repeat = torch.full(
                        (rows, 512), -2, dtype=torch.int32, device=q.device
                    )
                    select(reference, 0, repeat)
                    repeat = repeat[local]
                    selected.fill_(-2)
                    if owns_candidates:
                        self._candidates[local].fill_(-2)
                        self._candidate_lens[local].fill_(-2)
                select(query, split.start, selected)
                if reference is not None:
                    self._check_index_split(
                        split, selected, expected, repeat, expected_candidates
                    )
                self.topk_indices_buffer[:rows].copy_(split.gather(selected))

        if pending_aux is not None:
            torch.cuda.current_stream(q.device).wait_stream(pending_aux)
        if getattr(self, "n_local_heads", 1) == 0:
            return
        main = (
            self._query_metadata(metadata[self._owner().prefix])
            if self.compress_ratio
            else None
        )
        owner = (
            self._context[_source(self.prefix, self.index_source_layer_id)]
            if self.compress_ratio
            else self
        )
        if decode_rows:
            self._attend_split(
                q, output, positions, swa, main, owner, rows, decode_rows
            )
            return
        # Reuse the shared arena only after indexing completes. Keep full-batch
        # metadata beside, not overlapping, the native attention scratch.
        metadata_specs = self._attention_workspace_specs[mode]
        scratch_specs = self._attention_scratch_specs(mode, rows)
        # Layers sharing cache groups map identical pages, so the first layer of
        # each group keeps its metadata for the rest of the forward on decode and
        # decode-sized extend steps. Every replay rewrites it before use, so it
        # is an ordinary graph-pool activation: retaining it would pin one copy
        # per captured graph.
        if mode == "decode" or rows <= self._decode_capacity:
            shared_specs = (
                metadata_specs
                if mode == "decode"
                else tuple(
                    ((rows, *shape[1:]), dtype) for shape, dtype in metadata_specs
                )
            )
            metadata_buffers = self._shared_decode_metadata(
                swa, main, rows, shared_specs, q.device
            )
            arena = current_workspace_manager().get_simultaneous(*scratch_specs)
            scratch = list(arena)
        else:
            arena = current_workspace_manager().get_simultaneous(
                *metadata_specs, *scratch_specs
            )
            metadata_count = len(metadata_specs)
            self._write_decode_metadata(arena, swa, main, rows)
            metadata_buffers = arena[:metadata_count]
            scratch = arena[metadata_count:]
        swa_indices, swa_lengths, top_lengths = metadata_buffers[:3]
        kwargs = {}
        if main is not None:
            kwargs = dict(
                indexed_indices=owner.topk_indices_buffer[:rows],
                indexed_lengths=top_lengths[:rows],
                indexed_page_table=metadata_buffers[3][:rows],
            )
        # Keep the borrowed arena, not aliases of the transient query storage.
        retain_cuda_graph_capture_resource(arena)
        self._attend(
            mode,
            q,
            output,
            scratch=scratch,
            positions=positions,
            swa_indices=swa_indices[:rows],
            swa_lengths=swa_lengths[:rows],
            **kwargs,
        )

    def _shared_decode_metadata(self, swa, main, rows, specs, device):
        replay = self._replay_start(swa)
        key = (
            id(swa),
            id(main),
            id(replay),
            self.is_draft,
            self.is_ced_decoder,
            rows,
            specs,
        )
        context = get_forward_context()
        shared = context.__dict__.setdefault("_ds41_decode_metadata", {})
        entry = shared.get(key)
        if (
            entry is None
            or entry[0] is not swa
            or entry[1] is not main
            or entry[2] is not replay
        ):
            metadata_buffers = tuple(
                torch.empty(shape, dtype=dtype, device=device)
                for shape, dtype in specs
            )
            self._write_decode_metadata(metadata_buffers, swa, main, rows)
            entry = shared[key] = (swa, main, replay, metadata_buffers)
        return entry[3]

    def _attend_split(self, q, output, positions, swa, main, owner, rows, decode_rows):
        """A mixed step's attention: its decode requests' rows on the decode plan,
        the rest on the extend plan. Mixed steps run eagerly, so the per-row
        metadata is an ordinary allocation shared across contiguous layers of the
        same cache group and each plan borrows the workspace in turn (stream order
        keeps the second from overwriting the first's scratch while it runs)."""
        if torch.cuda.is_current_stream_capturing():
            raise RuntimeError("V4.1 mixed-step attention is never captured")
        extend_specs = tuple(
            ((rows, *shape[1:]), dtype)
            for shape, dtype in self._attention_workspace_specs["extend"]
        )
        replay = self._replay_start(swa)
        key = (
            id(swa),
            id(main),
            id(replay),
            self.is_draft,
            self.is_ced_decoder,
            rows,
            extend_specs,
        )
        context = get_forward_context()
        entry = context.__dict__.get("_ds41_split_metadata")
        if (
            entry is None
            or entry[0] != key
            or entry[1] is not swa
            or entry[2] is not main
            or entry[3] is not replay
        ):
            if entry is not None and entry[4] == extend_specs:
                metadata = entry[5]
            else:
                metadata = tuple(
                    torch.empty(shape, dtype=dtype, device=q.device)
                    for shape, dtype in extend_specs
                )
            self._write_decode_metadata(metadata, swa, main, rows)
            entry = context.__dict__["_ds41_split_metadata"] = (
                key,
                swa,
                main,
                replay,
                extend_specs,
                metadata,
            )
        metadata = entry[5]
        swa_indices, swa_lengths, top_lengths = metadata[:3]
        for mode, lo, hi in (("decode", 0, decode_rows), ("extend", decode_rows, rows)):
            if hi == lo:
                continue
            scratch = current_workspace_manager().get_simultaneous(
                *self._attention_scratch_specs(mode, hi - lo)
            )
            kwargs = {}
            if main is not None:
                kwargs = dict(
                    indexed_indices=owner.topk_indices_buffer[lo:hi],
                    indexed_lengths=top_lengths[lo:hi],
                    indexed_page_table=metadata[3][lo:hi],
                )
            self._attend(
                mode,
                q[lo:hi],
                output[lo:hi],
                scratch=list(scratch),
                positions=positions[lo:hi],
                swa_indices=swa_indices[lo:hi],
                swa_lengths=swa_lengths[lo:hi],
                **kwargs,
            )

    def bind_draft_replay_start(self, replay_start: torch.Tensor) -> None:
        """A drafter layer's window bound: CED's per-request replay start (the
        model state's persistent buffer, rewritten every step before the drafter
        runs). Before it, the request's draft window was never written: the
        decoder kept no rows there, or they precede a prefix hit."""
        assert self._draft_replays
        self._draft_replay_start = replay_start

    def _replay_start(self, swa):
        if self.is_ced_decoder:
            return swa.swa_replay_start
        if self._draft_replays:
            return self._draft_replay_start
        return None

    def _write_decode_metadata(self, buffers, swa, main, rows):
        from vllm.models.deepseek_v4_1.tilelang import metadata as tl_metadata

        swa_indices, swa_lengths, top_lengths = buffers[:3]
        visible = main.cache_lengths if main is not None else swa.cache_lengths
        window = dict(
            page=self.swa_cache_layer.block_size,
            window=self.window_size,
            draft=self.is_draft,
            replay_start=self._replay_start(swa),
        )
        common = (
            swa.positions,
            swa.req_id_per_token,
            swa.block_table,
            swa_indices,
            swa_lengths,
            top_lengths,
            visible,
            swa.query_start_loc,
            swa.request_positions,
        )
        if main is None:
            tl_metadata.chunk(*common, 0, rows, **window)
        else:
            # The window metadata and the main page table in one launch.
            tl_metadata.decode_metadata(
                *common,
                main.req_id_per_token,
                main.block_table,
                buffers[3],
                0,
                rows,
                main.block_table.shape[1],
                main_page=self._main_page,
                **window,
            )

    def _trim_padded_groups(self) -> None:
        """Drop trailing TP-padded output groups whose loaded weights are all zero."""
        hf = getattr(getattr(self.config, "model_config", None), "hf_config", None)
        orig_groups = getattr(hf, "original_o_groups", self.n_groups)
        if orig_groups >= self.n_groups:
            return
        tp_size = get_tensor_model_parallel_world_size()
        tp_rank = get_tensor_model_parallel_rank()
        padded_groups = self.n_groups // tp_size
        real_groups = max(0, min(orig_groups - tp_rank * padded_groups, padded_groups))
        groups = self.n_local_groups
        if groups > 0:
            self._heads_per_group = self.n_local_heads // groups
            self._padded_local_groups = groups
        if not 0 <= real_groups < groups:
            return
        heads_per_group = self._heads_per_group
        real_heads = real_groups * heads_per_group
        q_rows = real_heads * self.head_dim
        wo_rows = real_groups * self.o_lora_rank
        from vllm.models.deepseek_v4_1.tilelang.gemm import unpack_weight_tiles
        from vllm.models.deepseek_v4_1.tilelang.linear import _block32_scale_words

        if getattr(self.wq_b, "tilelang_weight_packed", False):
            w_q = unpack_weight_tiles(
                self.wq_b.tilelang_weight, *self.wq_b.weight.shape
            )
            self.wq_b.tilelang_weight_packed = False
        else:
            w_q = self.wq_b.weight
        self.wq_b.weight = nn.Parameter(w_q[:q_rows].contiguous(), requires_grad=False)
        self.wq_b.weight_scale_inv = nn.Parameter(
            self.wq_b.weight_scale_inv[: q_rows // 32].contiguous(),
            requires_grad=False,
        )
        self.wq_b.output_size_per_partition = q_rows
        if hasattr(self.wq_b, "tilelang_weight_sf"):
            _block32_scale_words(self.wq_b)

        self.attn_sink = nn.Parameter(
            self.attn_sink[:real_heads].contiguous(), requires_grad=False
        )
        self.wo_a.weight = nn.Parameter(
            self.wo_a.weight[:wo_rows].contiguous(), requires_grad=False
        )
        self.wo_a.weight_scale_inv = nn.Parameter(
            self.wo_a.weight_scale_inv[: wo_rows // 32].contiguous(),
            requires_grad=False,
        )
        self.wo_a.bmm_batch_size = real_groups
        self.wo_a.output_size_per_partition = wo_rows

        self.wo_b.weight = nn.Parameter(
            self.wo_b.weight[:, :wo_rows].contiguous(), requires_grad=False
        )
        self.wo_b.weight_scale_inv = nn.Parameter(
            self.wo_b.weight_scale_inv[:, : wo_rows // 32].contiguous(),
            requires_grad=False,
        )
        self.wo_b.input_size_per_partition = wo_rows

        self.n_local_groups = real_groups
        self.n_local_heads = real_heads

    def _sp_wo_rank_groups(self) -> tuple[int, ...]:
        """Trimmed WO group counts per TP rank on SP-capable attention layers."""
        tp_size = get_tensor_model_parallel_world_size()
        if (
            tp_size <= 1
            or getattr(self, "is_draft", False)
            or getattr(self, "is_ced_decoder", False)
        ):
            return ()
        n_groups = getattr(
            self,
            "n_groups",
            getattr(self, "_padded_local_groups", self.n_local_groups) * tp_size,
        )
        hf = getattr(getattr(self.config, "model_config", None), "hf_config", None)
        orig_groups = getattr(hf, "original_o_groups", n_groups)
        padded_groups = n_groups // tp_size
        if orig_groups >= n_groups:
            return (self.n_local_groups,) * tp_size
        return tuple(
            max(0, min(orig_groups - r * padded_groups, padded_groups))
            for r in range(tp_size)
        )

    def setup_wo_projection(self):
        self._trim_padded_groups()
        groups = self.n_local_groups
        heads_per_group = getattr(
            self,
            "_heads_per_group",
            self.n_local_heads // groups if groups else 8,
        )
        group_width = heads_per_group * self.head_dim
        rank = self.o_lora_rank
        hidden = self.hidden_size
        expected = (
            ("WO-A weight", self.wo_a.weight, (groups * rank, group_width)),
            (
                "WO-A scale",
                self.wo_a.weight_scale_inv,
                (groups * (rank // 32), group_width // 32),
            ),
            ("WO-B weight", self.wo_b.weight, (hidden, groups * rank)),
            (
                "WO-B scale",
                self.wo_b.weight_scale_inv,
                (hidden // 32, groups * rank // 32),
            ),
        )
        for name, tensor, shape in expected:
            if tuple(tensor.shape) != shape:
                raise RuntimeError(
                    f"V4.1 {name} shape mismatch: expected {shape}, "
                    f"got {tuple(tensor.shape)}"
                )
        from vllm.models.deepseek_v4_1.tilelang.wo import TileLangWOProjection

        # The checkpoint tensors in place, no packing.
        self.wo_a.o_lora_rank = rank
        self._wo_projection_weights = TileLangWOProjection(
            self.wo_a, self.wo_b, groups=groups
        )
        enable_sp = getattr(self._wo_projection_weights, "enable_sp", None)
        if enable_sp is not None:
            enable_sp(self._sp_wo_rank_groups())

    def _o_proj(self, o, sp_rows=None):
        """The TileLang WO projection of WO-A's input ``o``, which the attention
        kernels store already rotated back and through ``act_quant``.

        A sequence-parallel step on an encoder layer exchanges WO-A's native MXFP8
        ``o_lora`` output and projects each rank's WO-B shard on local rows into
        rank-order parts; layers without bound SP shards fall back to
        ``project_reduce_scatter``."""
        rows, hidden = o.shape[0], self.hidden_size
        if sp_rows is not None:
            if rows != sp_rows.num_tokens:
                raise ValueError(f"V4.1 SP WO expects {sp_rows.num_tokens} rows")
            then = lambda: l2_prefetch.issue(self._l2pf_ffn, rows)
            can_project_sp = getattr(
                self._wo_projection_weights, "can_project_sp", None
            )
            if can_project_sp is not None and can_project_sp(sp_rows):
                return self._wo_projection_weights.project_sp(
                    o, sp_rows, then=then
                )

            def project(start, stop, out):
                self._wo_projection_weights(o[start:stop], out)

            return sp_rows.project_reduce_scatter(
                project,
                (hidden,),
                torch.bfloat16,
                o.device,
                slices=sp_prefill.wo_slices(rows),
                then=then,
            )
        local = torch.empty((rows, hidden), dtype=torch.bfloat16, device=o.device)
        self._wo_projection_weights(o, local)
        l2_prefetch.issue(self._l2pf_ffn, rows)
        if get_tensor_model_parallel_world_size() > 1:
            local = get_tp_group().all_reduce(local)
        return local
